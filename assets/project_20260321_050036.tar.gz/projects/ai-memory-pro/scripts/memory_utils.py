"""
AI Memory Pro - 工具函数库
提供向量模型加载、数据结构定义、文件操作等基础功能
"""

import os
import json
import uuid
import time
import numpy as np
from typing import Dict, List, Optional, Any
from pathlib import Path

# 延迟导入 sentence_transformers（避免未安装时报错）
_embedding_model = None

def get_embedding_model():
    """获取或初始化向量模型（单例模式）"""
    global _embedding_model
    if _embedding_model is None:
        try:
            from sentence_transformers import SentenceTransformer
            model_name = os.getenv('MEMORY_EMBEDDING_MODEL', 'all-MiniLM-L6-v2')
            _embedding_model = SentenceTransformer(model_name)
        except ImportError:
            raise ImportError(
                "sentence-transformers 未安装，请执行：pip install sentence-transformers"
            )
    return _embedding_model

def embed_text(text: str) -> List[float]:
    """将文本转换为向量"""
    model = get_embedding_model()
    embedding = model.encode(text, convert_to_tensor=False)
    return embedding.tolist()

def embed_texts(texts: List[str]) -> np.ndarray:
    """批量向量化文本"""
    model = get_embedding_model()
    embeddings = model.encode(texts, convert_to_tensor=False)
    return embeddings

def cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """计算余弦相似度"""
    dot_product = np.dot(vec1, vec2)
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return dot_product / (norm1 * norm2)

def cosine_similarity_matrix(vecs1: np.ndarray, vecs2: np.ndarray) -> np.ndarray:
    """计算向量矩阵的余弦相似度"""
    # 归一化
    vecs1_norm = vecs1 / np.linalg.norm(vecs1, axis=1, keepdims=True)
    vecs2_norm = vecs2 / np.linalg.norm(vecs2, axis=1, keepdims=True)
    # 计算相似度矩阵
    return np.dot(vecs1_norm, vecs2_norm.T)

# ============== 数据结构定义 ==============

class MemoryEntry:
    """记忆条目数据结构"""
    
    def __init__(
        self,
        text: str,
        category: str = "other",
        memory_category: str = "entities",
        scope: str = "global",
        importance: float = 0.5,
        confidence: float = 0.8,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.id = str(uuid.uuid4())
        self.text = text
        self.category = category  # 存储类别
        self.memory_category = memory_category  # 语义类别
        self.scope = scope
        self.importance = max(0.0, min(1.0, importance))
        self.confidence = max(0.0, min(1.0, confidence))
        self.timestamp = int(time.time() * 1000)
        self.last_accessed = self.timestamp
        self.access_count = 0
        self.tier = "peripheral"  # peripheral, working, core
        self.vector = None
        self.metadata = metadata or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "text": self.text,
            "category": self.category,
            "memory_category": self.memory_category,
            "scope": self.scope,
            "importance": self.importance,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
            "last_accessed": self.last_accessed,
            "access_count": self.access_count,
            "tier": self.tier,
            "vector": self.vector,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MemoryEntry':
        """从字典创建"""
        entry = cls(
            text=data["text"],
            category=data.get("category", "other"),
            memory_category=data.get("memory_category", "entities"),
            scope=data.get("scope", "global"),
            importance=data.get("importance", 0.5),
            confidence=data.get("confidence", 0.8),
            metadata=data.get("metadata")
        )
        entry.id = data.get("id", str(uuid.uuid4()))
        entry.timestamp = data.get("timestamp", int(time.time() * 1000))
        entry.last_accessed = data.get("last_accessed", entry.timestamp)
        entry.access_count = data.get("access_count", 0)
        entry.tier = data.get("tier", "peripheral")
        entry.vector = data.get("vector")
        return entry

# ============== 文件操作 ==============

class MemoryStorage:
    """记忆存储管理器"""
    
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = Path(db_path or os.getenv('MEMORY_DB_PATH', './.memory-pro'))
        self.memories_file = self.db_path / "memories.json"
        self.vectors_file = self.db_path / "vectors.npy"
        self.metadata_file = self.db_path / "metadata.json"
        self.backup_dir = self.db_path / "backups"
        
        # 确保目录存在
        self.db_path.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(exist_ok=True)
    
    def load_memories(self) -> List[Dict[str, Any]]:
        """加载所有记忆"""
        if not self.memories_file.exists():
            return []
        
        with open(self.memories_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save_memories(self, memories: List[Dict[str, Any]]):
        """保存所有记忆"""
        with open(self.memories_file, 'w', encoding='utf-8') as f:
            json.dump(memories, f, ensure_ascii=False, indent=2)
    
    def load_vectors(self) -> Optional[np.ndarray]:
        """加载向量矩阵"""
        if not self.vectors_file.exists():
            return None
        return np.load(self.vectors_file)
    
    def save_vectors(self, vectors: np.ndarray):
        """保存向量矩阵"""
        np.save(self.vectors_file, vectors)
    
    def load_metadata(self) -> Dict[str, Any]:
        """加载元数据"""
        if not self.metadata_file.exists():
            return {
                "version": "1.0.0",
                "created_at": int(time.time() * 1000),
                "last_updated": int(time.time() * 1000),
                "total_count": 0
            }
        
        with open(self.metadata_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save_metadata(self, metadata: Dict[str, Any]):
        """保存元数据"""
        with open(self.metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
    
    def create_backup(self, prefix: str = "backup") -> str:
        """创建备份"""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        backup_file = self.backup_dir / f"{prefix}_{timestamp}.json"
        
        memories = self.load_memories()
        with open(backup_file, 'w', encoding='utf-8') as f:
            json.dump(memories, f, ensure_ascii=False, indent=2)
        
        return str(backup_file)
    
    def export_memories(
        self,
        output_path: str,
        scope: Optional[str] = None
    ) -> int:
        """导出记忆到文件"""
        memories = self.load_memories()
        
        if scope:
            memories = [m for m in memories if m.get("scope") == scope]
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(memories, f, ensure_ascii=False, indent=2)
        
        return len(memories)
    
    def import_memories(
        self,
        input_path: str,
        scope: Optional[str] = None,
        skip_duplicates: bool = True
    ) -> int:
        """从文件导入记忆"""
        with open(input_path, 'r', encoding='utf-8') as f:
            imported = json.load(f)
        
        existing = self.load_memories()
        existing_ids = {m["id"] for m in existing}
        existing_texts = {m["text"] for m in existing}
        
        new_memories = []
        for mem in imported:
            # 跳过重复 ID
            if skip_duplicates and mem["id"] in existing_ids:
                continue
            
            # 跳过重复内容
            if skip_duplicates and mem["text"] in existing_texts:
                continue
            
            # 覆盖作用域
            if scope:
                mem["scope"] = scope
            
            new_memories.append(mem)
        
        # 合并并保存
        all_memories = existing + new_memories
        self.save_memories(all_memories)
        
        return len(new_memories)

# ============== 配置管理 ==============

DEFAULT_CONFIG = {
    "embedding": {
        "model": "all-MiniLM-L6-v2",
        "dimensions": 384
    },
    "retrieval": {
        "mode": "hybrid",
        "vector_weight": 0.7,
        "bm25_weight": 0.3,
        "min_score": 0.3,
        "hard_min_score": 0.35,
        "candidate_pool_size": 20
    },
    "decay": {
        "recency_half_life_days": 30,
        "frequency_weight": 0.3,
        "intrinsic_weight": 0.3,
        "reinforcement_factor": 0.5,
        "max_half_life_multiplier": 3
    },
    "tiers": {
        "peripheral": {
            "half_life_days": 30,
            "beta": 1.3,
            "access_threshold": 3
        },
        "working": {
            "half_life_days": 60,
            "beta": 1.0,
            "access_threshold": 10
        },
        "core": {
            "half_life_days": 90,
            "beta": 0.8,
            "access_threshold": 999
        }
    }
}

def load_config() -> Dict[str, Any]:
    """加载配置"""
    return DEFAULT_CONFIG.copy()

# ============== 工具函数 ==============

def tokenize(text: str) -> List[str]:
    """简单的文本分词"""
    # 转小写
    text = text.lower()
    # 移除标点
    import re
    text = re.sub(r'[^\w\s\u4e00-\u9fff]', ' ', text)
    # 分词
    tokens = text.split()
    # 中文字符单独分词
    chinese_chars = re.findall(r'[\u4e00-\u9fff]', text)
    tokens.extend(chinese_chars)
    
    return tokens

def format_timestamp(timestamp_ms: int) -> str:
    """格式化时间戳"""
    import datetime
    dt = datetime.datetime.fromtimestamp(timestamp_ms / 1000)
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def calculate_age_days(timestamp_ms: int) -> float:
    """计算记忆年龄（天）"""
    current_ms = int(time.time() * 1000)
    age_ms = current_ms - timestamp_ms
    return age_ms / (1000 * 60 * 60 * 24)

if __name__ == "__main__":
    # 测试工具函数
    print("测试向量模型...")
    test_text = "这是一个测试文本"
    vector = embed_text(test_text)
    print(f"文本: {test_text}")
    print(f"向量维度: {len(vector)}")
    print(f"向量前5个值: {vector[:5]}")
    
    print("\n测试存储...")
    storage = MemoryStorage("./test_memory")
    print(f"存储路径: {storage.db_path}")
    print(f"元数据: {storage.load_metadata()}")
