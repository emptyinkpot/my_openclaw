"""
AI Memory Pro - 记忆检索模块
提供向量检索、BM25检索、混合检索功能
"""

import os
import sys
import json
import argparse
import time
import numpy as np
from typing import List, Dict, Any, Optional, Tuple

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_utils import (
    MemoryStorage,
    embed_text,
    tokenize,
    cosine_similarity_matrix,
    load_config,
    format_timestamp,
    calculate_age_days
)

# Weibull 衰减函数
def weibull_decay(age_days: float, half_life: float, beta: float) -> float:
    """
    计算 Weibull 衰减分数
    
    Args:
        age_days: 记忆年龄（天）
        half_life: 半衰期（天）
        beta: 形状参数
    
    Returns:
        衰减分数 (0-1)
    """
    if age_days <= 0:
        return 1.0
    
    # 从半衰期计算特征寿命
    lambda_scale = half_life / (np.log(2) ** (1/beta))
    
    # Weibull 衰减
    decay_score = np.exp(-((age_days / lambda_scale) ** beta))
    
    return decay_score

# BM25 实现
class BM25:
    """BM25 检索引擎"""
    
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1 = k1
        self.b = b
        self.doc_freqs = []
        self.doc_lens = []
        self.avgdl = 0
        self.doc_count = 0
        self.idf = {}
        self.doc_tokens = []
    
    def fit(self, documents: List[str]):
        """训练 BM25 模型"""
        self.doc_count = len(documents)
        self.doc_tokens = [tokenize(doc) for doc in documents]
        self.doc_lens = [len(tokens) for tokens in self.doc_tokens]
        self.avgdl = sum(self.doc_lens) / self.doc_count if self.doc_count > 0 else 0
        
        # 计算文档频率
        from collections import Counter
        df = Counter()
        for tokens in self.doc_tokens:
            df.update(set(tokens))
        
        # 计算 IDF
        for word, freq in df.items():
            self.idf[word] = np.log((self.doc_count - freq + 0.5) / (freq + 0.5) + 1)
    
    def get_scores(self, query: str) -> np.ndarray:
        """计算查询得分"""
        query_tokens = tokenize(query)
        scores = np.zeros(self.doc_count)
        
        for word in query_tokens:
            if word not in self.idf:
                continue
            
            idf = self.idf[word]
            
            for i, doc_tokens in enumerate(self.doc_tokens):
                if word not in doc_tokens:
                    continue
                
                # 词频
                tf = doc_tokens.count(word)
                dl = self.doc_lens[i]
                
                # BM25 公式
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (1 - self.b + self.b * dl / self.avgdl)
                scores[i] += idf * numerator / denominator
        
        return scores

class HybridRetriever:
    """混合检索引擎"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or load_config()
        self.storage = MemoryStorage()
        self.memories = []
        self.vectors = None
        self.bm25 = BM25()
        self.initialized = False
    
    def initialize(self):
        """初始化检索引擎"""
        if self.initialized:
            return
        
        # 加载记忆
        self.memories = self.storage.load_memories()
        
        if not self.memories:
            self.initialized = True
            return
        
        # 加载向量
        self.vectors = self.storage.load_vectors()
        
        # 训练 BM25
        texts = [m["text"] for m in self.memories]
        self.bm25.fit(texts)
        
        self.initialized = True
    
    def calculate_composite_score(
        self,
        memory: Dict[str, Any],
        base_score: float
    ) -> float:
        """
        计算综合评分（含衰减增强）
        
        Args:
            memory: 记忆对象
            base_score: 基础检索分数
        
        Returns:
            综合评分
        """
        config = self.config
        
        # 计算年龄
        age_days = calculate_age_days(memory["timestamp"])
        
        # 获取层级配置
        tier = memory.get("tier", "peripheral")
        tier_config = config["tiers"][tier]
        
        # Weibull 衰减
        recency_score = weibull_decay(
            age_days,
            tier_config["half_life_days"],
            tier_config["beta"]
        )
        
        # 访问强化
        access_count = memory.get("access_count", 0)
        reinforcement = 1 + config["decay"]["reinforcement_factor"] * np.log(access_count + 1)
        effective_half_life = min(
            tier_config["half_life_days"] * reinforcement,
            tier_config["half_life_days"] * config["decay"]["max_half_life_multiplier"]
        )
        
        # 重新计算带强化的衰减
        reinforced_score = weibull_decay(
            age_days,
            effective_half_life,
            tier_config["beta"]
        )
        
        # 综合评分
        frequency_norm = min(access_count / 10, 1.0)
        intrinsic_value = memory.get("importance", 0.5) * memory.get("confidence", 0.8)
        
        composite = (
            reinforced_score * (1 - config["decay"]["frequency_weight"] - config["decay"]["intrinsic_weight"]) +
            frequency_norm * config["decay"]["frequency_weight"] +
            intrinsic_value * config["decay"]["intrinsic_weight"]
        )
        
        # 应用衰减增强到检索分数
        final_score = base_score * (0.7 + 0.3 * composite)
        
        return final_score
    
    def retrieve(
        self,
        query: str,
        scope: Optional[str] = None,
        limit: int = 10,
        mode: str = "hybrid",
        min_score: Optional[float] = None
    ) -> List[Dict[str, Any]]:
        """
        检索记忆
        
        Args:
            query: 查询文本
            scope: 作用域过滤
            limit: 返回数量
            mode: 检索模式 (vector/bm25/hybrid)
            min_score: 最低分数阈值
        
        Returns:
            检索结果列表
        """
        self.initialize()
        
        if not self.memories:
            return []
        
        # 作用域过滤
        if scope:
            filtered_indices = [
                i for i, m in enumerate(self.memories)
                if m.get("scope") == scope or m.get("scope") == "global"
            ]
        else:
            filtered_indices = list(range(len(self.memories)))
        
        if not filtered_indices:
            return []
        
        min_score = min_score or self.config["retrieval"]["min_score"]
        
        # 向量检索
        vector_scores = np.zeros(len(self.memories))
        if mode in ["vector", "hybrid"] and self.vectors is not None:
            query_vector = np.array(embed_text(query))
            similarities = cosine_similarity_matrix(
                query_vector.reshape(1, -1),
                self.vectors
            )[0]
            vector_scores = similarities
        
        # BM25 检索
        bm25_scores = np.zeros(len(self.memories))
        if mode in ["bm25", "hybrid"]:
            bm25_scores = self.bm25.get_scores(query)
            # 归一化到 0-1
            if bm25_scores.max() > 0:
                bm25_scores = bm25_scores / bm25_scores.max()
        
        # 混合融合
        if mode == "hybrid":
            vector_weight = self.config["retrieval"]["vector_weight"]
            bm25_weight = self.config["retrieval"]["bm25_weight"]
            final_scores = vector_weight * vector_scores + bm25_weight * bm25_scores
        elif mode == "vector":
            final_scores = vector_scores
        else:
            final_scores = bm25_scores
        
        # 应用综合评分
        for i in filtered_indices:
            final_scores[i] = self.calculate_composite_score(
                self.memories[i],
                final_scores[i]
            )
        
        # 排序
        scored_results = [
            (i, final_scores[i])
            for i in filtered_indices
            if final_scores[i] >= min_score
        ]
        scored_results.sort(key=lambda x: x[1], reverse=True)
        
        # 返回结果
        results = []
        for idx, score in scored_results[:limit]:
            memory = self.memories[idx].copy()
            memory["retrieval_score"] = float(score)
            
            # 隐藏向量（减少输出体积）
            if "vector" in memory:
                del memory["vector"]
            
            results.append(memory)
            
            # 更新访问统计
            self.memories[idx]["access_count"] = self.memories[idx].get("access_count", 0) + 1
            self.memories[idx]["last_accessed"] = int(time.time() * 1000)
        
        # 保存更新后的访问统计
        self.storage.save_memories(self.memories)
        
        return results

def retrieve_memories(
    query: str,
    scope: Optional[str] = None,
    limit: int = 10,
    mode: str = "hybrid",
    min_score: Optional[float] = None
) -> Dict[str, Any]:
    """
    检索记忆（便捷函数）
    
    Args:
        query: 查询文本
        scope: 作用域
        limit: 数量限制
        mode: 检索模式
        min_score: 最低分数
    
    Returns:
        检索结果
    """
    retriever = HybridRetriever()
    results = retriever.retrieve(query, scope, limit, mode, min_score)
    
    return {
        "status": "success",
        "query": query,
        "scope": scope,
        "mode": mode,
        "count": len(results),
        "results": results
    }

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="AI Memory Pro - 记忆检索工具")
    
    parser.add_argument("--query", type=str, required=True, help="查询内容")
    parser.add_argument("--scope", type=str, help="作用域过滤")
    parser.add_argument("--limit", type=int, default=10, help="返回数量")
    parser.add_argument("--mode", type=str, default="hybrid", choices=["vector", "bm25", "hybrid"], help="检索模式")
    parser.add_argument("--min-score", type=float, help="最低分数阈值")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    
    args = parser.parse_args()
    
    result = retrieve_memories(
        query=args.query,
        scope=args.scope,
        limit=args.limit,
        mode=args.mode,
        min_score=args.min_score
    )
    
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"查询: {args.query}")
        print(f"模式: {args.mode}")
        print(f"作用域: {args.scope or '全部'}")
        print(f"结果数: {result['count']}")
        print("\n" + "="*60)
        
        for i, mem in enumerate(result["results"], 1):
            print(f"\n[{i}] 评分: {mem['retrieval_score']:.4f}")
            print(f"内容: {mem['text']}")
            print(f"类别: {mem.get('memory_category', 'N/A')} | 作用域: {mem.get('scope', 'N/A')}")
            print(f"层级: {mem.get('tier', 'N/A')} | 访问次数: {mem.get('access_count', 0)}")
            print(f"时间: {format_timestamp(mem['timestamp'])}")

if __name__ == "__main__":
    main()
