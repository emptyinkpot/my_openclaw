"""
AI Memory Pro - 衰减管理模块
提供记忆生命周期管理、衰减计算、层级晋升功能
"""

import os
import sys
import json
import argparse
import time
import numpy as np
from typing import List, Dict, Any, Optional

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_utils import (
    MemoryStorage,
    load_config,
    format_timestamp,
    calculate_age_days
)

# 导入衰减函数
from memory_retrieve import weibull_decay

class DecayManager:
    """衰减管理器"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or load_config()
        self.storage = MemoryStorage()
    
    def update_tier(self, memory: Dict[str, Any]) -> str:
        """
        更新记忆层级
        
        Args:
            memory: 记忆对象
        
        Returns:
            新层级
        """
        access_count = memory.get("access_count", 0)
        current_tier = memory.get("tier", "peripheral")
        
        # 晋升规则
        if access_count >= 10:
            new_tier = "core"
        elif access_count >= 3:
            new_tier = "working"
        else:
            new_tier = "peripheral"
        
        # 降级检查
        age_days = calculate_age_days(memory["timestamp"])
        
        if current_tier == "core" and access_count < 10 and age_days > 180:
            new_tier = "working"
        elif current_tier == "working" and access_count < 3 and age_days > 90:
            new_tier = "peripheral"
        
        memory["tier"] = new_tier
        return new_tier
    
    def calculate_decay_scores(self) -> List[Dict[str, Any]]:
        """
        计算所有记忆的衰减分数
        
        Returns:
            衰减分数列表
        """
        memories = self.storage.load_memories()
        scores = []
        
        for memory in memories:
            age_days = calculate_age_days(memory["timestamp"])
            tier = memory.get("tier", "peripheral")
            tier_config = self.config["tiers"][tier]
            
            # 基础衰减
            decay_score = weibull_decay(
                age_days,
                tier_config["half_life_days"],
                tier_config["beta"]
            )
            
            # 访问强化
            access_count = memory.get("access_count", 0)
            reinforcement = 1 + self.config["decay"]["reinforcement_factor"] * np.log(access_count + 1)
            effective_half_life = min(
                tier_config["half_life_days"] * reinforcement,
                tier_config["half_life_days"] * self.config["decay"]["max_half_life_multiplier"]
            )
            
            reinforced_score = weibull_decay(
                age_days,
                effective_half_life,
                tier_config["beta"]
            )
            
            scores.append({
                "id": memory["id"],
                "text": memory["text"][:50] + "..." if len(memory["text"]) > 50 else memory["text"],
                "tier": tier,
                "age_days": round(age_days, 1),
                "decay_score": round(decay_score, 4),
                "reinforced_score": round(reinforced_score, 4),
                "access_count": access_count
            })
        
        return scores
    
    def update_all_tiers(self) -> int:
        """
        更新所有记忆的层级
        
        Returns:
            更新数量
        """
        memories = self.storage.load_memories()
        updated = 0
        
        for memory in memories:
            old_tier = memory.get("tier", "peripheral")
            new_tier = self.update_tier(memory)
            
            if old_tier != new_tier:
                updated += 1
        
        self.storage.save_memories(memories)
        return updated
    
    def cleanup_memories(
        self,
        threshold: float = 0.1,
        scope: Optional[str] = None,
        dry_run: bool = True
    ) -> Dict[str, Any]:
        """
        清理低分记忆
        
        Args:
            threshold: 清理阈值
            scope: 作用域过滤
            dry_run: 是否仅预览
        
        Returns:
            清理结果
        """
        memories = self.storage.load_memories()
        to_delete = []
        
        for memory in memories:
            # 作用域过滤
            if scope and memory.get("scope") != scope:
                continue
            
            # 计算衰减分数
            age_days = calculate_age_days(memory["timestamp"])
            tier = memory.get("tier", "peripheral")
            tier_config = self.config["tiers"][tier]
            
            decay_score = weibull_decay(
                age_days,
                tier_config["half_life_days"],
                tier_config["beta"]
            )
            
            # 低于阈值且不是核心记忆
            if decay_score < threshold and tier != "core":
                to_delete.append({
                    "id": memory["id"],
                    "text": memory["text"][:50],
                    "decay_score": decay_score
                })
        
        # 执行删除
        if not dry_run and to_delete:
            delete_ids = {m["id"] for m in to_delete}
            memories = [m for m in memories if m["id"] not in delete_ids]
            self.storage.save_memories(memories)
            
            # 更新向量
            vectors = self.storage.load_vectors()
            if vectors is not None:
                # 简单重建向量矩阵
                from memory_utils import embed_texts
                remaining_texts = [m["text"] for m in memories]
                if remaining_texts:
                    new_vectors = embed_texts(remaining_texts)
                    self.storage.save_vectors(new_vectors)
        
        return {
            "dry_run": dry_run,
            "threshold": threshold,
            "scope": scope,
            "count": len(to_delete),
            "memories": to_delete[:10]  # 只显示前10条
        }
    
    def get_stats(self, scope: Optional[str] = None) -> Dict[str, Any]:
        """
        获取记忆统计
        
        Args:
            scope: 作用域过滤
        
        Returns:
            统计信息
        """
        memories = self.storage.load_memories()
        
        # 作用域过滤
        if scope:
            memories = [m for m in memories if m.get("scope") == scope]
        
        if not memories:
            return {
                "total": 0,
                "scope": scope
            }
        
        # 统计
        tier_dist = {"peripheral": 0, "working": 0, "core": 0}
        category_dist = {}
        scope_dist = {}
        
        for mem in memories:
            tier = mem.get("tier", "peripheral")
            tier_dist[tier] = tier_dist.get(tier, 0) + 1
            
            cat = mem.get("memory_category", "entities")
            category_dist[cat] = category_dist.get(cat, 0) + 1
            
            sc = mem.get("scope", "global")
            scope_dist[sc] = scope_dist.get(sc, 0) + 1
        
        # 平均分数
        scores = self.calculate_decay_scores()
        avg_score = np.mean([s["reinforced_score"] for s in scores]) if scores else 0
        
        return {
            "total": len(memories),
            "scope": scope,
            "tier_distribution": tier_dist,
            "category_distribution": category_dist,
            "scope_distribution": scope_dist,
            "average_decay_score": round(avg_score, 4),
            "oldest_memory_days": max([calculate_age_days(m["timestamp"]) for m in memories]),
            "newest_memory_days": min([calculate_age_days(m["timestamp"]) for m in memories])
        }
    
    def get_tier_report(self) -> Dict[str, Any]:
        """
        获取层级报告
        
        Returns:
            层级报告
        """
        memories = self.storage.load_memories()
        
        report = {
            "peripheral": {"count": 0, "samples": []},
            "working": {"count": 0, "samples": []},
            "core": {"count": 0, "samples": []}
        }
        
        for mem in memories:
            tier = mem.get("tier", "peripheral")
            report[tier]["count"] += 1
            
            if len(report[tier]["samples"]) < 3:
                report[tier]["samples"].append({
                    "text": mem["text"][:80],
                    "access_count": mem.get("access_count", 0),
                    "age_days": round(calculate_age_days(mem["timestamp"]), 1)
                })
        
        return report

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="AI Memory Pro - 衰减管理工具")
    
    parser.add_argument(
        "--action",
        type=str,
        required=True,
        choices=["stats", "tiers", "update", "cleanup", "scores"],
        help="操作类型"
    )
    parser.add_argument("--scope", type=str, help="作用域过滤")
    parser.add_argument("--threshold", type=float, default=0.1, help="清理阈值")
    parser.add_argument("--dry-run", action="store_true", help="仅预览不执行")
    parser.add_argument("--limit", type=int, default=20, help="返回数量限制")
    
    args = parser.parse_args()
    
    manager = DecayManager()
    
    if args.action == "stats":
        result = manager.get_stats(args.scope)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "tiers":
        result = manager.get_tier_report()
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "update":
        count = manager.update_all_tiers()
        print(json.dumps({
            "status": "success",
            "message": f"更新了 {count} 条记忆的层级"
        }, ensure_ascii=False, indent=2))
    
    elif args.action == "cleanup":
        result = manager.cleanup_memories(
            threshold=args.threshold,
            scope=args.scope,
            dry_run=args.dry_run
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif args.action == "scores":
        scores = manager.calculate_decay_scores()
        scores = scores[:args.limit]
        print(json.dumps({
            "count": len(scores),
            "scores": scores
        }, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
