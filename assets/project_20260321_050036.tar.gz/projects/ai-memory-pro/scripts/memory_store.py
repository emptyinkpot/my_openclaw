"""
AI Memory Pro - 记忆存储模块
提供记忆存储、更新、导入导出等功能
"""

import os
import sys
import json
import argparse
import time
import numpy as np
from typing import List, Dict, Any, Optional

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from memory_utils import (
    MemoryEntry,
    MemoryStorage,
    embed_text,
    embed_texts,
    cosine_similarity,
    load_config,
    format_timestamp
)

def check_duplicate(
    text: str,
    storage: MemoryStorage,
    threshold: float = 0.85
) -> Optional[str]:
    """
    检查是否存在重复记忆
    
    Args:
        text: 待检查的文本
        storage: 存储管理器
        threshold: 相似度阈值
    
    Returns:
        重复记忆的 ID，如果无重复返回 None
    """
    memories = storage.load_memories()
    
    if not memories:
        return None
    
    # 计算新文本向量
    new_vector = np.array(embed_text(text))
    
    # 加载现有向量
    vectors = storage.load_vectors()
    if vectors is None or len(vectors) == 0:
        return None
    
    # 计算相似度
    from memory_utils import cosine_similarity_matrix
    similarities = cosine_similarity_matrix(
        new_vector.reshape(1, -1),
        vectors
    )[0]
    
    # 找到最高相似度
    max_idx = np.argmax(similarities)
    max_sim = similarities[max_idx]
    
    if max_sim >= threshold:
        return memories[max_idx]["id"]
    
    return None

def store_memory(
    text: str,
    category: str = "other",
    memory_category: str = "entities",
    scope: str = "global",
    importance: float = 0.5,
    confidence: float = 0.8,
    metadata: Optional[Dict[str, Any]] = None,
    check_dup: bool = True,
    dup_threshold: float = 0.85
) -> Dict[str, Any]:
    """
    存储新记忆
    
    Args:
        text: 记忆内容
        category: 存储类别
        memory_category: 语义类别
        scope: 作用域
        importance: 重要性
        confidence: 置信度
        metadata: 元数据
        check_dup: 是否检查重复
        dup_threshold: 重复阈值
    
    Returns:
        存储结果
    """
    storage = MemoryStorage()
    
    # 检查重复
    if check_dup:
        dup_id = check_duplicate(text, storage, dup_threshold)
        if dup_id:
            return {
                "status": "duplicate",
                "message": f"检测到相似记忆（ID: {dup_id}），跳过存储",
                "duplicate_id": dup_id
            }
    
    # 创建记忆条目
    entry = MemoryEntry(
        text=text,
        category=category,
        memory_category=memory_category,
        scope=scope,
        importance=importance,
        confidence=confidence,
        metadata=metadata
    )
    
    # 计算向量
    entry.vector = embed_text(text)
    
    # 加载现有记忆
    memories = storage.load_memories()
    
    # 添加新记忆
    memories.append(entry.to_dict())
    
    # 更新向量矩阵
    vectors = storage.load_vectors()
    new_vector = np.array([entry.vector])
    
    if vectors is None or len(vectors) == 0:
        vectors = new_vector
    else:
        vectors = np.vstack([vectors, new_vector])
    
    # 保存
    storage.save_memories(memories)
    storage.save_vectors(vectors)
    
    # 更新元数据
    meta = storage.load_metadata()
    meta["last_updated"] = int(time.time() * 1000)
    meta["total_count"] = len(memories)
    storage.save_metadata(meta)
    
    return {
        "status": "success",
        "message": "记忆存储成功",
        "memory_id": entry.id,
        "timestamp": format_timestamp(entry.timestamp)
    }

def update_memory(
    memory_id: str,
    updates: Dict[str, Any]
) -> Dict[str, Any]:
    """
    更新记忆
    
    Args:
        memory_id: 记忆 ID
        updates: 更新内容
    
    Returns:
        更新结果
    """
    storage = MemoryStorage()
    memories = storage.load_memories()
    
    # 查找记忆
    for i, mem in enumerate(memories):
        if mem["id"] == memory_id:
            # 更新字段
            for key, value in updates.items():
                if key in mem and key != "id":
                    mem[key] = value
            
            # 如果更新了文本，重新计算向量
            if "text" in updates:
                mem["vector"] = embed_text(updates["text"])
            
            memories[i] = mem
            storage.save_memories(memories)
            
            # 更新向量矩阵
            if "text" in updates:
                vectors = storage.load_vectors()
                vectors[i] = np.array(mem["vector"])
                storage.save_vectors(vectors)
            
            return {
                "status": "success",
                "message": "记忆更新成功",
                "memory_id": memory_id
            }
    
    return {
        "status": "error",
        "message": f"未找到记忆 ID: {memory_id}"
    }

def delete_memory(memory_id: str) -> Dict[str, Any]:
    """
    删除记忆
    
    Args:
        memory_id: 记忆 ID
    
    Returns:
        删除结果
    """
    storage = MemoryStorage()
    memories = storage.load_memories()
    vectors = storage.load_vectors()
    
    # 查找并删除
    for i, mem in enumerate(memories):
        if mem["id"] == memory_id:
            memories.pop(i)
            if vectors is not None and len(vectors) > i:
                vectors = np.delete(vectors, i, axis=0)
            
            storage.save_memories(memories)
            if vectors is not None:
                storage.save_vectors(vectors)
            
            return {
                "status": "success",
                "message": "记忆删除成功",
                "memory_id": memory_id
            }
    
    return {
        "status": "error",
        "message": f"未找到记忆 ID: {memory_id}"
    }

def export_memories(
    output_path: str,
    scope: Optional[str] = None
) -> Dict[str, Any]:
    """
    导出记忆
    
    Args:
        output_path: 输出文件路径
        scope: 作用域过滤
    
    Returns:
        导出结果
    """
    storage = MemoryStorage()
    count = storage.export_memories(output_path, scope)
    
    return {
        "status": "success",
        "message": f"成功导出 {count} 条记忆",
        "output_path": output_path,
        "count": count
    }

def import_memories(
    input_path: str,
    scope: Optional[str] = None,
    skip_duplicates: bool = True
) -> Dict[str, Any]:
    """
    导入记忆
    
    Args:
        input_path: 输入文件路径
        scope: 作用域覆盖
        skip_duplicates: 是否跳过重复
    
    Returns:
        导入结果
    """
    storage = MemoryStorage()
    
    # 导入记忆
    count = storage.import_memories(input_path, scope, skip_duplicates)
    
    # 重新计算所有向量
    memories = storage.load_memories()
    if memories:
        texts = [m["text"] for m in memories]
        vectors = embed_texts(texts)
        storage.save_vectors(vectors)
        
        # 更新记忆中的向量
        for i, mem in enumerate(memories):
            mem["vector"] = vectors[i].tolist()
        storage.save_memories(memories)
    
    return {
        "status": "success",
        "message": f"成功导入 {count} 条记忆",
        "count": count
    }

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="AI Memory Pro - 记忆存储工具")
    
    # 存储命令
    parser.add_argument("--text", type=str, help="记忆内容")
    parser.add_argument("--category", type=str, default="other", help="存储类别")
    parser.add_argument("--memory-category", type=str, default="entities", help="语义类别")
    parser.add_argument("--scope", type=str, default="global", help="作用域")
    parser.add_argument("--importance", type=float, default=0.5, help="重要性 (0-1)")
    parser.add_argument("--confidence", type=float, default=0.8, help="置信度 (0-1)")
    parser.add_argument("--no-check-dup", action="store_true", help="不检查重复")
    parser.add_argument("--dup-threshold", type=float, default=0.85, help="重复阈值")
    
    # 导入导出命令
    parser.add_argument("--export", action="store_true", help="导出记忆")
    parser.add_argument("--import", dest="import_mem", action="store_true", help="导入记忆")
    parser.add_argument("--input", type=str, help="导入文件路径")
    parser.add_argument("--output", type=str, help="导出文件路径")
    
    args = parser.parse_args()
    
    # 导出
    if args.export:
        if not args.output:
            print("错误：导出需要指定 --output")
            sys.exit(1)
        
        result = export_memories(args.output, args.scope)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    # 导入
    if args.import_mem:
        if not args.input:
            print("错误：导入需要指定 --input")
            sys.exit(1)
        
        result = import_memories(
            args.input,
            scope=args.scope,
            skip_duplicates=not args.no_check_dup
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    # 存储
    if args.text:
        result = store_memory(
            text=args.text,
            category=args.category,
            memory_category=args.memory_category,
            scope=args.scope,
            importance=args.importance,
            confidence=args.confidence,
            check_dup=not args.no_check_dup,
            dup_threshold=args.dup_threshold
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return
    
    parser.print_help()

if __name__ == "__main__":
    main()
