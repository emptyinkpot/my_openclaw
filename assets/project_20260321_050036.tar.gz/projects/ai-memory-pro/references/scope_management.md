# 作用域管理规范

## 目录
1. [作用域概述](#作用域概述)
2. [内置作用域](#内置作用域)
3. [自定义作用域](#自定义作用域)
4. [访问控制规则](#访问控制规则)
5. [使用场景](#使用场景)
6. [最佳实践](#最佳实践)

---

## 作用域概述

### 为什么需要作用域？

**问题场景：**
- 多个 AI Agent 共享同一记忆库时，记忆互相干扰
- 项目敏感信息不应泄露到全局
- 用户私有信息需要隔离保护

**解决方案：**
作用域（Scope）提供记忆的命名空间隔离，确保：
- 不同上下文的记忆互不干扰
- 敏感信息访问受控
- 记忆检索更精准高效

---

## 内置作用域

### 作用域层级

```
global (全局作用域)
  ├── agent:<agent-id> (代理私有)
  ├── project:<project-id> (项目级)
  ├── user:<user-id> (用户级)
  └── custom:<name> (自定义)
```

### 1. Global（全局作用域）

**标识符：** `global`

**用途：**
- 通用知识、最佳实践
- 跨项目共享信息
- 用户通用偏好

**访问权限：** 所有上下文均可访问

**示例：**
```json
{
  "text": "代码最佳实践：函数长度不超过 50 行",
  "scope": "global",
  "memory_category": "patterns"
}
```

**适用内容：**
- 编程规范
- 通用工具用法
- 行业最佳实践
- 通用用户偏好

---

### 2. Agent（代理私有作用域）

**标识符：** `agent:<agent-id>`

**用途：**
- 单个 AI Agent 的私有记忆
- 代理特定的角色设定
- 代理级别的配置

**访问权限：** 仅该代理可访问

**示例：**
```json
{
  "text": "代理角色：专业前端架构师，擅长 React 生态",
  "scope": "agent:frontend-expert",
  "memory_category": "profile"
}
```

**适用内容：**
- 代理角色定义
- 代理特定指令
- 单代理工作流程

**命名规范：**
- `agent:code-assistant`
- `agent:data-analyst`
- `agent:doc-writer`

---

### 3. Project（项目作用域）

**标识符：** `project:<project-id>`

**用途：**
- 项目特定信息
- 技术栈、架构决策
- 项目配置和依赖

**访问权限：** 项目上下文内可访问

**示例：**
```json
{
  "text": "项目技术栈：Next.js + PostgreSQL + Redis",
  "scope": "project:ecommerce-app",
  "memory_category": "entities"
}
```

**适用内容：**
- 技术栈信息
- 架构决策
- 项目配置
- 团队约定

**命名规范：**
- `project:myapp`
- `project:ecommerce-frontend`
- `project:data-pipeline`

---

### 4. User（用户作用域）

**标识符：** `user:<user-id>`

**用途：**
- 用户私有信息
- 个人偏好
- 敏感配置

**访问权限：** 仅用户本人可访问

**示例：**
```json
{
  "text": "用户 API Key：sk-xxxx（OpenAI）",
  "scope": "user:alice",
  "memory_category": "entities"
}
```

**适用内容：**
- 个人 API 密钥
- 私人偏好
- 敏感配置

**命名规范：**
- `user:alice`
- `user:uuid-12345`
- `user:email-hash`

---

### 5. Custom（自定义作用域）

**标识符：** `custom:<name>`

**用途：**
- 特殊隔离需求
- 临时工作区
- 实验性记忆

**访问权限：** 需显式指定

**示例：**
```json
{
  "text": "实验性功能：测试新的对话模式",
  "scope": "custom:experiment-2024",
  "memory_category": "cases"
}
```

**适用内容：**
- 实验性记忆
- 临时工作区
- 特殊隔离需求

---

## 自定义作用域

### 定义新作用域

**步骤：**
1. 确定作用域标识符（格式：`custom:<name>`）
2. 定义描述和用途
3. 在存储时显式指定

**示例配置：**
```json
{
  "scope_definitions": {
    "custom:team-alpha": {
      "description": "Alpha 团队专用记忆",
      "access_policy": "whitelist",
      "allowed_agents": ["agent:alpha-lead", "agent:alpha-dev"]
    }
  }
}
```

### 作用域命名规范

**格式：** `<type>:<identifier>`

**规则：**
- 使用小写字母和连字符
- 避免特殊字符（除 `:` 和 `-`）
- 标识符应有意义且唯一
- 建议长度：3-30 字符

**示例：**
```
✅ global
✅ agent:code-reviewer
✅ project:mobile-app-v2
✅ user:john-doe
✅ custom:sprint-2024-q1

❌ Agent:CodeReviewer  (禁止大写)
❌ project:mobile_app  (使用连字符而非下划线)
❌ user:john@doe.com   (避免特殊字符)
```

---

## 访问控制规则

### 默认访问策略

**单一作用域访问：**
```python
# 只访问指定作用域
memories = retrieve(query, scope="project:myapp")
```

**多作用域访问：**
```python
# 访问多个作用域
memories = retrieve(query, scopes=["global", "project:myapp"])
```

**继承访问：**
```python
# 默认行为：自动包含 global
memories = retrieve(query, scope="project:myapp")
# 等价于：
memories = retrieve(query, scopes=["global", "project:myapp"])
```

### Agent 访问控制矩阵

| 作用域 | Agent A | Agent B | Agent C |
|--------|---------|---------|---------|
| `global` | ✅ | ✅ | ✅ |
| `agent:a` | ✅ | ❌ | ❌ |
| `agent:b` | ❌ | ✅ | ❌ |
| `project:shared` | ✅ | ✅ | ❌ |
| `user:alice` | ✅ | ❌ | ❌ |

### 配置示例

```json
{
  "scopes": {
    "default": "global",
    "definitions": {
      "global": {
        "description": "全局共享知识"
      },
      "agent:code-assistant": {
        "description": "代码助手私有记忆"
      },
      "project:myapp": {
        "description": "MyApp 项目专属"
      }
    },
    "agentAccess": {
      "code-assistant": ["global", "agent:code-assistant", "project:myapp"],
      "data-analyst": ["global", "agent:data-analyst"]
    }
  }
}
```

---

## 使用场景

### 场景 1：多代理协作

**需求：**
- 代码助手和文档助手共享项目信息
- 但各自有私有记忆

**实现：**
```python
# 存储项目共享信息
store("项目使用 Next.js 13", scope="project:myapp")

# 代码助手私有记忆
store("代码风格：函数式组件", scope="agent:code-assistant")

# 文档助手私有记忆
store("文档风格：简洁技术文档", scope="agent:doc-writer")

# 检索时自动合并作用域
# 代码助手检索：global + agent:code-assistant + project:myapp
# 文档助手检索：global + agent:doc-writer + project:myapp
```

---

### 场景 2：项目隔离

**需求：**
- 多个项目并行开发
- 项目间信息不互相干扰

**实现：**
```python
# 项目 A 的架构决策
store("项目A选择 MongoDB", scope="project:project-a")

# 项目 B 的架构决策
store("项目B选择 PostgreSQL", scope="project:project-b")

# 检索时限定作用域
retrieve("数据库选择", scope="project:project-a")
# 只返回 MongoDB 相关记忆
```

---

### 场景 3：敏感信息保护

**需求：**
- API 密钥等敏感信息需要隔离
- 避免泄露到全局作用域

**实现：**
```python
# 用户私有 API 密钥
store(
  "用户 OpenAI Key: sk-xxxx",
  scope="user:alice",
  importance=1.0
)

# 检索时只能在该用户上下文中访问
retrieve("API Key", scope="user:alice")

# 其他用户或代理无法访问
retrieve("API Key", scope="user:bob")  # 返回空
```

---

### 场景 4：团队协作

**需求：**
- 团队共享记忆池
- 团队成员有私有记忆

**实现：**
```python
# 团队共享规范
store("团队代码规范：Airbnb Style Guide", scope="custom:team-alpha")

# 成员私有笔记
store("个人学习笔记：TypeScript 泛型", scope="user:alice")

# 团队协作检索
retrieve(
  "代码规范",
  scopes=["global", "custom:team-alpha", "user:alice"]
)
```

---

## 最佳实践

### 1. 作用域选择指南

| 内容类型 | 推荐作用域 | 原因 |
|---------|-----------|------|
| 通用知识 | `global` | 跨项目复用 |
| 项目配置 | `project:<id>` | 项目隔离 |
| 用户偏好 | `user:<id>` | 个性化 |
| 敏感信息 | `user:<id>` 或受限作用域 | 安全性 |
| 代理角色 | `agent:<id>` | 角色隔离 |

### 2. 避免的作用域使用

**❌ 错误示例：**
```python
# 所有记忆都存全局
store("项目A的数据库配置", scope="global")  # 污染全局命名空间
```

**✅ 正确示例：**
```python
# 按实际范围存储
store("项目A的数据库配置", scope="project:project-a")
```

### 3. 作用域命名建议

**项目命名：**
- 使用项目代号或简称
- 示例：`project:ecom`、`project:mobile-v2`

**用户命名：**
- 使用用户名或 ID
- 示例：`user:alice`、`user:uid-12345`

**代理命名：**
- 反映代理角色
- 示例：`agent:code-reviewer`、`agent:test-runner`

### 4. 记忆迁移

**跨作用域迁移：**
```python
# 从全局迁移到项目作用域
memories = retrieve("项目X相关信息", scope="global")
for mem in memories:
    update_scope(mem['id'], new_scope="project:project-x")
```

### 5. 清理策略

**定期清理：**
```python
# 清理项目已完成的历史记忆
delete_memories(scope="project:archived-project")

# 清理过期的实验性记忆
delete_memories(scope="custom:experiment-2023")
```

---

## 命令参考

### 存储时指定作用域

```bash
python scripts/memory_store.py \
  --text "记忆内容" \
  --scope "project:myapp"
```

### 检索时限定作用域

```bash
python scripts/memory_retrieve.py \
  --query "查询内容" \
  --scope "project:myapp"
```

### 按作用域导出

```bash
python scripts/memory_store.py \
  --export \
  --scope "project:myapp" \
  --output project_myapp_backup.json
```

### 按作用域删除

```bash
python scripts/memory_decay.py \
  --action cleanup \
  --scope "project:deprecated"
```

---

## 参考链接
- [记忆类别定义](memory_categories.md)
- [衰减算法说明](decay_algorithm.md)
- [数据结构模板](../assets/memory_template.json)
