# Weibull 衰减算法说明

## 目录
1. [算法原理](#算法原理)
2. [参数配置](#参数配置)
3. [三层晋升机制](#三层晋升机制)
4. [访问强化机制](#访问强化机制)
5. [实现细节](#实现细节)
6. [示例计算](#示例计算)

---

## 算法原理

### Weibull 分布基础

Weibull 衰减模型基于 **Weibull 分布**，是一种用于描述时间依赖性衰减的数学模型。

**核心公式：**
```
score = e^(-(t/λ)^β)
```

**参数说明：**
- `t`：记忆年龄（天数）
- `λ`：特征寿命（scale parameter，控制衰减速度）
- `β`：形状参数（shape parameter，控制衰减曲线形态）
- `score`：衰减后分数（0-1）

### β 值对衰减曲线的影响

```
β < 1：早期快速衰减
  ┌─────────────────┐
  │╲                │ 记忆初期快速遗忘
  │ ╲___            │
  │     ──___       │
  └─────────────────┘
  
β = 1：标准指数衰减
  ┌─────────────────┐
  │╲                │ 稳定的衰减速率
  │  ╲              │
  │   ╲___          │
  └─────────────────┘
  
β > 1：S型衰减（延迟衰减）
  ┌─────────────────┐
  │──────╲          │ 初期保持，后期快速衰减
  │       ╲___      │
  │           ──___ │
  └─────────────────┘
```

---

## 参数配置

### 默认配置

**Peripheral 层（外围层）：**
```python
{
  "half_life_days": 30,    # 半衰期 30 天
  "beta": 1.3,             # S型衰减
  "decay_rate": 0.023      # 日衰减率
}
```

**Working 层（工作层）：**
```python
{
  "half_life_days": 60,    # 半衰期 60 天
  "beta": 1.0,             # 标准指数衰减
  "decay_rate": 0.012      # 日衰减率
}
```

**Core 层（核心层）：**
```python
{
  "half_life_days": 90,    # 半衰期 90 天
  "beta": 0.8,             # 早期快速衰减但长期稳定
  "decay_rate": 0.007      # 日衰减率
}
```

### 综合评分计算

**公式：**
```python
composite_score = (
    recency_score * (1 - frequency_weight - intrinsic_weight) +
    access_frequency_norm * frequency_weight +
    (importance * confidence) * intrinsic_weight
) * weibull_decay_boost
```

**权重配置：**
```python
{
  "frequency_weight": 0.3,     # 访问频率权重
  "intrinsic_weight": 0.3,     # 内在价值权重
  "recency_weight": 0.4        # 时间衰减权重
}
```

**归一化处理：**
- `access_frequency_norm = min(access_count / 10, 1.0)`  # 访问次数归一化
- `importance`：用户设定的重要性（0-1）
- `confidence`：智能体评估的置信度（0-1）

---

## 三层晋升机制

### 晋升路径

```
┌──────────────┐
│  Peripheral  │  访问 < 3 次
│  (外围层)     │  半衰期: 30 天
└──────┬───────┘  β = 1.3
       │
       │ 访问 ≥ 3 次
       ▼
┌──────────────┐
│   Working    │  访问 3-9 次
│  (工作层)     │  半衰期: 60 天
└──────┬───────┘  β = 1.0
       │
       │ 访问 ≥ 10 次
       ▼
┌──────────────┐
│    Core      │  访问 ≥ 10 次
│  (核心层)     │  半衰期: 90 天
└──────────────┘  β = 0.8
```

### 晋升规则

**Peripheral → Working：**
- 条件：`access_count >= 3`
- 效果：半衰期翻倍（30 → 60 天）
- β 值：1.3 → 1.0

**Working → Core：**
- 条件：`access_count >= 10`
- 效果：半衰期再延长（60 → 90 天）
- β 值：1.0 → 0.8

### 降级规则

**Core → Working：**
- 条件：`access_count < 10 AND age > 180 days`
- 效果：降低优先级

**Working → Peripheral：**
- 条件：`access_count < 3 AND age > 90 days`
- 效果：进一步降低优先级

---

## 访问强化机制

### 间隔重复原理

基于 **艾宾浩斯遗忘曲线** 的反向应用：
- 频繁访问的记忆衰减更慢
- 形成"越用越牢"的效果

### 强化公式

```python
effective_half_life = base_half_life * (1 + reinforcement_factor * log(access_count + 1))
```

**参数：**
- `reinforcement_factor`：强化因子（默认 0.5）
- `log`：自然对数
- 上限：`max_half_life_multiplier = 3`（最多延长 3 倍）

**示例：**
```python
base_half_life = 30  # 天
access_count = 5
reinforcement_factor = 0.5

effective_half_life = 30 * (1 + 0.5 * log(6))
                    = 30 * (1 + 0.5 * 1.79)
                    = 30 * 1.895
                    = 56.85 天
```

### 强化效果可视化

```
访问次数  |  有效半衰期（基础 30 天）
─────────┼─────────────────────────
   0     |  30 天
   1     |  33.6 天 (+12%)
   3     |  39.2 天 (+31%)
   5     |  45.3 天 (+51%)
  10     |  56.9 天 (+90%)
  20     |  72.1 天 (+140%)
  50     |  90.0 天 (达到上限 3倍)
```

---

## 实现细节

### 衰减计算函数

```python
import numpy as np

def weibull_decay(age_days, half_life, beta):
    """
    计算 Weibull 衰减分数
    
    Args:
        age_days: 记忆年龄（天）
        half_life: 半衰期（天）
        beta: 形状参数
    
    Returns:
        衰减分数 (0-1)
    """
    if age_days <= 0:
        return 1.0
    
    # 从半衰期计算特征寿命 λ
    # half_life = λ * (ln(2))^(1/β)
    # λ = half_life / (ln(2))^(1/β)
    lambda_scale = half_life / (np.log(2) ** (1/beta))
    
    # Weibull 衰减
    decay_score = np.exp(-((age_days / lambda_scale) ** beta))
    
    return decay_score
```

### 综合评分函数

```python
def calculate_composite_score(
    memory,
    current_time,
    config
):
    """
    计算记忆的综合评分
    
    Args:
        memory: 记忆对象
        current_time: 当前时间戳（毫秒）
        config: 配置参数
    
    Returns:
        综合评分 (0-1)
    """
    # 1. 计算年龄
    age_ms = current_time - memory['timestamp']
    age_days = age_ms / (1000 * 60 * 60 * 24)
    
    # 2. 根据层级选择参数
    tier = memory.get('tier', 'peripheral')
    tier_config = config['tiers'][tier]
    
    # 3. 计算 Weibull 衰减
    recency_score = weibull_decay(
        age_days,
        tier_config['half_life_days'],
        tier_config['beta']
    )
    
    # 4. 访问强化
    reinforcement = 1 + config['reinforcement_factor'] * np.log(memory['access_count'] + 1)
    effective_half_life = min(
        tier_config['half_life_days'] * reinforcement,
        tier_config['half_life_days'] * config['max_half_life_multiplier']
    )
    
    # 5. 重新计算带强化的衰减
    reinforced_score = weibull_decay(age_days, effective_half_life, tier_config['beta'])
    
    # 6. 计算综合评分
    frequency_norm = min(memory['access_count'] / 10, 1.0)
    intrinsic_value = memory['importance'] * memory['confidence']
    
    composite_score = (
        reinforced_score * (1 - config['frequency_weight'] - config['intrinsic_weight']) +
        frequency_norm * config['frequency_weight'] +
        intrinsic_value * config['intrinsic_weight']
    )
    
    return composite_score
```

---

## 示例计算

### 示例 1：新记忆

**输入：**
```json
{
  "text": "用户偏好使用 tabs 缩进",
  "importance": 0.8,
  "confidence": 0.95,
  "access_count": 0,
  "tier": "peripheral",
  "age_days": 1
}
```

**计算过程：**
```python
# Weibull 衰减
recency_score = weibull_decay(1, 30, 1.3) = 0.997

# 访问强化（无访问）
reinforced_score = 0.997

# 综合评分
composite = 0.997 * 0.4 + 0.0 * 0.3 + (0.8 * 0.95) * 0.3
          = 0.399 + 0.0 + 0.228
          = 0.627
```

**结果：** `0.627`

---

### 示例 2：频繁访问的核心记忆

**输入：**
```json
{
  "text": "项目选择 PostgreSQL 作为主数据库",
  "importance": 0.9,
  "confidence": 0.9,
  "access_count": 15,
  "tier": "core",
  "age_days": 60
}
```

**计算过程：**
```python
# 访问强化
reinforcement = 1 + 0.5 * log(16) = 2.39
effective_half_life = min(90 * 2.39, 90 * 3) = 215 天

# Weibull 衰减
recency_score = weibull_decay(60, 215, 0.8) = 0.871

# 综合评分
frequency_norm = min(15/10, 1.0) = 1.0
composite = 0.871 * 0.4 + 1.0 * 0.3 + (0.9 * 0.9) * 0.3
          = 0.348 + 0.3 + 0.243
          = 0.891
```

**结果：** `0.891`

---

### 示例 3：老旧外围记忆

**输入：**
```json
{
  "text": "临时会议讨论了 UI 细节",
  "importance": 0.5,
  "confidence": 0.7,
  "access_count": 1,
  "tier": "peripheral",
  "age_days": 45
}
```

**计算过程：**
```python
# 访问强化
reinforcement = 1 + 0.5 * log(2) = 1.35
effective_half_life = 30 * 1.35 = 40.5 天

# Weibull 衰减
recency_score = weibull_decay(45, 40.5, 1.3) = 0.412

# 综合评分
frequency_norm = min(1/10, 1.0) = 0.1
composite = 0.412 * 0.4 + 0.1 * 0.3 + (0.5 * 0.7) * 0.3
          = 0.165 + 0.03 + 0.105
          = 0.30
```

**结果：** `0.30`（接近清理阈值）

---

## 调优建议

### 参数调整

**加快衰减（适合信息更新频繁场景）：**
```python
{
  "decay.recencyHalfLifeDays": 14,
  "tier.peripheralAgeDays": 30
}
```

**减缓衰减（适合知识库场景）：**
```python
{
  "decay.recencyHalfLifeDays": 60,
  "reinforcementFactor": 0.8,
  "maxHalfLifeMultiplier": 5
}
```

### 性能优化

- 衰减计算可在检索时动态计算（无需预计算）
- 使用缓存存储常用记忆的综合评分
- 批量更新时采用增量计算

---

## 参考链接
- [记忆类别定义](memory_categories.md)
- [作用域管理](scope_management.md)
