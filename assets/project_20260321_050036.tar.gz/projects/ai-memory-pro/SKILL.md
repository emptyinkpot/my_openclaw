---
name: ai-memory-pro
description: AI长期记忆管理系统，支持6类记忆智能提取、混合检索（向量+BM25）、Weibull衰减模型、三层晋升机制；当用户需要管理长期记忆、跨会话记住信息、自动提取和检索记忆时使用
dependency:
  python:
    - sentence-transformers
    - rank-bm25
    - numpy
    - scikit-learn
---

# AI Memory Pro - AI长期记忆管理系统

## 任务目标
- 本 Skill 用于：为 AI 智能体提供生产级长期记忆能力，实现跨会话信息记忆与管理
- 能力包含：
  - 智能记忆提取（6类分类：profile/preferences/entities/events/cases/patterns）
  - 混合检索（向量检索 + BM25 全文搜索 + 衰减增强）
  - 记忆生命周期管理（Weibull 衰减 + 三层晋升）
  - 多作用域隔离（global/agent/project/user）
- 触发条件：用户需要记住信息、检索过往记忆、管理记忆库

## 前置准备
- 依赖说明：scripts 脚本所需的依赖包
  ```
  sentence-transformers
  rank-bm25
  numpy
  scikit-learn
  ```
- 记忆存储位置：默认 `./.memory-pro/` 目录下

## 核心操作流程

### 1. 存储记忆（自动提取）

**智能体判断逻辑：**
在对话过程中，智能体需判断是否需要存储记忆：
- ✅ **需要存储**：用户明确表达偏好、重要决策、关键事实、项目信息
- ❌ **无需存储**：临时问候、简单确认、无关闲聊

**存储步骤：**
1. 智能体根据 [references/memory_categories.md](references/memory_categories.md) 判断记忆类别
2. 智能体评估记忆重要性（0.0-1.0）和置信度（0.0-1.0）
3. 智能体精简记忆内容（建议 < 500 字符）
4. 调用脚本存储：`python scripts/memory_store.py --text "记忆内容" --category <类别> --importance <重要性> --confidence <置信度> --scope <作用域>`

**示例：**
```bash
# 存储用户偏好
python scripts/memory_store.py \
  --text "用户偏好使用 tabs 而非 spaces 进行缩进" \
  --category preferences \
  --importance 0.8 \
  --confidence 0.95 \
  --scope global

# 存储项目决策
python scripts/memory_store.py \
  --text "项目选择 PostgreSQL 作为主数据库，原因：ACID 支持、成熟稳定" \
  --category cases \
  --importance 0.9 \
  --confidence 0.9 \
  --scope project:myapp
```

### 2. 检索记忆（智能召回）

**检索步骤：**
1. 智能体分析用户意图，判断是否需要检索记忆
2. 构建查询语句（关键词或自然语言）
3. 调用检索脚本：`python scripts/memory_retrieve.py --query "查询内容" --scope <作用域> --limit <数量>`
4. 智能体根据检索结果生成回复

**检索模式：**
- `hybrid`（默认）：向量检索 + BM25 融合
- `vector`：纯语义相似度检索
- `bm25`：纯关键词检索

**示例：**
```bash
# 检索数据库相关决策
python scripts/memory_retrieve.py \
  --query "数据库选择" \
  --scope project:myapp \
  --limit 5

# 检索用户偏好
python scripts/memory_retrieve.py \
  --query "代码风格偏好" \
  --scope global \
  --limit 3
```

### 3. 记忆管理（生命周期）

**自动管理机制：**
- **Weibull 衰减**：记忆分数随时间衰减，重要记忆衰减更慢
- **三层晋升**：
  - `peripheral`（外围层）：默认，半衰期 30 天
  - `working`（工作层）：访问 ≥3 次，半衰期 60 天
  - `core`（核心层）：访问 ≥10 次，半衰期 90 天

**手动管理：**
```bash
# 查看记忆统计
python scripts/memory_decay.py --action stats

# 查看各层级分布
python scripts/memory_decay.py --action tiers

# 强制更新衰减分数
python scripts/memory_decay.py --action update

# 清理低分记忆
python scripts/memory_decay.py --action cleanup --threshold 0.1
```

### 4. 记忆导入导出

**导出记忆：**
```bash
python scripts/memory_store.py --export --output backup.json --scope global
```

**导入记忆：**
```bash
python scripts/memory_store.py --import --input backup.json --scope global
```

## 资源索引
- 必要脚本：
  - [scripts/memory_store.py](scripts/memory_store.py)：存储记忆、导入导出
  - [scripts/memory_retrieve.py](scripts/memory_retrieve.py)：混合检索记忆
  - [scripts/memory_decay.py](scripts/memory_decay.py)：生命周期管理
  - [scripts/memory_utils.py](scripts/memory_utils.py)：工具函数库
- 领域参考：
  - [references/memory_categories.md](references/memory_categories.md)：6类记忆详细定义（何时读取：存储前判断类别）
  - [references/decay_algorithm.md](references/decay_algorithm.md)：Weibull 衰减算法说明（何时读取：理解衰减机制）
  - [references/scope_management.md](references/scope_management.md)：多作用域管理规范（何时读取：配置作用域）
- 输出资产：
  - [assets/memory_template.json](assets/memory_template.json)：记忆数据结构模板

## 高级功能

### 自动向量化
- 使用 `sentence-transformers` 模型自动将文本转为向量
- 默认模型：`all-MiniLM-L6-v2`（轻量级，速度快）
- 支持自定义模型：通过环境变量 `MEMORY_EMBEDDING_MODEL` 指定

### 去重机制
- 向量相似度检测（阈值 ≥ 0.85）
- 智能体语义判断（避免重复存储相似内容）

### 噪音过滤
智能体在存储前应过滤：
- ❌ 拒绝回复（如"我无法..."）
- ❌ 元问题（如"你是什么模型"）
- ❌ 简单问候（如"你好"、"谢谢"）
- ❌ 低价值内容（如确认消息、表情符号）

## 注意事项
- **存储原则**：记忆内容应简洁、原子化（单条 < 500 字符）
- **重要性评估**：核心决策、用户偏好应设置 high importance（≥0.8）
- **作用域隔离**：敏感信息应存储在对应作用域，避免全局污染
- **去重优先**：存储前先检索，避免重复记忆
- **定期维护**：建议定期执行衰减更新和清理

## 快速开始示例

**场景 1：记住用户偏好**
```
用户："以后代码都用 4 空格缩进"
智能体判断：preferences 类别，importance=0.8
执行：python scripts/memory_store.py --text "用户偏好 4 空格缩进" --category preferences --importance 0.8 --scope global
```

**场景 2：检索过往决策**
```
用户："上次为什么选 PostgreSQL？"
智能体执行：python scripts/memory_retrieve.py --query "PostgreSQL 选择原因" --scope project:myapp --limit 3
根据检索结果回复："根据 3 月 12 日的讨论，选择 PostgreSQL 主要因为 ACID 支持..."
```

**场景 3：项目信息管理**
```
用户："这个项目的技术栈是什么？"
智能体执行：python scripts/memory_retrieve.py --query "技术栈" --scope project:myapp --limit 5
汇总回复：根据记忆显示，项目技术栈包括...
```

## 配置说明

**环境变量（可选）：**
- `MEMORY_DB_PATH`：记忆存储路径（默认：`./.memory-pro/`）
- `MEMORY_EMBEDDING_MODEL`：向量模型名称（默认：`all-MiniLM-L6-v2`）
- `MEMORY_VECTOR_WEIGHT`：混合检索向量权重（默认：`0.7`）
- `MEMORY_BM25_WEIGHT`：混合检索 BM25 权重（默认：`0.3`）

**数据结构：**
详见 [assets/memory_template.json](assets/memory_template.json)
