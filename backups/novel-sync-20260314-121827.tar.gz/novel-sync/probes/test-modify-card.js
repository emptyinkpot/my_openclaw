/**
 * 白梦写作 - 修改内容卡片操作探索
 * 
 * 功能：
 * 1. 悬停显示按钮
 * 2. 替换正文
 * 3. 复制内容
 * 4. 展开/折叠
 * 
 * 代码来源：src/platforms/baimeng/*.js 已验证模块
 */

const { runTask } = require('./src/utils/task-runner');

runTask('探索修改内容卡片', async (ctx) => {
  const baimeng = require('./src/platforms/baimeng');
  const config = require('./src/config');
  
  console.log('=== 启动浏览器 ===');
  const { browser, page } = await baimeng.browser.launch();
  
  // 恢复登录（来源：auth.js 已验证）
  await baimeng.auth.restoreLogin(page);
  
  // 打开作品（来源：works.js 已验证）
  const workTitle = '变身咳血少女的我也要努力活下去';
  const workId = 'cm8p6ql020000l308hcggtgk0';
  
  console.log(`\n打开作品: ${workTitle}`);
  await page.goto(`${config.BAIMENG.EDITOR_URL}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(5000);
  
  // 打开章节（来源：sidebar.js 已验证）
  console.log('\n打开第四十二章...');
  const result = await baimeng.sidebar.findChapter(page, '第四十二章');
  console.log(result.found ? '✅ 已打开第四十二章' : '❌ 未找到');
  
  await page.waitForTimeout(3000);
  
  // 探索修改内容卡片
  console.log('\n=== 探索修改内容卡片 ===');
  
  // 1. 查找修改内容卡片
  console.log('\n1. 查找修改内容卡片...');
  const cardInfo = await page.evaluate(() => {
    const allElements = document.querySelectorAll('*');
    const cards = [];
    
    for (const el of allElements) {
      const text = el.innerText || '';
      if (text.includes('修改内容') && text.includes('字')) {
        const rect = el.getBoundingClientRect();
        if (rect.width > 100 && rect.height > 50) {
          cards.push({
            tag: el.tagName,
            class: el.className,
            text: text.substring(0, 100),
            width: rect.width,
            height: rect.height,
            x: rect.x,
            y: rect.y
          });
        }
      }
    }
    
    return cards.slice(0, 5);
  });
  
  console.log('找到的卡片:', JSON.stringify(cardInfo, null, 2));
  
  // 2. 查找按钮
  console.log('\n2. 查找按钮...');
  const buttons = await page.evaluate(() => {
    const btns = [];
    const allButtons = document.querySelectorAll('button, [role="button"], [class*="btn"]');
    
    for (const btn of allButtons) {
      const text = btn.innerText || btn.textContent || '';
      if (text.includes('替换') || text.includes('复制') || text.includes('展开') || text.includes('收起')) {
        const rect = btn.getBoundingClientRect();
        btns.push({
          text: text.trim(),
          class: btn.className,
          tag: btn.tagName,
          visible: rect.width > 0 && rect.height > 0,
          x: rect.x,
          y: rect.y
        });
      }
    }
    
    return btns;
  });
  
  console.log('找到的按钮:', JSON.stringify(buttons, null, 2));
  
  // 3. 尝试悬停显示按钮
  console.log('\n3. 尝试悬停在修改内容卡片上...');
  await page.evaluate(() => {
    const allElements = document.querySelectorAll('*');
    for (const el of allElements) {
      const text = el.innerText || '';
      if (text.match(/修改内容.*\d+字/)) {
        const event = new MouseEvent('mouseenter', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        el.dispatchEvent(event);
        
        const overEvent = new MouseEvent('mouseover', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        el.dispatchEvent(overEvent);
        break;
      }
    }
  });
  
  await page.waitForTimeout(1000);
  
  // 截图
  await page.screenshot({ path: '/tmp/modify-card-explore.png' });
  console.log('\n截图保存: /tmp/modify-card-explore.png');
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
});
