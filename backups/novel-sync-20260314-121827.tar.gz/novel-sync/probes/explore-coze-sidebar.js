/**
 * Coze 操作 - 点击侧边栏"扣子编程"
 * 用法：node coze-sidebar-programming.js
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BROWSER_DIR = '/workspace/projects/browser/coze-1';
const BACKUP_FILE = '/workspace/projects/cookies-accounts/coze-account-1-full.json';
const URL = 'https://www.coze.cn/';

async function main() {
  console.log('🖱️ Coze 操作 - 点击侧边栏扣子编程\n');
  
  // 清理锁文件
  const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie'];
  lockFiles.forEach(f => {
    const p = path.join(BROWSER_DIR, f);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  });
  
  // ========== Step 1: 启动浏览器 ==========
  console.log('Step 1: 启动浏览器...');
  
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: { width: 1280, height: 800 },
    args: ['--start-maximized']
  });
  
  const page = browser.pages()[0] || await browser.newPage();
  console.log('  ✓ 浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  console.log('\nStep 2: 恢复登录...');
  
  if (fs.existsSync(BACKUP_FILE)) {
    const data = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf-8'));
    
    await page.goto(URL, { timeout: 30000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2000);
    
    if (data.localStorage) {
      await page.evaluate((items) => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, data.localStorage);
    }
    
    if (data.cookies) {
      await browser.addCookies(data.cookies);
    }
    
    await page.reload();
    await page.waitForTimeout(3000);
    console.log('  ✓ 登录已恢复');
  }
  
  // ========== Step 3: 查找侧边栏中的"扣子编程" ==========
  console.log('\nStep 3: 查找侧边栏"扣子编程"...');
  await page.waitForTimeout(2000);
  
  // 精确查找侧边栏中的"扣子编程"
  const clicked = await page.evaluate(() => {
    // 查找所有可能是菜单项的元素
    const candidates = [];
    
    // 方式1: 查找文本内容仅为"扣子编程"的元素
    const allElements = document.querySelectorAll('*');
    for (const el of allElements) {
      // 获取直接文本内容（不包含子元素）
      const directText = Array.from(el.childNodes)
        .filter(node => node.nodeType === Node.TEXT_NODE)
        .map(node => node.textContent.trim())
        .join('');
      
      const fullText = (el.innerText || '').trim();
      
      // 精确匹配"扣子编程"
      if (directText === '扣子编程' || fullText === '扣子编程') {
        candidates.push({ el, text: fullText, match: 'exact' });
      }
      
      // 包含匹配但文本较短（排除父容器）
      if (fullText.includes('扣子编程') && fullText.length < 20) {
        candidates.push({ el, text: fullText, match: 'contains' });
      }
    }
    
    console.log(`找到 ${candidates.length} 个候选元素`);
    
    // 优先点击精确匹配的
    for (const c of candidates) {
      if (c.match === 'exact') {
        c.el.click();
        return { success: true, text: c.text, method: 'exact' };
      }
    }
    
    // 其次点击包含匹配中面积最小的（更可能是具体菜单项）
    if (candidates.length > 0) {
      // 按文本长度排序，选择最短的
      candidates.sort((a, b) => a.text.length - b.text.length);
      candidates[0].el.click();
      return { success: true, text: candidates[0].text, method: 'shortest' };
    }
    
    return { success: false };
  });
  
  if (clicked.success) {
    console.log(`  ✓ 已点击: "${clicked.text}" (${clicked.method})`);
  } else {
    console.log('  ⚠️ 未找到，打印页面结构...');
    
    // 打印侧边栏结构帮助调试
    const debug = await page.evaluate(() => {
      const sidebar = document.querySelector('[class*="sidebar"]') || 
                      document.querySelector('[class*="menu"]') ||
                      document.querySelector('nav');
      
      if (!sidebar) return { found: false };
      
      const items = sidebar.querySelectorAll('a, button, [class*="item"], [class*="menu-item"]');
      return {
        found: true,
        items: Array.from(items).slice(0, 20).map(el => ({
          text: (el.innerText || '').trim().substring(0, 50),
          tag: el.tagName,
          class: el.className?.substring(0, 50)
        }))
      };
    });
    
    if (debug.found) {
      console.log('\n  侧边栏菜单项:');
      debug.items.forEach((item, i) => {
        console.log(`    ${i + 1}. [${item.tag}] "${item.text}"`);
      });
    }
  }
  
  // ========== Step 4: 等待页面加载 ==========
  console.log('\nStep 4: 等待页面加载...');
  await page.waitForTimeout(3000);
  
  const currentUrl = page.url();
  const title = await page.title();
  console.log(`  当前URL: ${currentUrl}`);
  console.log(`  页面标题: ${title}`);
  
  // 截图
  const screenshotPath = '/tmp/coze-sidebar-click.png';
  await page.screenshot({ path: screenshotPath });
  console.log(`  ✓ 截图: ${screenshotPath}`);
  
  console.log('\n✅ 操作完成！');
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  
  await new Promise(() => {});
}

main().catch(console.error);
