/**
 * Coze.cn 网站探测脚本
 * 用法：node explore-coze.js
 * 
 * 流程：
 * 1. 打开 coze.cn
 * 2. 记录页面结构
 * 3. 等待用户登录
 * 4. 保存登录数据
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BROWSER_DIR = '/workspace/projects/browser/coze-1';
const STORAGE_DIR = '/workspace/projects/cookies-accounts';
const URL = 'https://www.coze.cn/';

async function main() {
  console.log('🌐 Coze.cn 网站探测\n');
  console.log('========================================');
  
  // 确保目录存在
  if (!fs.existsSync(BROWSER_DIR)) {
    fs.mkdirSync(BROWSER_DIR, { recursive: true });
    console.log(`✓ 创建浏览器目录: ${BROWSER_DIR}`);
  }
  
  // ========== Step 1: 启动浏览器 ==========
  console.log('\nStep 1: 启动浏览器...');
  
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: { width: 1280, height: 800 },
    args: ['--start-maximized']
  });
  
  const page = browser.pages()[0] || await browser.newPage();
  console.log('✓ 浏览器已启动');
  
  // ========== Step 2: 打开网站 ==========
  console.log('\nStep 2: 打开 coze.cn...');
  
  await page.goto(URL, { timeout: 30000, waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(3000);
  console.log(`✓ 已打开: ${URL}`);
  
  // ========== Step 3: 记录页面信息 ==========
  console.log('\nStep 3: 记录页面结构...');
  
  const pageInfo = await page.evaluate(() => {
    return {
      title: document.title,
      url: window.location.href,
      
      // 登录相关元素
      loginButtons: Array.from(document.querySelectorAll('button, a, [class*="login"], [class*="sign"]'))
        .filter(el => {
          const text = el.innerText?.toLowerCase() || '';
          return text.includes('登录') || text.includes('注册') || text.includes('sign') || text.includes('login');
        })
        .map(el => ({
          tag: el.tagName,
          text: el.innerText?.substring(0, 50),
          class: el.className?.substring(0, 100)
        })),
      
      // 主要导航
      mainNav: Array.from(document.querySelectorAll('nav, [class*="nav"], [class*="menu"]'))
        .slice(0, 3)
        .map(el => ({
          tag: el.tagName,
          class: el.className?.substring(0, 100),
          items: Array.from(el.querySelectorAll('a, button')).slice(0, 5).map(i => i.innerText?.substring(0, 30))
        })),
      
      // 输入框
      inputs: Array.from(document.querySelectorAll('input')).map(i => ({
        type: i.type,
        placeholder: i.placeholder,
        name: i.name
      })),
      
      // Cookies 数量
      cookieCount: document.cookie.split(';').filter(c => c.trim()).length,
      
      // localStorage 数量
      localStorageCount: Object.keys(localStorage).length
    };
  });
  
  console.log(`  标题: ${pageInfo.title}`);
  console.log(`  URL: ${pageInfo.url}`);
  console.log(`  Cookies: ${pageInfo.cookieCount} 个`);
  console.log(`  localStorage: ${pageInfo.localStorageCount} 个`);
  console.log(`  登录按钮: ${pageInfo.loginButtons.length} 个`);
  
  if (pageInfo.loginButtons.length > 0) {
    console.log('\n  登录相关元素:');
    pageInfo.loginButtons.forEach((btn, i) => {
      console.log(`    ${i + 1}. [${btn.tag}] "${btn.text}"`);
    });
  }
  
  // 保存页面信息
  const infoPath = '/tmp/coze-page-info.json';
  fs.writeFileSync(infoPath, JSON.stringify(pageInfo, null, 2));
  console.log(`\n✓ 页面信息已保存: ${infoPath}`);
  
  // 截图
  const screenshotPath = '/tmp/coze-homepage.png';
  await page.screenshot({ path: screenshotPath, fullPage: false });
  console.log(`✓ 截图已保存: ${screenshotPath}`);
  
  // ========== Step 4: 等待用户登录 ==========
  console.log('\n========================================');
  console.log('📌 请在浏览器中完成登录操作');
  console.log('📌 登录完成后，按 Enter 键继续...');
  console.log('========================================');
  
  // 等待用户输入
  await new Promise(resolve => {
    process.stdin.once('data', resolve);
  });
  
  // ========== Step 5: 检查登录状态 ==========
  console.log('\nStep 5: 检查登录状态...');
  
  await page.waitForTimeout(2000);
  
  const loginStatus = await page.evaluate(() => {
    return {
      url: window.location.href,
      title: document.title,
      cookieCount: document.cookie.split(';').filter(c => c.trim()).length,
      localStorageCount: Object.keys(localStorage).length,
      localStorageKeys: Object.keys(localStorage),
      
      // 查找用户信息元素
      userElements: Array.from(document.querySelectorAll('[class*="user"], [class*="avatar"], [class*="profile"]'))
        .slice(0, 5)
        .map(el => ({
          tag: el.tagName,
          class: el.className?.substring(0, 50),
          text: el.innerText?.substring(0, 50)
        }))
    };
  });
  
  console.log(`  当前 URL: ${loginStatus.url}`);
  console.log(`  Cookies: ${loginStatus.cookieCount} 个`);
  console.log(`  localStorage: ${loginStatus.localStorageCount} 个`);
  console.log(`  localStorage Keys: ${loginStatus.localStorageKeys.slice(0, 10).join(', ')}...`);
  
  // ========== Step 6: 保存登录数据 ==========
  console.log('\nStep 6: 保存登录数据...');
  
  // 获取 cookies
  const cookies = await browser.cookies();
  console.log(`  Cookies: ${cookies.length} 个`);
  
  // 获取 localStorage
  const localStorage = await page.evaluate(() => {
    const items = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      items[key] = localStorage.getItem(key);
    }
    return items;
  });
  console.log(`  localStorage: ${Object.keys(localStorage).length} 个`);
  
  // 保存完整数据
  const backupData = {
    url: loginStatus.url,
    timestamp: new Date().toISOString(),
    cookies: cookies,
    localStorage: localStorage
  };
  
  const backupPath = path.join(STORAGE_DIR, 'coze-account-1-full.json');
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
  fs.writeFileSync(backupPath, JSON.stringify(backupData, null, 2));
  console.log(`\n✓ 登录数据已保存: ${backupPath}`);
  
  // 保存到知识库
  const knowledgeDir = '/workspace/projects/knowledge/coze';
  fs.mkdirSync(knowledgeDir, { recursive: true });
  
  const siteInfo = {
    name: 'Coze',
    url: 'https://www.coze.cn/',
    loginMethod: '待确认',
    storageType: localStorage.length > 0 ? 'localStorage + cookies' : 'cookies',
    backupFile: backupPath,
    exploredAt: new Date().toISOString()
  };
  
  fs.writeFileSync(
    path.join(knowledgeDir, 'site.yaml'),
    `# Coze.cn 网站配置\n\nname: Coze\nurl: https://www.coze.cn/\nloginMethod: 待确认\nstorageType: ${siteInfo.storageType}\nbackupFile: ${backupPath}\nexploredAt: ${siteInfo.exploredAt}\n`
  );
  console.log(`✓ 网站信息已保存: ${knowledgeDir}/site.yaml`);
  
  // 登录后截图
  const afterLoginScreenshot = '/tmp/coze-after-login.png';
  await page.screenshot({ path: afterLoginScreenshot, fullPage: false });
  console.log(`✓ 登录后截图: ${afterLoginScreenshot}`);
  
  console.log('\n✅ 探测完成！');
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  
  // 保持浏览器打开
  await new Promise(() => {});
}

main().catch(console.error);
