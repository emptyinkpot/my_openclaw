/**
 * 测试章节匹配逻辑
 */

const { numToChinese, chineseToNumber, parseChapterNumber } = require('./src/utils/helper');

console.log('===== 章节匹配测试 =====\n');

// 测试 chineseToNumber
console.log('1. chineseToNumber 测试:');
const testCases1 = [
  ['一', 1], ['十', 10], ['十一', 11], ['二十', 20],
  ['二十一', 21], ['六十六', 66], ['一百', 100], ['123', 123]
];

testCases1.forEach(([input, expected]) => {
  const result = chineseToNumber(input);
  const status = result === expected ? '✅' : '❌';
  console.log(`  ${status} chineseToNumber('${input}') = ${result} (期望: ${expected})`);
});

// 测试 parseChapterNumber
console.log('\n2. parseChapterNumber 测试:');
const testCases2 = [
  // [输入, 期望输出]
  [1, 1],
  ['1', 1],
  [66, 66],
  ['66', 66],
  ['第一章', 1],
  ['第1章', 1],
  ['第六十六章', 66],
  ['第66章', 66],
  ['第一百章', 100],
  ['第100章', 100],
  ['第一章：故事的开始', 1],
  ['第1章 故事的开始', 1],
  ['六十六', 66],
];

testCases2.forEach(([input, expected]) => {
  const result = parseChapterNumber(input);
  const status = result === expected ? '✅' : '❌';
  console.log(`  ${status} parseChapterNumber('${input}') = ${result} (期望: ${expected})`);
});

// 测试 numToChinese
console.log('\n3. numToChinese 测试:');
const testCases3 = [
  [1, '一'], [10, '十'], [11, '十一'], [20, '二十'],
  [21, '二十一'], [66, '六十六'], [100, '一百']
];

testCases3.forEach(([input, expected]) => {
  const result = numToChinese(input);
  const status = result === expected ? '✅' : '❌';
  console.log(`  ${status} numToChinese(${input}) = '${result}' (期望: '${expected}')`);
});

// 测试完整匹配流程
console.log('\n4. 模拟匹配流程:');
const userInputs = ['1', '66', '第一章', '第1章', '第六十六章', '第66章：测试'];

userInputs.forEach(input => {
  const num = parseChapterNumber(input);
  const chinese = numToChinese(num);
  console.log(`  用户输入: '${input}' → 章节号: ${num} → 中文: '${chinese}'`);
});

console.log('\n===== 测试完成 =====');
