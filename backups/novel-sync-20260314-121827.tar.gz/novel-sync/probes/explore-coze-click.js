/**
 * Coze 操作 - 点击扣子编程
 * 用法：node coze-click-programming.js
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const BROWSER_DIR = '/workspace/projects/browser/coze-1';
const BACKUP_FILE = '/workspace/projects/cookies-accounts/coze-account-1-full.json';
const URL = 'https://www.coze.cn/';

async function main() {
  console.log('🖱️ Coze 操作 - 点击扣子编程\n');
  
  // 清理锁文件
  const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie'];
  lockFiles.forEach(f => {
    const p = path.join(BROWSER_DIR, f);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  });
  
  // ========== Step 1: 启动浏览器 ==========
  console.log('Step 1: 启动浏览器...');
  
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: { width: 1280, height: 800 },
    args: ['--start-maximized']
  });
  
  const page = browser.pages()[0] || await browser.newPage();
  console.log('  ✓ 浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  console.log('\nStep 2: 恢复登录...');
  
  if (fs.existsSync(BACKUP_FILE)) {
    const data = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf-8'));
    
    await page.goto(URL, { timeout: 30000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2000);
    
    if (data.localStorage) {
      await page.evaluate((items) => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, data.localStorage);
    }
    
    if (data.cookies) {
      await browser.addCookies(data.cookies);
    }
    
    await page.reload();
    await page.waitForTimeout(3000);
    console.log('  ✓ 登录已恢复');
  } else {
    await page.goto(URL, { timeout: 30000 });
  }
  
  // ========== Step 3: 查找并点击"扣子编程" ==========
  console.log('\nStep 3: 查找"扣子编程"...');
  await page.waitForTimeout(2000);
  
  // 尝试多种方式查找并点击
  const clicked = await page.evaluate(() => {
    // 方式1: 精确匹配文本
    const allElements = document.querySelectorAll('*');
    for (const el of allElements) {
      const text = (el.innerText || el.textContent || '').trim();
      if (text === '扣子编程' || text.includes('扣子编程')) {
        // 确保是可点击元素
        if (el.tagName === 'A' || el.tagName === 'BUTTON' || 
            el.onclick || el.style.cursor === 'pointer' ||
            el.className?.includes('cursor') || el.className?.includes('click')) {
          el.click();
          return { success: true, method: 'exact', text: text.substring(0, 50) };
        }
      }
    }
    
    // 方式2: 查找包含"编程"的链接/按钮
    const links = document.querySelectorAll('a, button, [class*="link"], [class*="btn"]');
    for (const el of links) {
      const text = (el.innerText || '').trim();
      if (text.includes('编程') || text.includes('扣子')) {
        el.click();
        return { success: true, method: 'link', text: text.substring(0, 50) };
      }
    }
    
    // 方式3: 查找导航项
    const navItems = document.querySelectorAll('nav a, nav button, [class*="nav"] a, [class*="nav"] button');
    for (const el of navItems) {
      const text = (el.innerText || '').trim();
      if (text.includes('编程')) {
        el.click();
        return { success: true, method: 'nav', text: text.substring(0, 50) };
      }
    }
    
    return { success: false };
  });
  
  if (clicked.success) {
    console.log(`  ✓ 已点击: "${clicked.text}" (${clicked.method})`);
  } else {
    console.log('  ⚠️ 未找到"扣子编程"，尝试滚动页面...');
    
    // 滚动页面后再查找
    await page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight / 2);
    });
    await page.waitForTimeout(1000);
    
    const clicked2 = await page.evaluate(() => {
      const allElements = document.querySelectorAll('*');
      for (const el of allElements) {
        const text = (el.innerText || el.textContent || '').trim();
        if (text.includes('扣子编程')) {
          el.click();
          return { success: true, text: text.substring(0, 50) };
        }
      }
      return { success: false };
    });
    
    if (clicked2.success) {
      console.log(`  ✓ 已点击: "${clicked2.text}"`);
    } else {
      console.log('  ✗ 未找到"扣子编程"');
    }
  }
  
  // ========== Step 4: 等待页面加载 ==========
  console.log('\nStep 4: 等待页面加载...');
  await page.waitForTimeout(3000);
  
  const currentUrl = page.url();
  const title = await page.title();
  console.log(`  当前URL: ${currentUrl}`);
  console.log(`  页面标题: ${title}`);
  
  // 截图
  const screenshotPath = '/tmp/coze-programming.png';
  await page.screenshot({ path: screenshotPath });
  console.log(`  ✓ 截图: ${screenshotPath}`);
  
  console.log('\n✅ 操作完成！');
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  
  await new Promise(() => {});
}

main().catch(console.error);
