/**
 * 测试对话区域滚动
 * 
 * 代码来源：src/platforms/baimeng/*.js 已验证模块
 */

const { runTask } = require('./src/utils/task-runner');

runTask('测试对话区域滚动', async (ctx) => {
  const baimeng = require('./src/platforms/baimeng');
  
  const { browser, page } = await baimeng.browser.launch();
  await baimeng.auth.restoreLogin(page);
  
  // 打开作品（来源：works.js 已验证）
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, '变身咳血少女的我也要努力活下去');
  console.log('打开作品...');
  await page.goto('https://baimengxiezuo.com/zh-Hans/editor/?id=' + workId, { timeout: 30000 });
  await page.waitForTimeout(5000);
  
  // 查找对话区域 - 和侧边栏逻辑类似（来源：DEBUG_LOG.md 滚动要点）
  console.log('\n查找对话区域...');
  
  const dialogPos = await page.evaluate(() => {
    const allContainers = document.querySelectorAll('div');
    
    for (const container of allContainers) {
      const text = container.innerText || '';
      if (text.includes('修改内容') && text.includes('字') && !text.includes('请输入指令')) {
        const rect = container.getBoundingClientRect();
        if (rect.height > 200 && rect.height < 600) {
          return { 
            found: true, 
            x: rect.x + rect.width / 2, 
            y: rect.y + rect.height / 2,
            height: rect.height,
            preview: text.substring(0, 100)
          };
        }
      }
    }
    
    return { found: false };
  });
  
  console.log('对话区域:', dialogPos);
  
  if (dialogPos.found) {
    // 1. 点击获取焦点（来源：DEBUG_LOG.md - 滚动前先点击获取焦点）
    console.log('\n[Step 1] 点击对话区域获取焦点...');
    await page.mouse.click(dialogPos.x, dialogPos.y);
    await page.waitForTimeout(300);
    
    // 2. 滚动到顶部
    console.log('[Step 2] 滚动到顶部...');
    for (let i = 0; i < 10; i++) {
      await page.mouse.wheel(0, -200);
      await page.waitForTimeout(50);
    }
    console.log('  已滚动到顶部');
    await page.waitForTimeout(1000);
    
    // 3. 慢速向下滚动查看内容
    console.log('[Step 3] 慢速向下滚动...');
    for (let i = 0; i < 10; i++) {
      await page.mouse.wheel(0, 100);
      await page.waitForTimeout(150);
      console.log(`  滚动 ${i + 1}/10`);
    }
    
    console.log('\n✅ 对话区域滚动测试完成');
    console.log('\n总结：');
    console.log('  1. 找到对话内容区域');
    console.log('  2. 点击获取焦点（关键！）');
    console.log('  3. 使用滚轮上下滚动');
    console.log('  4. 逻辑和侧边栏滚动一致');
  } else {
    console.log('❌ 未找到对话区域');
  }
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
});
