/**
 * 探索白梦写作"修改内容"卡片
 * 
 * 使用强制任务运行器，确保遵循编码规范
 */

const { runTask, findReusableCode } = require('./src/utils/task-runner');

runTask('探索修改内容卡片', async (ctx) => {
  // === 从已验证模块导入（来源：docs/已验证代码库.md） ===
  const browser = require('./src/platforms/baimeng/browser');
  const works = require('./src/platforms/baimeng/works');
  const sidebar = require('./src/platforms/baimeng/sidebar');
  const content = require('./src/platforms/baimeng/content');
  const config = require('./src/config');
  const fs = require('fs');
  
  console.log('1. 启动浏览器...');
  const { browser: context, page } = await browser.launch();
  console.log('   ✓ 浏览器已启动');
  
  // === 登录恢复（来源：DEBUG_LOG.md 已验证） ===
  console.log('\n2. 恢复登录状态...');
  await page.goto(config.BAIMENG.URL, { timeout: 30000 });
  await page.waitForTimeout(2000);
  
  let token = await page.evaluate(() => localStorage.getItem('token'));
  if (!token) {
    // 从备份恢复
    const backupFile = '/workspace/projects/cookies-accounts/baimeng-account-1-full.json';
    const data = JSON.parse(fs.readFileSync(backupFile, 'utf-8'));
    await page.evaluate((items) => {
      for (const [k, v] of Object.entries(items)) localStorage.setItem(k, v);
    }, data.localStorage || {});
    await page.reload();  // 关键：必须刷新
    await page.waitForTimeout(3000);
    token = await page.evaluate(() => localStorage.getItem('token'));
  }
  console.log(`   ✓ Token: ${token ? '存在' : '不存在'}`);
  
  if (!token) {
    throw new Error('登录恢复失败，请手动登录');
  }
  
  // === 获取作品（来源：works.js 已验证） ===
  console.log('\n3. 获取作品列表...');
  const worksList = await works.getWorks(page);
  console.log(`   ✓ 找到 ${worksList.length} 个作品`);
  
  // === 打开编辑器（来源：用户教导记录） ===
  const targetWork = worksList[0];
  console.log(`\n4. 打开编辑器: ${targetWork.title}`);
  const editorUrl = `https://baimengxiezuo.com/zh-Hans/editor/?id=${targetWork.id}`;
  await page.goto(editorUrl, { timeout: 30000 });
  await page.waitForTimeout(3000);
  await page.screenshot({ path: '/tmp/explore-1.png' });
  console.log('   ✓ 截图: /tmp/explore-1.png');
  
  // === 查找章节（来源：sidebar.js 已验证） ===
  console.log('\n5. 查找第41章...');
  const result = await sidebar.findChapter(page, '第四十一章');
  
  if (result.found) {
    console.log(`   ✓ 找到: ${result.text}`);
    await page.waitForTimeout(3000);
    await page.screenshot({ path: '/tmp/explore-2.png' });
    
    // === 探索修改内容卡片 ===
    console.log('\n6. 探索"修改内容"卡片...');
    const cards = await page.evaluate(() => {
      const result = [];
      document.querySelectorAll('[class*="card"], [class*="message"], [class*="dialog"]').forEach(el => {
        const text = el.innerText || '';
        if (text.includes('修改内容')) {
          result.push({ text: text.substring(0, 200), class: el.className });
        }
      });
      return result;
    });
    console.log(`   ✓ 找到 ${cards.length} 个卡片`);
    await page.screenshot({ path: '/tmp/explore-cards.png' });
    
    // 保持浏览器打开
    console.log('\n浏览器保持打开，按 Ctrl+C 退出');
    await new Promise(() => {});
    
  } else {
    console.log('   ✗ 未找到第41章');
  }
});
