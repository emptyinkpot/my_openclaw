/**
 * 备份系统配置
 * 
 * 遵循 Gitee 企业级备份规范
 * 
 * 备份策略：
 * - 每次润色前自动备份原始内容
 * - 保留策略：最近7天每天一份，最近4周每周一份，最近12月每月一份
 * - 备份内容：原始章节、润色结果、配置文件、知识库
 * 
 * 目录结构：
 * backups/
 * ├── v20260314_020000/          # 版本目录（按时间戳命名）
 * │   ├── manifest.json          # 备份清单
 * │   ├── chapters/              # 章节备份
 * │   │   ├── 第1章.json
 * │   │   └── ...
 * │   ├── polish-results/        # 润色结果备份
 * │   │   ├── 第1章-polished.json
 * │   │   └── ...
 * │   ├── config/                # 配置文件备份
 * │   └── knowledge/             # 知识库备份
 * └── backup-index.json          # 备份索引
 */

module.exports = {
  // 备份根目录
  backupDir: 'backups',
  
  // 保留策略（天数）
  retention: {
    daily: 7,      // 最近7天每天一份
    weekly: 28,    // 最近4周每周一份
    monthly: 365   // 最近12月每月一份
  },
  
  // 需要备份的目录和文件
  backupTargets: {
    // 章节原始内容（最重要）
    chapters: {
      enabled: true,
      path: 'storage/chapters',
      priority: 'critical'  // critical, high, normal, low
    },
    
    // 润色结果
    polishResults: {
      enabled: true,
      path: 'storage/clipboard/polish',
      priority: 'high'
    },
    
    // 配置文件
    config: {
      enabled: true,
      files: [
        'src/config.js',
        'backup.config.js',
        'package.json'
      ],
      priority: 'normal'
    },
    
    // 知识库
    knowledge: {
      enabled: true,
      path: '../../knowledge',
      priority: 'normal'
    },
    
    // 调试日志
    debugLog: {
      enabled: true,
      files: ['DEBUG_LOG.md'],
      priority: 'low'
    }
  },
  
  // 压缩配置
  compress: {
    enabled: true,
    level: 9,  // 压缩级别 1-9
    keepOriginal: false  // 压缩后是否保留原始文件
  },
  
  // 校验配置
  verify: {
    enabled: true,
    algorithm: 'md5'  // md5, sha256
  },
  
  // 自动备份触发条件
  autoBackup: {
    // 润色前备份
    beforePolish: true,
    // 批量操作前备份（超过3章）
    beforeBatch: true,
    // 配置变更后备份
    afterConfigChange: true
  },
  
  // 告警配置
  alert: {
    // 备份失败时告警
    onFailure: true,
    // 磁盘空间不足时告警（剩余空间 < 1GB）
    onLowDiskSpace: true,
    lowDiskThreshold: 1024 * 1024 * 1024  // 1GB
  }
};
