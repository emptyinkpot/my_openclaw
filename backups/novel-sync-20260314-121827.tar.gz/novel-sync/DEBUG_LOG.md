<!--
文档元数据
- 文件名: DEBUG_LOG.md
- 用途: 记录所有问题和解决方案，作为调试知识库
- 触发更新: 问题解决（解决问题后必须更新）
- 检查方式: 自动（pre-commit 检查）
- 最后更新: 2024-01-15
- 更新者: AI
- 关联文件: 所有文件
- 优先级: 🔴 高（必须维护）
-->

# 调试日志

> 记录所有问题和解决方案，按时间倒序排列
> 
> **⚠️ 强制维护**：解决问题后必须更新本文档
> 
> **📖 参考文档**：`docs/Bug诊断方法论.md`、`docs/经验积累机制.md`

---

## 调试流程（强制执行）

```
1. 查知识库 → DEBUG_LOG.md, docs/已验证代码库.md
2. 用调试工具 → src/utils/debugger.js
3. 最小改动 → 只添加，不修改
4. 立即测试 → 改完马上测
5. 更新记录 → 成功/失败都记录
```

---

## 调试工具模块

> **位置**：`src/utils/debugger.js`
> 
> **功能**：统一调试工具，避免重复造轮子

### 快速使用

```javascript
const { Debugger, quickDiagnose, savePolishCache, loadPolishCache } = require('../../src/utils/debugger');

// 1. 快速诊断页面（一步获取页面状态）
const diagnosis = await quickDiagnose(page, 'baimeng');
console.log(diagnosis);
// { url, title, dom: { editors, buttons, inputs }, storage: { localStorage, cookies }, screenshot }

// 2. 探查元素
const debug = new Debugger({ namespace: 'my-task' });
const elementInfo = await debug.probeElement(page, '.Daydream');
console.log(elementInfo);
// { found: true, tag, text, visible, disabled, classes, attributes, boundingBox }

// 3. 保存中间结果（避免重复操作）
debug.saveCache('step-1-result', { content, title });
const cached = debug.loadCache('step-1-result');

// 4. 润色结果缓存（专用）
savePolishCache(66, polishResult);  // 保存第66章润色结果
const cached = loadPolishCache(66);   // 加载缓存
clearPolishCache();                    // 清除所有

// 5. 记录错误
debug.recordError(error, { url: page.url(), selector: '.Daydream' });
```

### 调试器方法

| 方法 | 功能 | 返回值 |
|------|------|--------|
| `diagnosePage(page)` | 诊断页面状态 | `{ url, dom, storage, screenshot }` |
| `probeElement(page, selector)` | 探查元素 | `{ found, tag, text, visible, ... }` |
| `findElementsWithText(page, text)` | 查找包含文本的元素 | `[{ tag, text, xpath }]` |
| `saveCache(key, data)` | 保存缓存 | 文件路径 |
| `loadCache(key)` | 加载缓存 | 数据或 null |
| `clearCache(pattern)` | 清除缓存 | 清除数量 |
| `recordError(error, context)` | 记录错误 | 文件路径 |
| `getLogs(options)` | 获取日志 | 日志数组 |

### 缓存目录结构

```
/tmp/openclaw/debug/
├── {namespace}/
│   ├── debug.log        # 日志文件
│   ├── cache/           # 缓存目录
│   │   ├── chapter-66.json
│   │   └── step-1-result.json
│   ├── errors/          # 错误记录
│   │   └── 1234567890.json
│   └── *.png            # 截图
```

---

## 五步诊断法

```
Step 1: 现象确认（What）
  - 问题发生的具体场景？
  - 预期结果 vs 实际结果？
  - 错误信息是什么？

Step 2: 定位范围（Where）
  - 哪个模块？哪个函数？哪行代码？

Step 3: 根因分析（Why）
  - 直接原因是什么？
  - 根本原因是什么？（5个为什么）

Step 4: 解决方案（How）
  - 解决方案是什么？
  - 是否需要同步修改其他地方？

Step 5: 经验总结（Learn）
  - 教训是什么？
  - 如何避免类似问题？
```

---

## 问题记录

### [编辑器问题] getContent 包含工具栏文字

**时间**: 2024-03-14

**现象**:
- 场景：润色后替换正文，再获取正文发现包含"章节概要"等工具栏文字
- 预期：只获取正文内容
- 实际：getContent 返回 "章节概要\n批量生成概要\n正文..."
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：getContent 返回的内容开头有工具栏按钮文字
2. Step 2 - 定位范围：
   - 模块：`src/platforms/baimeng/editor.js`
   - 函数：`getContent()`
   - 行号：原代码 `return editor?.innerText || '';`
3. Step 3 - 根因分析：
   - 直接原因：`.Daydream innerText` 包含所有子元素的文本
   - 根本原因：编辑器结构是 `.Daydream > (toolbar + p + p + ...)`，toolbar 在同一个父元素下
   - 5 Why：
     - 为什么包含工具栏？因为 innerText 获取所有子元素
     - 为什么工具栏在编辑器内？ProseMirror 设计如此
     - 为什么之前没发现？之前没有工具栏或没注意
4. Step 4 - 解决方案：只获取直接子元素 `<p>` 标签

**解决方案**:
```javascript
// ❌ 错误：获取所有子元素文本
return editor?.innerText || '';

// ✅ 正确：只获取直接子元素 p 标签
const paragraphs = editor.querySelectorAll(':scope > p');
return Array.from(paragraphs).map(p => p.innerText || '').join('\n\n');
```

**关键点**:
- `:scope > p` 只选择直接子元素
- ProseMirror 编辑器结构复杂，工具栏和正文在同一父元素下

**教训**: 富文本编辑器的 innerText 可能包含非正文内容，需要精确选择器

**预防措施**: 遇到编辑器内容操作，先分析 DOM 结构，不要假设 innerText 就是正文

---

### [编辑器问题] setContent 段落黏在一起

**时间**: 2024-03-14

**现象**:
- 场景：润色后替换正文，所有内容在一个段落里
- 预期：多个段落，段落之间有间隔
- 实际：所有内容在一个 `<p>` 标签里，没有换行
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：正文显示为一个整块，段落间没有空行
2. Step 2 - 定位范围：
   - 模块：`src/platforms/baimeng/editor.js`
   - 函数：`setContent()`
   - 行号：原代码直接设置 innerHTML
3. Step 3 - 根因分析：
   - 直接原因：直接把内容放进一个 `<p>` 标签
   - 根本原因：没有按段落分割内容
   - 5 Why：
     - 为什么段落黏在一起？没有按 `\n\n` 分割
     - 为什么没分割？原代码假设内容已经是 HTML 格式
     - 实际是什么格式？润色结果是纯文本，用 `\n\n` 分隔段落
4. Step 4 - 解决方案：按双换行分割，每个段落一个 `<p>` 标签

**解决方案**:
```javascript
// ❌ 错误：直接设置 innerHTML
editor.innerHTML = `<p>${text}</p>`;

// ✅ 正确：按段落分割
const paragraphs = text.split(/\n\n+/);  // 双换行分隔
for (const para of paragraphs) {
  const p = document.createElement('p');
  // 处理段落内的单换行
  const lines = para.split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (i > 0) p.appendChild(document.createElement('br'));
    p.appendChild(document.createTextNode(lines[i]));
  }
  editor.appendChild(p);
}
```

**关键点**:
- 段落分隔符：`\n\n`（双换行）
- 行内换行：`\n` → `<br>`
- 每个 `<p>` 是一个段落块

**教训**: 设置富文本编辑器内容时，需要正确理解内容格式和编辑器结构

**预防措施**: setContent 前先打印内容格式，确认分隔符

---

### [润色流程] 调试时反复重新润色导致输入变化

**时间**: 2024-03-14

**现象**:
- 场景：调试润色+替换流程，每次都要重新润色
- 问题：润色结果有随机性，每次结果不同，难以定位后续问题
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：每次运行脚本都要等待润色，且结果不同
2. Step 2 - 定位范围：
   - 模块：`tasks/baimeng/polish-and-replace.js`
   - 问题：没有缓存机制
3. Step 3 - 根因分析：
   - 直接原因：每次都调用润色流程
   - 根本原因：没有保存成功的中间结果
4. Step 4 - 解决方案：添加中间结果缓存

**解决方案**:
```javascript
// 润色成功后立即保存到临时文件
const cachePath = `/tmp/polish-result-${chapterNum}.json`;
if (result.success) {
  fs.writeFileSync(cachePath, JSON.stringify(result));
}

// 后续步骤优先使用缓存
if (fs.existsSync(cachePath)) {
  console.log('📝 发现已保存的润色结果，直接使用（使用 --force 强制重新润色）');
  return JSON.parse(fs.readFileSync(cachePath));
}
```

**关键点**:
- 中间结果保存到 `/tmp/` 目录（临时文件）
- 提供清除缓存的方式（删除文件或 `--force` 参数）
- 日志提示用户可以强制重新润色

**案例**: 2024-03-15 执行时发现缓存导致跳过润色，删除 `/tmp/polish-result-*.json` 后重新运行正常

---

### [缓存问题] 旧缓存导致流程异常

**时间**: 2024-03-15

**现象**:
- 场景：运行润色+替换流程
- 问题：日志显示 "(使用缓存)" 但缓存是之前测试时的结果
- 频率：偶发

**诊断过程**:
1. Step 1 - 现象确认：润色步骤被跳过，使用了旧缓存
2. Step 2 - 定位范围：缓存清理不彻底
3. Step 3 - 根因分析：
   - 直接原因：`/tmp/polish-result-*.json` 文件存在
   - 根本原因：上次运行后没有清理缓存
4. Step 4 - 解决方案：重新润色前清理缓存

**解决方案**:
```bash
# 删除所有润色缓存
rm -f /tmp/polish-result-*.json

# 再运行脚本
node tasks/baimeng/polish-and-replace.js "作品名" 章节号
```

**关键点**:
- 缓存文件路径：`/tmp/polish-result-{章节号}.json`
- 每次重新润色前必须清理
- 可以用通配符批量清理

**教训**: 缓存机制虽然方便调试，但会导致流程异常

**预防措施**: 添加 `--force` 参数或 `--clean-cache` 命令自动清理

**教训**: 有随机性的操作，必须保存成功的中间结果，避免反复重试

**预防措施**: 
- 润色成功后立即保存
- 后续测试优先使用缓存
- 提供 `--force` 参数强制重新润色

---

### [规范执行] AI 未遵守编码规范模板（复制使用）

```markdown
### [分类] 问题标题

**时间**: YYYY-MM-DD HH:MM

**现象**:
- 场景：[具体场景]
- 预期：[预期结果]
- 实际：[实际结果]
- 错误：[错误信息]
- 频率：[必现/偶现/条件]

**诊断过程**:
1. Step 1 - 现象确认：[内容]
2. Step 2 - 定位范围：
   - 模块：[模块名]
   - 函数：[函数名]
   - 行号：[行号]
3. Step 3 - 根因分析：
   - 直接原因：[原因]
   - 根本原因：[原因]
   - 5 Why 分析：[分析过程]
4. Step 4 - 解决方案：[方案]

**解决方案**:
```javascript
// 修复代码
```

**关键点**:
- [要点1]
- [要点2]

**教训**: [一句话总结]

**预防措施**: [如何避免]

**关联问题**: #[编号]
```

---

## 常见问题速查

| 症状 | 可能原因 | 解决方向 |
|------|----------|----------|
| 页面白屏 | 登录状态未生效 | localStorage后刷新页面 |
| 滚动无效 | 元素没有焦点 | 先点击获取焦点 |

---

### [润色流程] 润色结果提取失败

**时间**: 2024-03-14

**现象**:
- 场景：润色完成后提取正文，结果为空或包含页面配置信息
- 预期：只提取润色后的正文内容
- 实际：提取到"润色结果将显示在这里"或"处理配置"等内容
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：
   - 润色成功（进度条走完）
   - 但提取结果为空或包含垃圾内容
2. Step 2 - 定位范围：
   - 模块：`tasks/baimeng/polish-chapter.js`
   - 函数：提取润色结果的 page.evaluate
3. Step 3 - 根因分析：
   - 直接原因：提取逻辑假设有"标题"/"正文"标记
   - 实际情况：润色网站直接输出正文，没有标记
   - 页面结构：`输出结果\nXXX 字\n复制\n正文内容...\n替换记录`
4. Step 4 - 解决方案：简化提取逻辑

**解决方案**:
```javascript
// ❌ 错误：假设有标题/正文标记
if (lines[i].trim() === '标题') { ... }
if (lines[i].trim() === '正文') { ... }

// ✅ 正确：跳过前缀行，直接提取正文
let lines = rawContent.split('\n');
// 跳过"输出结果"、"XXX 字"、"复制"
let i = 0;
while (i < lines.length) {
  const t = lines[i].trim();
  if (t === '输出结果' || t.match(/^\d+\s*字$/) || t === '复制') {
    i++;
    continue;
  }
  break;
}
// 剩余的就是正文
const content = lines.slice(i).join('\n').trim();
```

**关键点**:
- 润色网站不输出标题，只输出正文
- 前缀行固定：`输出结果` → `XXX 字` → `复制` → 正文
- 结束标记：`替换记录`

**教训**: 不要假设页面结构，先打印完整内容再写提取逻辑

**预防措施**: 用 debug 脚本先打印页面完整内容，确认格式

---

### [润色流程] 润色按钮 disabled 无法点击

**时间**: 2024-03-14

**现象**:
- 场景：粘贴内容后点击润色按钮
- 预期：按钮可点击，开始润色
- 实际：按钮 disabled，点击超时
- 错误：`Timeout 30000ms exceeded... element is not enabled`
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：按钮存在但 disabled
2. Step 2 - 定位范围：按钮状态检测时机
3. Step 3 - 根因分析：
   - 直接原因：检测按钮状态时，内容还没粘贴
   - 根本原因：代码顺序错误
   - 5 Why：
     - 为什么按钮 disabled？textarea 没有内容
     - 为什么没内容？检测在粘贴之前
     - 为什么顺序错误？复制代码时位置搞错
4. Step 4 - 解决方案：调整顺序，先粘贴再检测

**解决方案**:
```javascript
// ❌ 错误：先检测按钮，再粘贴内容
const btnInfo = await checkButton();
await textarea.fill(content);  // 粘贴在检测之后

// ✅ 正确：先粘贴内容，再检测按钮
await textarea.fill(content);  // 粘贴在检测之前
await page.waitForTimeout(2000);
const btnInfo = await checkButton();
```

**关键点**:
- 润色按钮状态依赖 textarea 内容
- 内容为空时按钮 disabled
- 填充内容后需要等待状态更新

**教训**: 按钮状态可能依赖其他元素，操作顺序很重要

**预防措施**: 交互式按钮的操作，先确保前置条件完成

---

### [润色流程] 进度条检测逻辑不完整

**时间**: 2024-03-14

**现象**:
- 场景：等待润色完成
- 预期：等待进度条出现再消失
- 实际：直接判断"分段处理"存在，可能润色还没开始就退出
- 频率：偶现

**诊断过程**:
1. Step 1 - 现象确认：有时进度条还没出现就判断完成
2. Step 2 - 定位范围：进度条等待逻辑
3. Step 3 - 根因分析：
   - 直接原因：`while (hasProgress)` 假设进度条已存在
   - 根本原因：没有先等待进度条出现
4. Step 4 - 解决方案：两阶段等待

**解决方案**:
```javascript
// ❌ 错误：假设进度条已存在
while (hasProgress && count < 100) {
  hasProgress = await checkProgress();
}

// ✅ 正确：先等待出现，再等待消失
// 阶段1：等待进度条出现
let foundProgress = false;
for (let i = 0; i < 20; i++) {
  await page.waitForTimeout(3000);
  foundProgress = await checkProgress();
  if (foundProgress) break;
}
if (!foundProgress) {
  console.log('❌ 未检测到进度条');
  return;
}

// 阶段2：等待进度条消失
let hasProgress = true;
while (hasProgress && count < 100) {
  await page.waitForTimeout(3000);
  hasProgress = await checkProgress();
}
```

**关键点**:
- 进度条检测分两阶段：出现 → 消失
- 出现阶段超时要报错
- 消失阶段要限制最大次数

**教训**: 状态检测要考虑完整生命周期

**预防措施**: 所有状态检测都按"出现→消失"模式处理

---

### [编辑器问题] setContent 不生效

**时间**: 2024-03-14

**现象**:
- 场景：润色后替换正文到白梦编辑器
- 预期：正文被替换
- 实际：正文没变化，或变成空
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：setContent 调用成功但内容未更新
2. Step 2 - 定位范围：
   - 模块：`src/platforms/baimeng/editor.js`
   - 函数：`setContent()`
3. Step 3 - 根因分析：
   - 直接原因：ProseMirror 编辑器不响应 innerHTML 赋值
   - 根本原因：document.execCommand 方式对 ProseMirror 无效
   - 实际情况：需要直接操作 DOM
4. Step 4 - 解决方案：直接清空并重建段落

**解决方案**:
```javascript
// ❌ 错误：使用 execCommand
editor.focus();
document.execCommand('selectAll');
document.execCommand('insertText', false, text);

// ❌ 错误：直接设置 innerHTML（ProseMirror 不响应）
editor.innerHTML = `<p>${text}</p>`;

// ✅ 正确：直接 DOM 操作
const editor = document.querySelector('.Daydream');
editor.innerHTML = '';  // 清空

const paragraphs = text.split('\n');
for (const p of paragraphs) {
  if (p.trim()) {
    const pEl = document.createElement('p');
    pEl.textContent = p;
    editor.appendChild(pEl);
  }
}
```

**关键点**:
- 白梦使用 ProseMirror 编辑器
- ProseMirror 有自己的状态管理，不响应 execCommand
- 直接 DOM 操作可以绕过 ProseMirror 的限制
- 设置后需要保存才能持久化

**教训**: 富文本编辑器有特殊的操作方式，需要测试验证

**预防措施**: 编辑器操作后立即验证内容是否生效

---

### [数据安全] 润色失败导致章节内容丢失

**时间**: 2024-03-14

**现象**:
- 场景：润色脚本出错
- 问题：第4章、第5章、第6章内容被清空或覆盖
- 频率：调试期间多次发生

**诊断过程**:
1. Step 1 - 现象确认：章节内容长度为0或变成垃圾内容
2. Step 2 - 定位范围：脚本流程
3. Step 3 - 根因分析：
   - 直接原因：setContent 在提取失败时仍然执行
   - 根本原因：没有验证润色结果就替换
4. Step 4 - 解决方案：添加验证和恢复机制

**解决方案**:
```javascript
// 1. 润色前备份
const backupDir = '/tmp/openclaw/backups';
fs.writeFileSync(`${backupDir}/${chapterName}_备份_${Date.now()}.txt`, content);

// 2. 验证润色结果
if (!polished.content || polished.content.length < 100) {
  console.log('❌ 润色结果无效，跳过替换');
  return;
}

// 3. 提供恢复脚本
// 读取备份文件，恢复到白梦
```

**关键点**:
- 每次操作前自动备份
- 验证中间结果再继续
- 保留恢复途径

**教训**: 自动化脚本必须考虑失败场景，防止数据丢失

**预防措施**: 
- 所有修改操作前备份
- 中间步骤验证
- 提供恢复命令

**关联问题**: 第4章、第5章、第6章内容被清空，需要手动恢复
| 点击无效 | 元素被遮挡 | 使用JS的click() |
| 元素找不到 | 选择器错误 | 探测页面，更新选择器 |
| 数据为空 | 获取方式错误 | 检查选择器和数据源 |
| 超时失败 | 等待时间不足 | 增加等待时间 |

---

## 问题分类索引

| 分类 | 问题数 | 最后更新 |
|------|--------|----------|
| 登录问题 | 2 | 2024-01 |
| 滚动问题 | 2 | 2024-01 |
| 点击问题 | 2 | 2024-01 |
| 代码精简 | 1 | 2024-01 |
| 代码重构 | 1 | 2024-01 |
| 编辑器问题 | 2 | 2024-03 |

---

## 问题记录

### [编辑器问题] getContent 包含工具栏文字

**时间**: 2024-03-14

**现象**:
- 场景：润色后替换正文，再获取正文发现包含"章节概要"等工具栏文字
- 预期：只获取正文内容
- 实际：getContent 返回 "章节概要\n批量生成概要\n正文..."
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：getContent 返回的内容开头有工具栏按钮文字
2. Step 2 - 定位范围：
   - 模块：`src/platforms/baimeng/editor.js`
   - 函数：`getContent()`
   - 行号：原代码 `return editor?.innerText || '';`
3. Step 3 - 根因分析：
   - 直接原因：`.Daydream innerText` 包含所有子元素的文本
   - 根本原因：编辑器结构是 `.Daydream > (toolbar + p + p + ...)`，toolbar 在同一个父元素下
   - 5 Why：
     - 为什么包含工具栏？因为 innerText 获取所有子元素
     - 为什么工具栏在编辑器内？ProseMirror 设计如此
     - 为什么之前没发现？之前没有工具栏或没注意
4. Step 4 - 解决方案：只获取直接子元素 `<p>` 标签

**解决方案**:
```javascript
// ❌ 错误：获取所有子元素文本
return editor?.innerText || '';

// ✅ 正确：只获取直接子元素 p 标签
const paragraphs = editor.querySelectorAll(':scope > p');
return Array.from(paragraphs).map(p => p.innerText || '').join('\n\n');
```

**关键点**:
- `:scope > p` 只选择直接子元素
- ProseMirror 编辑器结构复杂，工具栏和正文在同一父元素下

**教训**: 富文本编辑器的 innerText 可能包含非正文内容，需要精确选择器

**预防措施**: 遇到编辑器内容操作，先分析 DOM 结构，不要假设 innerText 就是正文

---

### [编辑器问题] setContent 段落黏在一起

**时间**: 2024-03-14

**现象**:
- 场景：润色后替换正文，所有内容在一个段落里
- 预期：多个段落，段落之间有间隔
- 实际：所有内容在一个 `<p>` 标签里，没有换行
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：正文显示为一个整块，段落间没有空行
2. Step 2 - 定位范围：
   - 模块：`src/platforms/baimeng/editor.js`
   - 函数：`setContent()`
   - 行号：原代码直接设置 innerHTML
3. Step 3 - 根因分析：
   - 直接原因：直接把内容放进一个 `<p>` 标签
   - 根本原因：没有按段落分割内容
   - 5 Why：
     - 为什么段落黏在一起？没有按 `\n\n` 分割
     - 为什么没分割？原代码假设内容已经是 HTML 格式
     - 实际是什么格式？润色结果是纯文本，用 `\n\n` 分隔段落
4. Step 4 - 解决方案：按双换行分割，每个段落一个 `<p>` 标签

**解决方案**:
```javascript
// ❌ 错误：直接设置 innerHTML
editor.innerHTML = `<p>${text}</p>`;

// ✅ 正确：按段落分割
const paragraphs = text.split(/\n\n+/);  // 双换行分隔
for (const para of paragraphs) {
  const p = document.createElement('p');
  // 处理段落内的单换行
  const lines = para.split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (i > 0) p.appendChild(document.createElement('br'));
    p.appendChild(document.createTextNode(lines[i]));
  }
  editor.appendChild(p);
}
```

**关键点**:
- 段落分隔符：`\n\n`（双换行）
- 行内换行：`\n` → `<br>`
- 每个 `<p>` 是一个段落块

**教训**: 设置富文本编辑器内容时，需要正确理解内容格式和编辑器结构

**预防措施**: setContent 前先打印内容格式，确认分隔符

---

### [润色流程] 调试时反复重新润色导致输入变化

**时间**: 2024-03-14

**现象**:
- 场景：调试润色+替换流程，每次都要重新润色
- 问题：润色结果有随机性，每次结果不同，难以定位后续问题
- 频率：必现

**诊断过程**:
1. Step 1 - 现象确认：每次运行脚本都要等待润色，且结果不同
2. Step 2 - 定位范围：
   - 模块：`tasks/baimeng/polish-and-replace.js`
   - 问题：没有缓存机制
3. Step 3 - 根因分析：
   - 直接原因：每次都调用润色流程
   - 根本原因：没有保存成功的中间结果
4. Step 4 - 解决方案：添加中间结果缓存

**解决方案**:
```javascript
// 润色成功后立即保存到临时文件
const cachePath = `/tmp/polish-result-${chapterNum}.json`;
if (result.success) {
  fs.writeFileSync(cachePath, JSON.stringify(result));
}

// 后续步骤优先使用缓存
if (fs.existsSync(cachePath)) {
  console.log('📝 发现已保存的润色结果，直接使用（使用 --force 强制重新润色）');
  return JSON.parse(fs.readFileSync(cachePath));
}
```

**关键点**:
- 中间结果保存到 `/tmp/` 目录（临时文件）
- 提供清除缓存的方式（删除文件或 `--force` 参数）
- 日志提示用户可以强制重新润色

**教训**: 有随机性的操作，必须保存成功的中间结果，避免反复重试

**预防措施**: 
- 润色成功后立即保存
- 后续测试优先使用缓存
- 提供 `--force` 参数强制重新润色

---

### [规范执行] AI 未遵守编码规范

### [规范执行] AI 未遵守编码规范

**时间**: 2024-01-15

**现象**:
- AI 直接写代码，不读取规范文件
- AI 自己创建新脚本，不复用已验证模块
- AI 多次犯同样错误

**根本原因**:
- 没有形成强制习惯
- 规范只存在于文档中，AI 未在每次任务时读取

**解决方案**:
1. 创建 `src/utils/task-runner.js` 强制入口函数
2. 所有脚本必须使用 `runTask()` 作为入口
3. 创建 `scripts/check-compliance.js` 检查脚本
4. 更新 `docs/用户教导记录.md` 添加强制行为模式

**关键代码**:
```javascript
const { runTask } = require('./src/utils/task-runner');

runTask('任务名称', async (ctx) => {
  // 任务逻辑
});
```

**教训**: 规范必须有代码层面的强制执行机制，不能依赖自觉

**预防措施**: 
- 每次任务开始时调用 write_todos，第一项固定为「读取规范文件」
- 所有脚本必须通过 `runTask()` 入口
- 用户可运行 `node scripts/check-compliance.js` 检查

---

### [登录问题] 页面白屏

**时间**: 2024-01-XX

**现象**: 设置localStorage后页面显示白屏

**原因**: localStorage设置后登录状态未生效

**解决方案**: 
```javascript
await page.evaluate((items) => {
  for (const [k, v] of Object.entries(items)) localStorage.setItem(k, v);
}, backup.localStorage);
await page.reload();  // 关键：必须刷新！
```

**教训**: localStorage修改后必须刷新页面

---

### [滚动问题] 侧边栏滚动无效

**时间**: 2024-01-XX

**现象**: `mouse.wheel()` 不生效，列表不滚动

**原因**: 侧边栏没有焦点

**解决方案**:
```javascript
await page.mouse.click(sidebarPos.x, sidebarPos.y);  // 先点击获取焦点
await page.waitForTimeout(300);
await page.mouse.wheel(0, 100);  // 再滚动
```

**教训**: 任何区域滚动前都要先点击获取焦点

---

### [滚动问题] 主内容区滚动无效

**时间**: 2024-01-XX

**现象**: 主内容区无法滚动查看完整内容

**原因**: 与侧边栏同理，需要先点击获取焦点

**解决方案**:
```javascript
// 获取主内容区位置
const mainPos = await page.evaluate(() => {
  const main = document.querySelector('main') || document.querySelector('[class*="editor"]');
  const rect = main.getBoundingClientRect();
  return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
});

// 点击获取焦点
await page.mouse.click(mainPos.x, mainPos.y);
await page.waitForTimeout(500);

// 然后滚动
await page.mouse.wheel(0, 200);
```

**教训**: 与侧边栏滚动逻辑一致

---

### [点击问题] 点击章节打开其他页面

**时间**: 2024-01-XX

**现象**: 点击章节后打开了错误的内容

**原因**: 点击到了文件夹而不是文件

**解决方案**:
```javascript
// 检查是否是文件夹
const hasArrow = item.querySelector('[class*="chevron"]') || 
                item.querySelector('[class*="arrow"]') ||
                item.querySelector('svg');
if (!hasArrow) {
  item.click();  // 只有文件才点击
}
```

**教训**: 文件夹有箭头图标，需要排除

---

### [点击问题] 点击无效

**时间**: 2024-01-XX

**现象**: `mouse.click()` 点击无效果

**原因**: 元素被遮挡或不可点击

**解决方案**:
```javascript
// 使用JS的click()而不是mouse.click()
item.click();  // 在evaluate内部直接调用
```

**教训**: 复杂页面优先用 `el.click()`

---

### [代码精简] numToChinese错误

**时间**: 2024-01-XX

**现象**: 42变成"四二"而不是"四十二"

**原因**: 精简代码时丢失了units单位

**错误代码**:
```javascript
// 错误！丢失了单位
const digits = ['', '一', '二', '三', '四', ...];
let result = '', n = num;
while (n > 0) {
  result = digits[n % 10] + result;  // 没有 units
  n = Math.floor(n / 10);
}
```

**正确代码**:
```javascript
const digits = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
const units = ['', '十', '百'];  // 必须有单位！
let result = '', n = num, unitIndex = 0;
while (n > 0) {
  const digit = n % 10;
  if (digit > 0) result = digits[digit] + units[unitIndex] + result;
  n = Math.floor(n / 10);
  unitIndex++;
}
```

**教训**: 
- 能跑的代码不要动！
- 不要随意"精简"已验证的代码

---

### [代码重构] 模块化拆分

**时间**: 2024-01-XX

**目标**: 将白梦功能拆分成可复用模块

**步骤**:
1. 创建 `src/platforms/baimeng/` 目录
2. 按功能拆分模块：auth, works, sidebar, content, copy, browser
3. 保持入口脚本不变
4. 测试验证

**结果**: ✅ 成功

**新的目录结构**:
```
src/platforms/baimeng/
├── index.js        # 统一入口
├── auth.js         # 登录模块
├── works.js        # 作品模块
├── sidebar.js      # 侧边栏模块
├── content.js      # 主内容区模块
├── copy.js         # 复制模块
└── browser.js      # 浏览器模块
```

**教训**:
- 模块化要从已验证代码复制，不要重写
- 拆分后立即测试
- 保持入口脚本简单

---

## 经验总结

### 核心原则

1. **不要修改已工作的代码**
2. **滚动前必须点击获取焦点**
3. **localStorage后必须刷新页面**
4. **文件夹有箭头，需要排除**
5. **等待时间不能随意减少**

### 调试技巧

1. 截图保存：`page.screenshot({ path: 'debug.png' })`
2. 打印页面信息：`console.log(await page.evaluate(() => document.body.innerText))`
3. 保持浏览器打开：`await new Promise(() => {})`

---

## 2024-01-15: 代码优化框架建立

### 任务
建立代码优化框架，确保所有代码优化严格遵循稳定性优先、最小改动、渐进优化、可回滚原则。

### 创建文件
1. `docs/代码优化框架.md` - 优化规范文档
2. `scripts/optimization.sh` - 优化检查脚本
3. `scripts/benchmark.js` - 性能基准测试工具

### 核心原则
- 稳定性优先 - 能跑的代码不要动
- 最小改动 - 只修改必要的部分
- 渐进优化 - 一次只优化一个方面
- 可回滚 - 优化前必须创建回滚点

### 集成
- 更新 `PROJECT_STANDARDS.md` 添加代码优化流程章节
- 更新 `package.json` 添加优化相关命令

### 验证
- 性能基准测试通过
- 优化前检查脚本工作正常

---

## 2024-01-15: 框架体系完善与统一入口建立

### 任务
建立完整的框架体系，确保所有框架相互配合，形成完整的强制执行机制。

### 问题
原有框架各自独立，缺乏统一入口，框架之间配合不够紧密，强制执行机制不够完善。

### 解决方案

#### 1. 创建统一任务入口
- 文件: `scripts/task.sh`
- 功能: 自动识别任务类型，选择正确的流程
- 任务类型: 新功能开发、问题调试、代码优化、代码重构、文档维护、完整检查

#### 2. 创建框架配合关系文档
- 文件: `FRAMEWORK.md`
- 内容: 框架架构图、框架清单、配合矩阵、强制检查链

#### 3. 完善项目规范
- 更新 `PROJECT_STANDARDS.md`
- 添加三层强制执行机制
- 明确任务类型与流程映射

#### 4. 增强强制执行
- 更新 `.githooks/pre-commit`
- 添加 FRAMEWORK.md 检查

#### 5. 更新命令索引
- 更新 `package.json`
- 添加 task:* 系列命令

### 框架体系架构

```
┌─────────────────────────────────────────────────────────────┐
│                      统一入口层                              │
│                   scripts/task.sh                           │
│            (任务类型识别 → 流程选择 → 强制执行)              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                      流程控制层                              │
│  dev-flow.sh | diagnose.sh | optimization.sh | doc-check.sh │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                      知识库层                                │
│  已验证代码库 | 用户教导记录 | DEBUG_LOG | 元素选择器        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│                      强制执行层                              │
│      enforce.sh | sync-check.sh | .githooks/pre-commit      │
└─────────────────────────────────────────────────────────────┘
```

### 三层强制执行

1. **Layer 1: 任务入口层** - 无法跳过
   - 强制执行前置检查
   - 强制阅读知识库
   - 强制选择正确流程

2. **Layer 2: 流程执行层** - 可跳过但不推荐
   - 强制执行流程步骤
   - 强制验证
   - 强制更新文档

3. **Layer 3: Git 提交层** - 紧急可跳过
   - 强制检查同步性
   - 强制检查文档完整性
   - 强制检查编码规范

### 核心原则
- 所有任务必须通过 `source scripts/task.sh` 开始
- 框架之间相互配合，形成完整链条
- 强制执行机制确保规范被遵守

### 验证
- 统一入口脚本工作正常
- 完整检查流程通过（除锁定文件检测外）
- 所有核心文件已创建

---

## 2024-01-15: 垃圾文件清理

### 任务
按照框架体系，清理重复、过时、冗余的文件，确保项目整洁。

### 清理原则
1. 不影响现有功能
2. 删除与其他文档重复的内容
3. 删除过时的进度文档
4. 清理临时日志文件

### 删除的文件

| 文件 | 原因 | 替代方案 |
|------|------|----------|
| `DEBUG_WORKFLOW.md` | 与 PROJECT_STANDARDS.md 调试流程重复 | 使用 PROJECT_STANDARDS.md |
| `QUICK_REFERENCE.md` | 与 docs/白梦快速参考.md 和 task.sh reference 重复 | 使用 task.sh reference |
| `MAINTENANCE.md` | 与 PROJECT_STANDARDS.md 维护流程重复 | 使用 PROJECT_STANDARDS.md |
| `docs/目录结构.md` | 过时，PROJECT_STANDARDS.md 已有 | 使用 PROJECT_STANDARDS.md |
| `docs/自完善调试架构.md` | 与 FRAMEWORK.md 重复 | 使用 FRAMEWORK.md |
| `docs/功能开发进度.md` | 过时的进度文档 | 无需替代 |
| `.sync-check.log` | 临时日志 | 自动生成 |
| `.task.log` | 临时日志 | 自动生成 |

### 保留的文件

| 文件 | 原因 |
|------|------|
| `docs/通用经验.md` | 内容有价值，保留作为参考 |

### 更新的文件

| 文件 | 更新内容 |
|------|----------|
| `PROJECT_STANDARDS.md` | 移除对删除文件的引用 |
| `README.md` | 更新项目结构，移除对删除文件的引用 |
| `docs/文档维护规范.md` | 更新文档列表，移除对删除文件的引用 |

### 清理效果

- 文档数量：15 → 12（减少 3 个）
- 文档总行数：4386 → 3335（减少 1051 行）
- 项目结构更清晰，减少维护负担

### 验证
- ✅ 功能验证通过（3/3）
- ✅ 文档检查通过（5/5）
- ✅ 同步检查通过（6/6）
- ✅ 性能基准测试通过（5/5）

---

## 2024-01-15: 浏览器窗口最大化修复

### 问题
Coze 实时浏览器预览中，浏览器窗口没有全屏显示，周围有黑色区域。

### 原因
Playwright 启动浏览器时没有设置：
1. `viewport: null` - 让浏览器自动调整视口
2. `--start-maximized` - 最大化窗口参数

### 解决方案

修改 `src/platforms/baimeng/browser.js` 和 `src/utils/browser-manager.js`：

```javascript
const browser = await chromium.launchPersistentContext(BROWSER_DATA, {
  headless: false,
  viewport: null,  // 让浏览器自动调整视口
  args: [
    '--no-sandbox',
    '--start-maximized',  // 最大化窗口
    '--disable-session-crashed-bubble',
    '--hide-crash-restore-bubble'
  ]
});
```

### 关键点
- `viewport: null` 是关键，不设置默认为固定尺寸
- `--start-maximized` 让窗口启动时最大化

### 验证
- ✅ 功能验证通过
