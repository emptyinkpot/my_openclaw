# novel-sync

番茄小说 ↔ 白梦写作 自动化工具

## 脚本索引 ⭐

**所有可用脚本和模块** → [SCRIPTS.md](SCRIPTS.md)

| 常用脚本 | 用法 | 功能 |
|----------|------|------|
| `replace-content.js` | `node replace-content.js 66` | 替换第六十六章正文 |
| `baimeng-chapter-finder.js` | `node baimeng-chapter-finder.js` | 查找章节 |
| `baimeng-copy.js` | `node baimeng-copy.js` | 复制内容 |

## 快速开始

```bash
pnpm install

# 章节查找
node baimeng-chapter-finder.js 枪与凋零之花 42

# 复制内容
node baimeng-copy.js 枪与凋零之花 1

# 功能验证
pnpm validate
```

## 项目结构

```
novel-sync/
├── package.json                 # 项目配置
├── README.md                    # 本文档
│
├── baimeng-chapter-finder.js   # 章节查找入口
├── baimeng-copy.js             # 内容复制入口
│
├── FRAMEWORK.md                # 框架体系总览 ⭐
├── PROJECT_STANDARDS.md        # 项目规范总览 ⭐
├── CODING_STANDARDS.md         # 编码规范
├── DEBUG_LOG.md                # 问题记录
│
├── docs/                       # 知识库文档
│   ├── 已验证代码库.md
│   ├── 用户教导记录.md
│   ├── 白梦操作手册.md
│   ├── 白梦快速参考.md
│   ├── 元素选择器字典.md
│   ├── 存储规范.md
│   ├── 页面分析方法论.md
│   ├── 代码优化框架.md
│   └── 通用经验.md
│
├── scripts/                    # 工具脚本
│   ├── task.sh                # 统一任务入口 ⭐
│   ├── dev-flow.sh            # 开发流程检查
│   ├── diagnose.sh            # 诊断流程
│   ├── optimization.sh        # 优化流程
│   ├── storage.sh             # 存储管理
│   ├── validate.sh            # 功能验证
│   └── ...
│
├── src/                        # 源代码
│   ├── config.js              # 统一配置
│   ├── main.js                # 主入口（标题同步）
│   ├── platforms/             # 平台模块
│   │   └── baimeng/
│   ├── tasks/                 # 任务模块
│   └── utils/                 # 工具模块
│
└── storage/                    # 数据存储
    ├── accounts/              # 账号登录状态
    └── cache/                 # 缓存数据
```

## 常用命令

```bash
# === 任务入口（推荐） ===
source scripts/task.sh              # 统一任务入口
source scripts/task.sh new-feature  # 新功能开发
source scripts/task.sh debug        # 问题调试

# === 核心功能 ===
pnpm list              # 列出作品
pnpm find              # 章节查找
pnpm copy              # 复制内容

# === 检查验证 ===
pnpm validate          # 功能验证
pnpm check:all         # 完整检查
pnpm sync              # 同步检查

# === 存储管理 ===
bash scripts/storage.sh backup baimeng 1    # 备份登录状态
bash scripts/storage.sh restore baimeng 1   # 恢复登录状态
```

## 开发规范

**所有开发必须遵循** → [PROJECT_STANDARDS.md](PROJECT_STANDARDS.md)

**框架体系** → [FRAMEWORK.md](FRAMEWORK.md)

核心原则：
1. 所有任务通过 `source scripts/task.sh` 开始
2. 查知识库 → 复用代码 → 最小改动 → 立即测试
3. 能跑的代码不要动
4. 不随意修改等待时间和选择器

## 知识库

| 文档 | 用途 |
|------|------|
| [已验证代码库](docs/已验证代码库.md) | 可复用代码片段 |
| [用户教导记录](docs/用户教导记录.md) | 用户教导反馈 |
| [白梦操作手册](docs/白梦操作手册.md) | 完整操作指南 |
| [白梦快速参考](docs/白梦快速参考.md) | 命令速查 |
| [页面分析方法论](docs/页面分析方法论.md) | 探测新页面方法 |
| [代码优化框架](docs/代码优化框架.md) | 代码优化规范 |
| [通用经验](docs/通用经验.md) | Web自动化通用技巧 |

## 测试状态

```
通过率: 3/3 (100%)
- 章节查找: ✅
- 内容复制: ✅
- 存储备份: ✅
```
