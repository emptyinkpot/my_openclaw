# 严重问题记录

---

## [已解决] 润色脚本导致章节内容丢失

### 时间
2024-03-14

### 问题
润色脚本在调试过程中，第4章、第5章、第6章内容被清空或覆盖

### 根本原因
1. **提取逻辑错误**：假设润色结果有标题/正文标记，实际没有
2. **按钮状态检测时机错误**：在粘贴内容前检测按钮，导致按钮 disabled
3. **进度条检测不完整**：没有先等待出现，直接判断消失
4. **缺少结果验证**：提取失败后仍然执行替换

### 修复方案
1. ✅ 修复提取逻辑：跳过前缀行，直接提取正文
2. ✅ 修复按钮检测：先粘贴内容，再检测按钮状态
3. ✅ 修复进度条检测：两阶段等待（出现→消失）
4. ✅ 添加结果验证：检测润色内容长度
5. ✅ 自动备份：每次润色前备份原始内容

### 恢复操作
```bash
# 查看备份文件
ls -la /tmp/openclaw/backups/

# 恢复第6章
node -e "
const baimeng = require('./src/platforms/baimeng');
const config = require('./src/config');
const fs = require('fs');

(async () => {
  const { browser, page } = await baimeng.browser.launch();
  await baimeng.auth.restoreLogin(page);
  
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, '变身咳血少女的我也要努力活下去');
  
  await page.goto(config.BAIMENG.urls.editor + '?id=' + workId);
  await page.waitForTimeout(5000);
  
  await baimeng.sidebar.findChapter(page, '第六章');
  await page.waitForTimeout(3000);
  
  const backup = fs.readFileSync('/tmp/openclaw/backups/第六章_备份_xxx.txt', 'utf8');
  // ... 解析并恢复
})();
"
```

### 教训
1. 自动化脚本必须先保存成功的中间结果
2. 每个步骤都要验证结果
3. 数据修改操作前必须备份
4. 用固定结果测试后续流程，避免反复重新润色

---

## [待用户处理] 第3章和第4章内容混乱

### 时间
2024-03-14

### 问题
| 章节 | 标题输入框 | 正文内容 |
|-----|-----------|---------|
| 第3章 | "第六章" | 第6章的内容 |
| 第4章 | "第三章：旧部下的脚步声总是这么沉重" | 第3章的内容 |

### 根本原因
1. **setTitle 逻辑不完整**：只修改了 input 框，没有修改正文第一行
2. **章节匹配错误**：点击章节时可能匹配到错误元素
3. **备份系统不完整**：没有备份白梦网站的章节内容

### 修复方案
1. ⏸️ 用户手动在白梦网站恢复第3章和第4章数据
2. ✅ 修复 setTitle：直接操作编辑器内标题 input
3. ✅ 修复 setContent：直接 DOM 操作
4. ✅ 完善备份：润色前自动备份到 /tmp/openclaw/backups/

### 状态
等待用户提供第3章和第4章的原始内容

---

## 预防措施总结

### 代码层面
1. 所有修改操作前先备份
2. 中间步骤验证结果
3. 错误时立即停止，不要继续执行
4. 有随机性的操作，保存成功的中间结果

### 流程层面
1. 单次操作验证成功后再批量执行
2. 每个步骤都有日志输出
3. 提供恢复命令或脚本

### 测试层面
1. 用 debug 脚本先验证流程
2. 用固定数据测试后续步骤
3. 确认成功后再完整运行
