/**
 * 知识库查询工具
 * 
 * 用法: 
 *   node scripts/query-knowledge.js <类型> <关键词>
 *   node scripts/query-knowledge.js --search <关键词>  # 全局搜索
 * 
 * 类型: selector, code, problem, all
 * 
 * 示例:
 *   node scripts/query-knowledge.js selector 内容
 *   node scripts/query-knowledge.js code getContent
 *   node scripts/query-knowledge.js problem 白屏
 *   node scripts/query-knowledge.js --search 登录
 */

const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.join(__dirname, '..');
const DOCS = {
  verified: path.join(ROOT_DIR, 'docs/已验证代码库.md'),
  selectors: path.join(ROOT_DIR, 'docs/元素选择器字典.md'),
  teachings: path.join(ROOT_DIR, 'docs/用户教导记录.md'),
  debug: path.join(ROOT_DIR, 'DEBUG_LOG.md')
};

// 解析参数
let type = process.argv[2];
let keyword = process.argv[3];

// 处理 --search 参数
if (type === '--search' || type === '-s') {
  type = 'all';
  keyword = process.argv[3];
}

if (!type || !keyword) {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════════╗');
  console.log('║              知识库查询工具                                ║');
  console.log('╚══════════════════════════════════════════════════════════╝');
  console.log('');
  console.log('用法:');
  console.log('  node scripts/query-knowledge.js <类型> <关键词>');
  console.log('  node scripts/query-knowledge.js --search <关键词>  # 全局搜索');
  console.log('');
  console.log('类型:');
  console.log('  selector  - 选择器查询');
  console.log('  code      - 代码查询');
  console.log('  problem   - 问题查询');
  console.log('  all       - 全部查询');
  console.log('');
  console.log('示例:');
  console.log('  node scripts/query-knowledge.js selector 内容');
  console.log('  node scripts/query-knowledge.js code getContent');
  console.log('  node scripts/query-knowledge.js problem 白屏');
  console.log('  node scripts/query-knowledge.js --search 登录');
  console.log('');
  process.exit(0);
}

function findSelector(keyword) {
  const content = fs.readFileSync(DOCS.selectors, 'utf-8');
  const lines = content.split('\n');
  const results = [];
  
  for (const line of lines) {
    if (line.includes('|') && line.toLowerCase().includes(keyword.toLowerCase())) {
      results.push(line);
    }
  }
  
  return results;
}

function findCode(keyword) {
  const content = fs.readFileSync(DOCS.verified, 'utf-8');
  const regex = new RegExp(`(###.*${keyword}[\\s\\S]*?\`\`\`javascript[\\s\\S]*?\`\`\`)`, 'gi');
  const matches = content.match(regex) || [];
  return matches;
}

function findProblem(keyword) {
  const content = fs.readFileSync(DOCS.debug, 'utf-8');
  const lines = content.split('\n');
  const results = [];
  
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].toLowerCase().includes(keyword.toLowerCase())) {
      // 获取上下文
      const start = Math.max(0, i - 2);
      const end = Math.min(lines.length, i + 10);
      results.push({
        line: i + 1,
        context: lines.slice(start, end).join('\n')
      });
    }
  }
  
  return results;
}

function findInDoc(docPath, keyword) {
  if (!fs.existsSync(docPath)) return [];
  
  const content = fs.readFileSync(docPath, 'utf-8');
  const lines = content.split('\n');
  const results = [];
  
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].toLowerCase().includes(keyword.toLowerCase())) {
      const start = Math.max(0, i - 1);
      const end = Math.min(lines.length, i + 5);
      results.push({
        line: i + 1,
        context: lines.slice(start, end).join('\n')
      });
    }
  }
  
  return results.slice(0, 10); // 限制结果数量
}

console.log('');
console.log('╔══════════════════════════════════════════════════════════╗');
console.log('║              知识库查询工具                                ║');
console.log('╚══════════════════════════════════════════════════════════╝');
console.log('');
console.log(`查询: ${type} - "${keyword}"`);
console.log('');

let results = [];
let totalResults = 0;

switch (type) {
  case 'selector':
    results = findSelector(keyword);
    console.log('=== 选择器结果 ===\n');
    results.forEach(r => console.log('  ' + r));
    totalResults = results.length;
    break;
    
  case 'code':
    results = findCode(keyword);
    console.log('=== 代码结果 ===\n');
    results.forEach((r, i) => {
      console.log(`--- 匹配 ${i + 1} ---`);
      console.log(r);
      console.log('');
    });
    totalResults = results.length;
    break;
    
  case 'problem':
    results = findProblem(keyword);
    console.log('=== 问题结果 ===\n');
    results.forEach(r => {
      console.log(`--- 第 ${r.line} 行 ---`);
      console.log(r.context);
      console.log('');
    });
    totalResults = results.length;
    break;
    
  case 'all':
  default:
    // 全局搜索
    console.log('=== 已验证代码库 ===\n');
    const codeResults = findInDoc(DOCS.verified, keyword);
    if (codeResults.length > 0) {
      codeResults.forEach(r => {
        console.log(`第 ${r.line} 行附近:`);
        console.log(r.context.split('\n').map(l => '  ' + l).join('\n'));
        console.log('');
      });
    } else {
      console.log('  无匹配结果');
    }
    totalResults += codeResults.length;
    
    console.log('\n=== 调试日志 ===\n');
    const debugResults = findInDoc(DOCS.debug, keyword);
    if (debugResults.length > 0) {
      debugResults.forEach(r => {
        console.log(`第 ${r.line} 行附近:`);
        console.log(r.context.split('\n').map(l => '  ' + l).join('\n'));
        console.log('');
      });
    } else {
      console.log('  无匹配结果');
    }
    totalResults += debugResults.length;
    
    console.log('\n=== 用户教导记录 ===\n');
    const teachingResults = findInDoc(DOCS.teachings, keyword);
    if (teachingResults.length > 0) {
      teachingResults.forEach(r => {
        console.log(`第 ${r.line} 行附近:`);
        console.log(r.context.split('\n').map(l => '  ' + l).join('\n'));
        console.log('');
      });
    } else {
      console.log('  无匹配结果');
    }
    totalResults += teachingResults.length;
    break;
}

console.log('───────────────────────────────────────────────────────────');
console.log(`共找到 ${totalResults} 个结果`);
console.log('');
