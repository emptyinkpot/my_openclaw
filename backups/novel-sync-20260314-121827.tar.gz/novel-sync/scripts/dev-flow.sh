#!/bin/bash
# 开发流程强制检查脚本
# 用法: source scripts/dev-flow.sh
# 注意: 必须用 source 执行，否则无法正常工作

NOVEL_SYNC_DIR="/workspace/projects/workspace/projects/novel-sync"
FLOW_LOG="$NOVEL_SYNC_DIR/.dev-flow.log"
VERIFIED_CODE="$NOVEL_SYNC_DIR/docs/已验证代码库.md"
USER_TEACHING="$NOVEL_SYNC_DIR/docs/用户教导记录.md"
DEBUG_LOG="$NOVEL_SYNC_DIR/DEBUG_LOG.md"

# 颜色定义（兼容不支持颜色的终端）
if [ -t 1 ]; then
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    CYAN='\033[0;36m'
    NC='\033[0m'
else
    RED=''
    GREEN=''
    YELLOW=''
    CYAN=''
    NC=''
fi

# 检查是否在正确目录
if [ ! -d "$NOVEL_SYNC_DIR" ]; then
    echo "错误: 目录不存在 $NOVEL_SYNC_DIR"
    return 2>/dev/null || exit 1
fi

# 记录日志
log_flow() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$FLOW_LOG"
}

# 检查文件是否存在并显示
check_file_read() {
    local file="$1"
    local name="$2"
    
    if [ ! -f "$file" ]; then
        echo -e "${RED}✗ 文件不存在: $file${NC}"
        return 1
    fi
    
    echo -e "${CYAN}→ 请阅读 $name ...${NC}"
    echo ""
    cat "$file"
    echo ""
    echo -e "${GREEN}✓ 已显示 $name 内容${NC}"
    log_flow "读取: $name"
}

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              开发流程强制检查                              ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# ===== Step 1: 查知识库 =====
echo -e "${YELLOW}[Step 1/5] 查知识库${NC}"
echo ""

check_file_read "$VERIFIED_CODE" "已验证代码库"
echo ""
check_file_read "$USER_TEACHING" "用户教导记录"
echo ""

echo -e "${GREEN}是否找到可复用的代码？[y/n]: ${NC}\c"
read found_code
if [ "$found_code" = "y" ]; then
    echo -e "${GREEN}复用哪个函数/代码段？: ${NC}\c"
    read code_name
    log_flow "复用代码: $code_name"
else
    log_flow "未复用代码"
fi

# ===== Step 2: 确认改动范围 =====
echo ""
echo -e "${YELLOW}[Step 2/5] 确认改动范围${NC}"
echo ""

echo -e "${GREEN}本次改动描述: ${NC}\c"
read change_desc
echo -e "${GREEN}涉及的文件: ${NC}\c"
read change_files
log_flow "改动: $change_desc | 文件: $change_files"

# ===== Step 3: 检查编码规范 =====
echo ""
echo -e "${YELLOW}[Step 3/5] 编码规范检查${NC}"
echo ""

echo "□ 不随意修改已验证代码"
echo "□ 不随意修改等待时间"
echo "□ 不随意修改选择器"
echo "□ 从已验证代码复制，不重写"
echo ""

echo -e "${GREEN}是否遵守以上规范？[y/n]: ${NC}\c"
read follow_rules
if [ "$follow_rules" != "y" ]; then
    echo -e "${RED}✗ 必须遵守编码规范，流程终止${NC}"
    log_flow "规范检查: 未通过"
    return 2>/dev/null
fi
log_flow "规范检查: 通过"

# ===== Step 4: 执行测试 =====
echo ""
echo -e "${YELLOW}[Step 4/5] 执行测试${NC}"
echo ""

echo -e "${GREEN}测试命令: ${NC}\c"
read test_cmd
log_flow "测试命令: $test_cmd"

cd "$NOVEL_SYNC_DIR"
echo -e "${CYAN}→ 执行测试...${NC}"
echo ""

# 执行测试
eval "$test_cmd"
test_result=$?

echo ""
if [ $test_result -eq 0 ]; then
    echo -e "${GREEN}✓ 测试通过${NC}"
    log_flow "测试结果: 通过"
else
    echo -e "${RED}✗ 测试失败 (退出码: $test_result)${NC}"
    log_flow "测试结果: 失败 (退出码: $test_result)"
fi

# ===== Step 5: 更新知识库 =====
echo ""
echo -e "${YELLOW}[Step 5/5] 更新知识库${NC}"
echo ""

echo -e "${GREEN}是否需要更新知识库？[y/n]: ${NC}\c"
read need_update
if [ "$need_update" = "y" ]; then
    echo -e "${GREEN}更新 docs/已验证代码库.md？[y/n]: ${NC}\c"
    read update_verified
    if [ "$update_verified" = "y" ]; then
        echo -e "${CYAN}→ 请编辑 $VERIFIED_CODE${NC}"
        log_flow "更新: 已验证代码库"
    fi
    
    echo -e "${GREEN}更新 DEBUG_LOG.md？[y/n]: ${NC}\c"
    read update_debug
    if [ "$update_debug" = "y" ]; then
        echo -e "${CYAN}→ 请编辑 $DEBUG_LOG${NC}"
        log_flow "更新: DEBUG_LOG"
    fi
fi

# ===== 完成 =====
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              ✓ 开发流程检查完成                            ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "日志文件: $FLOW_LOG"
echo ""
