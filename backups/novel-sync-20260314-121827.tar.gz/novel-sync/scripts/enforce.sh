#!/bin/bash
# 强制执行脚本
# 安装和管理强制检查机制
#
# 用法:
#   bash scripts/enforce.sh install    # 安装 Git Hooks
#   bash scripts/enforce.sh uninstall  # 卸载 Git Hooks
#   bash scripts/enforce.sh status     # 查看状态
#   bash scripts/enforce.sh check      # 执行强制检查
#   bash scripts/enforce.sh lock       # 锁定已验证代码（禁止修改）

PROJECT_DIR="/workspace/projects/workspace/projects/novel-sync"
HOOKS_DIR="$PROJECT_DIR/.githooks"
LOCK_FILE="$PROJECT_DIR/.verified-lock"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 解析参数
COMMAND="${1:-status}"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              强制执行机制管理                              ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

cd "$PROJECT_DIR"

case "$COMMAND" in
    install)
        echo -e "${YELLOW}安装 Git Hooks...${NC}"
        echo ""
        
        # 确保 .githooks 目录存在
        mkdir -p "$HOOKS_DIR"
        
        # 设置执行权限
        chmod +x "$HOOKS_DIR/pre-commit" 2>/dev/null
        
        # 配置 Git 使用自定义 hooks 目录
        git config core.hooksPath .githooks
        
        echo -e "${GREEN}✓ Git Hooks 已安装${NC}"
        echo ""
        echo "配置:"
        echo "  Hooks 目录: .githooks/"
        echo "  Pre-commit: 已启用"
        echo ""
        echo "效果:"
        echo "  - 每次 git commit 前自动检查代码-文档同步性"
        echo "  - 代码修改后必须同时修改文档"
        echo "  - 使用 --no-verify 可跳过检查"
        ;;
        
    uninstall)
        echo -e "${YELLOW}卸载 Git Hooks...${NC}"
        echo ""
        
        # 恢复默认 hooks 目录
        git config --unset core.hooksPath
        
        echo -e "${GREEN}✓ Git Hooks 已卸载${NC}"
        echo ""
        echo "注意: 强制检查机制已禁用"
        ;;
        
    status)
        echo -e "${YELLOW}当前状态:${NC}"
        echo ""
        
        # 检查 Git Hooks 状态
        HOOKS_PATH=$(git config core.hooksPath 2>/dev/null || echo "默认")
        if [ "$HOOKS_PATH" = ".githooks" ]; then
            echo -e "  Git Hooks: ${GREEN}已启用${NC}"
            echo "  Hooks 目录: .githooks/"
        else
            echo -e "  Git Hooks: ${YELLOW}未启用${NC}"
            echo "  执行 'bash scripts/enforce.sh install' 启用"
        fi
        echo ""
        
        # 检查锁定文件
        if [ -f "$LOCK_FILE" ]; then
            echo -e "  代码锁定: ${GREEN}已启用${NC}"
            echo "  锁定文件: .verified-lock"
            echo ""
            echo "  已锁定的文件:"
            cat "$LOCK_FILE" | while read line; do
                echo "    - $line"
            done
        else
            echo -e "  代码锁定: ${YELLOW}未启用${NC}"
        fi
        echo ""
        
        # 检查同步状态
        if [ -f ".sync-check.log" ]; then
            LAST_CHECK=$(tail -1 "$PROJECT_DIR/.sync-check.log" 2>/dev/null)
            echo "  最后同步检查: $LAST_CHECK"
        fi
        ;;
        
    check)
        echo -e "${YELLOW}执行强制检查...${NC}"
        echo ""
        
        # 1. 同步性检查
        echo -e "${CYAN}[1/3] 同步性检查${NC}"
        bash "$PROJECT_DIR/scripts/sync-check.sh"
        SYNC_RESULT=$?
        
        # 2. 编码规范检查
        echo ""
        echo -e "${CYAN}[2/3] 编码规范检查${NC}"
        
        # 检查是否有修改已验证代码的风险操作
        if [ -f "$LOCK_FILE" ]; then
            while read locked_file; do
                if git diff --name-only HEAD~1 2>/dev/null | grep -q "$locked_file"; then
                    echo -e "${RED}✗ 检测到修改已锁定文件: $locked_file${NC}"
                    echo "  如需修改，请先执行: bash scripts/enforce.sh unlock"
                    exit 1
                fi
            done < "$LOCK_FILE"
        fi
        
        echo -e "${GREEN}✓ 编码规范检查通过${NC}"
        
        # 3. 文档完整性检查
        echo ""
        echo -e "${CYAN}[3/3] 文档完整性检查${NC}"
        
        REQUIRED_DOCS=(
            "docs/已验证代码库.md"
            "docs/用户教导记录.md"
            "DEBUG_LOG.md"
            "PROJECT_STANDARDS.md"
            "CODING_STANDARDS.md"
        )
        
        DOC_PASS=true
        for doc in "${REQUIRED_DOCS[@]}"; do
            if [ -f "$PROJECT_DIR/$doc" ]; then
                echo -e "  ${GREEN}✓${NC} $doc"
            else
                echo -e "  ${RED}✗${NC} $doc [缺失]"
                DOC_PASS=false
            fi
        done
        
        if [ "$DOC_PASS" = true ]; then
            echo ""
            echo -e "${GREEN}✓ 所有检查通过${NC}"
        else
            echo ""
            echo -e "${RED}✗ 存在缺失文档${NC}"
            exit 1
        fi
        ;;
        
    lock)
        echo -e "${YELLOW}锁定已验证代码...${NC}"
        echo ""
        
        # 需要锁定的文件列表
        LOCK_FILES=(
            "src/platforms/baimeng/auth.js"
            "src/platforms/baimeng/works.js"
            "src/platforms/baimeng/sidebar.js"
            "src/platforms/baimeng/content.js"
            "src/platforms/baimeng/copy.js"
        )
        
        echo "# 已验证代码锁定文件" > "$LOCK_FILE"
        echo "# 生成时间: $(date '+%Y-%m-%d %H:%M:%S')" >> "$LOCK_FILE"
        echo "" >> "$LOCK_FILE"
        
        for file in "${LOCK_FILES[@]}"; do
            if [ -f "$PROJECT_DIR/$file" ]; then
                echo "$file" >> "$LOCK_FILE"
                echo -e "  ${GREEN}✓${NC} 锁定: $file"
            fi
        done
        
        echo ""
        echo -e "${GREEN}✓ 已锁定 $(wc -l < "$LOCK_FILE") 个文件${NC}"
        echo ""
        echo "效果:"
        echo "  - 锁定的文件修改时将触发警告"
        echo "  - 执行 enforce.sh check 时会检查锁定文件"
        echo ""
        echo "解锁: bash scripts/enforce.sh unlock"
        ;;
        
    unlock)
        echo -e "${YELLOW}解锁已验证代码...${NC}"
        echo ""
        
        if [ -f "$LOCK_FILE" ]; then
            rm "$LOCK_FILE"
            echo -e "${GREEN}✓ 已解锁${NC}"
        else
            echo -e "${YELLOW}未锁定${NC}"
        fi
        ;;
        
    *)
        echo "用法: bash scripts/enforce.sh {install|uninstall|status|check|lock|unlock}"
        echo ""
        echo "命令:"
        echo "  install    安装 Git Hooks，启用提交前强制检查"
        echo "  uninstall  卸载 Git Hooks，禁用强制检查"
        echo "  status     查看当前状态"
        echo "  check      执行强制检查"
        echo "  lock       锁定已验证代码（禁止修改）"
        echo "  unlock     解锁已验证代码"
        ;;
esac
