#!/bin/bash
# 验证所有功能

ROOT_DIR="/workspace/projects/workspace/projects/novel-sync"
PASS=0
FAIL=0

echo ""
echo "========================================"
echo "         功能验证"
echo "========================================"
echo ""

# 1. 验证章节查找
echo "[1/3] 验证章节查找..."
RESULT=$(timeout 60 node "$ROOT_DIR/baimeng-chapter-finder.js" 枪与凋零之花 42 2>&1)
if echo "$RESULT" | grep -q "✅"; then
    echo "  ✅ 章节查找通过"
    ((PASS++))
else
    echo "  ❌ 章节查找失败"
    echo "$RESULT"
    ((FAIL++))
fi
echo ""

# 2. 验证内容复制
echo "[2/3] 验证内容复制..."
RESULT=$(timeout 90 node "$ROOT_DIR/baimeng-copy.js" 枪与凋零之花 1 2>&1)
if echo "$RESULT" | grep -q "✅ 已复制到剪贴板" && echo "$RESULT" | grep -q "内容预览 (共"; then
    # 提取字数
    WORDS=$(echo "$RESULT" | grep "内容预览" | grep -oE '[0-9]+' | head -1)
    if [ -n "$WORDS" ] && [ "$WORDS" -gt 100 ]; then
        echo "  ✅ 内容复制通过 ($WORDS 字)"
        ((PASS++))
    else
        echo "  ⚠️ 内容复制可能有问题 (字数: $WORDS)"
        ((FAIL++))
    fi
else
    echo "  ❌ 内容复制失败"
    echo "$RESULT"
    ((FAIL++))
fi
echo ""

# 3. 验证存储备份
echo "[3/3] 验证存储备份..."
RESULT=$(bash "$ROOT_DIR/scripts/storage.sh" verify baimeng 1 2>&1)
if echo "$RESULT" | grep -q "✓ 验证通过"; then
    echo "  ✅ 存储备份完整"
    ((PASS++))
else
    echo "  ❌ 存储备份不完整"
    echo "$RESULT"
    ((FAIL++))
fi
echo ""

echo "========================================"
echo "  通过: $PASS  失败: $FAIL"
echo "========================================"
echo ""

if [ $FAIL -eq 0 ]; then
    echo "✅ 所有验证通过"
    exit 0
else
    echo "❌ 存在失败的验证"
    exit 1
fi
