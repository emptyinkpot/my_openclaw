#!/usr/bin/env node
/**
 * 备份系统 - 恢复数据
 * 
 * 功能：
 * 1. 列出可用备份版本
 * 2. 从指定版本恢复数据
 * 3. 支持选择性恢复（只恢复特定内容）
 * 4. 恢复前自动备份当前状态
 * 
 * 用法：
 *   node scripts/restore.js --list              # 列出所有备份
 *   node scripts/restore.js --latest            # 恢复最新备份
 *   node scripts/restore.js v20260314_020000    # 恢复指定版本
 *   node scripts/restore.js v20260314 --chapters  # 只恢复章节
 * 
 * @author OpenClaw 配置专家
 * @date 2026-03-14
 */

const { runTask } = require('../src/utils/task-runner');
const fs = require('fs');
const path = require('path');

const backupConfig = require('../backup.config.js');

runTask('恢复备份', async (ctx) => {
  const args = process.argv.slice(2);
  
  // 列出所有备份
  if (args.includes('--list')) {
    return listBackups();
  }
  
  // 获取版本号
  let version = args.find(a => a.startsWith('v'));
  if (args.includes('--latest') || !version) {
    version = getLatestBackup();
    if (!version) {
      console.log('❌ 没有找到可用备份');
      return { success: false, error: '没有可用备份' };
    }
  }
  
  // 选择性恢复
  const restoreTargets = args.includes('--chapters') ? ['chapters'] :
                          args.includes('--config') ? ['config'] :
                          args.includes('--all') ? null : null;  // null = 全部
  
  console.log(`\n🔄 开始恢复 - ${version}`);
  console.log('='.repeat(50));
  
  const backupPath = path.join(backupConfig.backupDir, version);
  
  if (!fs.existsSync(backupPath)) {
    console.log(`❌ 备份版本不存在: ${version}`);
    return { success: false, error: '备份版本不存在' };
  }
  
  // 加载清单
  const manifestPath = path.join(backupPath, 'manifest.json');
  if (!fs.existsSync(manifestPath)) {
    console.log('❌ 备份清单不存在');
    return { success: false, error: '备份清单不存在' };
  }
  
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  console.log(`📅 备份时间: ${manifest.timestamp}`);
  console.log(`🎯 触发方式: ${manifest.trigger}`);
  console.log(`📊 文件数量: ${manifest.stats.totalFiles}`);
  
  // 恢复前备份当前状态
  console.log('\n📦 恢复前备份当前状态...');
  const { execSync } = require('child_process');
  try {
    execSync('node scripts/backup.js --auto', { stdio: 'inherit' });
  } catch (e) {
    console.log('⚠️  当前状态备份失败，继续恢复');
  }
  
  // 执行恢复
  console.log('\n📂 开始恢复文件...');
  const stats = { successCount: 0, failedCount: 0 };
  
  for (const targetName of Object.keys(backupConfig.backupTargets)) {
    if (restoreTargets && !restoreTargets.includes(targetName)) {
      continue;
    }
    
    const target = backupConfig.backupTargets[targetName];
    const srcDir = path.join(backupPath, targetName);
    
    if (!fs.existsSync(srcDir)) {
      continue;
    }
    
    console.log(`\n📁 恢复 ${targetName}...`);
    
    // 恢复目录
    if (target.path) {
      const destDir = path.join(process.cwd(), target.path);
      const result = restoreDirectory(srcDir, destDir);
      stats.successCount += result.successCount;
      stats.failedCount += result.failedCount;
    }
    
    // 恢复单个文件
    if (target.files) {
      for (const file of target.files) {
        const srcPath = path.join(srcDir, path.basename(file));
        const destPath = path.join(process.cwd(), file);
        
        if (fs.existsSync(srcPath)) {
          try {
            fs.mkdirSync(path.dirname(destPath), { recursive: true });
            fs.copyFileSync(srcPath, destPath);
            console.log(`  ✅ ${file}`);
            stats.successCount++;
          } catch (e) {
            console.log(`  ❌ ${file}: ${e.message}`);
            stats.failedCount++;
          }
        }
      }
    }
  }
  
  console.log('\n' + '='.repeat(50));
  console.log(`✅ 恢复完成: ${version}`);
  console.log(`📊 统计: ${stats.successCount} 个文件恢复成功, ${stats.failedCount} 个失败`);
  
  return {
    success: true,
    version,
    stats
  };
});

/**
 * 列出所有备份
 */
function listBackups() {
  const indexPath = path.join(backupConfig.backupDir, 'backup-index.json');
  
  if (!fs.existsSync(indexPath)) {
    console.log('没有找到备份索引');
    return { success: true, backups: [] };
  }
  
  const index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
  
  console.log('\n📋 备份列表\n');
  console.log('版本              | 时间                 | 触发方式       | 文件数 | 大小');
  console.log('-'.repeat(80));
  
  index.backups.forEach(b => {
    const date = new Date(b.timestamp).toLocaleString('zh-CN');
    const size = formatSize(b.stats.totalSize);
    console.log(`${b.version} | ${date} | ${b.trigger.padEnd(12)} | ${String(b.stats.totalFiles).padStart(6)} | ${size}`);
  });
  
  console.log('-'.repeat(80));
  console.log(`共 ${index.backups.length} 个备份`);
  
  return { success: true, backups: index.backups };
}

/**
 * 获取最新备份版本
 */
function getLatestBackup() {
  const indexPath = path.join(backupConfig.backupDir, 'backup-index.json');
  
  if (!fs.existsSync(indexPath)) return null;
  
  const index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
  return index.backups[0]?.version;
}

/**
 * 恢复目录
 */
function restoreDirectory(srcDir, destDir) {
  const stats = { successCount: 0, failedCount: 0 };
  
  if (!fs.existsSync(srcDir)) return stats;
  
  fs.mkdirSync(destDir, { recursive: true });
  
  const files = fs.readdirSync(srcDir, { withFileTypes: true });
  
  for (const file of files) {
    if (file.isDirectory()) {
      const subStats = restoreDirectory(
        path.join(srcDir, file.name),
        path.join(destDir, file.name)
      );
      stats.successCount += subStats.successCount;
      stats.failedCount += subStats.failedCount;
    } else {
      const srcPath = path.join(srcDir, file.name);
      const destPath = path.join(destDir, file.name);
      
      try {
        fs.copyFileSync(srcPath, destPath);
        console.log(`  ✅ ${file.name}`);
        stats.successCount++;
      } catch (e) {
        console.log(`  ❌ ${file.name}: ${e.message}`);
        stats.failedCount++;
      }
    }
  }
  
  return stats;
}

/**
 * 格式化文件大小
 */
function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}
