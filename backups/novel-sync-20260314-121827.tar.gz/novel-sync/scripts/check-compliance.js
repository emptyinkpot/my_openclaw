#!/usr/bin/env node
/**
 * 规范检查脚本
 * 
 * 检查所有脚本是否符合编码规范
 * 
 * 使用：
 *   node scripts/check-compliance.js         # 检查所有脚本
 *   node scripts/check-compliance.js --fix   # 显示修复建议
 *   node scripts/check-compliance.js --json  # JSON 输出
 */

const path = require('path');
const fs = require('fs');

const PROJECT_ROOT = path.join(__dirname, '..');

// 导入 task-runner
const { 
  checkScriptCompliance, 
  generateComplianceReport,
  hasCheckedStandards 
} = require('../src/utils/task-runner');

// 解析参数
const args = process.argv.slice(2);
const showFix = args.includes('--fix');
const jsonOutput = args.includes('--json');

// 检查结果
let totalScripts = 0;
let compliantScripts = 0;
let issues = [];

// ============================================================
// 检查函数
// ============================================================

function checkAllScripts() {
  const scriptsDir = PROJECT_ROOT;
  const scripts = fs.readdirSync(scriptsDir)
    .filter(f => f.endsWith('.js') && !f.endsWith('.config.js')) // 排除配置文件
    .map(f => ({
      name: f,
      path: path.join(scriptsDir, f),
      mtime: fs.statSync(path.join(scriptsDir, f)).mtime
    }))
    .sort((a, b) => b.mtime - a.mtime);
  
  scripts.forEach(script => {
    totalScripts++;
    const result = checkScriptCompliance(script.path);
    
    if (result.compliant) {
      compliantScripts++;
    } else {
      issues.push({
        script: script.name,
        ...result
      });
    }
  });
  
  return { totalScripts, compliantScripts, issues };
}

function printReport() {
  const { totalScripts, compliantScripts, issues } = checkAllScripts();
  
  if (jsonOutput) {
    console.log(JSON.stringify({
      total: totalScripts,
      compliant: compliantScripts,
      issues: issues,
      timestamp: new Date().toISOString()
    }, null, 2));
    return;
  }
  
  console.log('='.repeat(60));
  console.log('📋 编码规范检查报告');
  console.log('='.repeat(60));
  
  // 1. 规范检查标记
  console.log('\n【1】规范检查标记：');
  const flagFile = path.join(PROJECT_ROOT, '.task-check-flag');
  if (fs.existsSync(flagFile)) {
    try {
      const flag = JSON.parse(fs.readFileSync(flagFile, 'utf-8'));
      const age = Math.round((Date.now() - flag.timestamp) / 1000 / 60);
      console.log(`  ✓ 已检查（${age} 分钟前）`);
    } catch (e) {
      console.log('  ⚠️ 标记文件损坏');
    }
  } else {
    console.log('  ✗ 未检查');
  }
  
  // 2. 脚本检查结果
  console.log('\n【2】脚本检查结果：');
  console.log(`  总数: ${totalScripts}`);
  console.log(`  合规: ${compliantScripts}`);
  console.log(`  违规: ${totalScripts - compliantScripts}`);
  
  // 3. 违规详情
  if (issues.length > 0) {
    console.log('\n【3】违规详情：');
    issues.forEach(({ script, issues, warnings, score }) => {
      console.log(`\n  📄 ${script} (评分: ${score})`);
      issues.forEach(i => console.log(`    ${i}`));
      warnings.forEach(w => console.log(`    ${w}`));
      
      if (showFix) {
        console.log('    💡 修复建议：');
        console.log('    - 使用 runTask() 作为入口');
        console.log('    - 导入已验证模块而非直接使用 playwright');
        console.log('    - 添加代码来源注释');
      }
    });
  } else {
    console.log('\n【3】违规详情：无');
  }
  
  // 4. 违规日志
  console.log('\n【4】违规日志：');
  const violationLog = path.join(PROJECT_ROOT, '.violation-log.md');
  if (fs.existsSync(violationLog)) {
    const content = fs.readFileSync(violationLog, 'utf-8');
    const count = (content.match(/###\s*\[/g) || []).length;
    console.log(`  ⚠️ 发现 ${count} 条违规记录`);
  } else {
    console.log('  ✓ 无违规记录');
  }
  
  // 5. 文档更新状态
  console.log('\n【5】文档更新状态：');
  const docs = [
    'KNOWLEDGE_INDEX.md',
    'docs/已验证代码库.md',
    'DEBUG_LOG.md',
    'CODING_STANDARDS.md',
    'docs/用户教导记录.md'
  ];
  
  docs.forEach(doc => {
    const docPath = path.join(PROJECT_ROOT, doc);
    if (fs.existsSync(docPath)) {
      const stat = fs.statSync(docPath);
      const age = Math.round((Date.now() - stat.mtime) / 1000 / 60 / 60);
      console.log(`  ✓ ${doc}（${age} 小时前更新）`);
    } else {
      console.log(`  ✗ ${doc} 不存在`);
    }
  });
  
  // 6. 知识库完整性检查
  console.log('\n【6】知识库完整性：');
  const knowledgeIndex = path.join(PROJECT_ROOT, 'KNOWLEDGE_INDEX.md');
  if (fs.existsSync(knowledgeIndex)) {
    const content = fs.readFileSync(knowledgeIndex, 'utf-8');
    
    // 检查最近更新部分
    const hasRecentUpdates = content.includes('## 四、最近更新');
    if (hasRecentUpdates) {
      console.log('  ✓ 知识索引包含最近更新');
    } else {
      console.log('  ✗ 知识索引缺少最近更新');
    }
    
    // 检查是否有知识记录
    const debugLog = path.join(PROJECT_ROOT, 'DEBUG_LOG.md');
    const codeLib = path.join(PROJECT_ROOT, 'docs/已验证代码库.md');
    
    if (fs.existsSync(debugLog) && fs.existsSync(codeLib)) {
      console.log('  ✓ 核心知识库完整');
    } else {
      console.log('  ✗ 核心知识库缺失');
    }
    
    // 检查知识索引是否是最新
    const indexStat = fs.statSync(knowledgeIndex);
    const debugStat = fs.statSync(debugLog);
    if (indexStat.mtime >= debugStat.mtime) {
      console.log('  ✓ 知识索引已同步最新问题');
    } else {
      console.log('  ⚠️ 知识索引可能未同步最新问题');
    }
  } else {
    console.log('  ✗ KNOWLEDGE_INDEX.md 不存在（必须创建）');
  }
  
  // 总结
  console.log('\n' + '='.repeat(60));
  if (compliantScripts === totalScripts) {
    console.log('✅ 所有脚本都符合规范');
  } else {
    console.log(`⚠️ 发现 ${totalScripts - compliantScripts} 个违规脚本`);
    console.log('');
    console.log('修复方法：');
    console.log('  1. 使用 runTask() 作为脚本入口');
    console.log('  2. 导入已验证模块: require("./src/platforms/baimeng")');
    console.log('  3. 添加代码来源注释');
  }
  console.log('='.repeat(60));
  
  // 返回退出码
  process.exit(compliantScripts === totalScripts ? 0 : 1);
}

// 执行
printReport();
