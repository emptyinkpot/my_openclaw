#!/bin/bash
# 代码优化检查工具
# 严格按照优化框架执行
#
# 用法:
#   bash scripts/optimization.sh --pre-check     # 优化前检查
#   bash scripts/optimization.sh --baseline      # 建立基准
#   bash scripts/optimization.sh --check         # 优化检查
#   bash scripts/optimization.sh --compare       # 对比效果
#   bash scripts/optimization.sh --report        # 生成报告
#   bash scripts/optimization.sh --rollback      # 回滚

PROJECT_DIR="/workspace/projects/workspace/projects/novel-sync"
BASELINE_DIR="$PROJECT_DIR/.optimization"
BASELINE_FILE="$BASELINE_DIR/baseline.json"
OPTIMIZATION_LOG="$BASELINE_DIR/optimization.log"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 确保目录存在
mkdir -p "$BASELINE_DIR"

# 解析参数
MODE="${1:-help}"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              代码优化检查工具                              ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

cd "$PROJECT_DIR"

# ===== 功能函数 =====

# 获取当前性能指标
get_performance_metrics() {
    echo "{
  \"timestamp\": \"$(date -Iseconds)\",
  \"git_commit\": \"$(git rev-parse HEAD 2>/dev/null || echo 'unknown')\",
  \"git_status\": \"$(git status --porcelain 2>/dev/null | wc -l)\",
  \"code_stats\": {
    \"total_lines\": $(find src -name "*.js" -exec cat {} \; 2>/dev/null | wc -l),
    \"file_count\": $(find src -name "*.js" 2>/dev/null | wc -l),
    \"function_count\": $(grep -r "function\|=>" src --include="*.js" 2>/dev/null | wc -l)
  },
  \"doc_stats\": {
    \"total_lines\": $(find docs -name "*.md" -exec cat {} \; 2>/dev/null | wc -l),
    \"file_count\": $(find docs -name "*.md" 2>/dev/null | wc -l)
  },
  \"validation\": {
    \"sync_check\": \"$(bash scripts/sync-check.sh 2>&1 | grep -o "通过: [0-9]*" | head -1 || echo "未运行")\",
    \"doc_check\": \"$(bash scripts/doc-check.sh --core 2>&1 | grep -o "通过: [0-9]*" | head -1 || echo "未运行")\"
  }
}"
}

# 检查是否有未提交的更改
check_uncommitted_changes() {
    local changes=$(git status --porcelain 2>/dev/null | wc -l)
    if [ "$changes" -gt 0 ]; then
        return 0  # 有未提交的更改
    else
        return 1  # 没有未提交的更改
    fi
}

# 检查功能验证是否通过
check_functionality() {
    bash scripts/validate.sh >/dev/null 2>&1
    return $?
}

# ===== 优化前检查 =====
pre_check() {
    echo -e "${YELLOW}优化前检查${NC}"
    echo ""
    
    local issues=0
    
    # 1. 检查是否有优化目标
    echo -e "${CYAN}[1/5] 优化目标确认${NC}"
    echo "  请确认优化目标是否明确："
    echo "  - 是否有具体的性能问题？"
    echo "  - 是否有可量化的优化指标？"
    echo "  - 收益是否大于风险？"
    echo ""
    
    # 2. 检查当前状态
    echo -e "${CYAN}[2/5] 当前状态检查${NC}"
    
    if check_uncommitted_changes; then
        echo -e "  ${YELLOW}⚠${NC} 存在未提交的更改"
        echo "  建议先提交当前更改：git add . && git commit -m 'message'"
        issues=$((issues + 1))
    else
        echo -e "  ${GREEN}✓${NC} 没有未提交的更改"
    fi
    
    # 3. 检查功能验证
    echo ""
    echo -e "${CYAN}[3/5] 功能验证检查${NC}"
    
    if check_functionality; then
        echo -e "  ${GREEN}✓${NC} 功能验证通过"
    else
        echo -e "  ${RED}✗${NC} 功能验证失败，请先修复问题"
        issues=$((issues + 1))
    fi
    
    # 4. 检查同步状态
    echo ""
    echo -e "${CYAN}[4/5] 同步状态检查${NC}"
    
    local sync_result=$(bash scripts/sync-check.sh 2>&1 | grep "失败:" | head -1)
    if [ -n "$sync_result" ]; then
        echo -e "  ${RED}✗${NC} 同步检查失败"
        issues=$((issues + 1))
    else
        echo -e "  ${GREEN}✓${NC} 同步检查通过"
    fi
    
    # 5. 检查文档完整性
    echo ""
    echo -e "${CYAN}[5/5] 文档完整性检查${NC}"
    
    local doc_result=$(bash scripts/doc-check.sh --core 2>&1 | grep "失败:" | head -1)
    if [ -n "$doc_result" ]; then
        echo -e "  ${RED}✗${NC} 文档检查失败"
        issues=$((issues + 1))
    else
        echo -e "  ${GREEN}✓${NC} 文档检查通过"
    fi
    
    # 汇总
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    if [ $issues -gt 0 ]; then
        echo -e "${RED}✗ 存在 $issues 个问题，请先修复后再进行优化${NC}"
        echo ""
        echo "修复建议："
        echo "  1. 提交当前更改：git add . && git commit -m 'message'"
        echo "  2. 修复功能问题：bash scripts/diagnose.sh"
        echo "  3. 修复同步问题：bash scripts/sync-check.sh --fix"
        exit 1
    else
        echo -e "${GREEN}✓ 优化前检查通过，可以建立基准${NC}"
        echo ""
        echo "下一步：bash scripts/optimization.sh --baseline"
    fi
}

# ===== 建立基准 =====
create_baseline() {
    echo -e "${YELLOW}建立优化基准${NC}"
    echo ""
    
    # 检查是否有未提交的更改
    if check_uncommitted_changes; then
        echo -e "${RED}✗ 存在未提交的更改，请先提交${NC}"
        echo ""
        echo "执行：git add . && git commit -m '优化前状态'"
        exit 1
    fi
    
    # 检查功能验证
    if ! check_functionality; then
        echo -e "${RED}✗ 功能验证失败，请先修复${NC}"
        exit 1
    fi
    
    # 记录基准
    echo -e "${CYAN}记录当前基准...${NC}"
    
    get_performance_metrics > "$BASELINE_FILE"
    
    echo ""
    echo "基准已保存到: $BASELINE_FILE"
    echo ""
    echo "基准内容:"
    cat "$BASELINE_FILE" | head -20
    echo ""
    
    # 记录日志
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 基准已建立: $(git rev-parse HEAD 2>/dev/null)" >> "$OPTIMIZATION_LOG"
    
    echo -e "${GREEN}✓ 基准已建立${NC}"
    echo ""
    echo "现在可以开始优化："
    echo "  1. 修改代码（遵循最小改动原则）"
    echo "  2. 测试验证"
    echo "  3. 运行 bash scripts/optimization.sh --check"
}

# ===== 优化检查 =====
check_optimization() {
    echo -e "${YELLOW}优化检查${NC}"
    echo ""
    
    # 检查基准是否存在
    if [ ! -f "$BASELINE_FILE" ]; then
        echo -e "${RED}✗ 未找到基准文件，请先建立基准${NC}"
        echo ""
        echo "执行：bash scripts/optimization.sh --baseline"
        exit 1
    fi
    
    local issues=0
    
    # 1. 检查是否有更改
    echo -e "${CYAN}[1/4] 代码更改检查${NC}"
    
    if check_uncommitted_changes; then
        echo -e "  ${GREEN}✓${NC} 检测到代码更改"
        echo ""
        echo "更改的文件:"
        git status --porcelain 2>/dev/null | while read line; do
            echo "  - $line"
        done
    else
        echo -e "  ${YELLOW}⚠${NC} 未检测到代码更改"
    fi
    
    # 2. 检查功能验证
    echo ""
    echo -e "${CYAN}[2/4] 功能验证${NC}"
    
    if check_functionality; then
        echo -e "  ${GREEN}✓${NC} 功能验证通过"
    else
        echo -e "  ${RED}✗${NC} 功能验证失败"
        echo ""
        echo -e "${RED}优化破坏了现有功能，请立即回滚！${NC}"
        echo ""
        echo "回滚命令：bash scripts/optimization.sh --rollback"
        issues=$((issues + 1))
    fi
    
    # 3. 检查同步状态
    echo ""
    echo -e "${CYAN}[3/4] 同步状态检查${NC}"
    
    local sync_result=$(bash scripts/sync-check.sh 2>&1 | tail -5)
    echo "$sync_result"
    
    # 4. 检查代码质量
    echo ""
    echo -e "${CYAN}[4/4] 代码质量检查${NC}"
    
    # 检查函数长度
    local long_functions=$(grep -r "function\|=>" src --include="*.js" -A 50 2>/dev/null | grep -c "^--$" || echo "0")
    echo -e "  ${GREEN}✓${NC} 函数长度检查通过"
    
    # 检查是否有 console.log
    local console_logs=$(grep -r "console\.log" src --include="*.js" 2>/dev/null | wc -l)
    if [ "$console_logs" -gt 10 ]; then
        echo -e "  ${YELLOW}⚠${NC} console.log 较多 ($console_logs 个)，建议清理"
    else
        echo -e "  ${GREEN}✓${NC} console.log 数量合理 ($console_logs 个)"
    fi
    
    # 汇总
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    if [ $issues -gt 0 ]; then
        echo -e "${RED}✗ 优化检查失败，请回滚${NC}"
        exit 1
    else
        echo -e "${GREEN}✓ 优化检查通过${NC}"
        echo ""
        echo "下一步："
        echo "  1. 运行 bash scripts/optimization.sh --compare 对比效果"
        echo "  2. 如果效果满意，提交更改"
        echo "  3. 更新文档"
    fi
}

# ===== 对比效果 =====
compare_results() {
    echo -e "${YELLOW}对比优化效果${NC}"
    echo ""
    
    if [ ! -f "$BASELINE_FILE" ]; then
        echo -e "${RED}✗ 未找到基准文件${NC}"
        exit 1
    fi
    
    echo -e "${CYAN}基准数据:${NC}"
    cat "$BASELINE_FILE"
    echo ""
    
    echo -e "${CYAN}当前数据:${NC}"
    get_performance_metrics
    echo ""
    
    # 简单对比
    local baseline_lines=$(cat "$BASELINE_FILE" | grep "total_lines" | head -1 | grep -o "[0-9]*")
    local current_lines=$(find src -name "*.js" -exec cat {} \; 2>/dev/null | wc -l)
    
    echo -e "${CYAN}代码行数对比:${NC}"
    echo "  基准: $baseline_lines 行"
    echo "  当前: $current_lines 行"
    
    if [ "$current_lines" -lt "$baseline_lines" ]; then
        local diff=$((baseline_lines - current_lines))
        echo -e "  ${GREEN}↓ 减少了 $diff 行${NC}"
    elif [ "$current_lines" -gt "$baseline_lines" ]; then
        local diff=$((current_lines - baseline_lines))
        echo -e "  ${YELLOW}↑ 增加了 $diff 行${NC}"
    else
        echo -e "  ${GREEN}→ 行数不变${NC}"
    fi
    
    echo ""
    echo -e "${GREEN}对比完成${NC}"
    echo ""
    echo "如果效果满意："
    echo "  1. git add ."
    echo "  2. git commit -m '优化: 具体优化内容'"
    echo "  3. 更新文档: docs/已验证代码库.md"
    echo "  4. 记录优化: 追加到 docs/代码优化框架.md"
}

# ===== 回滚 =====
rollback() {
    echo -e "${YELLOW}回滚优化${NC}"
    echo ""
    
    if [ ! -f "$BASELINE_FILE" ]; then
        echo -e "${RED}✗ 未找到基准文件${NC}"
        exit 1
    fi
    
    local baseline_commit=$(cat "$BASELINE_FILE" | grep "git_commit" | grep -o '"[^"]*"' | tr -d '"')
    
    echo "基准提交: $baseline_commit"
    echo ""
    echo -e "${RED}警告: 这将丢弃所有未提交的更改！${NC}"
    echo ""
    echo "回滚命令:"
    echo "  git reset --hard $baseline_commit"
    echo ""
    echo -e "${GREEN}请手动执行上述命令完成回滚${NC}"
}

# ===== 生成报告 =====
generate_report() {
    local report_file="$BASELINE_DIR/optimization-report.md"
    
    echo -e "${YELLOW}生成优化报告${NC}"
    echo ""
    
    cat > "$report_file" << EOF
# 优化报告

生成时间: $(date '+%Y-%m-%d %H:%M:%S')

## 基准数据

\`\`\`json
$(cat "$BASELINE_FILE" 2>/dev/null || echo "未建立基准")
\`\`\`

## 当前数据

\`\`\`json
$(get_performance_metrics)
\`\`\`

## 验证状态

- 功能验证: $(check_functionality && echo "✅ 通过" || echo "❌ 失败")
- 同步检查: $(bash scripts/sync-check.sh 2>&1 | grep -o "通过: [0-9]*/[0-9]*" | head -1)
- 文档检查: $(bash scripts/doc-check.sh --core 2>&1 | grep -o "通过: [0-9]*/[0-9]*" | head -1)

## 优化历史

\`\`\`
$(cat "$OPTIMIZATION_LOG" 2>/dev/null || echo "无记录")
\`\`\`
EOF
    
    echo "报告已生成: $report_file"
    echo ""
    cat "$report_file"
}

# ===== 主执行 =====

case "$MODE" in
    --pre-check)
        pre_check
        ;;
    --baseline)
        create_baseline
        ;;
    --check)
        check_optimization
        ;;
    --compare)
        compare_results
        ;;
    --rollback)
        rollback
        ;;
    --report)
        generate_report
        ;;
    *)
        echo "用法:"
        echo "  bash scripts/optimization.sh --pre-check   # 优化前检查"
        echo "  bash scripts/optimization.sh --baseline    # 建立基准"
        echo "  bash scripts/optimization.sh --check       # 优化检查"
        echo "  bash scripts/optimization.sh --compare     # 对比效果"
        echo "  bash scripts/optimization.sh --rollback    # 回滚"
        echo "  bash scripts/optimization.sh --report      # 生成报告"
        ;;
esac
