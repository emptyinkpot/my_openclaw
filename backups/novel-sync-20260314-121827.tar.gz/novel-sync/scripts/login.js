/**
 * 登录工具
 * 
 * 统一的登录入口，浏览器保持运行
 * 
 * 用法：
 *   node scripts/login.js fanqie              # 登录番茄
 *   node scripts/login.js fanqie 墨水的灰色   # 登录指定账号
 *   node scripts/login.js baimeng             # 登录白梦
 *   node scripts/login.js status              # 查看状态
 *   node scripts/login.js list                # 列出账号
 *   node scripts/login.js close               # 关闭浏览器
 */

const globalBrowser = require('../src/core/global-browser');
const { authService } = require('../src/services');

// ============================================================
// 命令处理
// ============================================================

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'help';
  
  switch (command) {
    case 'status':
      await showStatus();
      break;
    case 'list':
      await listAccounts();
      break;
    case 'close':
      await closeBrowser();
      break;
    case 'fanqie':
    case 'baimeng':
      await login(command, args[1]);
      break;
    case 'help':
    default:
      showHelp();
      break;
  }
}

// ============================================================
// 命令实现
// ============================================================

async function showStatus() {
  console.log('=== 浏览器状态 ===\n');
  
  const info = globalBrowser.getCurrentInfo();
  if (info) {
    console.log(`浏览器: ${info.key}`);
    console.log(`CDP端口: ${info.port}`);
    
    const running = await globalBrowser.isRunning();
    console.log(`状态: ${running ? '✅ 运行中' : '❌ 已断开'}`);
  } else {
    console.log('浏览器: 无运行中的实例');
  }
  
  console.log('\n=== 数据目录 ===');
  const dirs = globalBrowser.listDataDirs();
  dirs.forEach(d => console.log(`  ${d}`));
}

async function listAccounts() {
  console.log('=== 账号列表 ===\n');
  
  const platforms = ['fanqie', 'baimeng'];
  
  for (const platform of platforms) {
    console.log(`【${platform}】`);
    const accounts = authService.listAccounts(platform);
    
    if (accounts.length === 0) {
      console.log('  无账号');
    } else {
      accounts.forEach(a => {
        const icon = a.valid ? '✅' : '❌';
        console.log(`  ${icon} ${a.userName}`);
      });
    }
    console.log('');
  }
}

async function closeBrowser() {
  console.log('关闭浏览器...');
  const result = await globalBrowser.closeBrowser();
  console.log(result ? '已关闭' : '无运行中的浏览器');
}

async function login(platform, userName) {
  console.log(`=== 登录 ${platform} ===\n`);
  
  // 列出可用账号
  const accounts = authService.listAccounts(platform);
  
  if (accounts.length === 0) {
    console.log(`无 ${platform} 账号，请先登录并保存`);
    return;
  }
  
  // 如果没有指定用户名，使用最新的
  if (!userName) {
    userName = accounts[0].userName;
    console.log(`使用账号: ${userName}`);
  }
  
  // 检查是否已有运行的浏览器
  const isRunning = await globalBrowser.isRunning(`${platform}-${userName}`);
  
  if (isRunning) {
    console.log('浏览器已在运行');
    console.log('提示: 可以在浏览器中继续操作');
    return;
  }
  
  // 获取浏览器
  const { page, isNew } = await globalBrowser.getBrowser({
    key: `${platform}-${userName}`,
  });
  
  if (!isNew) {
    console.log('连接到已有浏览器');
    console.log(`当前URL: ${page.url()}`);
    return;
  }
  
  // 执行登录
  console.log('恢复登录状态...');
  
  const result = await authService.login({
    platform,
    userName,
    page,
  });
  
  if (result.success) {
    console.log(`\n✅ 登录成功: ${result.userName}`);
    console.log('浏览器保持运行，可以继续操作');
    console.log('提示: 下次运行相同命令会连接到这个浏览器');
  } else {
    console.log(`\n❌ 登录失败`);
  }
}

function showHelp() {
  console.log(`
登录工具

用法:
  node scripts/login.js <命令> [参数]

命令:
  status              显示浏览器状态
  list                列出所有账号
  close               关闭浏览器
  fanqie [用户名]      登录番茄小说
  baimeng [用户名]     登录白梦写作
  help                显示帮助

示例:
  node scripts/login.js status
  node scripts/login.js list
  node scripts/login.js fanqie
  node scripts/login.js fanqie 墨水的灰色
  node scripts/login.js close

注意:
  - 浏览器会保持运行（使用 CDP 端口）
  - 再次运行相同命令会连接到已有浏览器
  - 可以在浏览器中继续操作
`);
}

// ============================================================
// 运行
// ============================================================

main().catch(e => {
  console.error('错误:', e.message);
  process.exit(1);
});
