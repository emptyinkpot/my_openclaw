#!/bin/bash
# 统一任务入口脚本
# 所有任务的统一入口，自动识别任务类型并执行正确的流程
#
# 用法:
#   source scripts/task.sh                    # 交互式任务入口
#   source scripts/task.sh new-feature        # 新功能开发
#   source scripts/task.sh debug              # 问题调试
#   source scripts/task.sh optimize           # 代码优化
#   source scripts/task.sh refactor           # 代码重构
#   source scripts/task.sh doc                # 文档维护
#   source scripts/task.sh check              # 完整检查

PROJECT_DIR="/workspace/projects/workspace/projects/novel-sync"
TASK_LOG="$PROJECT_DIR/.task.log"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

# 记录日志
log_task() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$TASK_LOG"
}

# 显示横幅
show_banner() {
    echo ""
    echo -e "${MAGENTA}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${MAGENTA}║           OpenClaw Novel-Sync 统一任务入口                 ║${NC}"
    echo -e "${MAGENTA}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# 显示任务类型菜单
show_task_menu() {
    echo -e "${CYAN}请选择任务类型:${NC}"
    echo ""
    echo "  1) 新功能开发    - 添加新功能或特性"
    echo "  2) 问题调试      - 修复 Bug 或解决异常"
    echo "  3) 代码优化      - 性能优化或代码改进"
    echo "  4) 代码重构      - 结构调整或模块拆分"
    echo "  5) 文档维护      - 更新或完善文档"
    echo "  6) 完整检查      - 执行所有检查项"
    echo "  7) 快速参考      - 查看常用命令和规范"
    echo ""
}

# 执行前置检查（所有任务必经）
run_pre_checks() {
    echo -e "${YELLOW}[前置检查] 确保环境就绪...${NC}"
    echo ""
    
    local checks_passed=true
    
    # 1. 检查必要文件
    local required_files=(
        "PROJECT_STANDARDS.md"
        "CODING_STANDARDS.md"
        "DEBUG_LOG.md"
        "docs/已验证代码库.md"
        "docs/用户教导记录.md"
    )
    
    echo -e "${CYAN}[1/3] 核心文件检查${NC}"
    for file in "${required_files[@]}"; do
        if [ -f "$PROJECT_DIR/$file" ]; then
            echo -e "  ${GREEN}✓${NC} $file"
        else
            echo -e "  ${RED}✗${NC} $file [缺失]"
            checks_passed=false
        fi
    done
    
    # 2. 检查 Git 状态
    echo ""
    echo -e "${CYAN}[2/3] Git 状态检查${NC}"
    cd "$PROJECT_DIR"
    local git_status=$(git status --porcelain 2>/dev/null | head -5)
    if [ -n "$git_status" ]; then
        echo -e "  ${YELLOW}!${NC} 存在未提交的更改:"
        echo "$git_status" | while read line; do
            echo "      $line"
        done
        echo ""
        echo -e "  ${YELLOW}建议: 先提交或暂存当前更改${NC}"
    else
        echo -e "  ${GREEN}✓${NC} 工作区干净"
    fi
    
    # 3. 检查强制执行机制
    echo ""
    echo -e "${CYAN}[3/3] 强制执行机制检查${NC}"
    local hooks_enabled=$(git config core.hooksPath 2>/dev/null)
    if [ "$hooks_enabled" = ".githooks" ]; then
        echo -e "  ${GREEN}✓${NC} Git Hooks 已启用"
    else
        echo -e "  ${YELLOW}!${NC} Git Hooks 未启用"
        echo -e "  ${YELLOW}  建议执行: bash scripts/enforce.sh install${NC}"
    fi
    
    echo ""
    
    if [ "$checks_passed" = true ]; then
        return 0
    else
        return 1
    fi
}

# 强制读取知识库（核心机制）
force_read_knowledge() {
    echo -e "${YELLOW}[强制步骤] 查阅知识库...${NC}"
    echo ""
    
    # 显示已验证代码库摘要
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}已验证代码库摘要 (docs/已验证代码库.md)${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    
    if [ -f "$PROJECT_DIR/docs/已验证代码库.md" ]; then
        # 提取主要章节标题
        grep -E "^##+ " "$PROJECT_DIR/docs/已验证代码库.md" | head -20
    fi
    
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # 显示用户教导摘要
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}用户教导记录摘要 (docs/用户教导记录.md)${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    
    if [ -f "$PROJECT_DIR/docs/用户教导记录.md" ]; then
        grep -E "^##+ " "$PROJECT_DIR/docs/用户教导记录.md" | head -10
    fi
    
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # 显示最近的问题记录
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}最近问题记录 (DEBUG_LOG.md)${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    
    if [ -f "$PROJECT_DIR/DEBUG_LOG.md" ]; then
        # 显示最近3条问题记录的标题
        grep -E "^## [0-9]" "$PROJECT_DIR/DEBUG_LOG.md" | head -3
    fi
    
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
}

# 新功能开发流程
task_new_feature() {
    log_task "任务类型: 新功能开发"
    
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              新功能开发流程                                ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # 执行前置检查
    run_pre_checks
    
    # 强制读取知识库
    force_read_knowledge
    
    # 显示开发流程
    echo -e "${YELLOW}[开发流程]${NC}"
    echo ""
    echo "  Step 1: 确认功能需求"
    echo "          - 功能描述是否清晰？"
    echo "          - 涉及哪些平台/模块？"
    echo "          - 是否有参考实现？"
    echo ""
    echo "  Step 2: 查找可复用代码"
    echo "          - 检查 docs/已验证代码库.md"
    echo "          - 检查 docs/用户教导记录.md"
    echo "          - 确定复用策略"
    echo ""
    echo "  Step 3: 实现功能"
    echo "          - 从已验证代码复制"
    echo "          - 只添加，不修改已有代码"
    echo "          - 保持函数签名一致"
    echo ""
    echo "  Step 4: 测试验证"
    echo "          - 执行功能测试"
    echo "          - 边缘情况测试"
    echo "          - 确保已有功能不受影响"
    echo ""
    echo "  Step 5: 更新文档"
    echo "          - 更新 docs/已验证代码库.md"
    echo "          - 更新 DEBUG_LOG.md（如有问题）"
    echo "          - 执行 bash scripts/sync-check.sh"
    echo ""
    
    # 启动完整开发流程
    echo -e "${GREEN}启动完整开发流程检查...${NC}"
    echo ""
    source "$PROJECT_DIR/scripts/dev-flow.sh"
}

# 问题调试流程
task_debug() {
    log_task "任务类型: 问题调试"
    
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              问题调试流程                                  ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # 执行前置检查
    run_pre_checks
    
    # 显示调试流程
    echo -e "${YELLOW}[调试流程] 五步诊断法${NC}"
    echo ""
    echo "  Step 1: 现象确认"
    echo "          - 问题是什么？"
    echo "          - 何时发生？"
    echo "          - 影响范围？"
    echo ""
    echo "  Step 2: 定位范围"
    echo "          - 查 DEBUG_LOG.md 是否有类似问题"
    echo "          - 查 docs/已验证代码库.md 确认选择器"
    echo "          - 查 docs/用户教导记录.md 确认操作逻辑"
    echo ""
    echo "  Step 3: 根因分析"
    echo "          - 使用 scripts/probe-page.js 分析页面"
    echo "          - 检查元素是否存在/可见"
    echo "          - 检查时序问题"
    echo ""
    echo "  Step 4: 解决方案"
    echo "          - 最小改动原则"
    echo "          - 从已验证代码复制"
    echo "          - 不修改核心逻辑"
    echo ""
    echo "  Step 5: 经验总结"
    echo "          - 更新 DEBUG_LOG.md"
    echo "          - 更新 docs/已验证代码库.md"
    echo "          - 更新 docs/经验积累机制.md"
    echo ""
    
    # 询问问题类型
    echo -e "${GREEN}请描述问题: ${NC}\c"
    read problem_desc
    log_task "问题描述: $problem_desc"
    echo ""
    
    # 搜索知识库中的相关内容
    echo -e "${CYAN}[自动搜索知识库]${NC}"
    echo ""
    
    if [ -f "$PROJECT_DIR/DEBUG_LOG.md" ]; then
        echo -e "${YELLOW}相关历史问题:${NC}"
        grep -i -A 3 "$problem_desc" "$PROJECT_DIR/DEBUG_LOG.md" 2>/dev/null | head -20
        echo ""
    fi
    
    if [ -f "$PROJECT_DIR/docs/已验证代码库.md" ]; then
        echo -e "${YELLOW}相关已验证代码:${NC}"
        grep -i -A 3 "$problem_desc" "$PROJECT_DIR/docs/已验证代码库.md" 2>/dev/null | head -20
        echo ""
    fi
    
    # 执行诊断
    echo -e "${GREEN}执行诊断检查...${NC}"
    bash "$PROJECT_DIR/scripts/diagnose.sh" --check
}

# 代码优化流程
task_optimize() {
    log_task "任务类型: 代码优化"
    
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              代码优化流程                                  ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # 执行前置检查
    run_pre_checks
    
    # 显示优化原则
    echo -e "${YELLOW}[核心原则]${NC}"
    echo ""
    echo "  1. 稳定性优先 - 能跑的代码不要动"
    echo "  2. 最小改动 - 只修改必要的部分"
    echo "  3. 渐进优化 - 一次只优化一个方面"
    echo "  4. 可回滚 - 优化前必须创建回滚点"
    echo ""
    
    # 显示优化流程
    echo -e "${YELLOW}[优化流程]${NC}"
    echo ""
    echo "  Step 1: 评估必要性"
    echo "          - 是否真的需要优化？"
    echo "          - 是否有可量化的指标？"
    echo "          - 收益是否大于风险？"
    echo ""
    echo "  Step 2: 建立基准"
    echo "          - pnpm optimize:baseline"
    echo "          - 创建 git commit（回滚点）"
    echo ""
    echo "  Step 3: 实施优化"
    echo "          - 最小改动原则"
    echo "          - 保持接口不变"
    echo ""
    echo "  Step 4: 验证效果"
    echo "          - pnpm optimize:check"
    echo "          - pnpm optimize:compare"
    echo "          - 功能验证"
    echo ""
    echo "  Step 5: 提交或回滚"
    echo "          - 通过: 提交并更新文档"
    echo "          - 失败: pnpm optimize:rollback"
    echo ""
    
    # 执行优化前检查
    echo -e "${GREEN}执行优化前检查...${NC}"
    bash "$PROJECT_DIR/scripts/optimization.sh" --pre-check
}

# 代码重构流程
task_refactor() {
    log_task "任务类型: 代码重构"
    
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              代码重构流程                                  ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # 执行前置检查
    run_pre_checks
    
    # 强制读取知识库
    force_read_knowledge
    
    # 显示重构原则
    echo -e "${YELLOW}[重构原则]${NC}"
    echo ""
    echo "  1. 测试先行 - 重构前确保有测试"
    echo "  2. 小步前进 - 每次只重构一小部分"
    echo "  3. 频繁验证 - 每次修改后立即测试"
    echo "  4. 保持行为 - 不改变外部行为"
    echo ""
    
    # 显示重构流程
    echo -e "${YELLOW}[重构流程]${NC}"
    echo ""
    echo "  Step 1: 识别重构目标"
    echo "          - 哪些代码需要重构？"
    echo "          - 重构的目的是什么？"
    echo ""
    echo "  Step 2: 建立安全网"
    echo "          - 创建 git commit"
    echo "          - 记录当前行为"
    echo "          - 准备回滚方案"
    echo ""
    echo "  Step 3: 小步重构"
    echo "          - 提取函数"
    echo "          - 移动代码"
    echo "          - 重命名"
    echo ""
    echo "  Step 4: 验证"
    echo "          - 运行测试"
    echo "          - 检查功能"
    echo "          - 确认行为不变"
    echo ""
    echo "  Step 5: 更新文档"
    echo "          - 更新结构说明"
    echo "          - 更新 API 文档"
    echo ""
    
    # 警告
    echo -e "${RED}[警告] 重构风险较高，建议:${NC}"
    echo ""
    echo "  1. 先执行 pnpm optimize:baseline 建立基准"
    echo "  2. 确保有可运行的测试"
    echo "  3. 每次修改后立即测试"
    echo ""
    
    # 启动开发流程
    echo -e "${GREEN}启动开发流程检查...${NC}"
    source "$PROJECT_DIR/scripts/dev-flow.sh"
}

# 文档维护流程
task_doc() {
    log_task "任务类型: 文档维护"
    
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              文档维护流程                                  ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # 显示文档维护规范
    echo -e "${YELLOW}[文档维护规范]${NC}"
    echo ""
    echo "  1. 所有文档必须有元数据头"
    echo "  2. 更新后必须更新最后更新时间"
    echo "  3. 代码修改后必须同步更新相关文档"
    echo "  4. 新增功能必须更新已验证代码库"
    echo ""
    
    # 显示文档检查
    echo -e "${GREEN}执行文档检查...${NC}"
    bash "$PROJECT_DIR/scripts/doc-check.sh" --core
}

# 完整检查流程
task_check() {
    log_task "任务类型: 完整检查"
    
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              完整检查流程                                  ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    local all_passed=true
    
    # 1. 同步性检查
    echo -e "${CYAN}[1/5] 代码-文档同步性检查${NC}"
    bash "$PROJECT_DIR/scripts/sync-check.sh"
    if [ $? -ne 0 ]; then
        all_passed=false
    fi
    
    # 2. 文档完整性检查
    echo ""
    echo -e "${CYAN}[2/5] 文档完整性检查${NC}"
    bash "$PROJECT_DIR/scripts/doc-check.sh" --core
    if [ $? -ne 0 ]; then
        all_passed=false
    fi
    
    # 3. 编码规范检查
    echo ""
    echo -e "${CYAN}[3/5] 编码规范检查${NC}"
    bash "$PROJECT_DIR/scripts/enforce.sh" check
    if [ $? -ne 0 ]; then
        all_passed=false
    fi
    
    # 4. 功能验证
    echo ""
    echo -e "${CYAN}[4/5] 功能验证${NC}"
    bash "$PROJECT_DIR/scripts/validate.sh"
    if [ $? -ne 0 ]; then
        all_passed=false
    fi
    
    # 5. 性能基准
    echo ""
    echo -e "${CYAN}[5/5] 性能基准测试${NC}"
    node "$PROJECT_DIR/scripts/benchmark.js" --all
    if [ $? -ne 0 ]; then
        all_passed=false
    fi
    
    # 汇总结果
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    if [ "$all_passed" = true ]; then
        echo -e "${GREEN}✓ 所有检查通过${NC}"
    else
        echo -e "${RED}✗ 存在检查未通过，请修复后再继续${NC}"
    fi
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
}

# 快速参考
task_reference() {
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║              快速参考                                      ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    # 核心命令
    echo -e "${CYAN}[核心命令]${NC}"
    echo ""
    echo "  pnpm list              # 列出作品"
    echo "  pnpm find              # 查找章节"
    echo "  pnpm copy              # 复制内容"
    echo "  pnpm validate          # 验证功能"
    echo ""
    
    # 流程命令
    echo -e "${CYAN}[流程命令]${NC}"
    echo ""
    echo "  source scripts/task.sh         # 任务入口"
    echo "  source scripts/dev-flow.sh     # 开发流程"
    echo "  bash scripts/diagnose.sh       # 诊断流程"
    echo "  bash scripts/optimization.sh   # 优化流程"
    echo ""
    
    # 检查命令
    echo -e "${CYAN}[检查命令]${NC}"
    echo ""
    echo "  pnpm check:all         # 完整检查"
    echo "  pnpm sync              # 同步检查"
    echo "  pnpm doc:check         # 文档检查"
    echo "  pnpm enforce:check     # 强制检查"
    echo ""
    
    # 核心原则
    echo -e "${CYAN}[核心原则]${NC}"
    echo ""
    echo "  1. 不要修改已工作的代码"
    echo "  2. 滚动前必须点击获取焦点"
    echo "  3. localStorage 后必须刷新页面"
    echo "  4. 文件夹有箭头，需要排除"
    echo "  5. 等待时间不能随意减少"
    echo ""
    
    # 关键文档
    echo -e "${CYAN}[关键文档]${NC}"
    echo ""
    echo "  PROJECT_STANDARDS.md      # 项目规范"
    echo "  docs/已验证代码库.md       # 已验证代码"
    echo "  docs/用户教导记录.md       # 用户教导"
    echo "  DEBUG_LOG.md              # 问题记录"
    echo ""
}

# 主入口
main() {
    show_banner
    
    local task_type="${1:-}"
    
    # 如果没有参数，显示菜单
    if [ -z "$task_type" ]; then
        show_task_menu
        echo -e "${GREEN}请选择 [1-7]: ${NC}\c"
        read choice
        
        case "$choice" in
            1) task_type="new-feature" ;;
            2) task_type="debug" ;;
            3) task_type="optimize" ;;
            4) task_type="refactor" ;;
            5) task_type="doc" ;;
            6) task_type="check" ;;
            7) task_type="reference" ;;
            *)
                echo -e "${RED}无效选择${NC}"
                return 1
                ;;
        esac
    fi
    
    # 执行对应任务
    case "$task_type" in
        new-feature|new)
            task_new_feature
            ;;
        debug|bug)
            task_debug
            ;;
        optimize|optimization)
            task_optimize
            ;;
        refactor|refactoring)
            task_refactor
            ;;
        doc|document)
            task_doc
            ;;
        check|all)
            task_check
            ;;
        reference|ref|help)
            task_reference
            ;;
        *)
            echo -e "${RED}未知任务类型: $task_type${NC}"
            echo ""
            echo "可用类型:"
            echo "  new-feature, debug, optimize, refactor, doc, check, reference"
            return 1
            ;;
    esac
    
    log_task "任务完成: $task_type"
}

# 执行主函数
main "$@"
