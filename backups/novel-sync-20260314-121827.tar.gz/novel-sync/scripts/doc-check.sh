#!/bin/bash
# 文档完整性检查脚本
# 强制检查文档是否与代码同步更新
#
# 用法:
#   bash scripts/doc-check.sh           # 检查所有文档
#   bash scripts/doc-check.sh --core    # 只检查核心文档
#   bash scripts/doc-check.sh --staged  # 只检查暂存的文件
#   bash scripts/doc-check.sh --report  # 生成报告

PROJECT_DIR="/workspace/projects/workspace/projects/novel-sync"
DOC_META_DIR="$PROJECT_DIR/.doc-meta"
REPORT_FILE="$PROJECT_DIR/.doc-report.md"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 解析参数
MODE="all"
while [[ $# -gt 0 ]]; do
    case $1 in
        --core) MODE="core"; shift ;;
        --staged) MODE="staged"; shift ;;
        --report) MODE="report"; shift ;;
        --fix) MODE="fix"; shift ;;
        *) shift ;;
    esac
done

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              文档完整性强制检查                            ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

cd "$PROJECT_DIR"

# ===== 文档定义 =====
# 格式: 文档路径|触发条件|关联文件|必须检查

# 核心文档（必须维护）
CORE_DOCS=(
    "docs/已验证代码库.md|代码变更|src/platforms/baimeng/*.js;src/utils/*.js|true"
    "docs/用户教导记录.md|用户教导|所有文件|true"
    "DEBUG_LOG.md|问题解决|所有文件|true"
    "PROJECT_STANDARDS.md|规范变更|所有文件|true"
    "CODING_STANDARDS.md|编码变更|所有文件|true"
)

# 知识库文档
KNOWLEDGE_DOCS=(
    "docs/元素选择器字典.md|选择器发现|src/platforms/baimeng/*.js|false"
    "docs/白梦操作手册.md|操作变更|src/platforms/baimeng/*.js|false"
    "docs/白梦快速参考.md|参考更新|所有文件|false"
    "docs/存储规范.md|存储变更|scripts/storage.sh|false"
    "docs/功能开发进度.md|功能完成|所有文件|false"
)

# 模块文档
MODULE_DOCS=(
    "src/platforms/baimeng/README.md|模块变更|src/platforms/baimeng/*.js|true"
    "src/utils/README.md|工具变更|src/utils/*.js|true"
    "README.md|项目变更|所有文件|false"
)

# ===== 检查函数 =====

# 检查文档是否存在
check_doc_exists() {
    local doc="$1"
    if [ -f "$PROJECT_DIR/$doc" ]; then
        return 0
    else
        return 1
    fi
}

# 检查文档元数据
check_doc_metadata() {
    local doc="$1"
    if [ ! -f "$PROJECT_DIR/$doc" ]; then
        echo "missing"
        return 1
    fi
    
    # 检查是否包含元数据块
    if head -20 "$PROJECT_DIR/$doc" | grep -q "文档元数据\|最后更新\|更新时间"; then
        echo "ok"
    else
        echo "missing_meta"
    fi
}

# 获取文件的最后修改时间
get_file_mtime() {
    local file="$1"
    if [ -f "$PROJECT_DIR/$file" ]; then
        stat -c %Y "$PROJECT_DIR/$file" 2>/dev/null || stat -f %m "$PROJECT_DIR/$file" 2>/dev/null
    else
        echo "0"
    fi
}

# 检查文档是否比关联代码新
check_doc_freshness() {
    local doc="$1"
    local related_files="$2"
    
    local doc_mtime=$(get_file_mtime "$doc")
    local need_update=false
    
    # 分割关联文件
    IFS=';' read -ra FILES <<< "$related_files"
    
    for pattern in "${FILES[@]}"; do
        # 处理通配符
        for file in $PROJECT_DIR/$pattern; do
            if [ -f "$file" ]; then
                local file_mtime=$(get_file_mtime "${file#$PROJECT_DIR/}")
                if [ "$file_mtime" -gt "$doc_mtime" ]; then
                    need_update=true
                    break 2
                fi
            fi
        done
    done
    
    if [ "$need_update" = true ]; then
        echo "stale"
    else
        echo "fresh"
    fi
}

# 检查文档内容完整性
check_doc_content() {
    local doc="$1"
    local min_lines="${2:-50}"
    
    if [ ! -f "$PROJECT_DIR/$doc" ]; then
        echo "missing"
        return 1
    fi
    
    local lines=$(wc -l < "$PROJECT_DIR/$doc")
    
    if [ "$lines" -lt "$min_lines" ]; then
        echo "incomplete"
    else
        echo "complete"
    fi
}

# 检查单个文档
check_single_doc() {
    local doc_entry="$1"
    IFS='|' read -r doc trigger related_files required <<< "$doc_entry"
    
    local result=""
    local status=""
    local message=""
    
    # 1. 检查存在性
    if ! check_doc_exists "$doc"; then
        result="missing"
        status="✗"
        message="文档不存在"
        echo "$status|$doc|$trigger|$message|$required"
        return 1
    fi
    
    # 2. 检查元数据
    local meta_status=$(check_doc_metadata "$doc")
    if [ "$meta_status" = "missing_meta" ]; then
        result="no_meta"
        status="⚠"
        message="缺少元数据"
        echo "$status|$doc|$trigger|$message|$required"
        return 0  # 警告不返回失败
    fi
    
    # 3. 检查新鲜度
    if [ "$related_files" != "所有文件" ]; then
        local freshness=$(check_doc_freshness "$doc" "$related_files")
        if [ "$freshness" = "stale" ]; then
            result="stale"
            status="⚠"
            message="文档可能过期（关联代码已更新）"
            echo "$status|$doc|$trigger|$message|$required"
            return 0  # 警告不返回失败
        fi
    fi
    
    # 4. 全部通过
    result="ok"
    status="✓"
    message="正常"
    echo "$status|$doc|$trigger|$message|$required"
    return 0
}

# ===== 执行检查 =====

TOTAL=0
PASS=0
WARN=0
FAIL=0
RESULTS=""
FAILED_DOCS=""

check_docs_array() {
    local docs=("$@")
    
    for doc_entry in "${docs[@]}"; do
        TOTAL=$((TOTAL + 1))
        
        local result=$(check_single_doc "$doc_entry")
        local status=$(echo "$result" | cut -d'|' -f1)
        local doc=$(echo "$result" | cut -d'|' -f2)
        local trigger=$(echo "$result" | cut -d'|' -f3)
        local message=$(echo "$result" | cut -d'|' -f4)
        local required=$(echo "$result" | cut -d'|' -f5)
        
        case "$status" in
            ✓)
                PASS=$((PASS + 1))
                echo -e "  ${GREEN}✓${NC} $doc"
                ;;
            ⚠)
                WARN=$((WARN + 1))
                echo -e "  ${YELLOW}⚠${NC} $doc - $message"
                ;;
            ✗)
                FAIL=$((FAIL + 1))
                echo -e "  ${RED}✗${NC} $doc - $message"
                if [ "$required" = "true" ]; then
                    FAILED_DOCS="$FAILED_DOCS $doc"
                fi
                ;;
        esac
        
        RESULTS="$RESULTS\n$result"
    done
}

# 根据模式选择检查范围
case "$MODE" in
    core)
        echo -e "${YELLOW}核心文档检查:${NC}"
        echo ""
        check_docs_array "${CORE_DOCS[@]}"
        ;;
    
    staged)
        echo -e "${YELLOW}暂存文件相关文档检查:${NC}"
        echo ""
        
        # 获取暂存的 JS 文件
        STAGED_JS=$(git diff --cached --name-only --diff-filter=ACM -- '*.js' 2>/dev/null || echo "")
        
        if [ -n "$STAGED_JS" ]; then
            echo "暂存的 JS 文件:"
            echo "$STAGED_JS" | while read file; do
                echo "  - $file"
            done
            echo ""
            
            # 检查相关文档
            check_docs_array "${CORE_DOCS[@]}"
        else
            echo "无暂存的 JS 文件"
        fi
        ;;
    
    report|all|*)
        echo -e "${YELLOW}[1/3] 核心文档:${NC}"
        echo ""
        check_docs_array "${CORE_DOCS[@]}"
        
        echo ""
        echo -e "${YELLOW}[2/3] 知识库文档:${NC}"
        echo ""
        check_docs_array "${KNOWLEDGE_DOCS[@]}"
        
        echo ""
        echo -e "${YELLOW}[3/3] 模块文档:${NC}"
        echo ""
        check_docs_array "${MODULE_DOCS[@]}"
        ;;
esac

# ===== 生成报告 =====

if [ "$MODE" = "report" ]; then
    cat > "$REPORT_FILE" << EOF
# 文档完整性检查报告

生成时间: $(date '+%Y-%m-%d %H:%M:%S')

## 统计

- 总计: $TOTAL 个文档
- 通过: $PASS 个
- 警告: $WARN 个
- 失败: $FAIL 个

## 详细结果

| 状态 | 文档 | 触发条件 | 消息 | 必须 |
|------|------|----------|------|------|
$(echo -e "$RESULTS" | while IFS='|' read -r status doc trigger message required; do
    echo "| $status | $doc | $trigger | $message | $required |"
done)

## 需要更新的文档

$(if [ -n "$FAILED_DOCS" ]; then
    echo "以下必须维护的文档存在问题:"
    for doc in $FAILED_DOCS; do
        echo "- $doc"
    done
else
    echo "所有必须维护的文档状态正常。"
fi)
EOF
    
    echo ""
    echo -e "${GREEN}✓ 报告已生成: $REPORT_FILE${NC}"
fi

# ===== 输出统计 =====

echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""

echo "统计:"
echo "  总计: $TOTAL 个文档"
echo -e "  通过: ${GREEN}$PASS${NC} 个"
echo -e "  警告: ${YELLOW}$WARN${NC} 个"
echo -e "  失败: ${RED}$FAIL${NC} 个"

# ===== 返回状态 =====

if [ $FAIL -gt 0 ]; then
    echo ""
    echo -e "${RED}✗ 存在必须维护的文档缺失或损坏${NC}"
    echo ""
    echo "需要修复的文档:"
    for doc in $FAILED_DOCS; do
        echo "  - $doc"
    done
    echo ""
    echo "修复方法:"
    echo "  1. 创建缺失的文档"
    echo "  2. 或运行: bash scripts/doc-check.sh --fix"
    echo ""
    exit 1
elif [ $WARN -gt 0 ]; then
    echo ""
    echo -e "${YELLOW}⚠ 文档检查通过，但存在警告${NC}"
    echo ""
    echo "建议修复:"
    echo "  - 为缺少元数据的文档添加元数据块"
    echo "  - 检查标记为过期的文档是否需要更新"
    echo ""
    exit 0
else
    echo ""
    echo -e "${GREEN}✓ 所有文档检查通过${NC}"
    echo ""
    exit 0
fi
