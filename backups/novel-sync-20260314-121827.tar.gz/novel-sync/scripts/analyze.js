#!/usr/bin/env node
/**
 * 对象信息分析工具
 * 分析页面元素、数据结构、API响应等
 * 
 * 用法:
 *   node scripts/analyze.js --element ".sidebar"      # 分析元素
 *   node scripts/analyze.js --data "localStorage"     # 分析数据
 *   node scripts/analyze.js --page                    # 分析整个页面
 *   node scripts/analyze.js --compare before after    # 对比差异
 */

const fs = require('fs');
const path = require('path');

// 分析模板
const ANALYSIS_TEMPLATE = {
    element: {
        selector: '',
        exists: false,
        visible: false,
        html: '',
        attributes: {},
        styles: {},
        children: [],
        parent: null,
        position: { x: 0, y: 0, width: 0, height: 0 }
    },
    data: {
        type: '',
        size: 0,
        keys: [],
        sample: null,
        valid: false,
        issues: []
    },
    page: {
        url: '',
        title: '',
        elements: {},
        scripts: [],
        localStorage: {},
        cookies: []
    }
};

// 元素分析函数（用于 Playwright context）
const ELEMENT_ANALYSIS_SCRIPT = `
(selector) => {
    const element = document.querySelector(selector);
    if (!element) {
        return { exists: false, error: 'Element not found' };
    }
    
    const rect = element.getBoundingClientRect();
    const styles = window.getComputedStyle(element);
    
    return {
        exists: true,
        visible: styles.display !== 'none' && styles.visibility !== 'hidden',
        tagName: element.tagName,
        className: element.className,
        id: element.id,
        text: element.innerText ? element.innerText.substring(0, 200) : '',
        html: element.outerHTML.substring(0, 1000),
        attributes: Array.from(element.attributes).reduce((acc, attr) => {
            acc[attr.name] = attr.value;
            return acc;
        }, {}),
        styles: {
            display: styles.display,
            visibility: styles.visibility,
            position: styles.position,
            width: styles.width,
            height: styles.height,
            overflow: styles.overflow
        },
        position: {
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height
        },
        childrenCount: element.children.length,
        parentTag: element.parentElement ? element.parentElement.tagName : null,
        parentClass: element.parentElement ? element.parentElement.className : null
    };
}
`;

// 页面分析函数（用于 Playwright context）
const PAGE_ANALYSIS_SCRIPT = `
() => {
    const analysis = {
        url: window.location.href,
        title: document.title,
        readyState: document.readyState,
        elements: {},
        forms: [],
        scripts: [],
        links: [],
        localStorage: {},
        sessionStorage: {},
        cookies: document.cookie
    };
    
    // 分析关键元素
    const keySelectors = [
        '.sidebar', '.editor', '.content', 'main', 'nav',
        '[class*="chapter"]', '[class*="title"]', '[class*="button"]',
        'button', 'input', 'textarea', 'select'
    ];
    
    for (const selector of keySelectors) {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
            analysis.elements[selector] = {
                count: elements.length,
                samples: Array.from(elements).slice(0, 3).map(el => ({
                    tag: el.tagName,
                    class: el.className,
                    text: (el.innerText || '').substring(0, 50)
                }))
            };
        }
    }
    
    // 分析表单
    analysis.forms = Array.from(document.querySelectorAll('form')).map(form => ({
        action: form.action,
        method: form.method,
        inputs: Array.from(form.querySelectorAll('input')).map(input => ({
            name: input.name,
            type: input.type
        }))
    }));
    
    // 分析脚本
    analysis.scripts = Array.from(document.querySelectorAll('script')).map(script => ({
        src: script.src,
        inline: !script.src,
        content: script.src ? null : (script.textContent || '').substring(0, 100)
    }));
    
    // 分析链接
    analysis.links = Array.from(document.querySelectorAll('a[href]')).slice(0, 10).map(a => ({
        href: a.href,
        text: (a.innerText || '').substring(0, 50)
    }));
    
    // 分析存储
    try {
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            analysis.localStorage[key] = localStorage.getItem(key).substring(0, 100);
        }
        for (let i = 0; i < sessionStorage.length; i++) {
            const key = sessionStorage.key(i);
            analysis.sessionStorage[key] = sessionStorage.getItem(key).substring(0, 100);
        }
    } catch (e) {
        analysis.storageError = e.message;
    }
    
    return analysis;
}
`;

// 数据分析函数
function analyzeData(data, type = 'unknown') {
    const analysis = {
        type: type,
        timestamp: new Date().toISOString(),
        issues: []
    };
    
    // 类型检测
    if (data === null) {
        analysis.actualType = 'null';
        analysis.issues.push('数据为 null');
        return analysis;
    }
    
    if (data === undefined) {
        analysis.actualType = 'undefined';
        analysis.issues.push('数据为 undefined');
        return analysis;
    }
    
    analysis.actualType = Array.isArray(data) ? 'array' : typeof data;
    
    // 大小分析
    if (typeof data === 'string') {
        analysis.size = data.length;
        analysis.sample = data.substring(0, 200);
    } else if (Array.isArray(data)) {
        analysis.size = data.length;
        analysis.sample = data.slice(0, 5);
    } else if (typeof data === 'object') {
        analysis.keys = Object.keys(data);
        analysis.size = analysis.keys.length;
        analysis.sample = {};
        for (const key of analysis.keys.slice(0, 10)) {
            const value = data[key];
            analysis.sample[key] = typeof value === 'string' ? value.substring(0, 50) : 
                                   typeof value === 'object' ? `{${Object.keys(value || {}).length} keys}` :
                                   value;
        }
    }
    
    // 问题检测
    if (analysis.size === 0) {
        analysis.issues.push('数据为空');
    }
    
    if (analysis.actualType === 'object' && !analysis.keys) {
        analysis.issues.push('对象无法遍历');
    }
    
    analysis.valid = analysis.issues.length === 0;
    
    return analysis;
}

// 对比分析函数
function compareObjects(before, after, path = '') {
    const diff = [];
    
    const allKeys = new Set([
        ...Object.keys(before || {}),
        ...Object.keys(after || {})
    ]);
    
    for (const key of allKeys) {
        const currentPath = path ? `${path}.${key}` : key;
        const beforeValue = before?.[key];
        const afterValue = after?.[key];
        
        if (beforeValue === undefined && afterValue !== undefined) {
            diff.push({ path: currentPath, type: 'added', before: undefined, after: typeof afterValue });
        } else if (beforeValue !== undefined && afterValue === undefined) {
            diff.push({ path: currentPath, type: 'removed', before: typeof beforeValue, after: undefined });
        } else if (typeof beforeValue !== typeof afterValue) {
            diff.push({ path: currentPath, type: 'type_changed', before: typeof beforeValue, after: typeof afterValue });
        } else if (typeof beforeValue === 'object' && beforeValue !== null) {
            diff.push(...compareObjects(beforeValue, afterValue, currentPath));
        } else if (beforeValue !== afterValue) {
            diff.push({ path: currentPath, type: 'changed', before: beforeValue, after: afterValue });
        }
    }
    
    return diff;
}

// 生成分析报告
function generateReport(analysis, type) {
    const reportPath = `/workspace/projects/workspace/projects/novel-sync/.analysis-report.json`;
    
    const report = {
        timestamp: new Date().toISOString(),
        type: type,
        analysis: analysis,
        summary: {
            issues: analysis.issues?.length || 0,
            valid: analysis.valid !== false
        }
    };
    
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
    
    return reportPath;
}

// 主函数
async function main() {
    const args = process.argv.slice(2);
    
    console.log('\n╔══════════════════════════════════════════════════════════╗');
    console.log('║              对象信息分析工具                              ║');
    console.log('╚══════════════════════════════════════════════════════════╝\n');
    
    // 解析参数
    let mode = 'help';
    let target = '';
    
    for (let i = 0; i < args.length; i++) {
        if (args[i] === '--element' || args[i] === '-e') {
            mode = 'element';
            target = args[i + 1];
            i++;
        } else if (args[i] === '--data' || args[i] === '-d') {
            mode = 'data';
            target = args[i + 1];
            i++;
        } else if (args[i] === '--page' || args[i] === '-p') {
            mode = 'page';
        } else if (args[i] === '--compare' || args[i] === '-c') {
            mode = 'compare';
            target = [args[i + 1], args[i + 2]];
            i += 2;
        } else if (args[i] === '--script' || args[i] === '-s') {
            mode = 'script';
            console.log('\n=== 元素分析脚本 ===\n');
            console.log(ELEMENT_ANALYSIS_SCRIPT);
            console.log('\n=== 页面分析脚本 ===\n');
            console.log(PAGE_ANALYSIS_SCRIPT);
            return;
        }
    }
    
    switch (mode) {
        case 'element':
            console.log('元素分析模式');
            console.log('选择器:', target);
            console.log('\n在 Playwright 中使用以下代码:');
            console.log('```javascript');
            console.log(`const analysis = await page.evaluate(${ELEMENT_ANALYSIS_SCRIPT}, '${target}');`);
            console.log('console.log(analysis);');
            console.log('```\n');
            break;
            
        case 'data':
            console.log('数据分析模式');
            console.log('数据源:', target);
            console.log('\n使用方法:');
            console.log('```javascript');
            console.log('const analysis = analyzeData(data, "localStorage");');
            console.log('console.log(analysis);');
            console.log('```\n');
            
            // 如果是文件，尝试分析
            const dataPath = path.join('/workspace/projects/workspace/projects/novel-sync', target);
            if (fs.existsSync(dataPath)) {
                try {
                    const data = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
                    const analysis = analyzeData(data, 'file');
                    console.log('=== 分析结果 ===\n');
                    console.log(JSON.stringify(analysis, null, 2));
                } catch (e) {
                    console.log('无法解析文件:', e.message);
                }
            }
            break;
            
        case 'page':
            console.log('页面分析模式');
            console.log('\n在 Playwright 中使用以下代码:');
            console.log('```javascript');
            console.log(`const analysis = await page.evaluate(${PAGE_ANALYSIS_SCRIPT});`);
            console.log('console.log(analysis);');
            console.log('```\n');
            break;
            
        case 'compare':
            console.log('对比分析模式');
            console.log('对比文件:', target);
            if (target.length === 2) {
                try {
                    const beforePath = path.join('/workspace/projects/workspace/projects/novel-sync', target[0]);
                    const afterPath = path.join('/workspace/projects/workspace/projects/novel-sync', target[1]);
                    
                    if (fs.existsSync(beforePath) && fs.existsSync(afterPath)) {
                        const before = JSON.parse(fs.readFileSync(beforePath, 'utf-8'));
                        const after = JSON.parse(fs.readFileSync(afterPath, 'utf-8'));
                        
                        const diff = compareObjects(before, after);
                        
                        console.log('\n=== 差异报告 ===\n');
                        if (diff.length === 0) {
                            console.log('无差异');
                        } else {
                            diff.forEach(d => {
                                console.log(`${d.path}: ${d.type}`);
                                console.log(`  前: ${JSON.stringify(d.before)}`);
                                console.log(`  后: ${JSON.stringify(d.after)}`);
                            });
                        }
                    } else {
                        console.log('文件不存在');
                    }
                } catch (e) {
                    console.log('对比失败:', e.message);
                }
            }
            break;
            
        default:
            console.log('用法:');
            console.log('  node scripts/analyze.js --element ".sidebar"    # 分析元素');
            console.log('  node scripts/analyze.js --data "file.json"      # 分析数据');
            console.log('  node scripts/analyze.js --page                  # 分析页面');
            console.log('  node scripts/analyze.js --compare a.json b.json # 对比差异');
            console.log('  node scripts/analyze.js --script                # 输出分析脚本');
            break;
    }
}

main().catch(console.error);

// 导出函数供外部使用
module.exports = {
    analyzeData,
    compareObjects,
    ELEMENT_ANALYSIS_SCRIPT,
    PAGE_ANALYSIS_SCRIPT
};
