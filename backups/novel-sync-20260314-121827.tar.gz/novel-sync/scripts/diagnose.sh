#!/bin/bash
# Bug诊断工具
# 系统化诊断问题，快速定位根因
#
# 用法:
#   bash scripts/diagnose.sh                    # 启动诊断模式
#   bash scripts/diagnose.sh --issue "问题描述"  # 诊断特定问题
#   bash scripts/diagnose.sh --auto             # 自动诊断（需要浏览器环境）
#   bash scripts/diagnose.sh --check            # 检查常见问题

PROJECT_DIR="/workspace/projects/workspace/projects/novel-sync"
DEBUG_LOG="$PROJECT_DIR/DEBUG_LOG.md"
VERIFIED_CODE="$PROJECT_DIR/docs/已验证代码库.md"
USER_TEACHING="$PROJECT_DIR/docs/用户教导记录.md"
DIAG_LOG="$PROJECT_DIR/.diagnose.log"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BLUE='\033[0;34m'
NC='\033[0m'

# 解析参数
MODE="interactive"
ISSUE_DESC=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --issue|-i)
            ISSUE_DESC="$2"
            MODE="issue"
            shift 2
            ;;
        --auto|-a)
            MODE="auto"
            shift
            ;;
        --check|-c)
            MODE="check"
            shift
            ;;
        --history|-h)
            MODE="history"
            shift
            ;;
        *)
            shift
            ;;
    esac
done

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              Bug 诊断工具                                  ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

cd "$PROJECT_DIR"

# ===== 问题分类映射 =====
declare -A ISSUE_PATTERNS=(
    ["登录|白屏|auth"]="登录问题:检查localStorage|检查刷新页面|检查凭证过期"
    ["章节|找不到|找不到章节|sidebar"]="章节问题:检查选择器|检查滚动|检查元素可见性"
    ["复制|copy|复制失败"]="复制问题:检查复制按钮|检查内容加载|检查权限"
    ["内容|获取|content"]="内容问题:检查选择器|检查滚动加载|检查权限"
    ["滚动|无法滚动|滚动无效"]="滚动问题:检查焦点|检查元素|检查事件"
    ["点击|click|点击无效"]="点击问题:检查元素可点击|检查遮挡|检查JS点击"
    ["超时|timeout|等待"]="超时问题:增加等待时间|检查网络|检查页面加载"
    ["选择器|selector|找不到元素"]="选择器问题:探测页面|检查选择器|更新选择器字典"
)

# ===== 诊断函数 =====

# 根据问题描述给出诊断步骤
diagnose_by_issue() {
    local issue="$1"
    
    echo -e "${YELLOW}问题描述:${NC} $issue"
    echo ""
    
    # 匹配问题模式
    local matched=false
    for pattern in "${!ISSUE_PATTERNS[@]}"; do
        if [[ "$issue" =~ $pattern ]]; then
            matched=true
            local category="${ISSUE_PATTERNS[$pattern]}"
            IFS=':' read -r cat_name steps <<< "$category"
            
            echo -e "${GREEN}匹配问题类型:${NC} $cat_name"
            echo ""
            echo -e "${CYAN}诊断步骤:${NC}"
            
            IFS='|' read -ra step_array <<< "$steps"
            local i=1
            for step in "${step_array[@]}"; do
                echo "  $i. $step"
                i=$((i + 1))
            done
            echo ""
            
            # 查询历史类似问题
            echo -e "${CYAN}历史类似问题:${NC}"
            grep -i -A 5 "$pattern" "$DEBUG_LOG" 2>/dev/null | head -20 || echo "  无历史记录"
            echo ""
            
            # 查询已验证代码
            echo -e "${CYAN}相关已验证代码:${NC}"
            grep -i -A 10 "$pattern" "$VERIFIED_CODE" 2>/dev/null | head -15 || echo "  无相关代码"
            echo ""
            
            break
        fi
    done
    
    if [ "$matched" = false ]; then
        echo -e "${YELLOW}未匹配到已知问题类型，使用通用诊断流程${NC}"
        echo ""
        echo -e "${CYAN}通用诊断步骤:${NC}"
        echo "  1. 确认问题现象（预期 vs 实际）"
        echo "  2. 定位问题模块（auth/works/sidebar/content/copy）"
        echo "  3. 检查输入数据"
        echo "  4. 检查处理逻辑"
        echo "  5. 检查输出结果"
        echo ""
    fi
}

# 检查常见问题
check_common_issues() {
    echo -e "${YELLOW}检查常见问题...${NC}"
    echo ""
    
    local issues_found=0
    
    # 1. 检查文档完整性
    echo -e "${CYAN}[1/5] 文档完整性${NC}"
    local core_docs=("docs/已验证代码库.md" "docs/用户教导记录.md" "DEBUG_LOG.md")
    for doc in "${core_docs[@]}"; do
        if [ -f "$PROJECT_DIR/$doc" ]; then
            echo -e "  ${GREEN}✓${NC} $doc"
        else
            echo -e "  ${RED}✗${NC} $doc [缺失]"
            issues_found=$((issues_found + 1))
        fi
    done
    echo ""
    
    # 2. 检查代码同步
    echo -e "${CYAN}[2/5] 代码-文档同步${NC}"
    local sync_result=$(bash scripts/sync-check.sh 2>&1 | grep -E "通过|失败|警告" | tail -5)
    echo "$sync_result"
    echo ""
    
    # 3. 检查浏览器数据
    echo -e "${CYAN}[3/5] 浏览器数据${NC}"
    if [ -d "$PROJECT_DIR/browser-data" ]; then
        local data_size=$(du -sh "$PROJECT_DIR/browser-data" 2>/dev/null | cut -f1)
        echo -e "  ${GREEN}✓${NC} browser-data 存在 ($data_size)"
    else
        echo -e "  ${YELLOW}⚠${NC} browser-data 不存在（首次运行会创建）"
    fi
    echo ""
    
    # 4. 检查登录备份
    echo -e "${CYAN}[4/5] 登录凭证备份${NC}"
    if [ -f "$PROJECT_DIR/storage/accounts/baimeng/backup.json" ]; then
        echo -e "  ${GREEN}✓${NC} 白梦登录备份存在"
        # 检查是否过期（超过7天）
        local backup_time=$(stat -c %Y "$PROJECT_DIR/storage/accounts/baimeng/backup.json" 2>/dev/null || echo "0")
        local current_time=$(date +%s)
        local age_days=$(( (current_time - backup_time) / 86400 ))
        if [ $age_days -gt 7 ]; then
            echo -e "  ${YELLOW}⚠${NC} 备份已过期 ($age_days 天前)"
        fi
    else
        echo -e "  ${RED}✗${NC} 白梦登录备份不存在"
        issues_found=$((issues_found + 1))
    fi
    echo ""
    
    # 5. 检查依赖
    echo -e "${CYAN}[5/5] 依赖检查${NC}"
    if [ -d "$PROJECT_DIR/node_modules" ]; then
        echo -e "  ${GREEN}✓${NC} node_modules 存在"
        if [ -d "$PROJECT_DIR/node_modules/playwright" ]; then
            echo -e "  ${GREEN}✓${NC} playwright 已安装"
        else
            echo -e "  ${RED}✗${NC} playwright 未安装"
            issues_found=$((issues_found + 1))
        fi
    else
        echo -e "  ${RED}✗${NC} node_modules 不存在，请运行 pnpm install"
        issues_found=$((issues_found + 1))
    fi
    echo ""
    
    # 汇总
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    if [ $issues_found -gt 0 ]; then
        echo -e "${RED}发现 $issues_found 个潜在问题${NC}"
        echo ""
        echo "建议修复:"
        echo "  - 运行 pnpm install 安装依赖"
        echo "  - 运行 pnpm storage:backup 备份登录凭证"
        echo "  - 运行 pnpm doc:check 检查文档"
    else
        echo -e "${GREEN}未发现常见问题${NC}"
    fi
}

# 查看历史问题
show_history() {
    echo -e "${YELLOW}最近的问题记录:${NC}"
    echo ""
    
    if [ -f "$DEBUG_LOG" ]; then
        # 提取最近的问题标题
        grep -E "^### " "$DEBUG_LOG" | head -10
        echo ""
        echo -e "${CYAN}查看详细记录: cat DEBUG_LOG.md${NC}"
    else
        echo "  无历史记录"
    fi
}

# 自动诊断
auto_diagnose() {
    echo -e "${YELLOW}自动诊断模式${NC}"
    echo ""
    
    echo "请选择诊断项目:"
    echo "  1. 登录状态"
    echo "  2. 页面元素"
    echo "  3. 章节查找"
    echo "  4. 内容获取"
    echo "  5. 复制功能"
    echo ""
    echo -e "${GREEN}请输入数字 (1-5): ${NC}\c"
    read choice
    
    case $choice in
        1)
            echo ""
            echo -e "${CYAN}诊断登录状态...${NC}"
            echo ""
            echo "检查项:"
            echo "  □ 备份文件是否存在"
            echo "  □ localStorage 是否有效"
            echo "  □ 页面是否正确加载"
            echo "  □ 登录状态是否保持"
            echo ""
            echo "运行命令: node -e \"const fs = require('fs'); console.log(JSON.parse(fs.readFileSync('storage/accounts/baimeng/backup.json', 'utf-8')));\""
            ;;
        2)
            echo ""
            echo -e "${CYAN}诊断页面元素...${NC}"
            echo ""
            echo "运行命令: node scripts/probe-page.js"
            ;;
        3)
            echo ""
            echo -e "${CYAN}诊断章节查找...${NC}"
            echo ""
            echo "检查项:"
            echo "  □ 侧边栏是否存在"
            echo "  □ 章节元素选择器是否正确"
            echo "  □ 滚动是否生效"
            echo "  □ 点击是否正确"
            echo ""
            echo "运行命令: node baimeng-chapter-finder.js"
            ;;
        4)
            echo ""
            echo -e "${CYAN}诊断内容获取...${NC}"
            echo ""
            echo "检查项:"
            echo "  □ 内容区域选择器是否正确"
            echo "  □ 内容是否需要滚动加载"
            echo "  □ 获取的内容是否完整"
            echo ""
            echo "运行命令: node baimeng-copy.js"
            ;;
        5)
            echo ""
            echo -e "${CYAN}诊断复制功能...${NC}"
            echo ""
            echo "检查项:"
            echo "  □ 复制按钮是否存在"
            echo "  □ 复制按钮是否可点击"
            echo "  □ 剪贴板是否可用"
            echo ""
            echo "运行命令: node baimeng-copy.js"
            ;;
        *)
            echo "无效选择"
            ;;
    esac
}

# 交互式诊断
interactive_diagnose() {
    echo -e "${YELLOW}交互式诊断模式${NC}"
    echo ""
    
    echo "请描述您遇到的问题（输入关键词，如：登录失败、章节找不到、复制无效）:"
    echo ""
    echo -e "${GREEN}问题描述: ${NC}\c"
    read issue
    
    if [ -n "$issue" ]; then
        echo ""
        diagnose_by_issue "$issue"
        
        # 记录诊断
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] 诊断: $issue" >> "$DIAG_LOG"
        
        echo ""
        echo -e "${CYAN}诊断完成，是否需要记录此问题到 DEBUG_LOG.md？[y/n]: ${NC}\c"
        read record
        
        if [ "$record" = "y" ]; then
            echo ""
            echo "请按照以下模板记录问题:"
            echo ""
            echo "### [分类] $issue"
            echo ""
            echo "**时间**: $(date '+%Y-%m-%d %H:%M')"
            echo ""
            echo "**现象**:"
            echo "- 场景："
            echo "- 预期："
            echo "- 实际："
            echo ""
            echo "**诊断过程**:"
            echo "1. Step 1 - 现象确认："
            echo "2. Step 2 - 定位范围："
            echo "3. Step 3 - 根因分析："
            echo "4. Step 4 - 解决方案："
            echo ""
            echo "**解决方案**:"
            echo "\`\`\`javascript"
            echo "// 修复代码"
            echo "\`\`\`"
            echo ""
            echo "**教训**:"
            echo ""
            echo ""
            echo -e "${CYAN}请将以上内容添加到 DEBUG_LOG.md${NC}"
        fi
    fi
}

# ===== 主执行 =====

case "$MODE" in
    issue)
        diagnose_by_issue "$ISSUE_DESC"
        ;;
    check)
        check_common_issues
        ;;
    history)
        show_history
        ;;
    auto)
        auto_diagnose
        ;;
    *)
        interactive_diagnose
        ;;
esac
