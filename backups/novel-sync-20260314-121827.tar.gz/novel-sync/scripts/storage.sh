#!/bin/bash
# 存储管理脚本 - 备份、恢复、验证登录状态
# 用法: bash scripts/storage.sh <命令> [参数]
#
# 命令:
#   backup <平台> <账号ID>   备份登录状态
#   restore <平台> <账号ID>  恢复登录状态
#   verify <平台> <账号ID>   验证登录状态
#   list <平台>              列出所有备份
#   migrate                  迁移旧数据到新结构

set -e

# 路径
NOVEL_SYNC_DIR="/workspace/projects/workspace/projects/novel-sync"
STORAGE_DIR="$NOVEL_SYNC_DIR/storage"
BROWSER_DATA="$NOVEL_SYNC_DIR/browser-data"
ACCOUNTS_DIR="$STORAGE_DIR/accounts"
CACHE_DIR="$STORAGE_DIR/cache"

# 颜色
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 帮助
show_help() {
    echo ""
    echo -e "${CYAN}存储管理脚本${NC}"
    echo ""
    echo "用法: bash scripts/storage.sh <命令> [参数]"
    echo ""
    echo "命令:"
    echo "  backup <平台> <账号ID>    备份登录状态"
    echo "  restore <平台> <账号ID>   恢复登录状态"
    echo "  verify <平台> <账号ID>    验证登录状态"
    echo "  list <平台>               列出所有备份"
    echo "  migrate                   迁移旧数据到新结构"
    echo ""
    echo "平台: baimeng, fanqie"
    echo "账号ID: 1, 2, 3..."
    echo ""
    echo "示例:"
    echo "  bash scripts/storage.sh backup baimeng 1"
    echo "  bash scripts/storage.sh restore baimeng 1"
    echo "  bash scripts/storage.sh list baimeng"
    echo ""
}

# 备份登录状态
backup_account() {
    local platform="$1"
    local account_id="$2"
    
    if [ -z "$platform" ] || [ -z "$account_id" ]; then
        echo -e "${RED}错误: 缺少参数${NC}"
        echo "用法: bash scripts/storage.sh backup <平台> <账号ID>"
        exit 1
    fi
    
    local account_dir="$ACCOUNTS_DIR/$platform/account-$account_id"
    mkdir -p "$account_dir"
    
    echo -e "${YELLOW}备份 $platform 账号 $account_id ...${NC}"
    
    # 检查浏览器数据目录
    if [ ! -d "$BROWSER_DATA/Default" ]; then
        echo -e "${RED}错误: 浏览器数据目录不存在${NC}"
        exit 1
    fi
    
    # 备份 Cookies
    if [ -f "$BROWSER_DATA/Default/Cookies" ]; then
        cp "$BROWSER_DATA/Default/Cookies" "$account_dir/Cookies"
        echo -e "${GREEN}✓ Cookies 已备份${NC}"
    fi
    
    # 备份 Local Storage
    if [ -d "$BROWSER_DATA/Default/Local Storage" ]; then
        cp -r "$BROWSER_DATA/Default/Local Storage" "$account_dir/"
        echo -e "${GREEN}✓ Local Storage 已备份${NC}"
    fi
    
    # 备份 Session Storage
    if [ -d "$BROWSER_DATA/Default/Session Storage" ]; then
        cp -r "$BROWSER_DATA/Default/Session Storage" "$account_dir/"
        echo -e "${GREEN}✓ Session Storage 已备份${NC}"
    fi
    
    # 备份 IndexedDB
    if [ -d "$BROWSER_DATA/Default/IndexedDB" ]; then
        cp -r "$BROWSER_DATA/Default/IndexedDB" "$account_dir/"
        echo -e "${GREEN}✓ IndexedDB 已备份${NC}"
    fi
    
    # 记录备份时间
    echo "$(date '+%Y-%m-%d %H:%M:%S')" > "$account_dir/backup-time.txt"
    
    # 创建摘要
    echo "{
  \"platform\": \"$platform\",
  \"accountId\": \"$account_id\",
  \"backupTime\": \"$(date -Iseconds)\",
  \"files\": {
    \"cookies\": $( [ -f "$account_dir/Cookies" ] && echo 'true' || echo 'false' ),
    \"localStorage\": $( [ -d "$account_dir/Local Storage" ] && echo 'true' || echo 'false' ),
    \"sessionStorage\": $( [ -d "$account_dir/Session Storage" ] && echo 'true' || echo 'false' ),
    \"indexedDB\": $( [ -d "$account_dir/IndexedDB" ] && echo 'true' || echo 'false' )
  }
}" > "$account_dir/manifest.json"
    
    echo ""
    echo -e "${GREEN}✓ 备份完成: $account_dir${NC}"
}

# 恢复登录状态
restore_account() {
    local platform="$1"
    local account_id="$2"
    
    if [ -z "$platform" ] || [ -z "$account_id" ]; then
        echo -e "${RED}错误: 缺少参数${NC}"
        echo "用法: bash scripts/storage.sh restore <平台> <账号ID>"
        exit 1
    fi
    
    local account_dir="$ACCOUNTS_DIR/$platform/account-$account_id"
    
    if [ ! -d "$account_dir" ]; then
        echo -e "${RED}错误: 备份不存在: $account_dir${NC}"
        exit 1
    fi
    
    echo -e "${YELLOW}恢复 $platform 账号 $account_id ...${NC}"
    
    # 确保目标目录存在
    mkdir -p "$BROWSER_DATA/Default"
    
    # 恢复 Cookies
    if [ -f "$account_dir/Cookies" ]; then
        cp "$account_dir/Cookies" "$BROWSER_DATA/Default/Cookies"
        echo -e "${GREEN}✓ Cookies 已恢复${NC}"
    fi
    
    # 恢复 Local Storage
    if [ -d "$account_dir/Local Storage" ]; then
        rm -rf "$BROWSER_DATA/Default/Local Storage"
        cp -r "$account_dir/Local Storage" "$BROWSER_DATA/Default/"
        echo -e "${GREEN}✓ Local Storage 已恢复${NC}"
    fi
    
    # 恢复 Session Storage
    if [ -d "$account_dir/Session Storage" ]; then
        rm -rf "$BROWSER_DATA/Default/Session Storage"
        cp -r "$account_dir/Session Storage" "$BROWSER_DATA/Default/"
        echo -e "${GREEN}✓ Session Storage 已恢复${NC}"
    fi
    
    # 恢复 IndexedDB
    if [ -d "$account_dir/IndexedDB" ]; then
        rm -rf "$BROWSER_DATA/Default/IndexedDB"
        cp -r "$account_dir/IndexedDB" "$BROWSER_DATA/Default/"
        echo -e "${GREEN}✓ IndexedDB 已恢复${NC}"
    fi
    
    # 记录恢复时间
    echo "$(date '+%Y-%m-%d %H:%M:%S')" > "$account_dir/restore-time.txt"
    
    echo ""
    echo -e "${GREEN}✓ 恢复完成${NC}"
    echo -e "${YELLOW}注意: 需要重启浏览器才能生效${NC}"
}

# 验证登录状态
verify_account() {
    local platform="$1"
    local account_id="$2"
    
    if [ -z "$platform" ] || [ -z "$account_id" ]; then
        echo -e "${RED}错误: 缺少参数${NC}"
        echo "用法: bash scripts/storage.sh verify <平台> <账号ID>"
        exit 1
    fi
    
    local account_dir="$ACCOUNTS_DIR/$platform/account-$account_id"
    
    echo -e "${YELLOW}验证 $platform 账号 $account_id ...${NC}"
    
    if [ ! -d "$account_dir" ]; then
        echo -e "${RED}✗ 备份不存在${NC}"
        exit 1
    fi
    
    local has_error=0
    
    # 检查文件
    if [ -f "$account_dir/Cookies" ]; then
        echo -e "${GREEN}✓ Cookies: 存在 ($(du -h "$account_dir/Cookies" | cut -f1))${NC}"
    else
        echo -e "${RED}✗ Cookies: 不存在${NC}"
        has_error=1
    fi
    
    if [ -d "$account_dir/Local Storage" ]; then
        echo -e "${GREEN}✓ Local Storage: 存在${NC}"
    else
        echo -e "${YELLOW}⚠ Local Storage: 不存在${NC}"
    fi
    
    if [ -f "$account_dir/manifest.json" ]; then
        echo -e "${GREEN}✓ Manifest: 存在${NC}"
        cat "$account_dir/manifest.json"
    else
        echo -e "${YELLOW}⚠ Manifest: 不存在${NC}"
    fi
    
    if [ -f "$account_dir/backup-time.txt" ]; then
        echo ""
        echo "备份时间: $(cat "$account_dir/backup-time.txt")"
    fi
    
    echo ""
    if [ $has_error -eq 0 ]; then
        echo -e "${GREEN}✓ 验证通过${NC}"
    else
        echo -e "${RED}✗ 验证失败${NC}"
        exit 1
    fi
}

# 列出备份
list_accounts() {
    local platform="$1"
    
    if [ -z "$platform" ]; then
        echo -e "${YELLOW}所有平台备份:${NC}"
        echo ""
        for p in baimeng fanqie; do
            if [ -d "$ACCOUNTS_DIR/$p" ]; then
                echo "[$p]"
                ls -1 "$ACCOUNTS_DIR/$p" 2>/dev/null | sed 's/^/  /'
            fi
        done
    else
        echo -e "${YELLOW}$platform 备份列表:${NC}"
        echo ""
        if [ -d "$ACCOUNTS_DIR/$platform" ]; then
            for dir in "$ACCOUNTS_DIR/$platform"/*; do
                if [ -d "$dir" ]; then
                    name=$(basename "$dir")
                    if [ -f "$dir/backup-time.txt" ]; then
                        time=$(cat "$dir/backup-time.txt")
                        echo "  $name (备份: $time)"
                    else
                        echo "  $name"
                    fi
                fi
            done
        else
            echo "  (无)"
        fi
    fi
    echo ""
}

# 迁移旧数据
migrate_old_data() {
    echo -e "${YELLOW}迁移旧数据到新结构...${NC}"
    echo ""
    
    local old_dir="/workspace/projects/cookies-accounts"
    local migrated=0
    
    # 确保目标目录存在
    mkdir -p "$CACHE_DIR"
    mkdir -p "$ACCOUNTS_DIR/baimeng"
    mkdir -p "$ACCOUNTS_DIR/fanqie"
    
    if [ ! -d "$old_dir" ]; then
        echo -e "${YELLOW}旧目录不存在，跳过迁移${NC}"
        return
    fi
    
    # 迁移所有 *-works.json 和 *-chapters.json 到 cache
    for file in "$old_dir"/*-works.json "$old_dir"/*-chapters.json "$old_dir"/*-summary.json "$old_dir"/match-*.json; do
        if [ -f "$file" ]; then
            filename=$(basename "$file")
            cp "$file" "$CACHE_DIR/$filename"
            echo "✓ 迁移到缓存: $filename"
            ((migrated++))
        fi
    done
    
    # 迁移白梦账号数据
    for file in "$old_dir"/baimeng-account-*.json; do
        if [ -f "$file" ]; then
            filename=$(basename "$file")
            # 提取账号ID (支持 baimeng-account-1, baimeng-account-1-full 等)
            account_id=$(echo "$filename" | grep -oE 'account-[0-9]+' | grep -oE '[0-9]+')
            
            if [ -n "$account_id" ]; then
                target_dir="$ACCOUNTS_DIR/baimeng/account-$account_id"
                mkdir -p "$target_dir"
                
                # 区分文件类型
                case "$filename" in
                    *-full.json)
                        cp "$file" "$target_dir/full-backup.json"
                        echo "✓ 迁移: $filename -> baimeng/account-$account_id/full-backup.json"
                        ;;
                    *-works.json)
                        # works 文件已在上面迁移到 cache
                        ;;
                    *)
                        cp "$file" "$target_dir/$filename"
                        echo "✓ 迁移: $filename -> baimeng/account-$account_id/"
                        ;;
                esac
                ((migrated++))
            fi
        fi
    done
    
    # 迁移番茄账号数据
    for file in "$old_dir"/fanqie-account-*.json; do
        if [ -f "$file" ]; then
            filename=$(basename "$file")
            account_id=$(echo "$filename" | grep -oE 'account-[0-9]+' | grep -oE '[0-9]+')
            
            if [ -n "$account_id" ]; then
                target_dir="$ACCOUNTS_DIR/fanqie/account-$account_id"
                mkdir -p "$target_dir"
                
                case "$filename" in
                    *-works.json|*-chapters.json)
                        # 已迁移到 cache
                        ;;
                    *)
                        cp "$file" "$target_dir/$filename"
                        echo "✓ 迁移: $filename -> fanqie/account-$account_id/"
                        ;;
                esac
                ((migrated++))
            fi
        fi
    done
    
    # 迁移项目根目录的缓存
    if [ -f "$NOVEL_SYNC_DIR/.baimeng-works-cache.json" ]; then
        mv "$NOVEL_SYNC_DIR/.baimeng-works-cache.json" "$CACHE_DIR/baimeng-works-cache.json"
        echo "✓ 迁移: .baimeng-works-cache.json -> cache/baimeng-works-cache.json"
        ((migrated++))
    fi
    
    echo ""
    echo -e "${GREEN}✓ 迁移完成，共迁移 $migrated 个文件${NC}"
    echo ""
    echo "新目录结构:"
    echo "  storage/accounts/baimeng/  - 白梦账号数据"
    echo "  storage/accounts/fanqie/   - 番茄账号数据"
    echo "  storage/cache/             - 缓存数据"
    echo ""
    echo -e "${YELLOW}提示: 旧数据保留在 $old_dir，确认无误后可手动删除${NC}"
}

# 主入口
case "${1:-}" in
    backup)
        backup_account "$2" "$3"
        ;;
    restore)
        restore_account "$2" "$3"
        ;;
    verify)
        verify_account "$2" "$3"
        ;;
    list)
        list_accounts "$2"
        ;;
    migrate)
        migrate_old_data
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        show_help
        exit 1
        ;;
esac
