#!/bin/bash
# 同步性检查脚本
# 确保代码和文档保持同步
#
# 用法:
#   bash scripts/sync-check.sh           # 检查同步性
#   bash scripts/sync-check.sh --fix     # 自动修复
#   bash scripts/sync-check.sh --report  # 生成报告

PROJECT_DIR="/workspace/projects/workspace/projects/novel-sync"
VERIFIED_CODE="$PROJECT_DIR/docs/已验证代码库.md"
USER_TEACHING="$PROJECT_DIR/docs/用户教导记录.md"
DEBUG_LOG="$PROJECT_DIR/DEBUG_LOG.md"
SYNC_LOG="$PROJECT_DIR/.sync-check.log"
SYNC_STATUS="$PROJECT_DIR/.sync-status.json"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 解析参数
MODE="check"
AUTO_FIX=false
SHOW_REPORT=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --fix|-f)
            AUTO_FIX=true
            MODE="fix"
            shift
            ;;
        --report|-r)
            SHOW_REPORT=true
            MODE="report"
            shift
            ;;
        --auto-update)
            AUTO_FIX=true
            MODE="auto-update"
            shift
            ;;
        *)
            shift
            ;;
    esac
done

# 初始化日志
echo "[$(date '+%Y-%m-%d %H:%M:%S')] 同步检查开始 (模式: $MODE)" > "$SYNC_LOG"

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              代码-文档同步性检查                           ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

cd "$PROJECT_DIR"

# ===== 定义同步规则 =====
# 格式: 源文件|文档文件|章节标识|检查函数名
SYNC_RULES=(
    "src/platforms/baimeng/auth.js|docs/已验证代码库.md|登录恢复|restoreLogin"
    "src/platforms/baimeng/works.js|docs/已验证代码库.md|作品列表获取|getWorks"
    "src/platforms/baimeng/sidebar.js|docs/已验证代码库.md|侧边栏操作|findChapter"
    "src/platforms/baimeng/content.js|docs/已验证代码库.md|内容获取|getContent"
    "src/platforms/baimeng/copy.js|docs/已验证代码库.md|复制操作|clickCopyButton"
    "src/utils/browser-manager.js|docs/已验证代码库.md|浏览器管理|BrowserManager"
)

# ===== 检查函数 =====

check_sync() {
    local rule="$1"
    IFS='|' read -r src_file doc_file section func_name <<< "$rule"
    
    local status="✓"
    local message="同步"
    local src_path="$PROJECT_DIR/$src_file"
    local doc_path="$PROJECT_DIR/$doc_file"
    
    # 检查源文件是否存在
    if [ ! -f "$src_path" ]; then
        status="⚠"
        message="源文件不存在"
        return 1
    fi
    
    # 检查文档是否存在
    if [ ! -f "$doc_path" ]; then
        status="✗"
        message="文档不存在"
        return 1
    fi
    
    # 检查文档中是否有对应的章节
    if ! grep -q "##.*$section\|###.*$section" "$doc_path" 2>/dev/null; then
        status="✗"
        message="文档缺少章节: $section"
        return 1
    fi
    
    # 检查函数是否在源文件中存在
    if ! grep -q "$func_name" "$src_path" 2>/dev/null; then
        status="⚠"
        message="函数不存在: $func_name"
        return 1
    fi
    
    # 检查文档中是否记录了该函数
    if ! grep -q "$func_name" "$doc_path" 2>/dev/null; then
        status="⚠"
        message="文档未记录函数: $func_name"
        return 1
    fi
    
    echo "$status|$src_file|$doc_file|$section|$message"
    return 0
}

# ===== 执行检查 =====

TOTAL=0
PASS=0
FAIL=0
WARN=0
RESULTS=""

echo -e "${YELLOW}检查项目:${NC}"
echo ""

for rule in "${SYNC_RULES[@]}"; do
    TOTAL=$((TOTAL + 1))
    
    result=$(check_sync "$rule" 2>/dev/null)
    exit_code=$?
    
    if [ $exit_code -eq 0 ]; then
        PASS=$((PASS + 1))
        echo -e "  ${GREEN}✓${NC} $(echo "$rule" | cut -d'|' -f1) → $(echo "$rule" | cut -d'|' -f4)"
        RESULTS="$RESULTS\n$result"
    else
        if [[ "$result" == *"✗"* ]]; then
            FAIL=$((FAIL + 1))
            echo -e "  ${RED}✗${NC} $(echo "$rule" | cut -d'|' -f1) → $(echo "$rule" | cut -d'|' -f4) [缺失]"
        else
            WARN=$((WARN + 1))
            echo -e "  ${YELLOW}⚠${NC} $(echo "$rule" | cut -d'|' -f1) → $(echo "$rule" | cut -d'|' -f4) [警告]"
        fi
        RESULTS="$RESULTS\n$result"
    fi
done

# ===== 检查文档完整性 =====
echo ""
echo -e "${YELLOW}文档完整性:${NC}"
echo ""

check_doc_file() {
    local file="$1"
    local name="$2"
    
    if [ -f "$PROJECT_DIR/$file" ]; then
        local lines=$(wc -l < "$PROJECT_DIR/$file")
        local sections=$(grep -c "^##\|^###" "$PROJECT_DIR/$file" 2>/dev/null || echo "0")
        echo -e "  ${GREEN}✓${NC} $name ($lines 行, $sections 章节)"
        return 0
    else
        echo -e "  ${RED}✗${NC} $name [不存在]"
        return 1
    fi
}

check_doc_file "docs/已验证代码库.md" "已验证代码库"
check_doc_file "docs/用户教导记录.md" "用户教导记录"
check_doc_file "DEBUG_LOG.md" "调试日志"
check_doc_file "PROJECT_STANDARDS.md" "项目规范"

# ===== 检查脚本完整性 =====
echo ""
echo -e "${YELLOW}脚本完整性:${NC}"
echo ""

check_script_file() {
    local file="$1"
    local name="$2"
    
    if [ -f "$PROJECT_DIR/$file" ]; then
        if [ -x "$PROJECT_DIR/$file" ]; then
            echo -e "  ${GREEN}✓${NC} $name [可执行]"
        else
            echo -e "  ${YELLOW}⚠${NC} $name [不可执行]"
        fi
        return 0
    else
        echo -e "  ${RED}✗${NC} $name [不存在]"
        return 1
    fi
}

check_script_file "scripts/dev-flow.sh" "开发流程检查"
check_script_file "scripts/dev-check.sh" "快速检查"
check_script_file "scripts/sync-check.sh" "同步检查"
check_script_file "scripts/validate.sh" "功能验证"

# ===== 输出统计 =====
echo ""
echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}"
echo ""

echo "统计:"
echo "  总计: $TOTAL 项"
echo -e "  通过: ${GREEN}$PASS${NC} 项"
echo -e "  警告: ${YELLOW}$WARN${NC} 项"
echo -e "  失败: ${RED}$FAIL${NC} 项"

# ===== 生成报告 =====
if [ "$SHOW_REPORT" = true ]; then
    REPORT_FILE="$PROJECT_DIR/.sync-report.md"
    
    echo "# 同步检查报告" > "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "生成时间: $(date '+%Y-%m-%d %H:%M:%S')" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "## 统计" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "- 总计: $TOTAL 项" >> "$REPORT_FILE"
    echo "- 通过: $PASS 项" >> "$REPORT_FILE"
    echo "- 警告: $WARN 项" >> "$REPORT_FILE"
    echo "- 失败: $FAIL 项" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo "## 详细结果" >> "$REPORT_FILE"
    echo "" >> "$REPORT_FILE"
    echo -e "$RESULTS" >> "$REPORT_FILE"
    
    echo ""
    echo -e "${GREEN}✓ 报告已生成: $REPORT_FILE${NC}"
fi

# ===== 自动修复 =====
if [ "$AUTO_FIX" = true ] && [ $FAIL -gt 0 ]; then
    echo ""
    echo -e "${YELLOW}尝试自动修复...${NC}"
    
    # 检查并创建缺失的文档结构
    if [ ! -f "$VERIFIED_CODE" ]; then
        echo "  创建 docs/已验证代码库.md ..."
        mkdir -p "$(dirname "$VERIFIED_CODE")"
        cat > "$VERIFIED_CODE" << 'EOF'
# 已验证代码库

> 所有代码均来自已测试通过的脚本
> 
> **原则**: 从本文档复制代码，不重写

---

## 一、登录恢复

**状态**: ⏳ 待补充

```javascript
// 待补充
```

---

## 二、作品列表获取

**状态**: ⏳ 待补充

```javascript
// 待补充
```

---

## 三、侧边栏操作

**状态**: ⏳ 待补充

```javascript
// 待补充
```

---

## 四、内容获取

**状态**: ⏳ 待补充

```javascript
// 待补充
```

---

## 五、复制操作

**状态**: ⏳ 待补充

```javascript
// 待补充
```
EOF
    fi
    
    echo -e "${GREEN}✓ 自动修复完成，请手动补充缺失的代码片段${NC}"
fi

# ===== 返回状态 =====
if [ $FAIL -gt 0 ]; then
    echo ""
    echo -e "${RED}✗ 同步检查失败，请修复上述问题${NC}"
    echo ""
    echo "修复方法:"
    echo "  1. 手动编辑文档，补充缺失的代码片段"
    echo "  2. 或执行: bash scripts/sync-check.sh --fix"
    echo ""
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 同步检查失败" >> "$SYNC_LOG"
    exit 1
elif [ $WARN -gt 0 ]; then
    echo ""
    echo -e "${YELLOW}⚠ 同步检查通过，但有警告${NC}"
    echo ""
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 同步检查通过(有警告)" >> "$SYNC_LOG"
    exit 0
else
    echo ""
    echo -e "${GREEN}✓ 同步检查完全通过${NC}"
    echo ""
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] 同步检查通过" >> "$SYNC_LOG"
    exit 0
fi
