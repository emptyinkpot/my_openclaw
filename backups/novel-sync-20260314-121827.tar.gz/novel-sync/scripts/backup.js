#!/usr/bin/env node
/**
 * 备份系统 - 创建备份
 * 
 * 功能：
 * 1. 创建版本化备份（按时间戳命名）
 * 2. 备份章节原始内容、润色结果、配置文件、知识库
 * 3. 生成备份清单（manifest.json）
 * 4. 校验备份完整性
 * 5. 自动清理旧备份
 * 
 * 用法：
 *   node scripts/backup.js                    # 手动备份
 *   node scripts/backup.js --before-polish    # 润色前备份
 *   node scripts/backup.js --before-batch     # 批量操作前备份
 *   node scripts/backup.js --auto             # 自动备份（检查条件）
 * 
 * 返回：JSON 格式备份结果
 * 
 * @author OpenClaw 配置专家
 * @date 2026-03-14
 */

const { runTask } = require('../src/utils/task-runner');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// 加载配置
const backupConfig = require('../backup.config.js');

runTask('创建备份', async (ctx) => {
  const args = process.argv.slice(2);
  const isAutoBackup = args.includes('--auto');
  const isBeforePolish = args.includes('--before-polish');
  const isBeforeBatch = args.includes('--before-batch');
  
  // 自动备份时检查是否需要备份
  if (isAutoBackup) {
    if (!shouldAutoBackup()) {
      console.log('⏭️  不满足自动备份条件，跳过');
      return { skipped: true, reason: '不满足自动备份条件' };
    }
  }
  
  // 生成版本号（时间戳）
  const timestamp = new Date().toISOString().replace(/[-:T]/g, '').substring(0, 14);
  const version = `v${timestamp}`;
  const backupPath = path.join(backupConfig.backupDir, version);
  
  console.log(`\n📦 开始备份 - ${version}`);
  console.log('='.repeat(50));
  
  // 创建备份目录
  fs.mkdirSync(backupPath, { recursive: true });
  
  // 备份清单
  const manifest = {
    version,
    timestamp: new Date().toISOString(),
    trigger: isBeforePolish ? 'before-polish' : 
             isBeforeBatch ? 'before-batch' : 
             isAutoBackup ? 'auto' : 'manual',
    files: [],
    stats: {
      totalFiles: 0,
      totalSize: 0,
      successCount: 0,
      failedCount: 0
    }
  };
  
  // 执行备份
  for (const [name, target] of Object.entries(backupConfig.backupTargets)) {
    if (!target.enabled) continue;
    
    console.log(`\n📁 备份 ${name}...`);
    
    if (target.path) {
      // 备份目录
      const result = backupDirectory(
        path.join(process.cwd(), target.path),
        path.join(backupPath, name),
        name
      );
      manifest.files.push(...result.files);
      manifest.stats.totalFiles += result.files.length;
      manifest.stats.totalSize += result.totalSize;
      manifest.stats.successCount += result.successCount;
      manifest.stats.failedCount += result.failedCount;
    }
    
    if (target.files) {
      // 备份单个文件
      const targetDir = path.join(backupPath, name);
      fs.mkdirSync(targetDir, { recursive: true });
      
      for (const file of target.files) {
        const srcPath = path.join(process.cwd(), file);
        const destPath = path.join(targetDir, path.basename(file));
        
        if (fs.existsSync(srcPath)) {
          const size = backupFile(srcPath, destPath, file);
          if (size > 0) {
            manifest.files.push({
              name: file,
              path: destPath,
              size,
              checksum: calculateChecksum(destPath)
            });
            manifest.stats.totalFiles++;
            manifest.stats.totalSize += size;
            manifest.stats.successCount++;
            console.log(`  ✅ ${file} (${formatSize(size)})`);
          } else {
            manifest.stats.failedCount++;
            console.log(`  ❌ ${file} (备份失败)`);
          }
        }
      }
    }
  }
  
  // 保存清单
  const manifestPath = path.join(backupPath, 'manifest.json');
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
  console.log(`\n✅ 清单已保存: manifest.json`);
  
  // 更新备份索引
  updateBackupIndex(version, manifest);
  
  // 校验备份
  if (backupConfig.verify.enabled) {
    console.log('\n🔍 校验备份完整性...');
    const verifyResult = verifyBackup(backupPath, manifest);
    if (!verifyResult.success) {
      console.log('❌ 备份校验失败:', verifyResult.errors);
      // 回滚
      fs.rmSync(backupPath, { recursive: true });
      return { success: false, error: '备份校验失败', errors: verifyResult.errors };
    }
    console.log('✅ 备份校验通过');
  }
  
  // 清理旧备份
  console.log('\n🧹 清理旧备份...');
  cleanupOldBackups();
  
  console.log('\n' + '='.repeat(50));
  console.log(`✅ 备份完成: ${version}`);
  console.log(`📊 统计: ${manifest.stats.successCount} 个文件, ${formatSize(manifest.stats.totalSize)}`);
  console.log(`📍 路径: ${backupPath}`);
  
  return {
    success: true,
    version,
    path: backupPath,
    stats: manifest.stats
  };
});

/**
 * 备份目录
 */
function backupDirectory(srcDir, destDir, name) {
  const result = {
    files: [],
    totalSize: 0,
    successCount: 0,
    failedCount: 0
  };
  
  if (!fs.existsSync(srcDir)) {
    console.log(`  ⚠️  目录不存在: ${srcDir}`);
    return result;
  }
  
  fs.mkdirSync(destDir, { recursive: true });
  
  const files = fs.readdirSync(srcDir, { withFileTypes: true });
  
  for (const file of files) {
    if (file.isDirectory()) {
      // 递归备份子目录
      const subResult = backupDirectory(
        path.join(srcDir, file.name),
        path.join(destDir, file.name),
        name
      );
      result.files.push(...subResult.files);
      result.totalSize += subResult.totalSize;
      result.successCount += subResult.successCount;
      result.failedCount += subResult.failedCount;
    } else {
      // 备份文件
      const srcPath = path.join(srcDir, file.name);
      const destPath = path.join(destDir, file.name);
      const size = backupFile(srcPath, destPath, `${name}/${file.name}`);
      
      if (size > 0) {
        result.files.push({
          name: `${name}/${file.name}`,
          path: destPath,
          size,
          checksum: calculateChecksum(destPath)
        });
        result.totalSize += size;
        result.successCount++;
        console.log(`  ✅ ${file.name} (${formatSize(size)})`);
      } else {
        result.failedCount++;
        console.log(`  ❌ ${file.name} (备份失败)`);
      }
    }
  }
  
  return result;
}

/**
 * 备份单个文件
 */
function backupFile(srcPath, destPath, name) {
  try {
    fs.copyFileSync(srcPath, destPath);
    const stats = fs.statSync(destPath);
    return stats.size;
  } catch (error) {
    console.error(`  ❌ 备份失败 ${name}: ${error.message}`);
    return 0;
  }
}

/**
 * 计算文件校验和
 */
function calculateChecksum(filePath) {
  const content = fs.readFileSync(filePath);
  return crypto.createHash(backupConfig.verify.algorithm).update(content).digest('hex');
}

/**
 * 格式化文件大小
 */
function formatSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

/**
 * 更新备份索引
 */
function updateBackupIndex(version, manifest) {
  const indexPath = path.join(backupConfig.backupDir, 'backup-index.json');
  let index = { backups: [] };
  
  if (fs.existsSync(indexPath)) {
    index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
  }
  
  index.backups.push({
    version,
    timestamp: manifest.timestamp,
    trigger: manifest.trigger,
    stats: manifest.stats
  });
  
  // 按时间倒序排序
  index.backups.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  
  fs.writeFileSync(indexPath, JSON.stringify(index, null, 2));
  console.log('✅ 备份索引已更新');
}

/**
 * 校验备份完整性
 */
function verifyBackup(backupPath, manifest) {
  const errors = [];
  
  for (const file of manifest.files) {
    // 🔴 修复：file.path 已经是绝对路径
    const filePath = file.path;
    
    if (!fs.existsSync(filePath)) {
      errors.push(`文件不存在: ${file.name}`);
      continue;
    }
    
    const stats = fs.statSync(filePath);
    if (stats.size !== file.size) {
      errors.push(`文件大小不匹配: ${file.name} (期望: ${file.size}, 实际: ${stats.size})`);
      continue;
    }
    
    if (backupConfig.verify.enabled) {
      const checksum = calculateChecksum(filePath);
      if (checksum !== file.checksum) {
        errors.push(`校验和不匹配: ${file.name}`);
      }
    }
  }
  
  return {
    success: errors.length === 0,
    errors
  };
}

/**
 * 清理旧备份（保留策略）
 */
function cleanupOldBackups() {
  const indexPath = path.join(backupConfig.backupDir, 'backup-index.json');
  if (!fs.existsSync(indexPath)) return;
  
  const index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
  const now = Date.now();
  const toKeep = new Set();
  
  // 按保留策略选择要保留的备份
  const daily = backupConfig.retention.daily * 24 * 60 * 60 * 1000;
  const weekly = backupConfig.retention.weekly * 24 * 60 * 60 * 1000;
  const monthly = backupConfig.retention.monthly * 24 * 60 * 60 * 1000;
  
  // 最近7天的备份全部保留
  const recentDaily = index.backups.filter(b => 
    now - new Date(b.timestamp).getTime() < daily
  );
  recentDaily.forEach(b => toKeep.add(b.version));
  
  // 最近4周每周保留一份
  const recentWeekly = index.backups.filter(b => {
    const age = now - new Date(b.timestamp).getTime();
    return age >= daily && age < weekly;
  });
  
  // 按周分组，每周保留最新的一份
  const weeklyGroups = {};
  recentWeekly.forEach(b => {
    const week = Math.floor((now - new Date(b.timestamp).getTime()) / (7 * 24 * 60 * 60 * 1000));
    if (!weeklyGroups[week] || new Date(b.timestamp) > new Date(weeklyGroups[week].timestamp)) {
      weeklyGroups[week] = b;
    }
  });
  Object.values(weeklyGroups).forEach(b => toKeep.add(b.version));
  
  // 最近12月每月保留一份
  const recentMonthly = index.backups.filter(b => {
    const age = now - new Date(b.timestamp).getTime();
    return age >= weekly && age < monthly;
  });
  
  // 按月分组，每月保留最新的一份
  const monthlyGroups = {};
  recentMonthly.forEach(b => {
    const month = Math.floor((now - new Date(b.timestamp).getTime()) / (30 * 24 * 60 * 60 * 1000));
    if (!monthlyGroups[month] || new Date(b.timestamp) > new Date(monthlyGroups[month].timestamp)) {
      monthlyGroups[month] = b;
    }
  });
  Object.values(monthlyGroups).forEach(b => toKeep.add(b.version));
  
  // 删除不需要的备份
  let deletedCount = 0;
  index.backups.forEach(b => {
    if (!toKeep.has(b.version)) {
      const backupPath = path.join(backupConfig.backupDir, b.version);
      if (fs.existsSync(backupPath)) {
        fs.rmSync(backupPath, { recursive: true });
        console.log(`  🗑️  已删除: ${b.version}`);
        deletedCount++;
      }
    }
  });
  
  // 更新索引
  index.backups = index.backups.filter(b => toKeep.has(b.version));
  fs.writeFileSync(indexPath, JSON.stringify(index, null, 2));
  
  console.log(`✅ 清理完成: 删除 ${deletedCount} 个旧备份，保留 ${toKeep.size} 个`);
}

/**
 * 检查是否需要自动备份
 */
function shouldAutoBackup() {
  const indexPath = path.join(backupConfig.backupDir, 'backup-index.json');
  
  if (!fs.existsSync(indexPath)) {
    return true;  // 从未备份过
  }
  
  const index = JSON.parse(fs.readFileSync(indexPath, 'utf8'));
  const lastBackup = index.backups[0];
  
  if (!lastBackup) return true;
  
  // 如果上次备份是今天，跳过
  const lastDate = new Date(lastBackup.timestamp).toDateString();
  const today = new Date().toDateString();
  
  return lastDate !== today;
}
