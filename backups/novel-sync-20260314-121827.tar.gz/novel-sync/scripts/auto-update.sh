#!/bin/bash
# 自动更新机制
# 从源代码提取已验证代码片段，自动更新到文档
#
# 用法:
#   bash scripts/auto-update.sh              # 更新所有
#   bash scripts/auto-update.sh auth         # 只更新 auth 模块
#   bash scripts/auto-update.sh --dry-run    # 预览不执行

PROJECT_DIR="/workspace/projects/workspace/projects/novel-sync"
VERIFIED_CODE="$PROJECT_DIR/docs/已验证代码库.md"
USER_TEACHING="$PROJECT_DIR/docs/用户教导记录.md"
DEBUG_LOG="$PROJECT_DIR/DEBUG_LOG.md"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# 解析参数
DRY_RUN=false
TARGET_MODULE=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run|-n)
            DRY_RUN=true
            shift
            ;;
        auth|works|sidebar|content|copy|browser)
            TARGET_MODULE="$1"
            shift
            ;;
        *)
            shift
            ;;
    esac
done

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║              自动更新机制                                  ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

cd "$PROJECT_DIR"

# ===== 提取函数 =====

# 从源文件提取函数代码
extract_function() {
    local file="$1"
    local func_name="$2"
    
    if [ ! -f "$file" ]; then
        echo "# 文件不存在: $file"
        return 1
    fi
    
    # 使用 awk 提取函数（支持 async function 和 function）
    awk -v func="$func_name" '
        /^(async )?function[[:space:]]+'"${func_name}"'[([:space:]]/ { found=1; brace=0 }
        found { print; if (/\{/) brace++; if (/\}/) { brace--; if (brace==0) { found=0; exit } } }
    ' "$file"
}

# 提取模块导出的函数
extract_export() {
    local file="$1"
    local func_name="$2"
    
    if [ ! -f "$file" ]; then
        echo "# 文件不存在: $file"
        return 1
    fi
    
    # 提取 module.exports 或 exports 的函数
    awk -v func="$func_name" '
        /^(async )?function[[:space:]]+'"${func_name}"'[([:space:]]/ { found=1; brace=0 }
        found { print; if (/\{/) brace++; if (/\}/) { brace--; if (brace==0) { found=0; exit } } }
    ' "$file"
}

# ===== 更新函数 =====

update_verified_code() {
    local module="$1"
    local src_file=""
    local func_name=""
    local section=""
    
    case "$module" in
        auth)
            src_file="src/platforms/baimeng/auth.js"
            func_name="restoreLogin"
            section="登录恢复"
            ;;
        works)
            src_file="src/platforms/baimeng/works.js"
            func_name="getWorks"
            section="作品列表获取"
            ;;
        sidebar)
            src_file="src/platforms/baimeng/sidebar.js"
            func_name="findChapter"
            section="侧边栏操作"
            ;;
        content)
            src_file="src/platforms/baimeng/content.js"
            func_name="getContent"
            section="内容获取"
            ;;
        copy)
            src_file="src/platforms/baimeng/copy.js"
            func_name="clickCopyButton"
            section="复制操作"
            ;;
        *)
            echo -e "${RED}未知模块: $module${NC}"
            return 1
            ;;
    esac
    
    echo -e "${YELLOW}更新: $module ($src_file)${NC}"
    
    if [ ! -f "$PROJECT_DIR/$src_file" ]; then
        echo -e "  ${RED}✗ 源文件不存在${NC}"
        return 1
    fi
    
    # 提取代码
    local code=$(extract_function "$PROJECT_DIR/$src_file" "$func_name")
    
    if [ -z "$code" ]; then
        echo -e "  ${YELLOW}⚠ 未找到函数: $func_name${NC}"
        return 1
    fi
    
    if [ "$DRY_RUN" = true ]; then
        echo -e "  ${CYAN}预览代码:${NC}"
        echo "$code" | head -20
        echo "  ..."
        return 0
    fi
    
    # 更新文档（这里需要手动确认，因为自动替换有风险）
    echo -e "  ${GREEN}✓ 已提取代码 (${#code} 字符)${NC}"
    echo ""
    echo "请手动更新 docs/已验证代码库.md 的 '$section' 章节"
    echo ""
}

# ===== 执行更新 =====

MODULES=("auth" "works" "sidebar" "content" "copy")

if [ -n "$TARGET_MODULE" ]; then
    update_verified_code "$TARGET_MODULE"
else
    echo -e "${YELLOW}更新所有模块...${NC}"
    echo ""
    
    for module in "${MODULES[@]}"; do
        update_verified_code "$module"
    done
fi

# ===== 同步检查 =====
echo ""
echo -e "${CYAN}执行同步检查...${NC}"
bash "$PROJECT_DIR/scripts/sync-check.sh"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║              ✓ 自动更新完成                                ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
