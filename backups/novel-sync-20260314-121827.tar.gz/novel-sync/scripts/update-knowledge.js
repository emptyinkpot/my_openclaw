#!/usr/bin/env node
/**
 * 知识库更新脚本
 * 
 * 用途：
 *   1. 检查知识库完整性
 *   2. 提示需要更新的文档
 *   3. 更新 KNOWLEDGE_INDEX.md 最近更新部分
 * 
 * 使用：
 *   node scripts/update-knowledge.js           # 检查状态
 *   node scripts/update-knowledge.js --sync    # 同步最近更新
 */

const path = require('path');
const fs = require('fs');

const PROJECT_ROOT = path.join(__dirname, '..');

// 知识库文件列表
const KNOWLEDGE_FILES = {
  problem: { path: 'DEBUG_LOG.md', name: '问题解决方案', priority: '🔴 最高' },
  code: { path: 'docs/已验证代码库.md', name: '已验证代码', priority: '🔴 最高' },
  critical: { path: 'CRITICAL_ISSUE.md', name: '严重问题', priority: '🔴 最高' },
  manual: { path: 'docs/白梦操作手册.md', name: '白梦操作手册', priority: '🟠 高' },
  experience: { path: 'docs/通用经验.md', name: '通用经验', priority: '🟠 高' },
  selector: { path: 'docs/元素选择器字典.md', name: '选择器字典', priority: '🟡 中' },
  teaching: { path: 'docs/用户教导记录.md', name: '用户教导', priority: '🟠 高' },
  quickRef: { path: 'docs/白梦快速参考.md', name: '白梦快速参考', priority: '🟡 中' },
  polish: { path: 'docs/polish-chapter.md', name: '润色文档', priority: '🟡 中' },
  index: { path: 'KNOWLEDGE_INDEX.md', name: '知识索引', priority: '🔴 最高' }
};

// 解析参数
const args = process.argv.slice(2);
const shouldSync = args.includes('--sync');

// ============================================================
// 检查知识库完整性
// ============================================================

function checkKnowledgeBase() {
  console.log('='.repeat(60));
  console.log('📚 知识库状态检查');
  console.log('='.repeat(60));
  
  const results = [];
  
  Object.entries(KNOWLEDGE_FILES).forEach(([key, file]) => {
    const filePath = path.join(PROJECT_ROOT, file.path);
    const exists = fs.existsSync(filePath);
    
    let age = null;
    let lines = 0;
    let lastSection = null;
    
    if (exists) {
      const stat = fs.statSync(filePath);
      age = Math.round((Date.now() - stat.mtime) / 1000 / 60 / 60); // 小时
      
      const content = fs.readFileSync(filePath, 'utf-8');
      lines = content.split('\n').length;
      
      // 提取最后一个二级标题
      const sections = content.match(/^## .+$/gm);
      if (sections && sections.length > 0) {
        lastSection = sections[sections.length - 1].replace('## ', '');
      }
    }
    
    results.push({
      key,
      ...file,
      exists,
      age,
      lines,
      lastSection,
      status: exists ? (age < 24 ? '✅' : '⚠️') : '❌'
    });
  });
  
  // 输出结果
  console.log('\n【核心知识库】');
  results.filter(r => r.priority === '🔴 最高').forEach(r => {
    if (r.exists) {
      console.log(`  ${r.status} ${r.name} - ${r.lines} 行, ${r.age} 小时前更新`);
      if (r.lastSection) console.log(`      最新: ${r.lastSection}`);
    } else {
      console.log(`  ${r.status} ${r.name} - 不存在`);
    }
  });
  
  console.log('\n【高优先级】');
  results.filter(r => r.priority === '🟠 高').forEach(r => {
    if (r.exists) {
      console.log(`  ${r.status} ${r.name} - ${r.lines} 行, ${r.age} 小时前更新`);
    } else {
      console.log(`  ${r.status} ${r.name} - 不存在`);
    }
  });
  
  console.log('\n【中优先级】');
  results.filter(r => r.priority === '🟡 中').forEach(r => {
    if (r.exists) {
      console.log(`  ${r.status} ${r.name} - ${r.lines} 行, ${r.age} 小时前更新`);
    } else {
      console.log(`  ${r.status} ${r.name} - 不存在`);
    }
  });
  
  return results;
}

// ============================================================
// 同步最近更新到知识索引
// ============================================================

function syncRecentUpdates(results) {
  const indexPath = path.join(PROJECT_ROOT, 'KNOWLEDGE_INDEX.md');
  
  if (!fs.existsSync(indexPath)) {
    console.log('\n❌ KNOWLEDGE_INDEX.md 不存在，请先创建');
    return;
  }
  
  // 获取最近更新的文件（排除索引本身）
  const recentFiles = results
    .filter(r => r.exists && r.key !== 'index')
    .sort((a, b) => b.age - a.age)
    .slice(0, 5);
  
  // 生成更新表格
  const today = new Date().toISOString().split('T')[0];
  const updateRows = recentFiles.map(r => {
    const date = r.age < 24 ? today : new Date(Date.now() - r.age * 60 * 60 * 1000).toISOString().split('T')[0];
    const content = r.lastSection || '内容更新';
    return `| ${date} | ${r.path} | ${content} |`;
  }).join('\n');
  
  // 读取索引内容
  let content = fs.readFileSync(indexPath, 'utf-8');
  
  // 替换最近更新部分
  const recentSectionRegex = /## 四、最近更新（最近7天）[\s\S]*?(?=\n---|\n##|$)/;
  const newRecentSection = `## 四、最近更新（最近7天）

| 日期 | 文档 | 内容 |
|------|------|------|
${updateRows}`;
  
  if (recentSectionRegex.test(content)) {
    content = content.replace(recentSectionRegex, newRecentSection);
    fs.writeFileSync(indexPath, content);
    console.log('\n✅ 已同步最近更新到知识索引');
  } else {
    console.log('\n⚠️ 未找到最近更新部分，请手动更新');
  }
}

// ============================================================
// 提供更新建议
// ============================================================

function suggestUpdates(results) {
  console.log('\n' + '='.repeat(60));
  console.log('📝 更新建议');
  console.log('='.repeat(60));
  
  // 检查是否有长时间未更新的核心文档
  const staleCore = results.filter(r => 
    r.priority === '🔴 最高' && r.exists && r.age > 168 // 7天
  );
  
  if (staleCore.length > 0) {
    console.log('\n⚠️ 以下核心知识库超过 7 天未更新：');
    staleCore.forEach(r => {
      console.log(`  - ${r.name} (${Math.round(r.age / 24)} 天)`);
    });
  }
  
  // 检查是否有缺失的文档
  const missing = results.filter(r => !r.exists);
  if (missing.length > 0) {
    console.log('\n❌ 以下知识库文件缺失：');
    missing.forEach(r => {
      console.log(`  - ${r.path} (${r.name})`);
    });
  }
  
  // 检查知识索引是否最新
  const indexResult = results.find(r => r.key === 'index');
  const debugResult = results.find(r => r.key === 'problem');
  
  if (indexResult && debugResult && indexResult.age > debugResult.age) {
    console.log('\n⚠️ 知识索引未同步最新问题');
    console.log('  建议: node scripts/update-knowledge.js --sync');
  }
  
  if (missing.length === 0 && staleCore.length === 0) {
    console.log('\n✅ 知识库状态良好');
  }
}

// ============================================================
// 主函数
// ============================================================

function main() {
  const results = checkKnowledgeBase();
  
  if (shouldSync) {
    syncRecentUpdates(results);
  }
  
  suggestUpdates(results);
  
  console.log('\n' + '='.repeat(60));
}

main();
