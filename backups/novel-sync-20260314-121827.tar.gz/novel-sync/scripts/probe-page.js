/**
 * 通用页面探测工具
 * 
 * 用法: node scripts/probe-page.js <URL> [target]
 * target: content(默认), button, list, input, all
 * 
 * 示例:
 *   node scripts/probe-page.js https://example.com content
 *   node scripts/probe-page.js https://example.com button
 *   node scripts/probe-page.js https://example.com all
 */

const { chromium } = require('playwright');

const url = process.argv[2];
const target = process.argv[3] || 'content';

if (!url) {
  console.log('用法: node scripts/probe-page.js <URL> [target]');
  console.log('target: content(默认), button, list, input, all');
  process.exit(0);
}

(async () => {
  console.log(`\n=== 探测: ${url} ===`);
  console.log(`目标: ${target}\n`);
  
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage();
  
  try {
    await page.goto(url, { timeout: 30000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(3000);
    
    let findings;
    
    switch (target) {
      case 'content':
        findings = await probeContent(page);
        break;
      case 'button':
        findings = await probeButton(page);
        break;
      case 'list':
        findings = await probeList(page);
        break;
      case 'input':
        findings = await probeInput(page);
        break;
      case 'all':
        findings = {
          content: await probeContent(page),
          buttons: await probeButton(page),
          lists: await probeList(page),
          inputs: await probeInput(page)
        };
        break;
      default:
        findings = await probeContent(page);
    }
    
    printFindings(findings, target);
    
  } catch (error) {
    console.error('错误:', error.message);
  } finally {
    await browser.close();
  }
})();

/**
 * 探测内容区域
 */
async function probeContent(page) {
  return page.evaluate(() => {
    const results = [];
    const exclude = ['SCRIPT', 'STYLE', 'NOSCRIPT', 'META', 'LINK', 'HEAD', 'HTML', 'SVG'];
    
    document.querySelectorAll('*').forEach(el => {
      if (exclude.includes(el.tagName)) return;
      
      const text = el.innerText || '';
      const children = el.children.length;
      const classStr = typeof el.className === 'string' ? el.className : '';
      
      // 正文特征：有足够文本、子元素适中
      if (text.length > 200 && text.length < 50000 && children < 50) {
        results.push({
          tag: el.tagName,
          class: classStr.substring(0, 60),
          selector: classStr ? `.${classStr.split(' ').find(c => c.length > 2) || 'unknown'}` : el.tagName,
          textLength: text.length,
          isEditable: el.isContentEditable,
          preview: text.substring(0, 150).replace(/\n/g, '|')
        });
      }
    });
    
    // 按文本长度排序，最可能是正文的在前
    return results
      .sort((a, b) => a.textLength - b.textLength)
      .slice(0, 15);
  });
}

/**
 * 探测按钮
 */
async function probeButton(page) {
  return page.evaluate(() => {
    const buttons = [];
    const seen = new Set();
    
    document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"], a.btn, .btn, [class*="button"]').forEach(btn => {
      const text = (btn.innerText || btn.value || '').trim().substring(0, 50);
      const key = text + btn.className;
      
      if (!seen.has(key) && text.length > 0) {
        seen.add(key);
        buttons.push({
          tag: btn.tagName,
          text: text,
          class: (btn.className || '').substring(0, 50),
          type: btn.type || 'button'
        });
      }
    });
    
    return buttons.slice(0, 20);
  });
}

/**
 * 探测列表
 */
async function probeList(page) {
  return page.evaluate(() => {
    const lists = [];
    
    document.querySelectorAll('ul, ol, [role="list"], [class*="list"], [class*="menu"]').forEach(list => {
      const items = list.children.length;
      const classStr = typeof list.className === 'string' ? list.className : '';
      
      if (items > 0) {
        lists.push({
          tag: list.tagName,
          class: classStr.substring(0, 50),
          itemCount: items,
          firstItem: (list.children[0]?.innerText || '').substring(0, 50)
        });
      }
    });
    
    return lists.slice(0, 10);
  });
}

/**
 * 探测输入框
 */
async function probeInput(page) {
  return page.evaluate(() => {
    const inputs = [];
    
    document.querySelectorAll('input, textarea, [contenteditable="true"], [role="textbox"]').forEach(inp => {
      inputs.push({
        tag: inp.tagName,
        type: inp.type || (inp.isContentEditable ? 'contenteditable' : 'unknown'),
        name: inp.name || '',
        placeholder: inp.placeholder || '',
        class: (inp.className || '').substring(0, 40)
      });
    });
    
    return inputs.slice(0, 15);
  });
}

/**
 * 打印结果
 */
function printFindings(findings, target) {
  if (target === 'all') {
    console.log('=== 内容区域 ===\n');
    printContent(findings.content);
    console.log('\n=== 按钮 ===\n');
    printButtons(findings.buttons);
    console.log('\n=== 列表 ===\n');
    printLists(findings.lists);
    console.log('\n=== 输入框 ===\n');
    printInputs(findings.inputs);
  } else {
    switch (target) {
      case 'content':
        printContent(findings);
        break;
      case 'button':
        printButtons(findings);
        break;
      case 'list':
        printLists(findings);
        break;
      case 'input':
        printInputs(findings);
        break;
    }
  }
}

function printContent(items) {
  items.forEach((item, i) => {
    console.log(`[${i + 1}] <${item.tag}> ${item.selector}`);
    console.log(`    长度: ${item.textLength}, 可编辑: ${item.isEditable}`);
    console.log(`    预览: ${item.preview}...`);
    console.log('');
  });
}

function printButtons(items) {
  items.forEach((item, i) => {
    console.log(`[${i + 1}] <${item.tag}> "${item.text}"`);
    console.log(`    class: ${item.class}`);
    console.log('');
  });
}

function printLists(items) {
  items.forEach((item, i) => {
    console.log(`[${i + 1}] <${item.tag}> ${item.itemCount} 项`);
    console.log(`    class: ${item.class}`);
    console.log(`    首项: ${item.firstItem}...`);
    console.log('');
  });
}

function printInputs(items) {
  items.forEach((item, i) => {
    console.log(`[${i + 1}] <${item.tag}> type="${item.type}"`);
    console.log(`    name: ${item.name}, placeholder: ${item.placeholder}`);
    console.log('');
  });
}
