#!/usr/bin/env node
/**
 * 性能基准测试工具
 * 测量和记录关键操作的性能指标
 * 
 * 用法:
 *   node scripts/benchmark.js              # 运行所有基准测试
 *   node scripts/benchmark.js --compare    # 与上次对比
 *   node scripts/benchmark.js --record     # 记录到文件
 */

const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.join(__dirname, '..');
const BENCHMARK_DIR = path.join(ROOT_DIR, '.optimization');
const BENCHMARK_FILE = path.join(BENCHMARK_DIR, 'benchmark.json');

// 确保目录存在
if (!fs.existsSync(BENCHMARK_DIR)) {
    fs.mkdirSync(BENCHMARK_DIR, { recursive: true });
}

// 基准测试配置
const BENCHMARKS = {
    '代码统计': {
        run: () => {
            const start = Date.now();
            const jsFiles = findFiles(path.join(ROOT_DIR, 'src'), '.js');
            const totalLines = jsFiles.reduce((sum, file) => {
                const content = fs.readFileSync(file, 'utf-8');
                return sum + content.split('\n').length;
            }, 0);
            const duration = Date.now() - start;
            return {
                duration,
                fileCount: jsFiles.length,
                totalLines,
                avgLinesPerFile: Math.round(totalLines / jsFiles.length)
            };
        }
    },
    '文档统计': {
        run: () => {
            const start = Date.now();
            const mdFiles = findFiles(path.join(ROOT_DIR, 'docs'), '.md');
            const totalLines = mdFiles.reduce((sum, file) => {
                const content = fs.readFileSync(file, 'utf-8');
                return sum + content.split('\n').length;
            }, 0);
            const duration = Date.now() - start;
            return {
                duration,
                fileCount: mdFiles.length,
                totalLines,
                avgLinesPerFile: Math.round(totalLines / mdFiles.length)
            };
        }
    },
    '模块加载': {
        run: () => {
            const start = Date.now();
            try {
                const baimeng = require(path.join(ROOT_DIR, 'src/platforms/baimeng'));
                const duration = Date.now() - start;
                return {
                    duration,
                    modules: Object.keys(baimeng),
                    moduleCount: Object.keys(baimeng).length,
                    success: true
                };
            } catch (e) {
                return {
                    duration: Date.now() - start,
                    success: false,
                    error: e.message
                };
            }
        }
    },
    '知识库查询': {
        run: () => {
            const start = Date.now();
            const verifiedCode = fs.readFileSync(path.join(ROOT_DIR, 'docs/已验证代码库.md'), 'utf-8');
            const debugLog = fs.readFileSync(path.join(ROOT_DIR, 'DEBUG_LOG.md'), 'utf-8');
            const userTeaching = fs.readFileSync(path.join(ROOT_DIR, 'docs/用户教导记录.md'), 'utf-8');
            
            // 模拟查询
            const searchTerms = ['登录', '章节', '复制', '滚动'];
            const results = {};
            for (const term of searchTerms) {
                results[term] = {
                    verified: (verifiedCode.match(new RegExp(term, 'g')) || []).length,
                    debug: (debugLog.match(new RegExp(term, 'g')) || []).length,
                    teaching: (userTeaching.match(new RegExp(term, 'g')) || []).length
                };
            }
            
            const duration = Date.now() - start;
            return {
                duration,
                searchResults: results,
                totalMatches: Object.values(results).reduce((sum, r) => 
                    sum + r.verified + r.debug + r.teaching, 0)
            };
        }
    },
    '存储检查': {
        run: () => {
            const start = Date.now();
            const storageDir = path.join(ROOT_DIR, 'storage');
            const stats = {
                accounts: { exists: false, size: 0 },
                cache: { exists: false, size: 0 }
            };
            
            if (fs.existsSync(path.join(storageDir, 'accounts'))) {
                stats.accounts.exists = true;
                stats.accounts.size = getDirSize(path.join(storageDir, 'accounts'));
            }
            
            if (fs.existsSync(path.join(storageDir, 'cache'))) {
                stats.cache.exists = true;
                stats.cache.size = getDirSize(path.join(storageDir, 'cache'));
            }
            
            const duration = Date.now() - start;
            return {
                duration,
                stats
            };
        }
    }
};

// 辅助函数
function findFiles(dir, ext) {
    const results = [];
    if (!fs.existsSync(dir)) return results;
    
    const items = fs.readdirSync(dir);
    for (const item of items) {
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
            results.push(...findFiles(fullPath, ext));
        } else if (item.endsWith(ext)) {
            results.push(fullPath);
        }
    }
    return results;
}

function getDirSize(dir) {
    let size = 0;
    if (!fs.existsSync(dir)) return 0;
    
    const items = fs.readdirSync(dir);
    for (const item of items) {
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
            size += getDirSize(fullPath);
        } else {
            size += stat.size;
        }
    }
    return size;
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
}

// 运行基准测试
function runBenchmarks() {
    console.log('');
    console.log('╔══════════════════════════════════════════════════════════╗');
    console.log('║              性能基准测试                                  ║');
    console.log('╚══════════════════════════════════════════════════════════╝');
    console.log('');
    
    const results = {
        timestamp: new Date().toISOString(),
        gitCommit: getGitCommit(),
        benchmarks: {}
    };
    
    for (const [name, config] of Object.entries(BENCHMARKS)) {
        console.log(`▶ ${name}...`);
        try {
            const result = config.run();
            results.benchmarks[name] = result;
            console.log(`  ✅ 完成 (${result.duration}ms)`);
            console.log('   ', JSON.stringify(result, null, 2).split('\n').slice(1, 4).join('\n    '));
        } catch (e) {
            results.benchmarks[name] = { error: e.message };
            console.log(`  ❌ 失败: ${e.message}`);
        }
        console.log('');
    }
    
    return results;
}

function getGitCommit() {
    try {
        const { execSync } = require('child_process');
        return execSync('git rev-parse HEAD', { cwd: ROOT_DIR, encoding: 'utf-8' }).trim();
    } catch {
        return 'unknown';
    }
}

// 对比结果
function compareResults(current) {
    if (!fs.existsSync(BENCHMARK_FILE)) {
        console.log('⚠️ 没有找到历史基准数据');
        return;
    }
    
    const previous = JSON.parse(fs.readFileSync(BENCHMARK_FILE, 'utf-8'));
    
    console.log('═══════════════════════════════════════════════════════════');
    console.log('                    对比结果                                ');
    console.log('═══════════════════════════════════════════════════════════');
    console.log('');
    
    for (const [name, currentResult] of Object.entries(current.benchmarks)) {
        const previousResult = previous.benchmarks[name];
        if (!previousResult) continue;
        
        console.log(`▶ ${name}`);
        
        // 对比时间
        if (currentResult.duration && previousResult.duration) {
            const diff = currentResult.duration - previousResult.duration;
            const percent = ((diff / previousResult.duration) * 100).toFixed(1);
            if (diff < 0) {
                console.log(`  时间: ${currentResult.duration}ms (${Math.abs(percent)}% 更快) ✅`);
            } else if (diff > 0) {
                console.log(`  时间: ${currentResult.duration}ms (${percent}% 更慢) ⚠️`);
            } else {
                console.log(`  时间: ${currentResult.duration}ms (不变)`);
            }
        }
        
        // 对比其他指标
        for (const key of Object.keys(currentResult)) {
            if (key === 'duration') continue;
            if (typeof currentResult[key] === 'number' && typeof previousResult[key] === 'number') {
                const diff = currentResult[key] - previousResult[key];
                if (diff !== 0) {
                    console.log(`  ${key}: ${currentResult[key]} (${diff > 0 ? '+' : ''}${diff})`);
                }
            }
        }
        
        console.log('');
    }
}

// 主函数
function main() {
    const args = process.argv.slice(2);
    const shouldCompare = args.includes('--compare');
    const shouldRecord = args.includes('--record');
    
    const results = runBenchmarks();
    
    if (shouldCompare) {
        compareResults(results);
    }
    
    if (shouldRecord) {
        fs.writeFileSync(BENCHMARK_FILE, JSON.stringify(results, null, 2));
        console.log(`✅ 基准数据已保存到: ${BENCHMARK_FILE}`);
    }
    
    // 汇总
    console.log('═══════════════════════════════════════════════════════════');
    console.log('                    测试汇总                                ');
    console.log('═══════════════════════════════════════════════════════════');
    console.log('');
    
    const benchmarkCount = Object.keys(results.benchmarks).length;
    const errorCount = Object.values(results.benchmarks).filter(r => r.error).length;
    
    console.log(`测试项: ${benchmarkCount}`);
    console.log(`通过: ${benchmarkCount - errorCount}`);
    console.log(`失败: ${errorCount}`);
    console.log('');
    
    if (shouldRecord) {
        console.log('下次对比: node scripts/benchmark.js --compare');
    } else {
        console.log('记录基准: node scripts/benchmark.js --record');
    }
}

main();
