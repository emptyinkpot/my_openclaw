#!/bin/bash
# 定期维护脚本

ROOT_DIR="/workspace/projects/workspace/projects/novel-sync"

echo ""
echo "========================================"
echo "         定期维护"
echo "========================================"
echo ""

# 1. 检查知识库完整性
echo "[1/5] 检查知识库完整性..."
DOCS=(
    "docs/已验证代码库.md"
    "docs/元素选择器字典.md"
    "docs/用户教导记录.md"
    "docs/白梦操作手册.md"
    "docs/存储规范.md"
    "docs/页面分析方法论.md"
    "docs/自完善调试架构.md"
    "DEBUG_LOG.md"
    "PROJECT_STANDARDS.md"
)

MISSING=0
for file in "${DOCS[@]}"; do
    if [ -f "$ROOT_DIR/$file" ]; then
        SIZE=$(wc -c < "$ROOT_DIR/$file")
        echo "  ✓ $file ($SIZE bytes)"
    else
        echo "  ✗ $file 不存在"
        ((MISSING++))
    fi
done

if [ $MISSING -gt 0 ]; then
    echo ""
    echo "  ⚠️ 有 $MISSING 个文件缺失"
fi
echo ""

# 2. 清理过期缓存
echo "[2/5] 清理过期缓存..."
CACHE_DIR="$ROOT_DIR/storage/cache"
if [ -d "$CACHE_DIR" ]; then
    OLD_FILES=$(find "$CACHE_DIR" -name "*.json" -mtime +7 2>/dev/null | wc -l)
    find "$CACHE_DIR" -name "*.json" -mtime +7 -delete 2>/dev/null
    echo "  ✓ 已清理 $OLD_FILES 个过期缓存文件 (7天前)"
else
    echo "  ⚠ 缓存目录不存在"
fi
echo ""

# 3. 检查备份完整性
echo "[3/5] 检查备份完整性..."
if [ -d "$ROOT_DIR/storage/accounts/baimeng/account-1" ]; then
    bash "$ROOT_DIR/scripts/storage.sh" verify baimeng 1 2>&1 | grep -E "✓|✗"
else
    echo "  ⚠ 白梦账号备份不存在"
fi
echo ""

# 4. 统计知识库
echo "[4/5] 知识库统计..."
if [ -f "$ROOT_DIR/docs/已验证代码库.md" ]; then
    CODE_COUNT=$(grep -c '^###' "$ROOT_DIR/docs/已验证代码库.md" 2>/dev/null || echo "0")
    echo "  已验证代码: $CODE_COUNT 个"
fi

if [ -f "$ROOT_DIR/docs/元素选择器字典.md" ]; then
    SELECTOR_COUNT=$(grep -c '^|' "$ROOT_DIR/docs/元素选择器字典.md" 2>/dev/null || echo "0")
    echo "  选择器记录: $SELECTOR_COUNT 行"
fi

if [ -f "$ROOT_DIR/DEBUG_LOG.md" ]; then
    PROBLEM_COUNT=$(grep -c '^### \[' "$ROOT_DIR/DEBUG_LOG.md" 2>/dev/null || echo "0")
    echo "  问题记录: $PROBLEM_COUNT 个"
fi
echo ""

# 5. 检查脚本可执行性
echo "[5/5] 检查脚本..."
SCRIPTS=(
    "scripts/dev-flow.sh"
    "scripts/dev-check.sh"
    "scripts/storage.sh"
    "scripts/validate.sh"
    "scripts/probe-page.js"
    "scripts/query-knowledge.js"
)

for script in "${SCRIPTS[@]}"; do
    if [ -f "$ROOT_DIR/$script" ]; then
        if [ -x "$ROOT_DIR/$script" ] || [[ "$script" == *.js ]]; then
            echo "  ✓ $script"
        else
            echo "  ⚠ $script 不可执行"
        fi
    else
        echo "  ✗ $script 不存在"
    fi
done
echo ""

echo "========================================"
echo "         维护完成"
echo "========================================"
echo ""
