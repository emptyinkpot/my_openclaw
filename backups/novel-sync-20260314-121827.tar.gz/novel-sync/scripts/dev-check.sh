#!/bin/bash
# 快速检查脚本 - 开发前必执行
# 用法: bash scripts/dev-check.sh

NOVEL_SYNC_DIR="/workspace/projects/workspace/projects/novel-sync"
VERIFIED_CODE="$NOVEL_SYNC_DIR/docs/已验证代码库.md"
USER_TEACHING="$NOVEL_SYNC_DIR/docs/用户教导记录.md"
DEBUG_LOG="$NOVEL_SYNC_DIR/DEBUG_LOG.md"

# 检查是否在正确目录
if [ ! -d "$NOVEL_SYNC_DIR" ]; then
    echo "错误: 目录不存在 $NOVEL_SYNC_DIR"
    exit 1
fi

echo "=== 开发前检查 ==="
echo ""

# 1. 显示已验证代码库摘要
echo "📄 已验证代码库:"
echo "-------------------"
if [ -f "$VERIFIED_CODE" ]; then
    grep -E "^## |^### " "$VERIFIED_CODE" | head -20
else
    echo "文件不存在: $VERIFIED_CODE"
fi
echo ""

# 2. 显示用户教导摘要
echo "📚 用户教导记录:"
echo "-------------------"
if [ -f "$USER_TEACHING" ]; then
    grep -E "^## |^### " "$USER_TEACHING" | head -10
else
    echo "文件不存在: $USER_TEACHING"
fi
echo ""

# 3. 显示最近问题
echo "🔍 最近问题 (DEBUG_LOG):"
echo "-------------------"
if [ -f "$DEBUG_LOG" ]; then
    grep -E "^### " "$DEBUG_LOG" | head -10
else
    echo "文件不存在: $DEBUG_LOG"
fi
echo ""

echo "✓ 检查完成，可以开始开发"
echo ""
echo "💡 提示: 执行 source scripts/dev-flow.sh 进入完整流程检查"
