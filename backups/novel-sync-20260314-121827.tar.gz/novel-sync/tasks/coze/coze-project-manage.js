/**
 * Coze 操作 - 进入项目管理
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 进入项目管理                                       │
 * │      ↓                                                       │
 * │  Step 4: 探测页面结构                                       │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node coze-project-manage.js
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { StepReporter } = require('../../src/utils');

const BROWSER_DIR = '/workspace/projects/browser/coze-1';
const BACKUP_FILE = '/workspace/projects/cookies-accounts/coze-account-1-full.json';
const PROJECT_MANAGE_URL = 'https://code.coze.cn/w/7587425486419378228/projects';

async function main() {
  const reporter = new StepReporter();
  
  console.log('🖱️ Coze 操作 - 进入项目管理\n');
  
  // 清理锁文件
  const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie'];
  lockFiles.forEach(f => {
    const p = path.join(BROWSER_DIR, f);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  });
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: { width: 1280, height: 800 },
    args: ['--start-maximized']
  });
  
  const page = browser.pages()[0] || await browser.newPage();
  reporter.success('浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  
  if (fs.existsSync(BACKUP_FILE)) {
    const data = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf-8'));
    
    await page.goto('https://www.coze.cn/', { timeout: 30000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2000);
    
    if (data.localStorage) {
      await page.evaluate((items) => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, data.localStorage);
    }
    
    if (data.cookies) {
      await browser.addCookies(data.cookies);
    }
    
    reporter.success('登录状态已设置');
  } else {
    reporter.success('无备份文件');
  }
  
  // ========== Step 3: 进入项目管理 ==========
  reporter.start('Step 3', '进入项目管理');
  
  await page.goto(PROJECT_MANAGE_URL, { timeout: 30000, waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(3000);
  
  reporter.success(page.url());
  
  // ========== Step 4: 探测页面结构 ==========
  reporter.start('Step 4', '探测页面结构');
  
  const pageInfo = await page.evaluate(() => {
    const cards = document.querySelectorAll('[class*="card"]');
    const sidebar = document.querySelector('[class*="sidebar"]') || document.querySelector('aside');
    const menuItems = sidebar ? Array.from(sidebar.querySelectorAll('a, button, [class*="item"]'))
      .map(el => (el.innerText || '').trim().substring(0, 30))
      .filter(t => t) : [];
    const topBar = document.querySelector('[class*="header"]') || document.querySelector('header');
    const topButtons = topBar ? Array.from(topBar.querySelectorAll('button'))
      .map(el => (el.innerText || '').trim().substring(0, 30))
      .filter(t => t) : [];
    
    return {
      cardCount: cards.length,
      menuItems: menuItems.slice(0, 15),
      topButtons: topButtons.slice(0, 10)
    };
  });
  
  const screenshotPath = '/tmp/coze-project-manage.png';
  await page.screenshot({ path: screenshotPath });
  fs.writeFileSync('/tmp/coze-project-manage-info.json', JSON.stringify(pageInfo, null, 2));
  
  reporter.success(`${pageInfo.cardCount} 项目卡片`);
  
  // 打印最终报告
  reporter.print();
  
  if (pageInfo.menuItems.length > 0) {
    console.log('\n  侧边栏菜单:');
    pageInfo.menuItems.forEach((item, i) => console.log(`    ${i + 1}. ${item}`));
  }
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
}

main().catch(console.error);
