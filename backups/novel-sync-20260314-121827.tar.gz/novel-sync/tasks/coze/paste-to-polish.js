/**
 * Coze 扣子编程 - 粘贴到润色网站
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 检查剪贴板文件                                     │
 * │      ↓                                                       │
 * │  Step 2: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 3: 恢复 Coze 登录                                     │
 * │      ↓                                                       │
 * │  Step 4: 进入项目管理                                       │
 * │      ↓                                                       │
 * │  Step 5: 打开润色网站                                       │
 * │      ↓                                                       │
 * │  Step 6: 粘贴内容                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node paste-to-polish.js [文件名]
 * 示例：node paste-to-polish.js chapter-64
 *       node paste-to-polish.js latest
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter, input } = require('../../src/utils');
const fs = require('fs');
const path = require('path');

runTask('粘贴到润色网站', async (ctx) => {
  const reporter = new StepReporter();
  
  const args = process.argv.slice(2);
  const fileName = args[0] || 'latest';
  
  // ========== Step 1: 检查剪贴板文件 ==========
  reporter.start('Step 1', '检查剪贴板文件');
  
  const clipboardDir = '/workspace/projects/workspace/projects/novel-sync/storage/clipboard';
  const contentFile = path.join(clipboardDir, `${fileName}.txt`);
  
  if (!fs.existsSync(contentFile)) {
    reporter.fail('文件不存在');
    reporter.print();
    console.log('\n请先运行复制脚本:');
    console.log('  node tasks/baimeng/copy-to-clipboard.js "作品名" 章节号');
    return;
  }
  
  const content = fs.readFileSync(contentFile, 'utf-8');
  reporter.success(`${content.length} 字`);
  
  console.log(`\n📋 文件: ${contentFile}`);
  
  // ========== Step 2: 启动浏览器 ==========
  reporter.start('Step 2', '启动浏览器');
  
  const { chromium } = require('playwright');
  const BROWSER_DIR = '/workspace/projects/browser/default';
  const COZE_BACKUP = '/workspace/projects/cookies-accounts/coze-account-1-full.json';
  const COZE_PROJECT_URL = 'https://code.coze.cn/w/7587425486419378228/projects';
  
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: null,
    args: ['--no-sandbox', '--start-maximized']
  });
  const page = browser.pages()[0] || await browser.newPage();
  reporter.success('浏览器已启动');
  
  // ========== Step 3: 恢复 Coze 登录 ==========
  reporter.start('Step 3', '恢复 Coze 登录');
  
  const backup = JSON.parse(fs.readFileSync(COZE_BACKUP, 'utf-8'));
  await page.goto('https://www.coze.cn', { waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(1500);
  await page.evaluate(items => {
    for (const [k, v] of Object.entries(items)) localStorage.setItem(k, v);
  }, backup.localStorage);
  if (backup.cookies) await browser.addCookies(backup.cookies);
  reporter.success('登录已恢复');
  
  // ========== Step 4: 进入项目管理 ==========
  reporter.start('Step 4', '进入项目管理');
  await page.goto(COZE_PROJECT_URL, { waitUntil: 'networkidle' });
  await page.waitForTimeout(2000);
  reporter.success('项目管理已加载');
  
  // ========== Step 5: 打开润色网站 ==========
  reporter.start('Step 5', '打开润色网站');
  
  const clicked = await page.evaluate(() => {
    const elements = document.querySelectorAll('*');
    for (const el of elements) {
      const text = el.innerText?.trim();
      if (text === '文本润色网站' || (text?.startsWith('文本润色网站') && text.length < 30)) {
        el.click();
        return true;
      }
    }
    return false;
  });
  
  if (clicked) {
    reporter.success('已打开润色网站');
  } else {
    reporter.fail('未找到项目');
  }
  
  await page.waitForTimeout(3000);
  
  // ========== Step 6: 粘贴内容 ==========
  reporter.start('Step 6', '粘贴内容');
  
  // 等待 textarea 可见
  await page.waitForSelector('textarea:visible', { timeout: 5000 });
  
  // 快速填充（瞬间完成，而非逐字符输入）
  await input.fastFill(page, 'textarea', content);
  reporter.success(`${content.length} 字已输入`);
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n浏览器保持打开...');
  await new Promise(() => {});
});
