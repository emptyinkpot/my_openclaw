/**
 * 打开 Coze 网站
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 检查状态                                           │
 * │      ↓                                                       │
 * │  Step 4: 截图确认                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node open-coze.js
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { StepReporter } = require('../../src/utils');

const BROWSER_DIR = '/workspace/projects/browser/coze-1';
const BACKUP_FILE = '/workspace/projects/cookies-accounts/coze-account-1-full.json';
const URL = 'https://www.coze.cn/';

async function main() {
  const reporter = new StepReporter();
  
  console.log('🌐 打开 Coze 网站\n');
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  
  // 清理锁文件
  const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie'];
  lockFiles.forEach(f => {
    const p = path.join(BROWSER_DIR, f);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  });
  
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: { width: 1280, height: 800 },
    args: ['--start-maximized']
  });
  
  const page = browser.pages()[0] || await browser.newPage();
  reporter.success('浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  
  if (fs.existsSync(BACKUP_FILE)) {
    const data = JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf-8'));
    
    await page.goto(URL, { timeout: 30000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2000);
    
    if (data.localStorage) {
      await page.evaluate((items) => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, data.localStorage);
    }
    
    if (data.cookies) {
      await browser.addCookies(data.cookies);
    }
    
    await page.reload();
    await page.waitForTimeout(3000);
    
    reporter.success('登录已恢复');
  } else {
    reporter.success('未找到备份，需手动登录');
    await page.goto(URL, { timeout: 30000 });
  }
  
  // ========== Step 3: 检查状态 ==========
  reporter.start('Step 3', '检查状态');
  
  const status = await page.evaluate(() => ({
    url: window.location.href,
    title: document.title,
    localStorageCount: Object.keys(localStorage).length
  }));
  
  reporter.success(`${status.localStorageCount} 个 localStorage 项`);
  
  // ========== Step 4: 截图确认 ==========
  reporter.start('Step 4', '截图确认');
  
  const screenshotPath = '/tmp/coze-opened.png';
  await page.screenshot({ path: screenshotPath });
  reporter.success(screenshotPath);
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
}

main().catch(console.error);
