/**
 * Coze 操作 - 打开扣子编程页面（重构版）
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 初始化平台                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 进入扣子编程                                       │
 * │      ↓                                                       │
 * │  Step 4: 截图确认                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node open-coze-code.js
 */

const { runTask } = require('../../../src/utils/task-runner');
const { StepReporter } = require('../../../src/utils');
const { CozePlatform } = require('../../../src/platforms/coze');

async function main() {
  const reporter = new StepReporter();
  
  // ========== Step 1: 初始化平台 ==========
  reporter.start('Step 1', '初始化平台');
  const platform = new CozePlatform({ accountId: 1 });
  await platform.init();
  reporter.success('平台已初始化');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  await platform.ensureLogin();
  reporter.success('登录已恢复');
  
  // ========== Step 3: 进入扣子编程 ==========
  reporter.start('Step 3', '进入扣子编程');
  await platform.gotoCodeSite();
  reporter.success('扣子编程已加载');
  
  // ========== Step 4: 截图确认 ==========
  reporter.start('Step 4', '截图确认');
  await platform.browser.screenshot('code-home');
  reporter.success('截图已保存');
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
}

main().catch(console.error);
