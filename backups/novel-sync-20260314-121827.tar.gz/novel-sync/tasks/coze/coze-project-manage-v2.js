/**
 * Coze 操作 - 项目管理
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 初始化平台                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 进入项目管理                                       │
 * │      ↓                                                       │
 * │  Step 4: 获取项目列表                                       │
 * │      ↓                                                       │
 * │  Step 5: 截图确认                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node coze-project-manage-v2.js
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');
const { CozePlatform } = require('../../src/platforms/coze');

async function main() {
  const reporter = new StepReporter();
  
  // ========== Step 1: 初始化平台 ==========
  reporter.start('Step 1', '初始化平台');
  const platform = new CozePlatform({ accountId: 1 });
  await platform.init();
  reporter.success('平台已初始化');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  await platform.ensureLogin();
  reporter.success('登录已恢复');
  
  // ========== Step 3: 进入项目管理 ==========
  reporter.start('Step 3', '进入项目管理');
  await platform.gotoProjectManage();
  reporter.success('项目管理已加载');
  
  // ========== Step 4: 获取项目列表 ==========
  reporter.start('Step 4', '获取项目列表');
  const projects = await platform.getProjects();
  reporter.success(`${projects.length} 个项目`);
  
  // ========== Step 5: 截图确认 ==========
  reporter.start('Step 5', '截图确认');
  await platform.browser.screenshot('project-list');
  reporter.success('截图已保存');
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n项目列表:');
  projects.forEach((p, i) => {
    console.log(`  ${i + 1}. ${p.text}`);
  });
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
}

main().catch(console.error);
