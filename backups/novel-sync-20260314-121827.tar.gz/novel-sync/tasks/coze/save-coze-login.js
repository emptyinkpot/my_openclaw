/**
 * Coze.cn 保存登录数据
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 连接浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 导航到网站                                         │
 * │      ↓                                                       │
 * │  Step 3: 检查登录状态                                       │
 * │      ↓                                                       │
 * │  Step 4: 获取并保存数据                                     │
 * │      ↓                                                       │
 * │  Step 5: 更新知识库                                         │
 * │      ↓                                                       │
 * │  Step 6: 截图确认                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node save-coze-login.js
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { StepReporter } = require('../../src/utils');

const BROWSER_DIR = '/workspace/projects/browser/coze-1';
const STORAGE_DIR = '/workspace/projects/cookies-accounts';

async function main() {
  const reporter = new StepReporter();
  
  console.log('💾 保存 Coze.cn 登录数据\n');
  
  // ========== Step 1: 连接浏览器 ==========
  reporter.start('Step 1', '连接浏览器');
  
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: { width: 1280, height: 800 }
  });
  
  const page = browser.pages()[0] || await browser.newPage();
  reporter.success('浏览器已连接');
  
  // ========== Step 2: 导航到网站 ==========
  reporter.start('Step 2', '导航到网站');
  
  await page.goto('https://www.coze.cn/', { timeout: 30000, waitUntil: 'domcontentloaded' });
  await page.waitForTimeout(3000);
  reporter.success('页面已加载');
  
  // ========== Step 3: 检查登录状态 ==========
  reporter.start('Step 3', '检查登录状态');
  
  const status = await page.evaluate(() => ({
    url: window.location.href,
    title: document.title,
    localStorageCount: Object.keys(localStorage).length,
    localStorageKeys: Object.keys(localStorage)
  }));
  
  reporter.success(`${status.localStorageCount} 个 localStorage 项`);
  
  // ========== Step 4: 获取并保存数据 ==========
  reporter.start('Step 4', '获取并保存数据');
  
  const cookies = await browser.cookies();
  const localStorage = await page.evaluate(() => {
    const items = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      items[key] = localStorage.getItem(key);
    }
    return items;
  });
  
  const backupData = {
    url: status.url,
    timestamp: new Date().toISOString(),
    cookies: cookies,
    localStorage: localStorage
  };
  
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
  
  const backupPath = path.join(STORAGE_DIR, 'coze-account-1-full.json');
  fs.writeFileSync(backupPath, JSON.stringify(backupData, null, 2));
  
  const basicPath = path.join(STORAGE_DIR, 'coze-account-1.json');
  fs.writeFileSync(basicPath, JSON.stringify({ cookies, timestamp: backupData.timestamp }, null, 2));
  
  reporter.success(`${cookies.length} cookies | ${Object.keys(localStorage).length} localStorage`);
  
  // ========== Step 5: 更新知识库 ==========
  reporter.start('Step 5', '更新知识库');
  
  const knowledgeDir = '/workspace/projects/knowledge/coze';
  fs.mkdirSync(knowledgeDir, { recursive: true });
  
  const siteYaml = `# Coze.cn 网站配置
name: Coze
url: https://www.coze.cn/
domain: coze.cn
loginMethod: 多种方式（手机/微信/抖音/飞书）
storageType: localStorage + cookies
browserDir: ${BROWSER_DIR}
backupFiles:
  full: coze-account-1-full.json
  basic: coze-account-1.json
exploredAt: ${new Date().toISOString()}
`;
  
  fs.writeFileSync(path.join(knowledgeDir, 'site.yaml'), siteYaml);
  
  const loginMd = `# Coze.cn - 登录知识

## 一、网站信息

| 项目 | 内容 |
|------|------|
| 网站 | 扣子 Coze |
| URL | https://www.coze.cn/ |
| 所属 | 字节跳动 |
| 功能 | AI 开发平台、智能体、工作流 |

## 二、登录方式

- 手机号登录
- 微信扫码登录
- 抖音扫码登录
- 飞书登录

## 三、备份文件

| 文件 | 内容 |
|------|------|
| \`coze-account-1-full.json\` | 完整备份（cookies + localStorage） |
| \`coze-account-1.json\` | 基础备份（仅 cookies） |

## 四、注意事项

1. 登录后会重定向到 \`/overview\` 页面
2. localStorage 中包含用户会话信息
3. 浏览器数据目录: \`browser/coze-1/\`
`;

  fs.writeFileSync(path.join(knowledgeDir, 'login.md'), loginMd);
  reporter.success(`site.yaml | login.md`);
  
  // ========== Step 6: 截图确认 ==========
  reporter.start('Step 6', '截图确认');
  
  const screenshotPath = '/tmp/coze-logged-in.png';
  await page.screenshot({ path: screenshotPath });
  reporter.success(screenshotPath);
  
  // 打印最终报告
  reporter.print();
  
  console.log(`\n备份文件:`);
  console.log(`  - ${backupPath}`);
  console.log(`  - ${basicPath}`);
  console.log(`\n知识库:`);
  console.log(`  - ${knowledgeDir}/site.yaml`);
  console.log(`  - ${knowledgeDir}/login.md`);
}

main().catch(console.error);
