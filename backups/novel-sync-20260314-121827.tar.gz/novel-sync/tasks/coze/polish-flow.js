/**
 * 文本润色流程任务
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 连接浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 读取输入内容                                       │
 * │      ↓                                                       │
 * │  Step 3: 打开润色网站                                       │
 * │      ↓                                                       │
 * │  Step 4: 粘贴内容                                           │
 * │      ↓                                                       │
 * │  Step 5: 点击润色                                           │
 * │      ↓                                                       │
 * │  Step 6: 等待进度条                                         │
 * │      ↓                                                       │
 * │  Step 7: 提取结果                                           │
 * │      ↓                                                       │
 * │  Step 8: 保存输出                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 使用方式：
 *   # 基础用法
 *   node tasks/coze/polish-flow.js
 *   
 *   # 指定完整元数据
 *   node tasks/coze/polish-flow.js --source baimeng --work "变身咳血少女" --chapter 64
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');
const { chromium } = require('playwright');

runTask('文本润色流程', async (ctx) => {
  // 统一报告器
  const reporter = new StepReporter();
  
  // 解析参数
  const args = process.argv.slice(2);
  
  let inputName = 'latest';
  let outputName = 'polished-clean';
  let source = 'unknown';
  let work = 'unknown';
  let chapter = 'unknown';
  
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--source' && args[i + 1]) {
      source = args[++i];
    } else if (args[i] === '--work' && args[i + 1]) {
      work = args[++i];
    } else if (args[i] === '--chapter' && args[i + 1]) {
      chapter = args[++i];
      if (/^\d+$/.test(chapter)) {
        const { numToChinese } = require('../../src/utils/helper');
        chapter = `第${numToChinese(parseInt(chapter))}章`;
      }
    } else if (!args[i].startsWith('--')) {
      if (inputName === 'latest') {
        inputName = args[i];
      } else if (outputName === 'polished-clean') {
        outputName = args[i];
      }
    }
  }
  
  console.log('输入文件:', inputName);
  console.log('来源:', source);
  console.log('作品:', work);
  console.log('章节:', chapter);
  
  // 导入润色模块
  const polish = require('../../src/platforms/coze/polish');
  
  // ========== Step 1: 连接浏览器 ==========
  reporter.start('Step 1', '连接浏览器');
  
  let browser, page;
  try {
    browser = await chromium.connectOverCDP('http://localhost:9222');
    const context = browser.contexts()[0];
    page = context.pages()[0];
    reporter.success('已连接 CDP 端口 9222');
  } catch (e) {
    reporter.fail('无法连接浏览器，请确保开启 CDP 端口 9222');
    reporter.print();
    return;
  }
  
  // ========== Step 2: 读取输入内容 ==========
  reporter.start('Step 2', '读取输入内容');
  
  const content = polish.loadFromFile(inputName);
  if (!content) {
    reporter.fail('无法读取输入文件');
    reporter.print();
    return;
  }
  reporter.success(`${content.length} 字`);
  
  // ========== Step 3: 打开润色网站 ==========
  reporter.start('Step 3', '打开润色网站');
  
  try {
    await page.goto('https://7d4jcknzqk.coze.site', { timeout: 30000 });
    await page.waitForTimeout(3000);
    reporter.success('润色网站已加载');
  } catch (e) {
    reporter.fail(e.message);
    reporter.print();
    return;
  }
  
  // ========== Step 4: 粘贴内容 ==========
  reporter.start('Step 4', '粘贴内容');
  
  try {
    const ta = await page.$('textarea:visible');
    if (ta) {
      await ta.fill(content);
      await page.waitForTimeout(1000);
      reporter.success(`${content.length} 字`);
    } else {
      reporter.fail('未找到文本框');
      reporter.print();
      return;
    }
  } catch (e) {
    reporter.fail(e.message);
    reporter.print();
    return;
  }
  
  // ========== Step 5: 点击润色 ==========
  reporter.start('Step 5', '点击润色');
  
  try {
    const btnInfo = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const btn = buttons.find(b => b.textContent.includes('开始润色'));
      return btn ? { found: true, disabled: btn.disabled } : { found: false };
    });
    
    if (btnInfo.found && !btnInfo.disabled) {
      await page.click('button:has-text("开始润色")');
      reporter.success('已点击润色按钮');
    } else {
      reporter.fail(btnInfo.found ? '按钮已禁用' : '未找到润色按钮');
      reporter.print();
      return;
    }
  } catch (e) {
    reporter.fail(e.message);
    reporter.print();
    return;
  }
  
  // ========== Step 6: 等待进度条 ==========
  reporter.start('Step 6', '等待进度条');
  
  try {
    // 等待进度条出现
    let foundProgress = false;
    for (let i = 0; i < 20; i++) {
      await page.waitForTimeout(3000);
      foundProgress = await page.evaluate(() => document.body.innerText.includes('分段处理'));
      if (foundProgress) break;
    }
    
    if (!foundProgress) {
      reporter.fail('未检测到进度条');
      reporter.print();
      return;
    }
    
    // 等待进度条消失
    let hasProgress = true;
    let count = 0;
    while (hasProgress && count < 100) {
      await page.waitForTimeout(3000);
      hasProgress = await page.evaluate(() => document.body.innerText.includes('分段处理'));
      count++;
    }
    
    reporter.success('润色完成');
  } catch (e) {
    reporter.fail(e.message);
    reporter.print();
    return;
  }
  
  // ========== Step 7: 提取结果 ==========
  reporter.start('Step 7', '提取结果');
  
  await page.waitForTimeout(5000);
  
  const result = await polish.polishFlow(page, {
    inputName,
    outputName,
    source,
    work,
    chapter
  });
  
  if (!result.success) {
    reporter.fail(result.error);
    reporter.print();
    return;
  }
  
  reporter.success(`标题 ${result.titleLength} 字 | 正文 ${result.contentLength} 字`);
  
  // ========== Step 8: 保存输出 ==========
  reporter.start('Step 8', '保存输出');
  
  if (result.path) {
    reporter.success(result.path);
  } else {
    reporter.success('已保存');
  }
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n--- 前100字对比 ---');
  console.log('原文:', content.substring(0, 100));
  console.log('润色:', result.content?.substring(0, 100));
});
