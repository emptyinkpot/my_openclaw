/**
 * 替换正文操作 - 模块化版
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 打开作品                                           │
 * │      ↓                                                       │
 * │  Step 4: 查找章节                                           │
 * │      ↓                                                       │
 * │  Step 5: 验证章节对应                                       │
 * │      ↓                                                       │
 * │  Step 6: 清空编辑器                                         │
 * │      ↓                                                       │
 * │  Step 7: 替换正文                                           │
 * │      ↓                                                       │
 * │  Step 8: 确认结果                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node replace-content.js <章节号>
 * 示例：node replace-content.js 66
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');

runTask('替换正文操作', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const { numToChinese } = require('../../src/utils/helper');
  const config = require('../../src/config');
  
  // 统一报告器
  const reporter = new StepReporter();
  
  // 获取章节号参数
  const chapterNum = parseInt(process.argv[2]) || 66;
  const chapterTitle = `第${numToChinese(chapterNum)}章`;
  const workTitle = '变身咳血少女的我也要努力活下去';
  
  console.log(`目标章节: ${chapterTitle}`);
  console.log(`目标作品: ${workTitle}\n`);
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  const { browser, page } = await baimeng.browser.launch();
  reporter.success('浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  await baimeng.auth.restoreLogin(page);
  reporter.success('登录已恢复');
  
  // ========== Step 3: 打开作品 ==========
  reporter.start('Step 3', '打开作品');
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, workTitle);
  
  if (!workId) {
    reporter.fail('未找到作品');
    await browser.close();
    reporter.print();
    return;
  }
  
  await page.goto(`${config.BAIMENG.EDITOR_URL}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(5000);
  reporter.success(workTitle);
  
  // ========== Step 4: 查找章节 ==========
  reporter.start('Step 4', '查找章节');
  const result = await baimeng.sidebar.findChapter(page, chapterTitle);
  
  if (!result.found) {
    reporter.fail('未找到章节');
    await browser.close();
    reporter.print();
    return;
  }
  reporter.success(result.text);
  await page.waitForTimeout(3000);
  
  // ========== Step 5: 验证章节对应 ==========
  reporter.start('Step 5', '验证章节对应');
  const verifyResult = await baimeng.verify.verifyChapterMatch(page, chapterTitle);
  
  if (verifyResult.warning) {
    reporter.success(`${verifyResult.sidebarChapter} ⚠️ ${verifyResult.warning}`);
  } else {
    reporter.success(`${verifyResult.sidebarChapter} ✓ 验证通过`);
  }
  
  // ========== Step 6: 清空编辑器 ==========
  reporter.start('Step 6', '清空编辑器');
  const clearResult = await baimeng.editor.clearContent(page);
  
  if (clearResult.success) {
    reporter.success('内容已清空');
  } else {
    reporter.fail(clearResult.error);
  }
  await page.waitForTimeout(1000);
  
  // ========== Step 7: 替换正文 ==========
  reporter.start('Step 7', '替换正文');
  const replaceResult = await baimeng.modifyCard.replaceContent(page);
  
  if (replaceResult.success) {
    reporter.success(replaceResult.message);
  } else {
    reporter.fail(replaceResult.message);
  }
  await page.waitForTimeout(3000);
  
  // ========== Step 8: 确认结果 ==========
  reporter.start('Step 8', '确认结果');
  const newContent = await baimeng.content.getContent(page);
  await page.screenshot({ path: `/tmp/replace-ch${chapterNum}.png` });
  reporter.success(`${newContent.length} 字符 | 截图已保存`);
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
});
