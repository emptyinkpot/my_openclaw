/**
 * 白梦写作 - 润色并替换章节
 * 
 * 流程（基于已验证的 polish-chapter.js）：
 * 1. 登录白梦，获取章节内容
 * 2. 备份原始内容
 * 3. 打开润色网站
 * 4. 导入资源库
 * 5. 返回润色页面并刷新（关键！）
 * 6. 粘贴并润色
 * 7. 等待进度条消失
 * 8. 提取润色结果
 * 9. 返回白梦替换
 * 
 * 全程一个浏览器、一个标签页
 * 
 * 用法：
 * node tasks/baimeng/polish-and-replace.js <作品名> <章节号> [--force]
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');
const fs = require('fs');
const path = require('path');

runTask('润色并替换章节', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const config = require('../../src/config');
  const browser = require('../../src/platforms/baimeng/browser');
  const clipboard = require('../../../../../lib/utils/clipboard');
  
  const reporter = new StepReporter();
  
  // 参数
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.log('用法: node polish-and-replace.js <作品名> <章节号> [--force]');
    return;
  }
  
  const workName = args[0];
  const chapterNum = parseInt(args[1]);
  const forceRefresh = args.includes('--force');
  const chapterTitle = `第${chapterNum}章`;
  
  console.log('=== 润色章节:', chapterTitle, '===\n');
  
  let page = null;
  let browserConn = null;
  
  try {
    // ========== Step 0: 获取浏览器 ==========
    reporter.start('Step 0', '获取浏览器');
    
    const result = await browser.launch();
    browserConn = result.browser;
    page = result.page;
    
    reporter.success(result.isNew ? '新启动' : '已复用');
    
    // ========== Step 1: 登录白梦 ==========
    reporter.start('Step 1', '登录白梦');
    await baimeng.auth.restoreLogin(page);
    reporter.success('登录成功');
    
    // ========== Step 2: 获取章节内容 ==========
    reporter.start('Step 2', '获取章节内容');
    
    const works = await baimeng.works.getWorks(page);
    const workId = baimeng.works.findWorkId(works, workName);
    
    if (!workId) {
      reporter.fail('未找到作品');
      return;
    }
    
    await page.goto(config.BAIMENG.urls.editor + '?id=' + workId, { timeout: 30000 });
    await page.waitForTimeout(5000);
    
    await baimeng.sidebar.findChapter(page, chapterTitle);
    await page.waitForTimeout(3000);
    
    await page.waitForSelector('.Daydream', { state: 'visible', timeout: 10000 }).catch(() => null);
    await page.waitForTimeout(2000);
    
    const originalTitle = await baimeng.editor.getTitle(page);
    const originalContent = await baimeng.editor.getContent(page);
    
    if (!originalContent || originalContent.length < 50) {
      reporter.fail('内容过短');
      return;
    }
    
    reporter.success(`${originalContent.length} 字`);
    
    // ========== Step 3: 备份原始内容 ==========
    reporter.start('Step 3', '备份原始内容');
    
    const backupDir = '/tmp/openclaw/backups';
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const backupFile = path.join(backupDir, `${chapterTitle}_备份_${Date.now()}.txt`);
    fs.writeFileSync(backupFile, `【标题】\n${originalTitle}\n\n【正文】\n${originalContent}`);
    
    // 同时保存到剪贴板
    clipboard.write(originalContent, 'backup-content', { namespace: 'polish' });
    clipboard.write(originalContent, 'latest', { namespace: 'polish' });
    
    reporter.success(backupFile);
    
    // ========== Step 4: 打开润色网站 ==========
    reporter.start('Step 4', '打开润色网站');
    
    await page.goto('https://7d4jcknzqk.coze.site');
    await page.waitForTimeout(5000);
    reporter.success('已加载');
    
    // ========== Step 5: 导入资源库 ==========
    reporter.start('Step 5', '导入资源库');
    
    // 对话框处理器（忽略已关闭的错误）
    page.on('dialog', async dialog => {
      console.log('  对话框:', dialog.message());
      try {
        await dialog.accept();
      } catch (e) {
        // 对话框可能已自动关闭
      }
    });
    
    await page.click('button:has-text("资源库")');
    await page.waitForTimeout(2000);
    await page.click('button:has-text("一键导入")');
    await page.waitForTimeout(2000);
    
    const inputs = await page.$$('input[type="file"]');
    if (inputs.length > 0) {
      await inputs[0].setInputFiles('/workspace/projects/workspace/projects/novel-sync/storage/polish/resources.json');
      await page.waitForTimeout(5000);
    }
    
    // 🔴 关键：返回润色页面并刷新
    await page.goto('https://7d4jcknzqk.coze.site');
    await page.waitForTimeout(5000);
    reporter.success('已导入');
    
    // ========== Step 6: 粘贴并润色 ==========
    reporter.start('Step 6', '粘贴并润色');
    
    const ta = await page.$('textarea:visible');
    await ta.fill(originalContent);
    await page.waitForTimeout(2000);
    
    // 检查润色按钮状态
    const btnInfo = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const btn = buttons.find(b => b.textContent.includes('开始润色'));
      return btn ? { found: true, disabled: btn.disabled } : { found: false };
    });
    
    if (!btnInfo.found) {
      reporter.fail('未找到润色按钮');
      return;
    }
    
    if (btnInfo.disabled) {
      reporter.fail('润色按钮已禁用');
      return;
    }
    
    await page.click('button:has-text("开始润色")');
    reporter.success('已点击');
    
    // ========== Step 7: 等待进度条 ==========
    reporter.start('Step 7', '等待进度条');
    
    // 等待进度条出现
    let foundProgress = false;
    for (let i = 0; i < 20; i++) {
      await page.waitForTimeout(3000);
      foundProgress = await page.evaluate(() => document.body.innerText.includes('分段处理'));
      if (foundProgress) break;
    }
    
    if (!foundProgress) {
      console.log('  未检测到进度条，可能已完成');
    }
    
    // 等待进度条消失
    let hasProgress = true;
    let count = 0;
    while (hasProgress && count < 100) {
      await page.waitForTimeout(3000);
      hasProgress = await page.evaluate(() => document.body.innerText.includes('分段处理'));
      count++;
    }
    
    reporter.success('润色完成');
    await page.waitForTimeout(10000);
    
    // ========== Step 8: 提取润色结果 ==========
    reporter.start('Step 8', '提取润色结果');
    
    const polished = await page.evaluate(() => {
      const bodyText = document.body.innerText;
      const outputIdx = bodyText.indexOf('输出结果');
      const replaceIdx = bodyText.indexOf('替换记录');
      
      if (outputIdx === -1) return { error: '找不到输出结果' };
      
      let rawContent = replaceIdx > outputIdx 
        ? bodyText.substring(outputIdx, replaceIdx)
        : bodyText.substring(outputIdx);
      
      let lines = rawContent.split('\n');
      let i = 0;
      while (i < lines.length) {
        const t = lines[i].trim();
        if (t === '输出结果' || t.match(/^\d+\s*字$/) || t === '复制') {
          i++;
          continue;
        }
        break;
      }
      
      let contentLines = [];
      while (i < lines.length) {
        contentLines.push(lines[i]);
        i++;
      }
      
      return { content: contentLines.join('\n').trim() };
    });
    
    if (polished.error) {
      reporter.fail(polished.error);
      return;
    }
    
    reporter.success(`${polished.content.length} 字`);
    
    // ========== Step 9: 返回白梦替换 ==========
    reporter.start('Step 9', '返回白梦替换');
    
    await page.goto(config.BAIMENG.urls.editor + '?id=' + workId, { timeout: 30000 });
    await page.waitForTimeout(5000);
    
    await baimeng.sidebar.findChapter(page, chapterTitle);
    await page.waitForTimeout(3000);
    
    // 清空并替换
    await baimeng.editor.clearContent(page);
    await page.waitForTimeout(1000);
    
    const contentResult = await baimeng.editor.setContent(page, polished.content);
    
    if (contentResult.success) {
      await baimeng.editor.save(page);
      reporter.success('已保存');
    } else {
      reporter.fail(contentResult.error);
    }
    
    // 截图
    await page.screenshot({ path: `/tmp/polish-replace-ch${chapterNum}.png` });
    
    // 打印报告
    reporter.print();
    
    console.log('\n✅ 完成');
    console.log(`标题: ${originalTitle}（保持不变）`);
    console.log(`正文: ${polished.content.length} 字`);
    
  } catch (e) {
    reporter.fail(e.message);
    reporter.print();
    console.log('\n❌ 错误:', e.message);
    
  } finally {
    // 移除对话框处理器
    if (page) {
      page.removeAllListeners('dialog');
    }
    
    // 🔴 关键：只关闭标签页，浏览器保持运行
    if (page) {
      try {
        await page.close();
        console.log('\n标签页已关闭，浏览器保持运行');
      } catch (e) {}
    }
    
    // 断开连接
    if (browserConn) {
      try {
        browserConn.disconnect();
      } catch (e) {}
    }
  }
});
