/**
 * 打开指定作品的指定章节
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 获取作品列表                                       │
 * │      ↓                                                       │
 * │  Step 4: 打开编辑器                                         │
 * │      ↓                                                       │
 * │  Step 5: 查找章节                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 代码来源：src/platforms/baimeng/*.js 已验证模块
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');

runTask('打开章节', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const config = require('../../src/config');
  
  // 统一报告器
  const reporter = new StepReporter();
  
  const workTitle = '变身咳血少女的我也要努力活下去';
  const chapterTitle = '第六十五章';
  
  console.log(`打开: ${workTitle} - ${chapterTitle}\n`);
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  const { browser, page } = await baimeng.browser.launch();
  reporter.success('浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  await baimeng.auth.restoreLogin(page);
  reporter.success('登录已恢复');
  
  // ========== Step 3: 获取作品列表 ==========
  reporter.start('Step 3', '获取作品列表');
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, workTitle);
  
  if (!workId) {
    reporter.fail('未找到作品');
    reporter.print();
    await browser.close();
    return;
  }
  reporter.success(`作品ID: ${workId}`);
  
  // ========== Step 4: 打开编辑器 ==========
  reporter.start('Step 4', '打开编辑器');
  await page.goto(`${config.BAIMENG.EDITOR_URL}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(5000);
  reporter.success('编辑器已加载');
  
  // ========== Step 5: 查找章节 ==========
  reporter.start('Step 5', '查找章节');
  const result = await baimeng.sidebar.findChapter(page, chapterTitle);
  
  if (result.found) {
    reporter.success(chapterTitle);
  } else {
    reporter.fail('未找到章节');
  }
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
});
