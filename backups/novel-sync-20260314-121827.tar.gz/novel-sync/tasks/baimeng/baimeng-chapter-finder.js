/**
 * 白梦写作 - 章节查找器
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 解析参数                                           │
 * │      ↓                                                       │
 * │  [无参数] → 列出所有作品                                    │
 * │  [仅作品] → 列出章节列表                                    │
 * │  [作品+章节] → Step 4: 打开编辑器 → Step 5: 查找章节       │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：
 *   node baimeng-chapter-finder.js                      # 列出所有作品
 *   node baimeng-chapter-finder.js <作品名或ID>          # 列出作品章节
 *   node baimeng-chapter-finder.js <作品名或ID> <章节号> # 打开指定章节
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');

runTask('章节查找器', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const { numToChinese } = require('../../src/utils/helper');
  const config = require('../../src/config');
  
  // 统一报告器
  const reporter = new StepReporter();
  
  const args = process.argv.slice(2).filter(a => a !== '--close');
  const autoClose = process.argv.includes('--close');
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  const { browser, page } = await baimeng.browser.launch();
  reporter.success('浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  await baimeng.auth.restoreLogin(page);
  reporter.success('登录已恢复');
  
  // 情况1：无参数，列出所有作品
  if (args.length === 0) {
    reporter.start('Step 3', '列出作品');
    const works = await baimeng.works.getWorks(page);
    reporter.success(`${works.length} 部作品`);
    
    console.log('\n作品列表:');
    works.forEach((w, i) => console.log(`  ${i + 1}. ${w.title}`));
    console.log('\n用法: node baimeng-chapter-finder.js <作品名或ID> <章节号>');
    
    reporter.print();
    
    if (autoClose) {
      await browser.close();
      return;
    }
    console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
    await new Promise(() => {});
    return;
  }
  
  // ========== Step 3: 解析参数 ==========
  reporter.start('Step 3', '解析参数');
  
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, args[0]);
  
  if (!workId) {
    reporter.fail('未找到作品');
    reporter.print();
    if (autoClose) await browser.close();
    return;
  }
  
  const workTitle = works.find(w => w.id === workId)?.title;
  reporter.success(workTitle);
  
  // ========== Step 4: 打开编辑器 ==========
  reporter.start('Step 4', '打开编辑器');
  
  console.log(`\n打开: ${workTitle}`);
  await page.goto(`${config.BAIMENG.EDITOR_URL}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(8000);
  reporter.success('编辑器已加载');
  
  // 情况2：只有作品名，列出章节
  if (args.length === 1) {
    reporter.start('Step 5', '列出章节');
    
    const pos = await baimeng.sidebar.getPosition(page);
    if (pos) {
      await baimeng.sidebar.scrollToTop(page);
      
      const chapters = new Set();
      let lastCount = 0, noChange = 0;
      
      for (let i = 0; i < 200; i++) {
        const visible = await page.evaluate(() => {
          const sidebar = document.querySelector('.sidebar');
          if (!sidebar) return [];
          return Array.from(sidebar.querySelectorAll('*'))
            .map(el => (el.innerText || '').trim().match(/^第[零一二三四五六七八九十百千万]+章/)?.[0])
            .filter(Boolean);
        });
        visible.forEach(c => chapters.add(c));
        
        await page.mouse.wheel(0, 100);
        await page.waitForTimeout(80);
        
        if (chapters.size === lastCount) {
          if (++noChange > 25) break;
        } else {
          noChange = 0;
          lastCount = chapters.size;
        }
      }
      
      reporter.success(`${chapters.size} 章`);
      
      console.log(`\n章节列表 (${chapters.size} 章):`);
      [...chapters].forEach((c, i) => {
        process.stdout.write((i + 1) % 10 === 0 ? `${c}\n` : `${c.padEnd(8)} `);
      });
      if (chapters.size % 10 !== 0) console.log();
    }
    
    console.log('\n用法: node baimeng-chapter-finder.js', workTitle, '<章节号>');
    
    reporter.print();
    
    if (autoClose) {
      await browser.close();
      return;
    }
    console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
    await new Promise(() => {});
    return;
  }
  
  // 情况3：查找并打开章节
  reporter.start('Step 5', '查找章节');
  
  const chapterNum = parseInt(args[1]) || 1;
  const targetText = `第${numToChinese(chapterNum)}章`;
  
  console.log(`查找: ${targetText}\n`);
  
  const result = await baimeng.sidebar.findChapter(page, targetText);
  
  if (result.found) {
    reporter.success(targetText);
  } else {
    reporter.fail('未找到章节');
  }
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n浏览器保持打开，按 Ctrl+C 退出...');
  await new Promise(() => {});
});
