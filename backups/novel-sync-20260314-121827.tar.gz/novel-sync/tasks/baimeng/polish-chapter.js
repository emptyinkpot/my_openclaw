/**
 * 白梦写作 - 单章润色替换脚本
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 登录白梦                                           │
 * │      ↓                                                       │
 * │  Step 2: 获取章节内容                                       │
 * │      ↓                                                       │
 * │  Step 3: 备份原始内容                                       │
 * │      ↓                                                       │
 * │  Step 4: 打开润色网站                                       │
 * │      ↓                                                       │
 * │  Step 5: 导入资源库                                         │
 * │      ↓                                                       │
 * │  Step 6: 粘贴并润色                                         │
 * │      ↓                                                       │
 * │  Step 7: 等待进度条                                         │
 * │      ↓                                                       │
 * │  Step 8: 提取润色结果                                       │
 * │      ↓                                                       │
 * │  Step 9: 替换到编辑器                                       │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：
 * node tasks/baimeng/polish-chapter.js <章节号>
 * 示例：node tasks/baimeng/polish-chapter.js 4
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');
const fs = require('fs');
const path = require('path');

runTask('单章润色替换', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const config = require('../../src/config');
  
  // 统一报告器
  const reporter = new StepReporter();
  
  // 获取章节号
  const chapterArg = process.argv[2];
  if (!chapterArg) {
    console.log('用法: node tasks/baimeng/polish-chapter.js <章节号>');
    console.log('示例: node tasks/baimeng/polish-chapter.js 4');
    return;
  }
  
  // 解析章节号
  let chapterNum;
  const numMap = {'一':1,'二':2,'三':3,'四':4,'五':5,'六':6,'七':7,'八':8,'九':9,'十':10,
                  '十一':11,'十二':12,'十三':13,'十四':14,'十五':15,'十六':16,'十七':17,'十八':18,'十九':19,'二十':20};
  
  if (numMap[chapterArg]) {
    chapterNum = numMap[chapterArg];
  } else if (chapterArg.match(/^第(.+)章$/)) {
    const chinese = chapterArg.match(/^第(.+)章$/)[1];
    chapterNum = numMap[chinese] || parseInt(chinese);
  } else {
    chapterNum = parseInt(chapterArg);
  }
  
  const nums = ['一','二','三','四','五','六','七','八','九','十',
                '十一','十二','十三','十四','十五','十六','十七','十八','十九','二十'];
  const chapterName = '第' + (nums[chapterNum-1] || chapterNum) + '章';
  
  console.log('=== 润色章节:', chapterName, '===\n');
  
  const { browser, page } = await baimeng.browser.launch();
  
  try {
    // ========== Step 1: 登录白梦 ==========
    reporter.start('Step 1', '登录白梦');
    await baimeng.auth.restoreLogin(page);
    reporter.success('登录成功');
    
    // ========== Step 2: 获取章节内容 ==========
    reporter.start('Step 2', '获取章节内容');
    
    const works = await baimeng.works.getWorks(page);
    const workId = baimeng.works.findWorkId(works, '变身咳血少女的我也要努力活下去');
    
    await page.goto(config.BAIMENG.urls.editor + '?id=' + workId, { timeout: 30000 });
    await page.waitForTimeout(5000);
    
    await baimeng.sidebar.findChapter(page, chapterName);
    await page.waitForTimeout(3000);
    
    const originalTitle = await baimeng.editor.getTitle(page);
    const originalContent = await baimeng.editor.getContent(page);
    
    if (originalContent.length < 50) {
      reporter.fail('内容过短，可能是占位符');
      reporter.print();
      await browser.close();
      return;
    }
    
    reporter.success(`${originalContent.length} 字`);
    
    // ========== Step 3: 备份原始内容 ==========
    reporter.start('Step 3', '备份原始内容');
    
    const backupDir = '/tmp/openclaw/backups';
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const backupFile = path.join(backupDir, `${chapterName}_备份_${Date.now()}.txt`);
    fs.writeFileSync(backupFile, `【标题】\n${originalTitle}\n\n【正文】\n${originalContent}`);
    reporter.success(backupFile);
    
    // ========== Step 4: 打开润色网站 ==========
    reporter.start('Step 4', '打开润色网站');
    
    await page.goto('https://7d4jcknzqk.coze.site');
    await page.waitForTimeout(5000);
    reporter.success('润色网站已加载');
    
    // ========== Step 5: 导入资源库 ==========
    reporter.start('Step 5', '导入资源库');
    
    // 对话框处理器
    page.on('dialog', async dialog => {
      console.log('  对话框:', dialog.message());
      try { await dialog.accept(); } catch (e) {}
    });
    
    await page.click('button:has-text("资源库")');
    await page.waitForTimeout(2000);
    await page.click('button:has-text("一键导入")');
    await page.waitForTimeout(2000);
    
    const inputs = await page.$$('input[type="file"]');
    await inputs[0].setInputFiles('/workspace/projects/workspace/projects/novel-sync/storage/polish/resources.json');
    await page.waitForTimeout(5000);
    
    // 返回润色页面并刷新
    await page.goto('https://7d4jcknzqk.coze.site');
    await page.waitForTimeout(5000);
    reporter.success('资源库已导入');
    
    // ========== Step 6: 粘贴并润色 ==========
    reporter.start('Step 6', '粘贴并润色');
    
    const ta = await page.$('textarea:visible');
    await ta.fill(originalContent);
    await page.waitForTimeout(2000);
    
    // 检查润色按钮状态
    const btnInfo = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('button'));
      const btn = buttons.find(b => b.textContent.includes('开始润色'));
      return btn ? { found: true, disabled: btn.disabled } : { found: false };
    });
    
    if (btnInfo.found && !btnInfo.disabled) {
      await page.click('button:has-text("开始润色")');
      reporter.success('已点击润色按钮');
    } else {
      reporter.fail(btnInfo.found ? '按钮已禁用' : '未找到润色按钮');
      reporter.print();
      await browser.close();
      return;
    }
    
    // ========== Step 7: 等待进度条 ==========
    reporter.start('Step 7', '等待进度条');
    
    // 等待进度条出现
    let foundProgress = false;
    for (let i = 0; i < 20; i++) {
      await page.waitForTimeout(3000);
      foundProgress = await page.evaluate(() => document.body.innerText.includes('分段处理'));
      if (foundProgress) break;
    }
    
    if (!foundProgress) {
      reporter.fail('未检测到进度条');
      reporter.print();
      await browser.close();
      return;
    }
    
    // 等待进度条消失
    let hasProgress = true;
    let count = 0;
    while (hasProgress && count < 100) {
      await page.waitForTimeout(3000);
      hasProgress = await page.evaluate(() => document.body.innerText.includes('分段处理'));
      count++;
    }
    
    reporter.success('润色完成');
    await page.waitForTimeout(10000);
    
    // ========== Step 8: 提取润色结果 ==========
    reporter.start('Step 8', '提取润色结果');
    
    const polished = await page.evaluate(() => {
      const bodyText = document.body.innerText;
      const outputIdx = bodyText.indexOf('输出结果');
      const replaceIdx = bodyText.indexOf('替换记录');
      
      if (outputIdx === -1) return { error: '找不到输出结果' };
      
      let rawContent = replaceIdx > outputIdx 
        ? bodyText.substring(outputIdx, replaceIdx)
        : bodyText.substring(outputIdx);
      
      let lines = rawContent.split('\n');
      let i = 0;
      while (i < lines.length) {
        const t = lines[i].trim();
        if (t === '输出结果' || t.match(/^\d+\s*字$/) || t === '复制') {
          i++;
          continue;
        }
        break;
      }
      
      let contentLines = [];
      while (i < lines.length) {
        contentLines.push(lines[i]);
        i++;
      }
      
      return { content: contentLines.join('\n').trim() };
    });
    
    if (polished.error) {
      reporter.fail(polished.error);
      reporter.print();
      await browser.close();
      return;
    }
    
    reporter.success(`${polished.content.length} 字`);
    
    // ========== Step 9: 替换到编辑器 ==========
    reporter.start('Step 9', '替换到编辑器');
    
    // 返回白梦编辑器
    await page.goto(config.BAIMENG.urls.editor + '?id=' + workId, { timeout: 30000 });
    await page.waitForTimeout(5000);
    
    await baimeng.sidebar.findChapter(page, chapterName);
    await page.waitForTimeout(3000);
    
    // 清空并替换
    await baimeng.editor.clearContent(page);
    await page.waitForTimeout(1000);
    
    const contentResult = await baimeng.editor.setContent(page, polished.content);
    
    if (contentResult.success) {
      // 保存
      await baimeng.editor.save(page);
      reporter.success('已保存');
    } else {
      reporter.fail(contentResult.error);
    }
    
    // 打印最终报告
    reporter.print();
    
    await browser.close();
    
  } catch (e) {
    reporter.fail(e.message);
    reporter.print();
    await browser.close();
  }
});
