/**
 * 白梦写作 - 复制章节到持久化剪贴板
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 获取作品                                           │
 * │      ↓                                                       │
 * │  Step 4: 打开编辑器                                         │
 * │      ↓                                                       │
 * │  Step 5: 查找章节                                           │
 * │      ↓                                                       │
 * │  Step 6: 滚动加载                                           │
 * │      ↓                                                       │
 * │  Step 7: 复制并保存                                         │
 * │      ↓                                                       │
 * │  Step 8: 关闭浏览器                                         │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node copy-to-clipboard.js <作品名> <章节号>
 * 示例：node copy-to-clipboard.js "变身咳血少女的我也要努力活下去" 64
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');

runTask('复制章节到剪贴板', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const config = require('../../src/config');
  
  // 统一报告器
  const reporter = new StepReporter();
  
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.log('用法: node copy-to-clipboard.js <作品名> <章节号>');
    console.log('示例: node copy-to-clipboard.js "变身咳血少女的我也要努力活下去" 64');
    return;
  }
  
  const workName = args[0];
  const chapterNum = parseInt(args[1]) || 1;
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  const { browser, page } = await baimeng.browser.launch();
  reporter.success('浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  await baimeng.auth.restoreLogin(page);
  reporter.success('登录已恢复');
  
  // ========== Step 3: 获取作品 ==========
  reporter.start('Step 3', '获取作品');
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, workName);
  
  if (!workId) {
    reporter.fail('未找到作品');
    reporter.print();
    await browser.close();
    return;
  }
  
  const workTitle = works.find(w => w.id === workId)?.title;
  reporter.success(workTitle);
  
  console.log(`\n作品: ${workTitle}`);
  console.log(`章节: 第${chapterNum}章\n`);
  
  // ========== Step 4: 打开编辑器 ==========
  reporter.start('Step 4', '打开编辑器');
  await page.goto(`${config.BAIMENG.urls.editor}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(5000);
  reporter.success('编辑器已加载');
  
  // ========== Step 5: 查找章节 ==========
  reporter.start('Step 5', '查找章节');
  const result = await baimeng.sidebar.findChapter(page, `第${chapterNum}章`);
  
  if (!result.found) {
    reporter.fail('未找到章节');
    reporter.print();
    await browser.close();
    return;
  }
  reporter.success(`第${chapterNum}章`);
  await page.waitForTimeout(3000);
  
  // ========== Step 6: 滚动加载 ==========
  reporter.start('Step 6', '滚动加载');
  await baimeng.content.scrollToBottom(page);
  await page.waitForTimeout(2000);
  await baimeng.content.scrollToBottom(page);
  await page.waitForTimeout(1000);
  reporter.success('完整内容已加载');
  
  // ========== Step 7: 复制并保存 ==========
  reporter.start('Step 7', '复制并保存');
  const copyResult = await baimeng.copy.copyAndSave(page, `chapter-${chapterNum}`);
  
  if (copyResult.success) {
    // 同时保存为 latest
    baimeng.copy.saveToFile(copyResult.content, 'latest');
    reporter.success(`${copyResult.content.length} 字 → ${copyResult.path}`);
  } else {
    reporter.fail(copyResult.error);
  }
  
  // ========== Step 8: 关闭浏览器 ==========
  reporter.start('Step 8', '关闭浏览器');
  await browser.close();
  reporter.success('完成');
  
  // 打印最终报告
  reporter.print();
  
  if (copyResult.success) {
    console.log(`\n内容预览: ${copyResult.content.substring(0, 100)}...`);
  }
});
