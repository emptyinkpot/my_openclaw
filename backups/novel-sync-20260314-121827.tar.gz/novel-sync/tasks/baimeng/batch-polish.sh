#!/bin/bash
# 批量润色脚本
# 用法: ./batch-polish.sh "作品名" 起始章 结束章

WORK_NAME="$1"
START_CHAPTER="$2"
END_CHAPTER="$3"
LOG_DIR="/tmp/batch-polish-logs"

mkdir -p "$LOG_DIR"

echo "=========================================="
echo "批量润色任务"
echo "作品: $WORK_NAME"
echo "章节范围: 第${START_CHAPTER}章 - 第${END_CHAPTER}章"
echo "开始时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "=========================================="

# 结果统计
SUCCESS_COUNT=0
FAIL_COUNT=0
FAILED_CHAPTERS=""

cd /workspace/projects/workspace/projects/novel-sync

for i in $(seq $START_CHAPTER $END_CHAPTER); do
  echo ""
  echo "========================================"
  echo "[$(date '+%H:%M:%S')] 开始处理第${i}章"
  echo "========================================"
  
  # 清理该章的缓存（强制重新润色）
  rm -f /tmp/polish-result-${i}.json
  
  # 执行润色+替换
  LOG_FILE="$LOG_DIR/chapter-${i}.log"
  timeout 300 node tasks/baimeng/polish-and-replace.js "$WORK_NAME" $i > "$LOG_FILE" 2>&1
  EXIT_CODE=$?
  
  if [ $EXIT_CODE -eq 0 ]; then
    # 检查是否成功
    if grep -q "✅ 全部完成" "$LOG_FILE"; then
      echo "✅ 第${i}章 完成"
      SUCCESS_COUNT=$((SUCCESS_COUNT + 1))
    else
      echo "❌ 第${i}章 失败（未完成）"
      FAIL_COUNT=$((FAIL_COUNT + 1))
      FAILED_CHAPTERS="$FAILED_CHAPTERS $i"
    fi
  else
    echo "❌ 第${i}章 失败（退出码: $EXIT_CODE）"
    FAIL_COUNT=$((FAIL_COUNT + 1))
    FAILED_CHAPTERS="$FAILED_CHAPTERS $i"
    # 显示错误日志最后10行
    echo "--- 错误日志 ---"
    tail -10 "$LOG_FILE"
    echo "----------------"
  fi
  
  # 章节间休息2秒，避免操作过快
  sleep 2
done

echo ""
echo "=========================================="
echo "批量润色完成"
echo "结束时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "成功: $SUCCESS_COUNT 章"
echo "失败: $FAIL_COUNT 章"
if [ -n "$FAILED_CHAPTERS" ]; then
  echo "失败章节:$FAILED_CHAPTERS"
fi
echo "日志目录: $LOG_DIR"
echo "=========================================="
