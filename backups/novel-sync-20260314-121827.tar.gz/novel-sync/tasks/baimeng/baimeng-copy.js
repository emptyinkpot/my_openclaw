/**
 * 白梦写作 - 复制章节内容
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 获取作品列表                                       │
 * │      ↓                                                       │
 * │  Step 4: 打开编辑器                                         │
 * │      ↓                                                       │
 * │  Step 5: 查找章节                                           │
 * │      ↓                                                       │
 * │  Step 6: 滚动加载                                           │
 * │      ↓                                                       │
 * │  Step 7: 点击复制                                           │
 * │      ↓                                                       │
 * │  Step 8: 显示内容                                           │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：node baimeng-copy.js <作品名> <章节号>
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');

runTask('复制章节内容', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const { numToChinese } = require('../../src/utils/helper');
  const config = require('../../src/config');
  
  // 统一报告器
  const reporter = new StepReporter();
  
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.log('用法: node baimeng-copy.js <作品名> <章节号>');
    console.log('示例: node baimeng-copy.js 枪与凋零之花 1');
    return;
  }
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  const { browser, page } = await baimeng.browser.launch();
  reporter.success('浏览器已启动');
  
  // ========== Step 2: 恢复登录 ==========
  reporter.start('Step 2', '恢复登录');
  await baimeng.auth.restoreLogin(page);
  reporter.success('登录已恢复');
  
  // ========== Step 3: 获取作品列表 ==========
  reporter.start('Step 3', '获取作品列表');
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, args[0]);
  
  if (!workId) {
    reporter.fail('未找到作品');
    await browser.close();
    reporter.print();
    return;
  }
  
  const workTitle = works.find(w => w.id === workId)?.title;
  reporter.success(workTitle);
  
  const chapterName = `第${numToChinese(parseInt(args[1]) || 1)}章`;
  console.log(`\n作品: ${workTitle}`);
  console.log(`章节: ${chapterName}\n`);
  
  // ========== Step 4: 打开编辑器 ==========
  reporter.start('Step 4', '打开编辑器');
  await page.goto(`${config.BAIMENG.urls.editor}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(8000);
  reporter.success('编辑器已加载');
  
  // ========== Step 5: 查找章节 ==========
  reporter.start('Step 5', '查找章节');
  const result = await baimeng.sidebar.findChapter(page, chapterName);
  
  if (!result.found) {
    reporter.fail('未找到章节');
    await browser.close();
    reporter.print();
    return;
  }
  reporter.success(chapterName);
  await page.waitForTimeout(2000);
  
  // ========== Step 6: 滚动加载 ==========
  reporter.start('Step 6', '滚动加载');
  await baimeng.content.scrollToBottom(page);
  reporter.success('完整内容已加载');
  
  // ========== Step 7: 点击复制 ==========
  reporter.start('Step 7', '点击复制');
  const copied = await baimeng.copy.clickCopyButton(page);
  
  if (copied) {
    reporter.success('已复制到剪贴板');
  } else {
    reporter.fail('未找到复制按钮');
  }
  
  // ========== Step 8: 显示内容 ==========
  reporter.start('Step 8', '显示内容');
  const content = await baimeng.content.getContent(page);
  reporter.success(`${content.length} 字`);
  
  // 打印最终报告
  reporter.print();
  
  console.log('\n' + '='.repeat(50));
  console.log(`内容预览:`);
  console.log('='.repeat(50));
  console.log(content.substring(0, 2000));
  if (content.length > 2000) {
    console.log(`\n... (预览截断，完整内容已复制到剪贴板)`);
  }
  console.log('='.repeat(50));
  
  console.log('\n浏览器保持打开，可在其他应用粘贴...');
  await new Promise(() => {});
});
