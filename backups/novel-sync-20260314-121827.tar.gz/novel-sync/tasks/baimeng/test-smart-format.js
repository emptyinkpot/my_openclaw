/**
 * 白梦写作 - 测试智能排版功能
 * 
 * 流程图：
 * ┌─────────────────────────────────────────────────────────────┐
 * │  Step 1: 启动浏览器                                         │
 * │      ↓                                                       │
 * │  Step 2: 恢复登录                                           │
 * │      ↓                                                       │
 * │  Step 3: 打开章节                                           │
 * │      ↓                                                       │
 * │  Step 4: 检查智能排版按钮                                   │
 * │      ↓                                                       │
 * │  Step 5: 获取排版前内容                                     │
 * │      ↓                                                       │
 * │  Step 6: 执行智能排版                                       │
 * │      ↓                                                       │
 * │  Step 7: 对比排版结果                                       │
 * │      ↓                                                       │
 * │  Step 8: 保存（可选）                                       │
 * └─────────────────────────────────────────────────────────────┘
 * 
 * 用法：
 *   node tasks/baimeng/test-smart-format.js "作品名" 66
 *   node tasks/baimeng/test-smart-format.js "作品名" 66 --save
 */

const { runTask } = require('../../src/utils/task-runner');
const { StepReporter } = require('../../src/utils');

runTask('测试智能排版', async (ctx) => {
  const baimeng = require('../../src/platforms/baimeng');
  const config = require('../../src/config');
  
  // 统一报告器
  const reporter = new StepReporter();
  
  const args = process.argv.slice(2).filter(a => !a.startsWith('--'));
  const shouldSave = process.argv.includes('--save');
  
  if (args.length < 2) {
    console.log('用法: node tasks/baimeng/test-smart-format.js <作品名> <章节号> [--save]');
    console.log('');
    console.log('参数:');
    console.log('  --save    保存排版后的内容');
    return;
  }
  
  const workName = args[0];
  const chapterNum = parseInt(args[1]);
  
  console.log(`📚 作品: ${workName}`);
  console.log(`📖 章节: 第${chapterNum}章`);
  console.log(`💾 保存: ${shouldSave ? '是' : '否'}`);
  console.log('');
  
  // ========== Step 1: 启动浏览器 ==========
  reporter.start('Step 1', '启动浏览器');
  const { browser, page } = await baimeng.browser.launch();
  reporter.success('浏览器已启动');
  
  try {
    // ========== Step 2: 恢复登录 ==========
    reporter.start('Step 2', '恢复登录');
    await baimeng.auth.restoreLogin(page);
    reporter.success('登录已恢复');
    
    // ========== Step 3: 打开章节 ==========
    reporter.start('Step 3', '打开章节');
    await baimeng.sidebar.openChapter(page, workName, chapterNum);
    await page.waitForTimeout(3000);
    reporter.success(`第${chapterNum}章`);
    
    // ========== Step 4: 检查智能排版按钮 ==========
    reporter.start('Step 4', '检查智能排版按钮');
    const hasButton = await baimeng.editor.hasSmartFormatButton(page);
    
    if (!hasButton) {
      reporter.fail('未找到智能排版按钮');
      reporter.print();
      return;
    }
    reporter.success('按钮存在');
    
    // ========== Step 5: 获取排版前内容 ==========
    reporter.start('Step 5', '获取排版前内容');
    const before = await baimeng.editor.getContent(page);
    reporter.success(`${before.length} 字`);
    
    // ========== Step 6: 执行智能排版 ==========
    reporter.start('Step 6', '执行智能排版');
    const result = await baimeng.editor.smartFormat(page);
    
    if (!result.success) {
      reporter.fail(result.error);
      reporter.print();
      return;
    }
    reporter.success(result.changed ? '内容已变化' : '无变化');
    
    // ========== Step 7: 对比排版结果 ==========
    reporter.start('Step 7', '对比排版结果');
    
    if (result.changed) {
      const beforeLines = result.before.split('\n');
      const afterLines = result.after.split('\n');
      reporter.success(`${beforeLines.length} → ${afterLines.length} 段落`);
    } else {
      reporter.success('内容格式已规范');
    }
    
    // ========== Step 8: 保存（可选） ==========
    if (shouldSave && result.changed) {
      reporter.start('Step 8', '保存修改');
      const saveResult = await baimeng.editor.save(page);
      
      if (saveResult.success) {
        reporter.success('已保存');
      } else {
        reporter.fail(saveResult.error);
      }
    } else if (shouldSave) {
      reporter.start('Step 8', '保存修改');
      reporter.skip('内容无变化');
    }
    
    // 打印最终报告
    reporter.print();
    
    if (result.changed) {
      console.log('\n📝 排版后内容（前200字）:');
      console.log(result.after.substring(0, 200) + '...');
    }
    
  } finally {
    console.log('\n🌐 浏览器保持打开，可手动检查');
  }
});
