# 白梦写作 - 章节润色脚本使用文档

## 功能

自动润色指定章节并替换到白梦写作平台。

## 用法

```bash
cd /workspace/projects/workspace/projects/novel-sync
node tasks/baimeng/polish-chapter.js <章节号>
```

### 示例

```bash
# 润色第4章
node tasks/baimeng/polish-chapter.js 4

# 润色第五章
node tasks/baimeng/polish-chapter.js 第五章

# 润色第10章
node tasks/baimeng/polish-chapter.js 10
```

## 流程说明

1. **获取章节内容** - 从白梦写作平台获取指定章节的标题和正文
2. **自动备份** - 备份原始内容到 `/tmp/openclaw/backups/`
3. **打开润色网站** - 访问 Coze 润色网站
4. **导入资源库** - 自动导入词汇、禁用词等资源
5. **执行润色** - 发送内容到润色网站，等待处理完成
6. **提取结果** - 从润色网站提取润色后的正文
7. **替换内容** - 将润色后的内容替换到白梦编辑器
8. **保持标题** - 标题保持不变（润色网站只输出正文）

## 润色效果对比

| 项目 | 原文 | 润色后 |
|------|------|--------|
| 第6章长度 | 6082字 | 3986字 |
| 文风变化 | 较直白 | 更有文学感 |
| 标点处理 | 中英混用 | 统一日式标点 |

### 示例对比

**原文：**
> 那一声枪响，像是某种古老仪式的开场锣鼓，震碎了卫宫府邸最后一点名为"体面"的伪装。
> 空气中那种令人窒息的粘稠感被撕裂了...

**润色后：**
> 那一声枪响，像是某种古老仪式的开场锣鼓，震碎了卫宫府邸最后一点名为「体面」的伪装。
> 空气中那种令人窒息的粘稠感被撕裂了，取而代之的是一种更为直接、更为赤裸的硝烟味...

## 注意事项

1. **备份位置**：`/tmp/openclaw/backups/` 目录下
2. **资源库文件**：`/workspace/projects/workspace/projects/novel-sync/storage/polish/resources.json`
3. **润色时间**：每章约需 1-2 分钟
4. **网络要求**：需要能访问润色网站

## 批量润色

如需批量润色多个章节，可以使用循环：

```bash
# 润色第4-10章
for i in 4 5 6 7 8 9 10; do
  node tasks/baimeng/polish-chapter.js $i
  echo "等待30秒..."
  sleep 30
done
```

## 已完成章节

| 章节 | 状态 | 完成时间 |
|------|------|----------|
| 第4章 | ✅ 已润色 | 2024-03-14 |
| 第6章 | ✅ 已润色 | 2024-03-14 |

## 问题排查

### 润色按钮不可用

**原因**：内容未粘贴成功  
**解决**：检查 textarea 是否正确填充

### 进度条未检测到

**原因**：润色服务可能出错  
**解决**：手动检查润色网站状态

### 内容为空

**原因**：提取逻辑失败  
**解决**：检查润色网站输出格式是否变化

## 相关文件

- `tasks/baimeng/polish-chapter.js` - 主脚本
- `src/platforms/baimeng/editor.js` - 编辑器操作模块
- `src/platforms/coze/polish.js` - 润色网站模块
- `storage/polish/resources.json` - 润色资源库
