# 模块架构图

## 层级结构

```
┌─────────────────────────────────────────────────────────────┐
│                      一级脚本 (tasks/)                        │
│  用户直接运行的命令行脚本                                       │
│  polish-and-replace.js, polish-flow.js, ...                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    平台模块 (src/platforms/)                  │
│  baimeng/                    │ coze/                         │
│  ├── browser.js              │ ├── index.js (CozePlatform)   │
│  ├── auth.js                 │ ├── polish.js                 │
│  ├── editor.js               │ └── polish-executor.js        │
│  ├── sidebar.js              │                               │
│  └── chapter-nav.js          │                               │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     工具模块 (src/utils/)                     │
│  task-runner.js    args-parser.js    file-utils.js          │
│  safe-action.js    backup-manager.js  workflow.js           │
│  screenshot.js     storage.js         result-checker.js     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     全局共享 (lib/)                           │
│  utils/clipboard.js - 跨脚本数据传递                          │
└─────────────────────────────────────────────────────────────┘
```

## 调用关系

### 润色并替换流程

```
polish-and-replace.js
    │
    ├─→ baimeng/browser.js      (启动浏览器)
    ├─→ baimeng/auth.js         (恢复登录)
    ├─→ baimeng/works.js        (获取作品列表)
    ├─→ baimeng/sidebar.js      (查找章节)
    ├─→ baimeng/editor.js       (获取/设置内容)
    ├─→ baimeng/content.js      (滚动加载)
    ├─→ coze/polish.js          (润色流程)
    └─→ lib/clipboard.js        (备份内容)
```

### 章节导航流程

```
baimeng-chapter-finder.js
    │
    ├─→ baimeng/browser.js      (启动浏览器)
    ├─→ baimeng/auth.js         (恢复登录)
    ├─→ baimeng/works.js        (获取作品列表)
    ├─→ baimeng/sidebar.js      (查找章节)
    └─→ utils/helper.js         (中文数字转换)
```

## 模块职责

| 模块类型 | 职责 | 示例 |
|----------|------|------|
| 一级脚本 | 用户入口，组装流程 | `tasks/baimeng/*.js` |
| 平台模块 | 平台特定操作 | `src/platforms/baimeng/editor.js` |
| 工具模块 | 通用功能，跨平台复用 | `src/utils/safe-action.js` |
| 全局共享 | 跨项目共享 | `lib/utils/clipboard.js` |

## 扩展新平台

1. 创建 `src/platforms/new-platform/` 目录
2. 实现必需模块：
   - `browser.js` - 浏览器管理
   - `auth.js` - 登录管理
   - `index.js` - 整合导出
3. 在 `src/config.js` 添加配置
4. 创建一级脚本 `tasks/new-platform/`
