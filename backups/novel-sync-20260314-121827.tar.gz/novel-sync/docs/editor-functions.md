# 编辑器模块功能清单

## src/platforms/baimeng/editor.js

### 正文编辑功能

| 函数 | 功能 | 状态 |
|------|------|------|
| `getContent(page)` | 获取正文内容（清洗后） | ✅ |
| `getRawContent(page)` | 获取原始正文（未清洗，用于备份） | ✅ |
| `setContent(page, content)` | 设置正文内容 | ✅ |
| `appendContent(page, text)` | 追加内容到末尾 | ✅ 🆕 |
| `insertContent(page, text, options)` | 在指定位置插入内容 | ✅ 🆕 |
| `replaceText(page, oldText, newText, options)` | 替换指定文本 | ✅ 🆕 |
| `clearContent(page)` | 清空正文 | ✅ |
| `focus(page)` | 聚焦编辑器 | ✅ |
| `isEmpty(page)` | 检查是否为空 | ✅ |

### 标题编辑功能

| 函数 | 功能 | 状态 |
|------|------|------|
| `getTitle(page)` | 获取章节标题 | ✅ |
| `setTitle(page, newTitle)` | 修改章节标题 | ✅ |

### 其他功能

| 函数 | 功能 | 状态 |
|------|------|------|
| `save(page)` | 保存作品 | ✅ |
| `smartFormat(page)` | 智能排版 | ✅ |
| `hasSmartFormatButton(page)` | 检查排版按钮是否存在 | ✅ |

### 内容清洗工具

| 函数 | 功能 |
|------|------|
| `cleanContent(text)` | 清洗文本内容 |
| `extractTitle(text)` | 从文本提取标题 |
| `isJunkLine(line, index, lines)` | 判断是否垃圾行 |

---

## 使用示例

### 编辑正文

```javascript
const baimeng = require('./src/platforms/baimeng');

// 获取正文
const content = await baimeng.editor.getContent(page);
console.log('当前正文:', content.length, '字');

// 设置正文
const result = await baimeng.editor.setContent(page, newContent);
if (result.success) {
  console.log('正文已更新');
}

// 清空正文
await baimeng.editor.clearContent(page);

// 追加内容到末尾
await baimeng.editor.appendContent(page, '\n这是新增的段落。');

// 在指定行插入内容
await baimeng.editor.insertContent(page, '插入的段落', {
  lineNumber: 5,      // 在第5行
  position: 'before'  // 在该行之前插入
});

// 替换文本
const result = await baimeng.editor.replaceText(
  page, 
  '旧文本', 
  '新文本',
  { all: true }  // 替换所有匹配项
);
console.log('替换了', result.count, '处');
```

### 编辑标题

```javascript
// 获取标题
const title = await baimeng.editor.getTitle(page);
console.log('当前标题:', title);

// 修改标题
const result = await baimeng.editor.setTitle(page, '第六十六章：新的开始');
if (result.success) {
  console.log('原标题:', result.oldTitle);
}
```

### 完整编辑流程

```javascript
const baimeng = require('./src/platforms/baimeng');

async function editChapter(page, newTitle, newContent) {
  // 1. 备份原始内容
  const oldTitle = await baimeng.editor.getTitle(page);
  const oldContent = await baimeng.editor.getRawContent(page);
  
  // 2. 修改标题
  const titleResult = await baimeng.editor.setTitle(page, newTitle);
  if (!titleResult.success) {
    return { success: false, error: '标题修改失败' };
  }
  
  // 3. 清空并设置正文
  await baimeng.editor.clearContent(page);
  const contentResult = await baimeng.editor.setContent(page, newContent);
  if (!contentResult.success) {
    // 回滚标题
    await baimeng.editor.setTitle(page, oldTitle);
    return { success: false, error: '正文修改失败' };
  }
  
  // 4. 保存
  await baimeng.editor.save(page);
  
  return { 
    success: true, 
    oldTitle, 
    oldContent,
    newTitle,
    newContent
  };
}
```

### insertContent 详解

```javascript
// 在第3行之前插入
await baimeng.editor.insertContent(page, '新段落', {
  lineNumber: 3,
  position: 'before'
});

// 在第3行之后插入
await baimeng.editor.insertContent(page, '新段落', {
  lineNumber: 3,
  position: 'after'
});

// 替换第3行内容
await baimeng.editor.insertContent(page, '新段落', {
  lineNumber: 3,
  position: 'replace'
});
```

### replaceText 详解

```javascript
// 只替换第一个匹配项
const result1 = await baimeng.editor.replaceText(
  page, 
  '张三', 
  '李四'
);

// 替换所有匹配项
const result2 = await baimeng.editor.replaceText(
  page, 
  '张三', 
  '李四',
  { all: true }
);

console.log(`替换了 ${result2.count} 处`);
```
