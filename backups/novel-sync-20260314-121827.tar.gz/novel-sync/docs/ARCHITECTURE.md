# 项目架构文档

## 架构总览

```
┌─────────────────────────────────────────────────────────────────┐
│                          调用层                                  │
│     CLI      │    机器人     │     API     │    其他脚本        │
└───────────────┼───────────────┼─────────────┼───────────────────┘
                │               │             │
                ▼               ▼             ▼
┌─────────────────────────────────────────────────────────────────┐
│                        服务层 (services)                         │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │  authService    │  │ platformService │  │   ...服务       │  │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘  │
│  统一入口，支持多种调用方式                                       │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                        平台层 (platforms)                        │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    平台适配器                            │    │
│  │  fanqie/adapter  │  baimeng/adapter  │  coze/adapter    │    │
│  │  - checkLogin    │  - checkLogin     │  - checkLogin    │    │
│  │  - restore       │  - restore        │  - restore       │    │
│  │  - getUserName   │  - getUserName    │  - getUserName   │    │
│  └─────────────────────────────────────────────────────────┘    │
│  低耦合：每个平台独立实现，不依赖浏览器实例                         │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                         核心层 (core)                            │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌───────────┐  │
│  │   error    │  │  storage   │  │  browser   │  │  logger   │  │
│  │ 错误处理    │  │ 安全存储    │  │ 浏览器管理  │  │ 日志      │  │
│  │ 重试机制    │  │ 原子写入    │  │ 锁机制     │  │           │  │
│  │ 数据校验    │  │ 自动备份    │  │ 资源清理    │  │           │  │
│  └────────────┘  └────────────┘  └────────────┘  └───────────┘  │
│  高鲁棒性：防止数据损坏，异常恢复                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 核心设计原则

### 1. 低耦合

| 层级 | 依赖关系 | 说明 |
|------|----------|------|
| 服务层 | → 核心层 | 只依赖核心层，不依赖具体平台 |
| 平台层 | → 核心层 | 只依赖核心层，不依赖其他平台 |
| 核心层 | 无依赖 | 完全独立，可单独测试 |

**关键点：**
- 平台适配器接受 `page` 参数，不创建浏览器
- 服务层统一管理平台注册
- 核心模块可独立运行

### 2. 高鲁棒性

**数据保护：**
- 原子写入：先写临时文件，再重命名
- 自动备份：每次修改前备份
- 数据校验：写入后验证内容

**错误处理：**
- 统一错误类型
- 自动重试机制
- 优雅降级

**资源管理：**
- 浏览器锁机制
- 进程退出自动清理
- 健康检查

### 3. DRY 原则

| 功能 | 统一实现位置 |
|------|-------------|
| 错误处理 | `core/error.js` |
| 数据存储 | `core/storage.js` |
| 浏览器管理 | `core/browser.js` |
| 日志 | `core/index.js` |
| 登录逻辑 | `services/auth-service.js` |

## 文件结构

```
src/
├── core/                       # 核心层
│   ├── index.js               # 统一入口
│   ├── error.js               # 错误处理
│   ├── storage.js             # 安全存储
│   └── browser.js             # 浏览器管理
│
├── services/                   # 服务层
│   ├── index.js               # 统一入口
│   └── auth-service.js        # 认证服务
│
├── platforms/                  # 平台层
│   ├── fanqie/
│   │   ├── adapter.js         # 平台适配器
│   │   └── auth.js            # 认证 API
│   ├── baimeng/
│   │   ├── adapter.js
│   │   └── auth.js
│   └── coze/
│       └── ...
│
└── utils/                      # 工具层（逐步精简）
    └── ...
```

## 使用示例

### 本地 CLI 调用

```javascript
const fanqieAuth = require('./src/platforms/fanqie/auth');

// 列出账号
const accounts = fanqieAuth.listAccounts();

// 登录
const result = await fanqieAuth.restoreLogin(page, '墨水的灰色', {
  targetUrl: 'https://fanqienovel.com/main/writer/book-manage'
});
```

### 机器人远程调用

```javascript
const { authService } = require('./src/services');

// 检查账号状态
const status = authService.checkAccount('fanqie', '墨水的灰色');

// 登录（机器人需要传入 page）
const result = await authService.login({
  platform: 'fanqie',
  userName: '墨水的灰色',
  targetUrl: 'https://fanqienovel.com/main/writer/book-manage',
  page: robotPage,
});
```

### 添加新平台

1. 创建适配器 `src/platforms/new-platform/adapter.js`:
```javascript
const newPlatformAdapter = {
  name: '新平台',
  homeUrl: 'https://example.com',
  domains: ['example.com'],
  
  async checkLogin(page) {
    // 实现登录检测
  },
  
  async restore(page, data) {
    // 实现登录恢复
  },
};

module.exports = newPlatformAdapter;
```

2. 注册平台 `src/services/index.js`:
```javascript
registerPlatform('new-platform', require('../platforms/new-platform/adapter'));
```

3. 创建 API `src/platforms/new-platform/auth.js`:
```javascript
const { authService } = require('../../services');

function listAccounts() {
  return authService.listAccounts('new-platform');
}

// ... 其他方法

module.exports = { listAccounts, ... };
```

## 常见问题

### Q: 机器人调用时登录失败？

A: 确保机器人传入 `page` 参数：
```javascript
const result = await authService.login({
  platform: 'fanqie',
  userName: '用户名',
  page: robotPage,  // 重要！
});
```

### Q: 数据损坏如何恢复？

A: 核心存储模块会自动备份，在 `cookies-accounts/.backups/` 目录中找到最新备份。

### Q: 浏览器锁冲突？

A: 核心浏览器模块会自动检测死锁并清理：
```javascript
// 强制清理锁
const { browserManager } = require('./src/core');
browserManager.release('fanqie-用户名');
```
