# 备份系统使用指南

## 一、概述

本文档说明如何使用备份系统保护数据安全。

### 备份策略

遵循 Gitee 企业级备份规范，采用**多级保留策略**：

| 保留级别 | 时间范围 | 保留数量 |
|---------|---------|---------|
| 每日备份 | 最近7天 | 每天1份 |
| 每周备份 | 最近4周 | 每周1份 |
| 每月备份 | 最近12月 | 每月1份 |

### 备份内容

| 内容 | 优先级 | 说明 |
|-----|-------|------|
| 章节原始内容 | 🔴 critical | 最重要的数据，必须备份 |
| 润色结果 | 🟠 high | 润色后的内容 |
| 配置文件 | 🟡 normal | 项目配置 |
| 知识库 | 🟡 normal | 经验文档 |
| 调试日志 | 🟢 low | DEBUG_LOG.md |

## 二、使用方法

### 2.1 手动备份

```bash
cd workspace/projects/novel-sync

# 创建备份
node scripts/backup.js

# 输出示例：
# 📦 开始备份 - v20260314_020000
# 📁 备份 chapters...
#   ✅ 第1章.json (3.12 KB)
#   ✅ 第2章.json (2.39 KB)
# ✅ 备份完成: v20260314_020000
```

### 2.2 列出所有备份

```bash
node scripts/restore.js --list

# 输出示例：
# 📋 备份列表
# 版本              | 时间                 | 触发方式       | 文件数 | 大小
# v20260314_020000 | 2026/3/14 02:00:00  | manual        |     25 | 1.25 MB
# v20260313_180000 | 2026/3/13 18:00:00  | before-polish |     24 | 1.20 MB
```

### 2.3 恢复数据

```bash
# 恢复最新备份
node scripts/restore.js --latest

# 恢复指定版本
node scripts/restore.js v20260314_020000

# 只恢复章节
node scripts/restore.js v20260314 --chapters

# 只恢复配置
node scripts/restore.js v20260314 --config
```

### 2.4 自动备份

润色脚本会自动触发备份：

```bash
# 润色前自动备份
node tasks/baimeng/polish-and-replace.js "作品名" 1

# 跳过备份（不推荐）
node tasks/baimeng/polish-and-replace.js "作品名" 1 --no-backup
```

## 三、目录结构

```
backups/
├── v20260314_020000/          # 版本目录
│   ├── manifest.json          # 备份清单（记录所有文件信息）
│   ├── chapters/              # 章节备份
│   │   ├── 第1章.json
│   │   └── 第2章.json
│   ├── polish-results/        # 润色结果备份
│   ├── config/                # 配置文件备份
│   └── knowledge/             # 知识库备份
├── v20260313_180000/
└── backup-index.json          # 备份索引（快速查找）
```

## 四、备份清单格式

`manifest.json` 记录每次备份的详细信息：

```json
{
  "version": "v20260314_020000",
  "timestamp": "2026-03-14T02:00:00.000Z",
  "trigger": "before-polish",
  "files": [
    {
      "name": "chapters/第1章.json",
      "path": "chapters/第1章.json",
      "size": 3120,
      "checksum": "a1b2c3d4..."
    }
  ],
  "stats": {
    "totalFiles": 25,
    "totalSize": 1310720,
    "successCount": 25,
    "failedCount": 0
  }
}
```

## 五、恢复流程

**重要**：恢复前会自动备份当前状态，防止误操作。

```
1. 选择要恢复的版本
2. 自动备份当前状态
3. 恢复文件
4. 校验完整性
5. 完成恢复
```

## 六、故障恢复案例

### 案例1：润色结果异常

**场景**：润色后内容被替换为占位符

**恢复步骤**：
```bash
# 1. 查看备份列表
node scripts/restore.js --list

# 2. 恢复最近的备份（润色前的备份）
node scripts/restore.js --latest --chapters

# 3. 重新润色
rm /tmp/polish-result-*.json
node tasks/baimeng/polish-and-replace.js "作品名" 1
```

### 案例2：配置丢失

**场景**：误删配置文件

**恢复步骤**：
```bash
# 从最新备份恢复配置
node scripts/restore.js --latest --config
```

### 案例3：批量操作失败

**场景**：批量润色多个章节时中途失败

**恢复步骤**：
```bash
# 1. 查看失败前的备份
node scripts/restore.js --list

# 2. 恢复失败前的状态
node scripts/restore.js v20260313_180000

# 3. 重新执行（从失败的章节继续）
node tasks/baimeng/polish-and-replace.js "作品名" 5
```

## 七、最佳实践

### 7.1 定期手动备份

```bash
# 每天开始工作前
node scripts/backup.js

# 重要操作前
node scripts/backup.js --before-batch
```

### 7.2 验证备份完整性

```bash
# 检查备份是否完整
ls -la backups/v20260314_020000/
cat backups/v20260314_020000/manifest.json
```

### 7.3 异地备份

定期将备份目录复制到其他位置：

```bash
# 复制到外部存储
cp -r backups/ /external-storage/novel-sync-backups/

# 或使用 rsync
rsync -av backups/ user@remote:/backup/novel-sync/
```

## 八、配置说明

编辑 `backup.config.js` 可自定义备份策略：

```javascript
module.exports = {
  // 备份目录
  backupDir: 'backups',
  
  // 保留策略
  retention: {
    daily: 7,      // 最近7天
    weekly: 28,    // 最近4周
    monthly: 365   // 最近12月
  },
  
  // 备份内容
  backupTargets: {
    chapters: { enabled: true, priority: 'critical' },
    // ...
  },
  
  // 自动备份触发
  autoBackup: {
    beforePolish: true,   // 润色前备份
    beforeBatch: true,    // 批量操作前备份
    afterConfigChange: true  // 配置变更后备份
  }
};
```

## 九、常见问题

### Q1: 备份会占用多少空间？

**A**: 每个备份大约占用 1-2 MB（取决于章节数量）。按保留策略，最多保留约 20-30 个备份，总空间约 30-50 MB。

### Q2: 备份会影响润色速度吗？

**A**: 备份通常在 1-2 秒内完成，对润色速度影响极小。

### Q3: 如何完全禁用自动备份？

**A**: 不推荐禁用。如确需禁用，可在 `backup.config.js` 中设置：

```javascript
autoBackup: {
  beforePolish: false,
  beforeBatch: false,
  afterConfigChange: false
}
```

或在命令中使用 `--no-backup` 参数。

### Q4: 备份失败怎么办？

**A**: 
1. 检查磁盘空间：`df -h`
2. 检查权限：`ls -la backups/`
3. 查看错误日志：备份会输出详细错误信息

---

**相关文档**：
- [润色流程](../knowledge/baimeng/polish-replace-workflow.md)
- [调试日志](../DEBUG_LOG.md)
- [项目规范](../CODING_STANDARDS.md)
