# 项目架构文档

> 全面优化的模块化架构

---

## 目录结构

```
novel-sync/
├── src/
│   ├── config.js              # 统一配置管理
│   ├── platforms/
│   │   ├── base/              # 基类模块
│   │   │   ├── browser.js     # 浏览器基类
│   │   │   ├── auth.js        # 认证基类
│   │   │   ├── element.js     # 元素操作基类
│   │   │   └── index.js       # 导出
│   │   ├── baimeng/           # 白梦写作平台
│   │   │   ├── platform.js    # 平台管理器（新）
│   │   │   ├── browser.js     # 浏览器操作
│   │   │   ├── auth.js        # 登录恢复
│   │   │   ├── sidebar.js     # 侧边栏操作
│   │   │   ├── editor.js      # 编辑器操作
│   │   │   ├── modify-card.js # 修改内容卡片
│   │   │   └── verify.js      # 验证逻辑
│   │   └── coze/              # Coze 扣子编程平台（新）
│   │       └── index.js       # 平台管理器
│   └── utils/
│       ├── logger.js          # 日志记录系统（新）
│       ├── retry.js           # 重试机制（新）
│       ├── progress.js        # 进度持久化（新）
│       ├── scheduler.js       # 定时任务（新）
│       ├── account-manager.js # 多账号管理（新）
│       └── task-runner.js     # 任务运行器
├── tasks/
│   ├── baimeng/               # 白梦写作任务脚本
│   └── coze/                  # Coze 任务脚本
├── tests/
│   └── runner.js              # 测试框架（新）
└── scripts/                   # 工具脚本
```

---

## 核心模块

### 1. 统一配置管理 (`src/config.js`)

集中管理所有配置，支持运行时修改。

```javascript
const config = require('./src/config');

// 获取平台配置
const baimeng = config.getSiteConfig('baimeng');
console.log(baimeng.url);
console.log(baimeng.getBrowserDir(1));

// 获取全局配置
const timeout = config.getGlobalConfig('defaultTimeout');

// 设置配置
config.setGlobalConfig('logLevel', 'debug');
```

### 2. 基类模块 (`src/platforms/base/`)

提供平台模块的基础能力。

```javascript
const { BrowserBase, AuthBase, ElementBase } = require('./src/platforms/base');

class MyPlatformBrowser extends BrowserBase {
  constructor(options) {
    super('myplatform', options);
  }
}
```

### 3. 日志记录系统 (`src/utils/logger.js`)

统一的日志输出，支持文件存储和终端彩色输出。

```javascript
const logger = require('./src/utils/logger');

const log = logger.create('my-task');
log.info('开始执行');
log.success('执行成功');
log.error('执行失败', error);
```

### 4. 重试机制 (`src/utils/retry.js`)

自动重试失败的操作。

```javascript
const { retry } = require('./src/utils/retry');

const result = await retry(async () => {
  return await someAsyncOperation();
}, { maxRetries: 3, delay: 2000 });
```

### 5. 进度持久化 (`src/utils/progress.js`)

支持长时间任务的断点续传。

```javascript
const progress = require('./src/utils/progress');

await progress.create('my-task').run({
  'step1': async (data) => { return { count: 10 }; },
  'step2': async (data) => { return { processed: 10 }; },
  'finish': async (data) => { /* 完成 */ },
});
```

### 6. 定时任务 (`src/utils/scheduler.js`)

支持 cron 表达式的定时任务。

```javascript
const scheduler = require('./src/utils/scheduler');

scheduler.schedule('0 2 * * *', async () => {
  console.log('每天凌晨 2 点执行');
});
```

### 7. 多账号管理 (`src/utils/account-manager.js`)

支持账号轮换和负载均衡。

```javascript
const { AccountManager } = require('./src/utils/account-manager');

const manager = new AccountManager('baimeng');
const account = manager.getNextAccount('round-robin');

await manager.withAccount(async (accountId) => {
  // 使用账号执行任务
});
```

---

## 平台使用示例

### 白梦写作平台

```javascript
const { BaimengPlatform } = require('./src/platforms/baimeng/platform');

async function main() {
  const platform = new BaimengPlatform({ accountId: 1 });
  
  await platform.init();           // 初始化
  await platform.ensureLogin();    // 确保登录
  await platform.gotoEditor();     // 进入编辑器
  
  const found = await platform.findChapter('66');  // 查找章节
  const content = await platform.getContent();     // 获取内容
  
  await platform.close();
}
```

### Coze 扣子编程平台

```javascript
const { CozePlatform } = require('./src/platforms/coze');

async function main() {
  const platform = new CozePlatform({ accountId: 1 });
  
  await platform.init();
  await platform.ensureLogin();
  await platform.gotoCodeSite();   // 进入扣子编程
  
  const projects = await platform.getProjects();
  
  await platform.close();
}
```

---

## 测试框架

```javascript
const { runAllTests } = require('./tests/runner');

await runAllTests([
  {
    name: '配置检查',
    script: 'scripts/check-compliance.js',
    timeout: 30000,
  },
]);
```

---

## 迁移指南

### 从旧模块迁移

旧代码：
```javascript
const browser = require('./src/platforms/baimeng/browser');
const { browser: b, page } = await browser.launch();
```

新代码：
```javascript
const { BaimengPlatform } = require('./src/platforms/baimeng/platform');
const platform = new BaimengPlatform();
await platform.init();
// platform.browser.page 可用
```

### 兼容性

新模块完全兼容旧模块的 API，可以逐步迁移：

```javascript
// 旧方式仍然可用
const sidebar = require('./src/platforms/baimeng/sidebar');
await sidebar.findChapter(page, '66');

// 新方式推荐
const platform = new BaimengPlatform();
await platform.findChapter('66');
```
