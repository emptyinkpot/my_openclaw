# novel-sync 脚本分类规范

> **核心原则**：分类清晰、职责单一、易于维护

---

## 一、目录结构

```
workspace/projects/novel-sync/
│
├── src/                          # 📦 基础模块（不直接执行）
│   ├── platforms/                # 平台模块
│   │   ├── baimeng/              # 白梦写作
│   │   │   ├── auth.js           #   - 登录恢复
│   │   │   ├── browser.js        #   - 浏览器启动
│   │   │   ├── sidebar.js        #   - 侧边栏操作
│   │   │   ├── content.js        #   - 内容操作
│   │   │   ├── copy.js           #   - 复制操作
│   │   │   ├── works.js          #   - 作品操作
│   │   │   ├── editor.js         #   - 编辑器操作 ⭐新增
│   │   │   ├── modify-card.js    #   - 修改内容卡片 ⭐新增
│   │   │   └── verify.js         #   - 验证逻辑 ⭐新增
│   │   └── coze/                 # Coze（待创建）
│   ├── tasks/                    # 任务定义
│   └── utils/                    # 工具函数
│
├── tasks/                        # 🎯 任务脚本（复杂脚本）
│   ├── baimeng/                  # 白梦写作任务
│   │   ├── replace-content.js    #   - 替换正文 ⭐⭐⭐⭐
│   │   ├── chapter-finder.js     #   - 章节查找器 ⭐⭐⭐
│   │   ├── copy-chapter.js       #   - 复制章节 ⭐⭐⭐
│   │   └── open-chapter.js       #   - 打开章节 ⭐⭐
│   └── coze/                     # Coze 任务
│       ├── open-coze.js          #   - 打开主站 ⭐
│       ├── coze-programming.js   #   - 扣子编程 ⭐⭐
│       └── coze-project-manage.js #   - 项目管理 ⭐⭐⭐
│
├── probes/                       # 🔍 探测脚本（临时探索）
│   ├── explore-coze.js           # 探测 Coze 结构
│   ├── explore-modify-card.js    # 探测修改卡片
│   ├── test-chapter-match.js     # 测试章节匹配
│   ├── test-dialog-scroll.js     # 测试对话滚动
│   └── test-modify-card.js       # 测试修改卡片
│
├── scripts/                      # 🛠️ 工具脚本（开发辅助）
│   ├── analyze.js                # 分析页面结构
│   ├── benchmark.js              # 性能测试
│   ├── check-compliance.js       # 规范检查
│   ├── probe-page.js             # 页面探测
│   └── query-knowledge.js        # 知识库查询
│
├── docs/                         # 📄 文档
│   └── ...
│
└── knowledge/                    # 📚 知识库（项目外）
    ├── baimeng/
    ├── coze/
    └── ...
```

---

## 二、分类定义

### 2.1 基础模块 (src/platforms/)

| 特征 | 说明 |
|------|------|
| **职责** | 单一功能的可复用模块 |
| **执行** | 不直接执行，被其他脚本调用 |
| **导出** | 导出函数/类供其他模块使用 |
| **示例** | `auth.js`, `sidebar.js`, `copy.js` |

```javascript
// src/platforms/baimeng/sidebar.js
// ✓ 正确：导出函数
module.exports = {
  findChapter: async (page, title) => { ... },
  scrollToTop: async (page) => { ... }
};

// ✗ 错误：直接执行
runTask('章节查找', async () => { ... });
```

### 2.2 任务脚本

| 特征 | 说明 |
|------|------|
| **职责** | 组合多个操作完成复杂任务 |
| **执行** | 可直接执行 `node tasks/xxx.js` |
| **复杂度** | ⭐⭐ 及以上，至少组合 2 个基础模块 |
| **命名** | 动词+名词，如 `replace-content.js` |

```javascript
// tasks/baimeng/replace-content.js
// ✓ 正确：组合多个模块
const baimeng = require('../../src/platforms/baimeng');

runTask('替换正文', async () => {
  await baimeng.browser.launch();
  await baimeng.auth.restoreLogin();
  await baimeng.sidebar.findChapter();
  // ... 更多操作
});
```

### 2.3 探测脚本

| 特征 | 说明 |
|------|------|
| **职责** | 探索页面结构、验证功能 |
| **执行** | 临时性，验证后可删除 |
| **命名** | `explore-*.js` 或 `test-*.js` |
| **生命周期** | 短期，完成后归档或删除 |

### 2.4 工具脚本

| 特征 | 说明 |
|------|------|
| **职责** | 开发辅助、检查、分析 |
| **执行** | 开发时使用，不影响业务流程 |
| **示例** | `check-compliance.js`, `analyze.js` |

---

## 三、复杂度分级

| 级别 | 定义 | 示例 |
|------|------|------|
| ⭐ | 单一操作，无组合 | `open-coze.js` |
| ⭐⭐ | 2-3步，简单组合 | `open-chapter.js` |
| ⭐⭐⭐ | 4-6步，有分支逻辑 | `chapter-finder.js`, `copy-chapter.js` |
| ⭐⭐⭐⭐ | 7+步，有验证逻辑 | `replace-content.js` |
| ⭐⭐⭐⭐⭐ | 完整工作流，多平台协作 | （待创建） |

---

## 四、添加新脚本流程

### Step 1: 确定分类

```
问题1: 是否可复用？
  └─ 是 → src/platforms/ 基础模块
  └─ 否 → 继续

问题2: 是否组合多个操作？
  └─ 是 → tasks/ 任务脚本
  └─ 否 → 继续

问题3: 是否临时探索/测试？
  └─ 是 → probes/ 探测脚本
  └─ 否 → scripts/ 工具脚本
```

### Step 2: 选择目录

```
基础模块 → src/platforms/{平台}/
任务脚本 → tasks/{平台}/
探测脚本 → probes/
工具脚本 → scripts/
```

### Step 3: 命名规范

```
基础模块: 功能名.js（如 sidebar.js, auth.js）
任务脚本: 动词-名词.js（如 replace-content.js, copy-chapter.js）
探测脚本: explore-对象.js 或 test-功能.js
工具脚本: 功能名.js（如 analyze.js, check-compliance.js）
```

---

## 五、迁移计划

### 当前根目录脚本分类

| 脚本 | 分类 | 目标位置 |
|------|------|----------|
| `replace-content.js` | 任务脚本 | `tasks/baimeng/replace-content.js` |
| `baimeng-chapter-finder.js` | 任务脚本 | `tasks/baimeng/chapter-finder.js` |
| `baimeng-copy.js` | 任务脚本 | `tasks/baimeng/copy-chapter.js` |
| `open-chapter.js` | 任务脚本 | `tasks/baimeng/open-chapter.js` |
| `open-coze.js` | 任务脚本 | `tasks/coze/open-coze.js` |
| `coze-programming.js` | 任务脚本 | `tasks/coze/programming.js` |
| `coze-project-manage.js` | 任务脚本 | `tasks/coze/project-manage.js` |
| `coze-click-programming.js` | 探测脚本 | `probes/explore-coze-click.js` |
| `coze-sidebar-programming.js` | 探测脚本 | `probes/explore-coze-sidebar.js` |
| `explore-coze.js` | 探测脚本 | `probes/explore-coze.js` |
| `explore-modify-card.js` | 探测脚本 | `probes/explore-modify-card.js` |
| `test-*.js` | 探测脚本 | `probes/test-*.js` |
| `save-coze-login.js` | 任务脚本 | `tasks/coze/save-login.js` |

---

## 六、规范检查

使用 `scripts/check-compliance.js` 检查脚本分类：

```bash
# 检查单个脚本
node scripts/check-compliance.js tasks/baimeng/replace-content.js

# 检查所有脚本
node scripts/check-compliance.js --all
```

检查项：
- [ ] 是否在正确的目录
- [ ] 是否符合命名规范
- [ ] 是否使用 `runTask()` 入口（任务脚本）
- [ ] 是否有清晰的注释说明
