# 模块 API 参考

> 所有模块的详细 API 文档

---

## 配置模块 (config)

### 方法

| 方法 | 参数 | 返回 | 说明 |
|------|------|------|------|
| `getSiteConfig(site)` | site: 平台名 | Object | 获取平台配置 |
| `getGlobalConfig(key, default)` | key, default | any | 获取全局配置 |
| `setGlobalConfig(key, value)` | key, value | void | 设置全局配置 |
| `loadUserConfig(path)` | path | void | 加载用户配置 |
| `exportConfig()` | - | Object | 导出当前配置 |

### 平台配置结构

```javascript
{
  name: '平台名称',
  url: 'https://example.com',
  urls: { home: '...', editor: '...' },
  getBrowserDir(accountId),
  getBackupFile(accountId),
  selectors: { ... },
  timeout: { ... }
}
```

---

## 日志模块 (logger)

### 创建日志器

```javascript
const log = logger.create('namespace');
```

### 日志方法

| 方法 | 说明 |
|------|------|
| `debug(message, data?)` | 调试日志 |
| `info(message, data?)` | 信息日志 |
| `success(message, data?)` | 成功日志 |
| `warn(message, data?)` | 警告日志 |
| `error(message, error?)` | 错误日志 |
| `taskStart(name)` | 任务开始 |
| `taskEnd(name, startTime)` | 任务结束 |
| `separator(char, length)` | 分隔线 |
| `title(text)` | 标题 |

### 全局配置

```javascript
logger.setGlobalConfig({
  level: 'debug',
  logDir: '/tmp/logs',
  enableFile: true,
  enableConsole: true,
});
```

---

## 重试模块 (retry)

### retry(fn, options)

```javascript
await retry(async () => {
  return await someOperation();
}, {
  maxRetries: 3,
  delay: 2000,
  backoff: 'linear', // linear | exponential | none
  onRetry: (error, attempt, delay) => {},
  onSuccess: (result, attempt) => {},
  onFinalError: (error, attempt) => {},
});
```

### batchRetry(items, fn, options)

```javascript
const results = await batchRetry(items, async (item, index) => {
  return await processItem(item);
}, { stopOnError: false });

// results: { success: [...], failed: [...] }
```

### withTimeout(promise, timeout, message)

```javascript
const result = await withTimeout(
  someAsyncOperation(),
  30000,
  '操作超时'
);
```

---

## 进度模块 (progress)

### 创建进度管理器

```javascript
const progress = require('./src/utils/progress').create('task-name');
```

### 方法

| 方法 | 说明 |
|------|------|
| `save(step, data)` | 保存进度 |
| `load()` | 加载进度 |
| `hasProgress()` | 检查是否有进度 |
| `clear()` | 清除进度 |
| `run(steps, options)` | 执行任务（支持断点续传） |

### 示例

```javascript
await progress.run({
  'init': async (data) => { return { count: 10 }; },
  'process': async (data) => { return { processed: 10 }; },
  'finish': async (data) => { /* 完成 */ },
});
```

---

## 定时任务模块 (scheduler)

### schedule(cron, task, options)

```javascript
const taskId = scheduler.schedule('0 2 * * *', async () => {
  // 每天 2:00 执行
}, { name: 'daily-backup', timezone: 'Asia/Shanghai' });
```

### 管理

| 方法 | 说明 |
|------|------|
| `cancel(taskId)` | 取消任务 |
| `pause(taskId)` | 暂停任务 |
| `resume(taskId)` | 恢复任务 |
| `list()` | 列出所有任务 |
| `stopAll()` | 停止所有任务 |

### 预设任务

```javascript
scheduler.presets.dailyBackup('baimeng', 1, 2);
scheduler.presets.hourlyCheck('baimeng', 1);
```

---

## 账号管理模块 (account-manager)

### 创建管理器

```javascript
const { AccountManager } = require('./src/utils/account-manager');
const manager = new AccountManager('baimeng');
```

### 方法

| 方法 | 说明 |
|------|------|
| `getAllAccounts()` | 获取所有账号 |
| `getNextAccount(mode)` | 获取下一个可用账号 |
| `setBusy(accountId)` | 标记忙碌 |
| `setAvailable(accountId)` | 标记可用 |
| `setError(accountId, error)` | 标记错误 |
| `setCooldown(accountId, duration)` | 设置冷却 |
| `getStatusReport()` | 获取状态报告 |
| `withAccount(taskFn, options)` | 使用账号执行任务 |

### 账号选择模式

- `round-robin` - 轮换
- `random` - 随机
- `least-used` - 最少使用

### 示例

```javascript
await manager.withAccount(async (accountId) => {
  // 自动选择可用账号
  // 自动处理忙碌/错误状态
}, { mode: 'round-robin', maxRetries: 3 });
```

---

## 基类模块 (platforms/base)

### BrowserBase

```javascript
class MyBrowser extends BrowserBase {
  constructor(options) {
    super('myplatform', options);
  }
}

// 方法
await browser.launch();
await browser.close();
await browser.goto(url);
await browser.wait(ms);
await browser.screenshot(name);
```

### AuthBase

```javascript
class MyAuth extends AuthBase {
  async checkLogin() {
    // 实现登录检查
    return { isLoggedIn: true, message: '已登录' };
  }
}

// 方法
await auth.restoreLogin();
await auth.checkLogin();
await auth.backupLogin();
await auth.ensureLoggedIn();
```

### ElementBase

```javascript
class MyElement extends ElementBase {
  // 继承所有通用方法
}

// 方法
await element.waitFor(selector);
await element.click(selector);
await element.type(selector, text);
await element.getText(selector);
await element.isVisible(selector);
await element.evaluate(fn, ...args);
```

---

## 平台模块

### BaimengPlatform

```javascript
const { BaimengPlatform } = require('./src/platforms/baimeng/platform');

const platform = new BaimengPlatform({ accountId: 1 });
await platform.init();
await platform.ensureLogin();
await platform.gotoEditor();
await platform.findChapter('66');
await platform.getContent();
await platform.setContent('新内容');
await platform.close();
```

### CozePlatform

```javascript
const { CozePlatform } = require('./src/platforms/coze');

const platform = new CozePlatform({ accountId: 1 });
await platform.init();
await platform.ensureLogin();
await platform.gotoCodeSite();
await platform.gotoProjectManage();
await platform.getProjects();
await platform.close();
```
