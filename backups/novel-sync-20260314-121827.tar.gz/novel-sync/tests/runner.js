/**
 * 脚本测试框架
 * 
 * 提供轻量级的脚本测试能力
 * 
 * @module tests/runner
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { promisify } = require('util');

const execAsync = promisify(exec);
const logger = require('../src/utils/logger');

// 测试结果
const results = {
  passed: [],
  failed: [],
  skipped: [],
};

/**
 * 运行单个测试
 * @param {Object} test - 测试配置
 */
async function runTest(test) {
  const log = logger.create('test');
  const startTime = Date.now();
  
  log.info(`\n${'='.repeat(60)}`);
  log.info(`测试: ${test.name}`);
  log.info(`描述: ${test.description || '无'}`);
  log.info(`${'='.repeat(60)}`);
  
  try {
    // 检查脚本是否存在
    if (!fs.existsSync(test.script)) {
      log.warn(`跳过: 脚本不存在 ${test.script}`);
      results.skipped.push({ ...test, reason: '脚本不存在' });
      return;
    }
    
    // 运行脚本
    const command = `node ${test.script} ${test.args?.join(' ') || ''}`;
    log.info(`执行: ${command}`);
    
    const { stdout, stderr } = await execAsync(command, {
      timeout: test.timeout || 60000,
      cwd: process.cwd(),
    });
    
    const elapsed = Date.now() - startTime;
    
    // 检查输出
    if (test.expectOutput && !stdout.includes(test.expectOutput)) {
      throw new Error(`输出不包含期望内容: ${test.expectOutput}`);
    }
    
    // 检查错误输出
    if (stderr && !test.allowStderr) {
      throw new Error(`脚本有错误输出: ${stderr.substring(0, 200)}`);
    }
    
    log.success(`✅ 通过 (${elapsed}ms)`);
    results.passed.push({ ...test, elapsed, output: stdout });
    
  } catch (error) {
    const elapsed = Date.now() - startTime;
    log.error(`❌ 失败: ${error.message}`);
    results.failed.push({ ...test, elapsed, error: error.message });
  }
}

/**
 * 运行所有测试
 * @param {Array} tests - 测试配置数组
 */
async function runAllTests(tests) {
  const log = logger.create('test-runner');
  
  log.title('脚本测试框架');
  log.info(`共 ${tests.length} 个测试\n`);
  
  const startTime = Date.now();
  
  for (const test of tests) {
    if (test.skip) {
      log.warn(`跳过: ${test.name}`);
      results.skipped.push({ ...test, reason: '手动跳过' });
      continue;
    }
    
    await runTest(test);
  }
  
  const totalElapsed = Date.now() - startTime;
  
  // 输出结果摘要
  log.title('测试结果摘要');
  
  log.success(`通过: ${results.passed.length}`);
  log.error(`失败: ${results.failed.length}`);
  log.warn(`跳过: ${results.skipped.length}`);
  log.info(`总耗时: ${totalElapsed}ms`);
  
  if (results.failed.length > 0) {
    log.title('失败详情');
    results.failed.forEach((test, i) => {
      log.error(`${i + 1}. ${test.name}: ${test.error}`);
    });
  }
  
  return results;
}

/**
 * 快速测试单个脚本
 */
async function quickTest(scriptPath, args = []) {
  return runTest({
    name: path.basename(scriptPath),
    script: scriptPath,
    args,
  });
}

/**
 * 测试配置示例
 */
const sampleTests = [
  {
    name: '白梦写作 - 章节查找',
    description: '测试章节查找功能',
    script: 'tasks/baimeng/baimeng-chapter-finder.js',
    args: ['66'],
    timeout: 60000,
    skip: true, // 需要浏览器，默认跳过
  },
  {
    name: '白梦写作 - 内容替换',
    description: '测试内容替换功能',
    script: 'tasks/baimeng/replace-content.js',
    args: ['66'],
    timeout: 60000,
    skip: true,
  },
  {
    name: '配置检查',
    description: '检查配置文件有效性',
    script: 'scripts/check-compliance.js',
    timeout: 30000,
  },
];

// 导出
module.exports = {
  runTest,
  runAllTests,
  quickTest,
  results,
  sampleTests,
};

// 直接运行
if (require.main === module) {
  runAllTests(sampleTests).catch(console.error);
}
