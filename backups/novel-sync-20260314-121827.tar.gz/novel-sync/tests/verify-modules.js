/**
 * 二级模块验证测试
 * 
 * 验证所有新创建的二级模块功能
 */

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');

console.log('='.repeat(60));
console.log('🧪 二级模块验证测试');
console.log('='.repeat(60));

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`✅ ${name}`);
    passed++;
  } catch (e) {
    console.log(`❌ ${name}`);
    console.log(`   错误: ${e.message}`);
    failed++;
  }
}

// ============================================================
// 1. 测试 file-utils.js
// ============================================================
console.log('\n📦 测试 file-utils.js');

test('导入 file-utils', () => {
  const fileUtils = require(path.join(ROOT, 'src/utils/file-utils'));
  assert(fileUtils.copyDirectory);
  assert(fileUtils.copyFile);
  assert(fileUtils.calculateChecksum);
  assert(fileUtils.formatSize);
  assert(fileUtils.safeWrite);
  assert(fileUtils.safeRead);
});

test('formatSize 格式化文件大小', () => {
  const { formatSize } = require(path.join(ROOT, 'src/utils/file-utils'));
  assert.strictEqual(formatSize(0), '0 B');
  assert.strictEqual(formatSize(1024), '1 KB');
  assert.strictEqual(formatSize(1024 * 1024), '1 MB');
});

test('safeWrite/safeRead 安全读写', () => {
  const { safeWrite, safeRead } = require(path.join(ROOT, 'src/utils/file-utils'));
  const testFile = '/tmp/test-file-utils.json';
  
  const writeResult = safeWrite(testFile, JSON.stringify({ test: 'hello' }));
  assert.strictEqual(writeResult.success, true);
  
  const readResult = safeRead(testFile);
  assert.strictEqual(readResult.success, true);
  
  fs.unlinkSync(testFile);
});

test('calculateChecksum 计算校验和', () => {
  const { safeWrite, calculateChecksum } = require(path.join(ROOT, 'src/utils/file-utils'));
  const testFile = '/tmp/test-checksum.txt';
  
  safeWrite(testFile, 'hello world');
  const checksum = calculateChecksum(testFile);
  
  assert(checksum);
  assert.strictEqual(checksum.length, 32);
  
  fs.unlinkSync(testFile);
});

// ============================================================
// 2. 测试 safe-action.js
// ============================================================
console.log('\n🛡️ 测试 safe-action.js');

test('导入 safe-action', () => {
  const safeAction = require(path.join(ROOT, 'src/utils/safe-action'));
  assert(safeAction.safeClick);
  assert(safeAction.safeInput);
  assert(safeAction.safeWait);
  assert(safeAction.safeNavigate);
  assert(safeAction.waitForText);
});

// ============================================================
// 3. 测试 progress-detector.js
// ============================================================
console.log('\n📊 测试 progress-detector.js');

test('导入 progress-detector', () => {
  const progressDetector = require(path.join(ROOT, 'src/utils/progress-detector'));
  assert(progressDetector.waitForPolishProgress);
  assert(progressDetector.checkTextExists);
  assert(progressDetector.waitForDOMStable);
  assert(progressDetector.checkLoadingState);
});

// ============================================================
// 4. 测试 backup-manager.js
// ============================================================
console.log('\n💾 测试 backup-manager.js');

test('导入 backup-manager', () => {
  const backupManager = require(path.join(ROOT, 'src/utils/backup-manager'));
  assert(backupManager.createBackup);
  assert(backupManager.restoreBackup);
  assert(backupManager.verifyBackup);
  assert(backupManager.cleanupOldBackups);
  assert(backupManager.listBackups);
});

test('listBackups 列出备份', () => {
  const { listBackups } = require(path.join(ROOT, 'src/utils/backup-manager'));
  const backups = listBackups({ backupDir: path.join(ROOT, 'backups') });
  assert(Array.isArray(backups));
});

// ============================================================
// 5. 测试 editor.js 新增函数
// ============================================================
console.log('\n✏️ 测试 editor.js 新增函数');

test('导入 editor 模块', () => {
  const editor = require(path.join(ROOT, 'src/platforms/baimeng/editor'));
  assert(editor.appendContent);
  assert(editor.insertContent);
  assert(editor.replaceText);
  assert(editor.getContent);
  assert(editor.setContent);
  assert(editor.getTitle);
  assert(editor.setTitle);
});

// ============================================================
// 6. 测试 chapter-nav.js
// ============================================================
console.log('\n📖 测试 chapter-nav.js');

test('导入 chapter-nav', () => {
  const chapterNav = require(path.join(ROOT, 'src/platforms/baimeng/chapter-nav'));
  assert(chapterNav.openChapter);
  assert(chapterNav.parseChapterNum);
  assert(chapterNav.chineseToNumber);
});

test('parseChapterNum 解析章节号', () => {
  const { parseChapterNum } = require(path.join(ROOT, 'src/platforms/baimeng/chapter-nav'));
  
  assert.strictEqual(parseChapterNum('66'), 66);
  assert.strictEqual(parseChapterNum('六十六'), 66);
  assert.strictEqual(parseChapterNum('第66章'), 66);
  assert.strictEqual(parseChapterNum('第六十六章'), 66);
  assert.strictEqual(parseChapterNum('一'), 1);
  assert.strictEqual(parseChapterNum('二十'), 20);
});

// ============================================================
// 7. 测试 polish-executor.js
// ============================================================
console.log('\n✨ 测试 polish-executor.js');

test('导入 polish-executor', () => {
  const polishExecutor = require(path.join(ROOT, 'src/platforms/coze/polish-executor'));
  assert(polishExecutor.executePolish);
  assert(polishExecutor.pasteContent);
  assert(polishExecutor.clickPolishButton);
  assert(polishExecutor.waitForCompletion);
  assert(polishExecutor.extractResult);
  assert(polishExecutor.verifyPolishResult);
});

test('verifyPolishResult 验证润色结果', () => {
  const { verifyPolishResult } = require(path.join(ROOT, 'src/platforms/coze/polish-executor'));
  
  const original = '这是一段测试文本，大约五十个字左右，用于测试验证功能是否正常工作。';
  const short = '短';
  
  // 正常情况
  const r1 = verifyPolishResult(original, original, { minRatio: 0.5, maxRatio: 1.5 });
  assert.strictEqual(r1.valid, true);
  
  // 过短
  const r2 = verifyPolishResult(original, short);
  assert.strictEqual(r2.valid, false);
});

// ============================================================
// 8. 测试 result-checker.js
// ============================================================
console.log('\n🔍 测试 result-checker.js');

test('导入 result-checker', () => {
  const resultChecker = require(path.join(ROOT, 'src/utils/result-checker'));
  assert(resultChecker.verifyLength);
  assert(resultChecker.verifyChange);
  assert(resultChecker.detectAnomalies);
  assert(resultChecker.verifyChapterTitle);
  assert(resultChecker.comprehensiveVerify);
});

test('verifyLength 验证长度', () => {
  const { verifyLength } = require(path.join(ROOT, 'src/utils/result-checker'));
  
  // 短文本（默认 minLength = 50）
  const r1 = verifyLength('短文本');
  assert.strictEqual(r1.valid, false);
  
  // 正常长度文本（超过 50 字）
  const longText = '这是一段测试文本，超过五十个字的内容才能通过验证检查，我们需要更多文字才能通过验证。'.repeat(2);
  const r2 = verifyLength(longText);
  assert.strictEqual(r2.valid, true);
  
  // 自定义 minLength
  const r3 = verifyLength('短文本', { minLength: 2 });
  assert.strictEqual(r3.valid, true);
});

test('detectAnomalies 检测异常', () => {
  const { detectAnomalies } = require(path.join(ROOT, 'src/utils/result-checker'));
  
  // 正常内容
  const r1 = detectAnomalies('这是正常的内容，没有问题。');
  assert.strictEqual(r1.valid, true);
  
  // 包含占位符
  const r2 = detectAnomalies('润色结果将显示在这里');
  assert.strictEqual(r2.valid, false);
  
  // 包含工具栏文字
  const r3 = detectAnomalies('章节概要\n正文内容');
  assert.strictEqual(r3.valid, false);
});

// ============================================================
// 9. 测试 args-parser.js
// ============================================================
console.log('\n🔤 测试 args-parser.js');

test('导入 args-parser', () => {
  const argsParser = require(path.join(ROOT, 'src/utils/args-parser'));
  assert(argsParser.parseChapterNum);
  assert(argsParser.parseArgs);
  assert(argsParser.showUsage);
});

test('parseChapterNum 解析章节号', () => {
  const { parseChapterNum } = require(path.join(ROOT, 'src/utils/args-parser'));
  
  assert.strictEqual(parseChapterNum('1'), 1);
  assert.strictEqual(parseChapterNum('第1章'), 1);
  assert.strictEqual(parseChapterNum('第一章'), 1);
  assert.strictEqual(parseChapterNum('一百'), 100);
});

// ============================================================
// 10. 测试模块整合
// ============================================================
console.log('\n📦 测试模块整合');

test('utils/index.js 导出所有模块', () => {
  const utils = require(path.join(ROOT, 'src/utils'));
  
  assert(utils.logger);
  assert(utils.retry);
  assert(utils.progress);
  assert(utils.resultChecker);
  assert(utils.argsParser);
  assert(utils.helper);
  assert(utils.taskRunner);
  assert(utils.fileUtils);
  assert(utils.safeAction);
  assert(utils.progressDetector);
  assert(utils.backupManager);
});

test('baimeng/index.js 导出所有模块', () => {
  const baimeng = require(path.join(ROOT, 'src/platforms/baimeng'));
  
  assert(baimeng.auth);
  assert(baimeng.works);
  assert(baimeng.sidebar);
  assert(baimeng.content);
  assert(baimeng.copy);
  assert(baimeng.browser);
  assert(baimeng.editor);
  assert(baimeng.modifyCard);
  assert(baimeng.verify);
  assert(baimeng.polishResult);
  assert(baimeng.chapterNav);
  assert(baimeng.platform);
});

test('coze/index.js 导出所有模块', () => {
  const coze = require(path.join(ROOT, 'src/platforms/coze'));
  
  assert(coze.polish);
  assert(coze.polishExecutor);
});

// ============================================================
// 总结
// ============================================================
console.log('\n' + '='.repeat(60));
console.log(`📊 测试结果: ${passed} 通过, ${failed} 失败`);
console.log('='.repeat(60));

if (failed > 0) {
  process.exit(1);
} else {
  console.log('✅ 所有测试通过！');
}
