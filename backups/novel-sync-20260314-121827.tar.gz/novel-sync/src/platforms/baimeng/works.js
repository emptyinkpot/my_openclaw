/**
 * 白梦写作 - 作品模块
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

// 使用新的缓存路径（来源：config.PATHS.STORAGE）
const CACHE_FILE = path.join(config.PATHS.STORAGE, 'cache', 'baimeng-works-cache.json');

/**
 * 获取作品列表
 * 来源：baimeng-chapter-finder.js 已验证
 */
async function getWorks(page) {
  // 使用缓存
  if (fs.existsSync(CACHE_FILE)) {
    const cache = JSON.parse(fs.readFileSync(CACHE_FILE, 'utf-8'));
    if (Date.now() - cache.timestamp < 24 * 60 * 60 * 1000) {
      console.log('(使用缓存)');
      return cache.works;
    }
  }
  
  console.log('获取作品列表...');
  await page.goto(config.BAIMENG.urls.library, { timeout: 30000 });
  await page.waitForTimeout(3000);
  
  const works = await page.evaluate(() => {
    const result = [];
    document.querySelectorAll('a[href*="editor"]').forEach(el => {
      const href = el.href || '';
      const match = href.match(/[?&]id=([a-f0-9-]+)/i) || href.match(/\/([a-f0-9-]{36})/i);
      if (match) {
        const titleEl = el.querySelector('[class*="title"], [class*="name"], h2, h3, h4') || el;
        const title = titleEl.innerText?.trim().split('\n')[0];
        if (title && title.length > 0 && title.length < 100) {
          result.push({ id: match[1], title });
        }
      }
    });
    const seen = new Set();
    return result.filter(w => !seen.has(w.id) && seen.add(w.id));
  });
  
  // 保存缓存
  fs.writeFileSync(CACHE_FILE, JSON.stringify({ timestamp: Date.now(), works }, null, 2));
  
  return works;
}

/**
 * 查找作品ID
 */
function findWorkId(works, input) {
  if (input.match(/^[a-f0-9-]{36}$/i)) {
    return input;
  }
  const match = works.find(w => 
    w.title === input || 
    w.title.includes(input) || 
    input.includes(w.title)
  );
  return match?.id;
}

module.exports = { getWorks, findWorkId };
