# 白梦写作模块 (baimeng)

## 功能说明

白梦写作平台的自动化操作模块，支持登录、作品管理、章节操作、内容复制等功能。

## 模块列表

| 模块 | 功能 | 文档 |
|------|------|------|
| auth.js | 登录状态恢复 | [查看](#authjs) |
| works.js | 作品管理 | [查看](#worksjs) |
| sidebar.js | 侧边栏操作 | [查看](#sidebarjs) |
| content.js | 主内容区操作 | [查看](#contentjs) |
| copy.js | 复制功能 | [查看](#copyjs) |
| browser.js | 浏览器管理 | [查看](#browserjs) |

---

## auth.js

### 功能
恢复白梦写作的登录状态

### 导出函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `restoreLogin(page)` | 恢复登录状态 | `page`: Playwright页面对象 | `Promise<boolean>` |

### 使用示例

```javascript
const baimeng = require('./src/platforms/baimeng');
const { browser, page } = await baimeng.browser.launch();
await baimeng.auth.restoreLogin(page);
```

### 关键点
- 必须先访问首页
- 设置 localStorage 后必须 `reload()`
- 等待至少 3 秒

### 来源
- 来源文件：`baimeng-chapter-finder.js`
- 验证状态：✅ 已验证

---

## works.js

### 功能
作品列表获取和查找

### 导出函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `getWorks(page)` | 获取作品列表 | `page`: Playwright页面对象 | `Promise<Array<{id, title}>>` |
| `findWorkId(works, input)` | 查找作品ID | `works`: 作品列表, `input`: 作品名称或ID | `string \| null` |

### 使用示例

```javascript
const works = await baimeng.works.getWorks(page);
const workId = baimeng.works.findWorkId(works, '枪与凋零之花');
```

### 关键点
- 支持缓存 24 小时
- 支持模糊匹配作品名

### 来源
- 来源文件：`baimeng-chapter-finder.js`
- 验证状态：✅ 已验证

---

## sidebar.js

### 功能
侧边栏操作，包括滚动、查找章节

### 导出函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `getPosition(page)` | 获取侧边栏位置 | `page` | `Promise<{x, y} \| null>` |
| `focus(page)` | 点击获取焦点 | `page` | `Promise<boolean>` |
| `scrollToTop(page)` | 滚动到顶部 | `page` | `Promise<boolean>` |
| `findChapter(page, chapterName)` | 查找并点击章节 | `page`, `chapterName` | `Promise<{found, text}>` |

### 使用示例

```javascript
// 查找章节
const result = await baimeng.sidebar.findChapter(page, '第四十二章');
if (result.found) {
  console.log('已打开:', result.text);
}
```

### 关键点
- 滚动前必须点击获取焦点
- 排除带箭头的文件夹
- 滚动步长 80px，间隔 80ms

### 来源
- 来源文件：`baimeng-chapter-finder.js`
- 验证状态：✅ 已验证

---

## content.js

### 功能
主内容区操作

### 导出函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `getPosition(page)` | 获取主内容区位置 | `page` | `Promise<{x, y} \| null>` |
| `focus(page)` | 点击获取焦点 | `page` | `Promise<boolean>` |
| `scrollToBottom(page)` | 滚动到底部 | `page` | `Promise<boolean>` |
| `getContent(page)` | 获取内容文本 | `page` | `Promise<string>` |

### 使用示例

```javascript
await baimeng.content.scrollToBottom(page);
const content = await baimeng.content.getContent(page);
```

### 关键点
- 与侧边栏滚动逻辑一致
- 先点击获取焦点再滚动

### 来源
- 来源文件：`baimeng-copy.js`
- 验证状态：✅ 已验证

---

## copy.js

### 功能
复制章节内容

### 导出函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `clickCopyButton(page)` | 点击复制按钮 | `page` | `Promise<boolean>` |

### 使用示例

```javascript
const copied = await baimeng.copy.clickCopyButton(page);
if (copied) {
  console.log('已复制到剪贴板');
}
```

### 关键点
- 复制按钮在主内容区顶部
- 按钮文本为"复制"

### 来源
- 来源文件：`baimeng-copy.js`
- 验证状态：✅ 已验证

---

## browser.js

### 功能
浏览器启动和管理

### 导出函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `cleanLockFiles()` | 清理锁文件 | 无 | `void` |
| `launch()` | 启动浏览器 | 无 | `Promise<{browser, page}>` |

### 使用示例

```javascript
const { browser, page } = await baimeng.browser.launch();
// 使用后
await browser.close();
```

### 关键点
- 启动前自动清理锁文件
- 使用持久化上下文保存登录状态

### 来源
- 来源文件：`baimeng-chapter-finder.js`
- 验证状态：✅ 已验证

---

## 完整使用示例

```javascript
const baimeng = require('./src/platforms/baimeng');

async function main() {
  // 1. 启动浏览器
  const { browser, page } = await baimeng.browser.launch();
  
  // 2. 恢复登录
  await baimeng.auth.restoreLogin(page);
  
  // 3. 获取作品
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, '枪与凋零之花');
  
  // 4. 进入编辑器
  await page.goto(`https://baimengxiezuo.com/zh-Hans/editor/?id=${workId}`);
  await page.waitForTimeout(8000);
  
  // 5. 查找章节
  await baimeng.sidebar.findChapter(page, '第四十二章');
  
  // 6. 复制内容
  await baimeng.content.scrollToBottom(page);
  await baimeng.copy.clickCopyButton(page);
  
  // 7. 关闭
  await browser.close();
}
```
