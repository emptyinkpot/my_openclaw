/**
 * 白梦写作 - 验证模块
 * 
 * 来源：replace-content.js 已验证逻辑
 * 功能：各种验证操作（章节对应验证、登录验证等）
 */

/**
 * 验证章节对应（侧边栏 vs 修改内容卡片）
 * 来源：replace-content.js Step 5 已验证
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} expectedChapter - 期望的章节标题（如 "第六十六章"）
 * @returns {Promise<{match: boolean, sidebarChapter: string, cardChapter: string, warning?: string}>}
 */
async function verifyChapterMatch(page, expectedChapter) {
  const result = await page.evaluate(() => {
    // 检查侧边栏高亮章节
    const activeItem = document.querySelector('[class*="active"], [class*="selected"]');
    const sidebarChapter = activeItem?.innerText?.match(/第.+章/)?.[0] || '';
    
    // 检查修改内容卡片章节
    const cards = document.querySelectorAll('*');
    let cardChapter = '';
    for (const el of cards) {
      const text = el.innerText || '';
      if (text.match(/修改内容.*\d+字/) && text.length < 500) {
        cardChapter = text.match(/第.+章/)?.[0] || '';
        break;
      }
    }
    
    return { sidebarChapter, cardChapter };
  });
  
  // 判断是否匹配
  const sidebarMatch = result.sidebarChapter.includes(expectedChapter.replace('章', ''));
  const cardMatch = result.cardChapter.includes(expectedChapter.replace('章', ''));
  
  let warning = null;
  if (!cardMatch && result.cardChapter) {
    warning = `卡片章节(${result.cardChapter}) 与目标章节(${expectedChapter}) 可能不对应`;
  }
  
  return {
    match: sidebarMatch && (cardMatch || !result.cardChapter),
    sidebarChapter: result.sidebarChapter,
    cardChapter: result.cardChapter,
    warning
  };
}

/**
 * 验证编辑器内容长度
 * 
 * @param {Page} page - Playwright page 对象
 * @param {number} minLength - 最小长度
 * @returns {Promise<{valid: boolean, length: number}>}
 */
async function verifyContentLength(page, minLength = 0) {
  const content = await page.evaluate(() => {
    const editor = document.querySelector('.ProseMirror') || 
                   document.querySelector('[contenteditable="true"]');
    return editor?.innerText || '';
  });
  
  return {
    valid: content.length >= minLength,
    length: content.length
  };
}

/**
 * 验证修改内容卡片存在
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{exists: boolean, wordCount?: number}>}
 */
async function verifyModifyCardExists(page) {
  const result = await page.evaluate(() => {
    const allElements = document.querySelectorAll('*');
    for (const el of allElements) {
      const text = el.innerText || '';
      const match = text.match(/修改内容.*?(\d+)字/);
      if (match && text.length < 500) {
        return {
          exists: true,
          wordCount: parseInt(match[1]) || 0
        };
      }
    }
    return { exists: false };
  });
  
  return result;
}

/**
 * 验证作品是否打开
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{isOpen: boolean, workTitle?: string}>}
 */
async function verifyWorkOpen(page) {
  const result = await page.evaluate(() => {
    // 检查是否在编辑器页面
    const editor = document.querySelector('.ProseMirror') || 
                   document.querySelector('[contenteditable="true"]');
    const sidebar = document.querySelector('[class*="sidebar"]');
    
    return {
      isOpen: !!(editor && sidebar),
      // 可以扩展获取作品标题
    };
  });
  
  return result;
}

module.exports = {
  verifyChapterMatch,
  verifyContentLength,
  verifyModifyCardExists,
  verifyWorkOpen
};
