/**
 * 白梦写作 - 修改内容卡片模块
 * 
 * 来源：replace-content.js 已验证逻辑
 * 功能：修改内容卡片操作（查找、悬停、替换正文、复制）
 */

/**
 * 查找修改内容卡片
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{found: boolean, element?: object, chapter?: string, wordCount?: number}>}
 */
async function findCard(page) {
  const result = await page.evaluate(() => {
    const allElements = document.querySelectorAll('*');
    
    for (const el of allElements) {
      const text = el.innerText || '';
      // 匹配 "修改内容 XXX字" 格式
      const match = text.match(/修改内容.*?(\d+)字/);
      if (match && text.length < 500) {
        // 提取章节号
        const chapterMatch = text.match(/第[零一二三四五六七八九十百千万\d]+章/);
        
        return {
          found: true,
          chapter: chapterMatch ? chapterMatch[0] : '',
          wordCount: parseInt(match[1]) || 0,
          text: text.substring(0, 200)
        };
      }
    }
    
    return { found: false };
  });
  
  return result;
}

/**
 * 悬停修改内容卡片（显示操作按钮）
 * 来源：replace-content.js Step 7 已验证
 * 
 * @param {Page} page - Playwright page 对象
 */
async function hoverCard(page) {
  await page.evaluate(() => {
    const allElements = document.querySelectorAll('*');
    for (const el of allElements) {
      const text = el.innerText || '';
      if (text.match(/修改内容.*\d+字/) && text.length < 500) {
        el.dispatchEvent(new MouseEvent('mouseenter', { 
          bubbles: true, 
          cancelable: true, 
          view: window 
        }));
        break;
      }
    }
  });
  
  // 等待按钮显示
  await page.waitForTimeout(500);
}

/**
 * 点击替换正文按钮
 * 来源：replace-content.js Step 7 已验证
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{success: boolean, text?: string}>}
 */
async function clickReplace(page) {
  const result = await page.evaluate(() => {
    // 方法1: 查找包含"替换正文"的按钮
    const buttons = document.querySelectorAll('button, [role="button"]');
    for (const btn of buttons) {
      const text = btn.innerText || '';
      if (text.includes('替换') && (text.includes('正文') || text.length < 10)) {
        btn.click();
        return { success: true, method: 'button', text: text };
      }
    }
    
    // 方法2: 查找可点击元素
    const clickables = document.querySelectorAll('[class*="cursor-pointer"], [onclick]');
    for (const el of clickables) {
      const text = el.innerText || '';
      if (text.includes('替换')) {
        el.click();
        return { success: true, method: 'clickable', text: text.substring(0, 50) };
      }
    }
    
    return { success: false };
  });
  
  return result;
}

/**
 * 点击复制按钮（修改内容卡片上的）
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{success: boolean}>}
 */
async function clickCopy(page) {
  const result = await page.evaluate(() => {
    const buttons = document.querySelectorAll('button, [role="button"]');
    for (const btn of buttons) {
      const text = btn.innerText || '';
      if (text.trim() === '复制') {
        btn.click();
        return { success: true };
      }
    }
    return { success: false };
  });
  
  return result;
}

/**
 * 完整的替换正文流程
 * 组合：悬停 → 点击替换
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{success: boolean, message?: string}>}
 */
async function replaceContent(page) {
  // 1. 悬停显示按钮
  await hoverCard(page);
  
  // 2. 点击替换正文
  const clicked = await clickReplace(page);
  
  if (clicked.success) {
    return { 
      success: true, 
      message: `已点击: ${clicked.text}` 
    };
  } else {
    return { 
      success: false, 
      message: '未找到替换按钮' 
    };
  }
}

/**
 * 获取卡片中的章节内容
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<string>} 卡片中的正文内容
 */
async function getCardContent(page) {
  const content = await page.evaluate(() => {
    const allElements = document.querySelectorAll('*');
    for (const el of allElements) {
      const text = el.innerText || '';
      if (text.match(/修改内容.*\d+字/) && text.length < 500) {
        // 获取卡片内的正文（排除标题行）
        const lines = text.split('\n');
        // 跳过标题行，获取正文
        const contentLines = lines.slice(1);
        return contentLines.join('\n').trim();
      }
    }
    return '';
  });
  
  return content;
}

module.exports = {
  findCard,
  hoverCard,
  clickReplace,
  clickCopy,
  replaceContent,
  getCardContent
};
