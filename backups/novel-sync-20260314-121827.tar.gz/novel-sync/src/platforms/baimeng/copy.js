/**
 * 白梦写作 - 复制模块
 * 
 * 功能：
 * 1. 点击复制按钮
 * 2. 保存内容到文件（持久化剪贴板）
 * 3. 从文件读取内容
 * 4. 粘贴到目标输入框
 */

const fs = require('fs');
const path = require('path');

// 持久化剪贴板目录
const CLIPBOARD_DIR = path.join(__dirname, '../../../storage/clipboard');

/**
 * 确保剪贴板目录存在
 */
function ensureDir() {
  if (!fs.existsSync(CLIPBOARD_DIR)) {
    fs.mkdirSync(CLIPBOARD_DIR, { recursive: true });
  }
}

/**
 * 点击复制按钮
 * 来源：baimeng-chapter-finder.js 已验证
 */
async function clickCopyButton(page) {
  return page.evaluate(() => {
    const buttons = document.querySelectorAll('button');
    for (const btn of buttons) {
      const text = btn.innerText?.trim();
      if (text === '复制') {
        btn.click();
        return true;
      }
    }
    return false;
  });
}

/**
 * 保存内容到文件（持久化剪贴板）
 * 
 * @param {string} content - 要保存的内容
 * @param {string} name - 文件名（默认 'latest'）
 * @returns {string} 保存的文件路径
 */
function saveToFile(content, name = 'latest') {
  ensureDir();
  
  const filePath = path.join(CLIPBOARD_DIR, `${name}.txt`);
  const metaPath = path.join(CLIPBOARD_DIR, `${name}.meta.json`);
  
  // 保存内容
  fs.writeFileSync(filePath, content, 'utf-8');
  
  // 保存元数据
  fs.writeFileSync(metaPath, JSON.stringify({
    timestamp: new Date().toISOString(),
    length: content.length,
    preview: content.substring(0, 100)
  }, null, 2), 'utf-8');
  
  console.log(`[剪贴板] 已保存: ${filePath} (${content.length} 字)`);
  return filePath;
}

/**
 * 从文件读取内容
 * 
 * @param {string} name - 文件名（默认 'latest'）
 * @returns {string|null} 文件内容，不存在返回 null
 */
function loadFromFile(name = 'latest') {
  const filePath = path.join(CLIPBOARD_DIR, `${name}.txt`);
  
  if (!fs.existsSync(filePath)) {
    console.log(`[剪贴板] 文件不存在: ${filePath}`);
    return null;
  }
  
  const content = fs.readFileSync(filePath, 'utf-8');
  console.log(`[剪贴板] 已读取: ${filePath} (${content.length} 字)`);
  return content;
}

/**
 * 获取剪贴板信息
 * 
 * @param {string} name - 文件名（默认 'latest'）
 * @returns {object|null} 元数据，不存在返回 null
 */
function getInfo(name = 'latest') {
  const metaPath = path.join(CLIPBOARD_DIR, `${name}.meta.json`);
  
  if (!fs.existsSync(metaPath)) {
    return null;
  }
  
  return JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
}

/**
 * 粘贴内容到输入框
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} content - 要粘贴的内容（可选，不传则从文件读取）
 * @param {string} name - 文件名（可选，从文件读取时使用）
 * @returns {boolean} 是否成功
 */
async function pasteToInput(page, content = null, name = 'latest') {
  // 如果没有传入内容，从文件读取
  if (content === null) {
    content = loadFromFile(name);
    if (!content) {
      console.log('[剪贴板] 没有可粘贴的内容');
      return false;
    }
  }
  
  // 查找输入框
  const inputFound = await page.evaluate(() => {
    // 查找 textarea
    const textarea = document.querySelector('textarea');
    if (textarea) {
      textarea.focus();
      return { found: true, type: 'textarea' };
    }
    
    // 查找 contenteditable
    const editable = document.querySelector('[contenteditable="true"]');
    if (editable) {
      editable.focus();
      return { found: true, type: 'contenteditable' };
    }
    
    // 查找 input[type="text"]
    const input = document.querySelector('input[type="text"]');
    if (input) {
      input.focus();
      return { found: true, type: 'input' };
    }
    
    return { found: false };
  });
  
  if (!inputFound.found) {
    console.log('[剪贴板] 未找到输入框');
    return false;
  }
  
  console.log(`[剪贴板] 找到输入框: ${inputFound.type}`);
  
  // 输入内容
  if (inputFound.type === 'textarea') {
    await page.fill('textarea', content);
  } else if (inputFound.type === 'contenteditable') {
    await page.fill('[contenteditable="true"]', content);
  } else {
    await page.fill('input[type="text"]', content);
  }
  
  console.log(`[剪贴板] 已粘贴: ${content.length} 字`);
  return true;
}

/**
 * 复制章节内容并保存（完整流程）
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} name - 保存的文件名
 * @returns {object} { success, content, path }
 */
async function copyAndSave(page, name = 'latest') {
  // 1. 等待编辑器加载
  console.log('[剪贴板] 等待编辑器加载...');
  await page.waitForTimeout(2000);
  
  // 2. 点击复制按钮（会触发内容加载）
  const clicked = await clickCopyButton(page);
  console.log('[剪贴板] 点击复制按钮:', clicked);
  
  // 3. 再次等待
  await page.waitForTimeout(1000);
  
  // 4. 获取编辑器内容（来源：content.js 已验证）
  // 注意：.ProseMirror 的 innerText 可能为空，优先使用 .Daydream
  const content = await page.evaluate(() => {
    // 优先使用 .Daydream（有完整内容）
    const editor = document.querySelector('.Daydream') || 
                   document.querySelector('.overflow-auto') ||
                   document.querySelector('.ProseMirror');
    
    if (!editor) return '';
    
    // 获取所有文本内容
    let text = editor.innerText || '';
    
    // 如果内容为空，尝试获取所有段落
    if (!text && editor.querySelectorAll) {
      const paragraphs = editor.querySelectorAll('p, div');
      text = Array.from(paragraphs).map(p => p.innerText).join('\n');
    }
    
    return text;
  });
  
  if (!content || content.length < 10) {
    return { success: false, error: `内容过短: ${content.length} 字` };
  }
  
  // 5. 保存到文件
  const filePath = saveToFile(content, name);
  
  return { 
    success: true, 
    content, 
    path: filePath,
    clicked
  };
}

module.exports = { 
  clickCopyButton,
  saveToFile,
  loadFromFile,
  getInfo,
  pasteToInput,
  copyAndSave,
  CLIPBOARD_DIR
};
