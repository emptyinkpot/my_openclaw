/**
 * 白梦写作 - 侧边栏模块
 */

const { parseChapterNumber } = require('../../utils/helper');

/**
 * 获取侧边栏位置
 * 来源：baimeng-chapter-finder.js 已验证
 */
async function getPosition(page) {
  return page.evaluate(() => {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return null;
    const rect = sidebar.getBoundingClientRect();
    return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
  });
}

/**
 * 点击侧边栏获取焦点
 */
async function focus(page) {
  const pos = await getPosition(page);
  if (!pos) return false;
  
  await page.mouse.click(pos.x, pos.y);
  await page.waitForTimeout(300);
  
  return true;
}

/**
 * 滚动到顶部
 * 来源：baimeng-chapter-finder.js 已验证
 */
async function scrollToTop(page) {
  const pos = await getPosition(page);
  if (!pos) return false;
  
  // 先点击获取焦点
  await page.mouse.click(pos.x, pos.y);
  await page.waitForTimeout(300);
  
  // 滚动到顶部
  for (let i = 0; i < 30; i++) {
    await page.mouse.wheel(0, -200);
    await page.waitForTimeout(30);
  }
  await page.waitForTimeout(500);
  
  return true;
}

/**
 * 滚动查找并点击章节
 * 来源：baimeng-chapter-finder.js 已验证
 * 
 * 支持多种格式匹配：
 * - 数字：1, 66, 100
 * - 中文：第一章, 第六十六章
 * - 阿拉伯：第1章, 第66章
 * - 带标题：第一章：故事的开始, 第1章 故事的开始
 */
async function findChapter(page, chapterName) {
  const pos = await getPosition(page);
  if (!pos) return { found: false };
  
  // 点击获取焦点
  await page.mouse.click(pos.x, pos.y);
  await page.waitForTimeout(300);
  
  // 滚动到顶部
  for (let i = 0; i < 30; i++) {
    await page.mouse.wheel(0, -200);
    await page.waitForTimeout(30);
  }
  await page.waitForTimeout(500);
  
  // 解析章节号
  const chapterNum = parseChapterNumber(chapterName);
  console.log(`查找章节号: ${chapterNum} (原始输入: ${chapterName})`);
  
  // 滚动查找章节
  for (let i = 0; i < 150; i++) {
    const result = await page.evaluate((num) => {
      // 浏览器端中文数字转数字函数
      function chineseToNum(str) {
        if (/^\d+$/.test(str)) return parseInt(str, 10);
        
        const nums = { '零': 0, '〇': 0, '一': 1, '二': 2, '三': 3, '四': 4,
          '五': 5, '六': 6, '七': 7, '八': 8, '九': 9 };
        const units = { '十': 10, '百': 100, '千': 1000 };
        
        let result = 0, temp = 0;
        for (let i = 0; i < str.length; i++) {
          const c = str[i];
          if (nums[c] !== undefined) temp = temp * 10 + nums[c];
          else if (units[c] !== undefined) {
            if (temp === 0 && i === 0) temp = 1; // "十一" = 11
            result += temp * units[c];
            temp = 0;
          }
        }
        return result + temp;
      }
      
      const sidebar = document.querySelector('.sidebar');
      if (!sidebar) return { found: false };
      
      const fileItems = sidebar.querySelectorAll('[class*="cursor-pointer"]');
      
      for (const item of fileItems) {
        const itemText = (item.innerText || '').trim();
        
        // 匹配 "第X章" 格式（支持中文数字和阿拉伯数字）
        const match = itemText.match(/^第([零一二三四五六七八九十百千\d]+)章/);
        if (!match) continue;
        
        // 提取章节号并转为数字比较
        const itemNum = chineseToNum(match[1]);
        if (itemNum !== num) continue;
        
        // 排除文件夹（文件夹有折叠箭头）
        const hasArrow = item.querySelector('[class*="chevron"]') || 
                        item.querySelector('[class*="arrow"]') ||
                        item.querySelector('svg[class*="rotate"]');
        
        if (!hasArrow && typeof item.click === 'function') {
          item.click();
          return { found: true, text: itemText.split('\n')[0] };
        }
      }
      return { found: false };
    }, chapterNum);
    
    if (result.found) {
      console.log(`✅ 点击: ${result.text}`);
      return { found: true, text: result.text };
    }
    
    await page.mouse.move(pos.x, pos.y);
    await page.mouse.wheel(0, 80);
    await page.waitForTimeout(80);
  }
  
  return { found: false };
}

module.exports = { getPosition, focus, scrollToTop, findChapter };
