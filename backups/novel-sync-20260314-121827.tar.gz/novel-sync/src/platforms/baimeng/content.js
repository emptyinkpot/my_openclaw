/**
 * 白梦写作 - 主内容区模块
 * 
 * 选择器来源：调试确认
 * 正文编辑器: .ProseMirror 或 .Daydream
 */

/**
 * 获取主内容区位置
 */
async function getPosition(page) {
  return page.evaluate(() => {
    // 优先找 ProseMirror 编辑器
    const editor = document.querySelector('.ProseMirror') || 
                   document.querySelector('.Daydream') ||
                   document.querySelector('.overflow-auto');
    if (!editor) return null;
    const rect = editor.getBoundingClientRect();
    return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
  });
}

/**
 * 点击主内容区获取焦点
 */
async function focus(page) {
  const pos = await getPosition(page);
  if (!pos) return false;
  
  await page.mouse.click(pos.x, pos.y);
  await page.waitForTimeout(500);
  
  return true;
}

/**
 * 滚动到底部加载完整内容
 */
async function scrollToBottom(page) {
  const pos = await getPosition(page);
  if (!pos) return false;
  
  // 点击获取焦点
  await page.mouse.click(pos.x, pos.y);
  await page.waitForTimeout(500);
  
  // 滚动到底部
  for (let i = 0; i < 30; i++) {
    await page.mouse.wheel(0, 300);
    await page.waitForTimeout(50);
  }
  await page.waitForTimeout(1000);
  
  return true;
}

/**
 * 获取内容文本
 * 选择器: .Daydream (优先) 或 .overflow-auto
 * 
 * 注意：.ProseMirror 存在但 innerText 为空，不能使用
 */
async function getContent(page) {
  return page.evaluate(() => {
    // 优先使用 .Daydream（有完整内容）
    const editor = document.querySelector('.Daydream') || 
                   document.querySelector('.overflow-auto');
    return editor ? editor.innerText : '';
  });
}

/**
 * 获取章节标题
 */
async function getChapterTitle(page) {
  return page.evaluate(() => {
    const editor = document.querySelector('.ProseMirror') || 
                   document.querySelector('.Daydream');
    if (!editor) return '';
    
    // 章节标题通常是第一个段落或标题元素
    const firstPara = editor.querySelector('p, h1, h2, h3');
    return firstPara ? firstPara.innerText.trim() : '';
  });
}

module.exports = { 
  getPosition, 
  focus, 
  scrollToBottom, 
  getContent,
  getChapterTitle 
};
