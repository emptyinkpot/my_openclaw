/**
 * 白梦写作 - 平台适配器（新版）
 * 
 * 低耦合、高鲁棒性
 * 
 * @module platforms/baimeng/adapter
 */

const { logger, safeCall } = require('../../core');

const log = logger.create('baimeng-adapter');

/**
 * 白梦写作适配器
 */
const baimengAdapter = {
  // 平台信息
  name: '白梦写作',
  homeUrl: 'https://baimengxiezuo.com',
  domains: ['baimengxiezuo.com', '.baimengxiezuo.com'],
  
  /**
   * 检查登录状态
   * 
   * @param {Page} page
   * @returns {Promise<{isLoggedIn: boolean, userName: string|null}>}
   */
  async checkLogin(page) {
    try {
      // 确保在平台页面
      const url = page.url();
      if (!this.domains.some(d => url.includes(d))) {
        await page.goto(this.homeUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });
        await page.waitForTimeout(2000);
      }
      
      // 检查登录按钮
      const hasLoginBtn = await safeCall(
        () => page.locator('button:has-text("登录"), a:has-text("登录")').first().isVisible(),
        false
      );
      
      if (hasLoginBtn) {
        return { isLoggedIn: false, userName: null };
      }
      
      // 从 localStorage 的 token 中获取用户名
      const userName = await this._getUserName(page);
      
      return { isLoggedIn: true, userName };
    } catch (error) {
      log.error('检查登录状态失败', error.message);
      return { isLoggedIn: false, userName: null };
    }
  },
  
  /**
   * 获取用户名
   * 
   * 从 localStorage 的 JWT token 中解析
   */
  async _getUserName(page) {
    try {
      const token = await page.evaluate(() => localStorage.getItem('token'));
      if (token) {
        // JWT 解码
        const payload = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString());
        return payload.user_metadata?.name || null;
      }
    } catch (e) {}
    
    return null;
  },
  
  /**
   * 恢复登录状态
   * 
   * 白梦写作需要先恢复 localStorage 再刷新
   * 
   * @param {Page} page
   * @param {Object} data
   */
  async restore(page, data) {
    // 恢复 cookies
    if (data.cookies?.length) {
      await page.context().addCookies(data.cookies);
    }
    
    // 访问页面
    await page.goto(this.homeUrl, { waitUntil: 'domcontentloaded' });
    
    // 恢复 localStorage（关键！）
    if (data.localStorage && Object.keys(data.localStorage).length > 0) {
      await page.evaluate((items) => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, data.localStorage);
      
      // 刷新使 localStorage 生效
      await page.reload({ waitUntil: 'domcontentloaded' });
    }
    
    await page.waitForTimeout(1500);
  },
  
  /**
   * 判断是否在平台域名
   */
  isOnPlatform(url) {
    return this.domains.some(d => url.includes(d));
  },
};

module.exports = baimengAdapter;
