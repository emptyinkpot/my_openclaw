/**
 * 白梦写作 - 润色结果处理模块
 * 
 * 功能：
 * - 解析润色结果（标题和正文分离）
 * - 内容清理（去除章节概要等）
 * - 标题格式化
 */

const { numToChinese } = require('../../utils/helper');

/**
 * 清理正文内容
 * 
 * 删除：
 * - 章节概要
 * - 总结当前章节概要
 * - 批量生成概要
 * 
 * @param {string} content - 原始内容
 * @returns {string} 清理后的内容
 */
function cleanContent(content) {
  const lines = content.split('\n');
  const cleanedLines = [];
  
  for (const line of lines) {
    const trimmed = line.trim();
    
    // 跳过章节概要相关行
    if (trimmed === '章节概要' ||
        trimmed === '总结当前章节概要' ||
        trimmed === '批量生成概要') {
      continue;
    }
    
    cleanedLines.push(line);
  }
  
  return cleanedLines.join('\n').trim();
}

/**
 * 格式化标题
 * 
 * 标准格式：第【中文数字】章：【标题内容】
 * 
 * 规则：
 * - 章节号统一使用中文数字
 * - 章节号和标题之间用冒号分隔
 * - 如果润色标题已包含章节号，提取标题内容
 * 
 * @param {string} polishTitle - 润色后的标题
 * @param {number} chapterNum - 章节号（数字）
 * @returns {string} 格式化后的标题
 */
function formatTitle(polishTitle, chapterNum) {
  // 🔴 关键：章节号统一使用中文数字
  const chineseNum = numToChinese(chapterNum);
  const chapterPrefix = `第${chineseNum}章`;
  
  if (!polishTitle) {
    return chapterPrefix;
  }
  
  // 清理标题开头和结尾的空白
  polishTitle = polishTitle.trim();
  
  // 情况1：标题以 "第X章：" 开头（阿拉伯数字+冒号）
  const match1 = polishTitle.match(/^第\d+章[：:]\s*(.+)$/);
  if (match1) {
    return `${chapterPrefix}：${match1[1].trim()}`;
  }
  
  // 情况2：标题以 "第X章" 开头（阿拉伯数字，无冒号）
  const match2 = polishTitle.match(/^第\d+章\s*(.+)$/);
  if (match2) {
    const rest = match2[1].trim();
    if (rest) {
      return `${chapterPrefix}：${rest}`;
    }
    return chapterPrefix;
  }
  
  // 情况3：标题以 "第【中文】章：" 开头（中文数字+冒号）
  const match3 = polishTitle.match(/^第[一二三四五六七八九十百千]+章[：:]\s*(.+)$/);
  if (match3) {
    return `${chapterPrefix}：${match3[1].trim()}`;
  }
  
  // 情况4：标题以 "第【中文】章" 开头（中文数字，无冒号）
  const match4 = polishTitle.match(/^第[一二三四五六七八九十百千]+章\s*(.+)$/);
  if (match4) {
    const rest = match4[1].trim();
    if (rest) {
      return `${chapterPrefix}：${rest}`;
    }
    return chapterPrefix;
  }
  
  // 情况5：标题不包含章节号，添加标准格式
  return `${chapterPrefix}：${polishTitle}`;
}

/**
 * 解析润色结果
 * 
 * @param {object} polishResult - 润色模块返回的结果
 * @param {object} options - 选项
 * @param {number} options.chapterNum - 章节号
 * @returns {{title: string, content: string}}
 */
function parsePolishResult(polishResult, options = {}) {
  const { chapterNum } = options;
  
  let title = polishResult.title || '';
  let content = polishResult.content || '';
  
  // 清理正文
  content = cleanContent(content);
  
  // 格式化标题
  if (chapterNum) {
    title = formatTitle(title, chapterNum);
  }
  
  return { title, content };
}

/**
 * 从剪贴板读取润色结果
 * 
 * @param {object} clipboard - 剪贴板模块
 * @returns {{title: string, content: string} | null}
 */
function readFromClipboard(clipboard) {
  const raw = clipboard.read('latest', { namespace: 'polish' });
  if (!raw) return null;
  
  // 解析格式：【来源】xxx\n【作品】xxx\n【章节】xxx\n【标题】xxx\n【正文】xxx
  const titleMatch = raw.match(/【标题】\n([\s\S]*?)(?=\n【正文】|$)/);
  const contentMatch = raw.match(/【正文】\n([\s\S]*)$/);
  
  return {
    title: titleMatch ? titleMatch[1].trim() : '',
    content: contentMatch ? contentMatch[1].trim() : ''
  };
}

module.exports = {
  cleanContent,
  formatTitle,
  parsePolishResult,
  readFromClipboard
};
