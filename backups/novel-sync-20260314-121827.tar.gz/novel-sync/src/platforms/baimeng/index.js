/**
 * 白梦写作 - 统一入口
 */

const auth = require('./auth');
const works = require('./works');
const sidebar = require('./sidebar');
const content = require('./content');
const copy = require('./copy');
const browser = require('./browser');
const editor = require('./editor');
const modifyCard = require('./modify-card');
const verify = require('./verify');
const polishResult = require('./polish-result');
const chapterNav = require('./chapter-nav');
const platform = require('./platform');

module.exports = {
  auth,
  works,
  sidebar,
  content,
  copy,
  browser,
  editor,
  modifyCard,
  verify,
  polishResult,
  chapterNav,
  platform
};
