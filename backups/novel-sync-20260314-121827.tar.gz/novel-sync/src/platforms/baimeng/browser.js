/**
 * 白梦写作 - 浏览器模块（最终版）
 * 
 * 核心原则：
 * 1. 浏览器是独立进程，不依赖 Node.js
 * 2. 只创建新标签页，不创建新窗口
 * 3. 脚本结束不关闭浏览器
 * 
 * @module platforms/baimeng/browser
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { spawn, exec, execSync } = require('child_process');

// ============================================================
// 配置
// ============================================================

const BROWSER_DIR = '/workspace/projects/browser/baimeng-default';
const CDP_PORT = 9223;
const CHROMIUM_PATH = '/root/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome';

// ============================================================
// 锁文件清理
// ============================================================

function cleanLockFiles() {
  const files = ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'Lock'];
  for (const f of files) {
    try {
      const p = path.join(BROWSER_DIR, f);
      if (fs.existsSync(p)) fs.unlinkSync(p);
    } catch (e) {}
  }
}

// ============================================================
// 浏览器进程管理
// ============================================================

/**
 * 检查浏览器进程是否存在
 */
function isProcessRunning() {
  try {
    const result = execSync(`pgrep -f "remote-debugging-port=${CDP_PORT}" 2>/dev/null`, { encoding: 'utf8' });
    return result.trim().length > 0;
  } catch (e) {
    return false;
  }
}

/**
 * 启动浏览器进程（独立于 Node.js）
 */
function startBrowserProcess() {
  if (!fs.existsSync(BROWSER_DIR)) {
    fs.mkdirSync(BROWSER_DIR, { recursive: true });
  }
  
  cleanLockFiles();
  
  const args = [
    `--user-data-dir=${BROWSER_DIR}`,
    `--remote-debugging-port=${CDP_PORT}`,
    '--no-first-run',
    '--no-sandbox',
    '--disable-session-crashed-bubble',
    '--hide-crash-restore-bubble',
    '--window-size=1920,1080',
    '--no-default-browser-check',
    '--disable-default-apps',
    '--disable-extensions',
    '--disable-sync',
    '--disable-infobars',
    '--enable-automation',
    '--disable-dev-shm-usage',
    'about:blank',
  ];
  
  // 使用 spawn 启动独立进程
  const proc = spawn(CHROMIUM_PATH, args, {
    detached: true,  // 独立于父进程
    stdio: 'ignore', // 忽略所有 I/O
    setsid: true,    // 新会话
  });
  
  proc.unref();  // 允许父进程退出
  
  console.log('[Browser] 浏览器进程已启动');
  return proc.pid;
}

/**
 * 等待浏览器就绪
 */
async function waitReady(timeout = 15000) {
  const start = Date.now();
  
  while (Date.now() - start < timeout) {
    try {
      // 只检查连接，不关闭
      const browser = await chromium.connectOverCDP(`http://localhost:${CDP_PORT}`);
      // 断开连接但不关闭浏览器
      browser.disconnect();
      return true;
    } catch (e) {
      await new Promise(r => setTimeout(r, 500));
    }
  }
  
  return false;
}

// ============================================================
// 核心接口
// ============================================================

/**
 * 获取或创建浏览器
 * 
 * 返回：
 * - browser: CDP 连接对象
 * - page: 新标签页
 * - isNew: 是否是新启动的浏览器
 */
async function launch() {
  console.log('[Browser] 获取浏览器...');
  
  // 检查是否已有进程
  const running = isProcessRunning();
  
  if (running) {
    console.log('[Browser] 发现运行中的浏览器');
    
    try {
      const browser = await chromium.connectOverCDP(`http://localhost:${CDP_PORT}`);
      
      if (browser.isConnected()) {
        // 获取默认上下文
        const contexts = browser.contexts();
        const context = contexts.length > 0 ? contexts[0] : await browser.newContext();
        
        // 创建新标签页
        const page = await context.newPage();
        
        console.log('[Browser] ✅ 已连接，创建新标签页');
        return { browser, context, page, isNew: false };
      }
    } catch (e) {
      console.log('[Browser] 连接失败:', e.message);
    }
  }
  
  // 启动新进程
  console.log('[Browser] 启动新浏览器...');
  
  startBrowserProcess();
  
  // 等待就绪
  const ready = await waitReady();
  if (!ready) {
    throw new Error('浏览器启动超时');
  }
  
  // 连接
  const browser = await chromium.connectOverCDP(`http://localhost:${CDP_PORT}`);
  const contexts = browser.contexts();
  const context = contexts.length > 0 ? contexts[0] : await browser.newContext();
  const page = await context.newPage();
  
  console.log('[Browser] ✅ 浏览器已启动');
  
  return { browser, context, page, isNew: true };
}

/**
 * 关闭标签页（不关闭浏览器）
 */
async function closePage(page) {
  try {
    await page.close();
    console.log('[Browser] 标签页已关闭');
  } catch (e) {}
}

/**
 * 关闭上下文
 */
async function closeContext(context) {
  try {
    await context.close();
    console.log('[Browser] 上下文已关闭');
  } catch (e) {}
}

/**
 * 断开连接（不关闭浏览器）
 */
function disconnect(browser) {
  try {
    browser.disconnect();
    console.log('[Browser] 已断开连接（浏览器保持运行）');
  } catch (e) {}
}

/**
 * 检查浏览器是否运行
 */
function isRunning() {
  return isProcessRunning();
}

/**
 * 获取状态
 */
function getStatus() {
  return {
    running: isProcessRunning(),
    port: CDP_PORT,
    dataDir: BROWSER_DIR,
  };
}

/**
 * 关闭浏览器（通常不需要）
 */
function killBrowser() {
  try {
    execSync(`pkill -f "remote-debugging-port=${CDP_PORT}" 2>/dev/null`);
    console.log('[Browser] 浏览器已关闭');
  } catch (e) {}
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  launch,
  closePage,
  closeContext,
  disconnect,
  isRunning,
  getStatus,
  killBrowser,
  DEFAULT_VIEWPORT: { width: 1920, height: 1080 },
};
