/**
 * 章节导航模块
 * 
 * 提供统一的章节打开流程，避免重复代码
 * 
 * 功能：
 * - 打开作品编辑器
 * - 查找并打开指定章节
 * - 验证章节对应
 * - 等待编辑器加载完成
 * 
 * 使用：
 *   const { openChapter } = require('./chapter-nav');
 *   const result = await openChapter(page, { workName: '作品名', chapter: 66 });
 */

const baimeng = require('./index');
const config = require('../../config');
const { numToChinese } = require('../../utils/helper');

/**
 * 打开指定章节（完整流程）
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @param {string} options.workName - 作品名称
 * @param {number|string} options.chapter - 章节号（数字或"第X章"）
 * @param {boolean} options.verify - 是否验证章节对应（默认 true）
 * @param {number} options.waitAfterOpen - 打开后等待时间（默认 3000ms）
 * @returns {Promise<{success: boolean, workId?: string, chapterTitle?: string, error?: string}>}
 */
async function openChapter(page, options) {
  const { 
    workName, 
    chapter, 
    verify = true, 
    waitAfterOpen = 3000 
  } = options;
  
  // 1. 解析章节号
  const chapterNum = typeof chapter === 'string' 
    ? parseChapterNum(chapter) 
    : chapter;
  
  if (!chapterNum) {
    return { success: false, error: '无效的章节号' };
  }
  
  const chapterTitle = `第${numToChinese(chapterNum)}章`;
  
  // 2. 获取作品列表
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, workName);
  
  if (!workId) {
    return { success: false, error: `未找到作品: ${workName}` };
  }
  
  // 3. 进入编辑器
  await page.goto(`${config.BAIMENG.urls.editor}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(5000);
  
  // 4. 查找章节
  const findResult = await baimeng.sidebar.findChapter(page, chapterTitle);
  
  if (!findResult.found) {
    return { success: false, error: `未找到章节: ${chapterTitle}` };
  }
  
  await page.waitForTimeout(waitAfterOpen);
  
  // 5. 等待编辑器加载
  await page.waitForSelector('.Daydream', { state: 'visible', timeout: 10000 }).catch(() => null);
  await page.waitForTimeout(2000);
  
  // 6. 验证章节对应
  if (verify) {
    const verifyResult = await baimeng.verify.verifyChapterMatch(page, chapterTitle);
    
    if (verifyResult.warning) {
      console.log(`  ⚠️ 章节验证警告: ${verifyResult.warning}`);
    }
  }
  
  // 7. 加载完整内容
  await baimeng.content.scrollToBottom(page);
  await page.waitForTimeout(2000);
  
  return { 
    success: true, 
    workId, 
    chapterTitle,
    chapterNum 
  };
}

/**
 * 解析章节号
 * 
 * @param {string} input - 输入（"66", "第六十六章", "第66章"）
 * @returns {number|null}
 */
function parseChapterNum(input) {
  // 纯数字
  if (/^\d+$/.test(input)) {
    return parseInt(input);
  }
  
  // 第X章 格式
  const match = input.match(/^第(.+)章$/);
  if (match) {
    const num = match[1];
    
    // 数字
    if (/^\d+$/.test(num)) {
      return parseInt(num);
    }
    
    // 中文数字
    return chineseToNumber(num);
  }
  
  // 纯中文数字
  return chineseToNumber(input);
}

/**
 * 中文数字转数字
 */
function chineseToNumber(str) {
  // 简单映射
  const simpleMap = {
    '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
    '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
    '十一': 11, '十二': 12, '十三': 13, '十四': 14, '十五': 15,
    '十六': 16, '十七': 17, '十八': 18, '十九': 19, '二十': 20,
    '二十一': 21, '二十二': 22, '二十三': 23, '二十四': 24, '二十五': 25,
    '二十六': 26, '二十七': 27, '二十八': 28, '二十九': 29, '三十': 30,
    '三十一': 31, '三十二': 32, '三十三': 33, '三十四': 34, '三十五': 35,
    '三十六': 36, '三十七': 37, '三十八': 38, '三十九': 39, '四十': 40,
    '四十一': 41, '四十二': 42, '四十三': 43, '四十四': 44, '四十五': 45,
    '四十六': 46, '四十七': 47, '四十八': 48, '四十九': 49, '五十': 50,
    '五十一': 51, '五十二': 52, '五十三': 53, '五十四': 54, '五十五': 55,
    '五十六': 56, '五十七': 57, '五十八': 58, '五十九': 59, '六十': 60,
    '六十一': 61, '六十二': 62, '六十三': 63, '六十四': 64, '六十五': 65,
    '六十六': 66, '六十七': 67, '六十八': 68, '六十九': 69, '七十': 70,
    '七十一': 71, '七十二': 72, '七十三': 73, '七十四': 74, '七十五': 75,
    '七十六': 76, '七十七': 77, '七十八': 78, '七十九': 79, '八十': 80,
    '八十一': 81, '八十二': 82, '八十三': 83, '八十四': 84, '八十五': 85,
    '八十六': 86, '八十七': 87, '八十八': 88, '八十九': 89, '九十': 90,
    '九十一': 91, '九十二': 92, '九十三': 93, '九十四': 94, '九十五': 95,
    '九十六': 96, '九十七': 97, '九十八': 98, '九十九': 99, '一百': 100
  };
  
  // 直接匹配
  if (simpleMap[str]) {
    return simpleMap[str];
  }
  
  return null;
}

/**
 * 批量打开章节
 * 
 * @param {Page} page 
 * @param {string} workName 
 * @param {number[]} chapters 
 * @param {Function} callback - 每个章节的回调函数
 */
async function openChapters(page, workName, chapters, callback) {
  // 打开作品一次
  const works = await baimeng.works.getWorks(page);
  const workId = baimeng.works.findWorkId(works, workName);
  
  if (!workId) {
    return { success: false, error: `未找到作品: ${workName}` };
  }
  
  await page.goto(`${config.BAIMENG.urls.editor}?id=${workId}`, { timeout: 30000 });
  await page.waitForTimeout(5000);
  
  const results = [];
  
  for (const chapter of chapters) {
    const chapterTitle = `第${numToChinese(chapter)}章`;
    
    const findResult = await baimeng.sidebar.findChapter(page, chapterTitle);
    
    if (findResult.found) {
      await page.waitForTimeout(3000);
      
      // 执行回调
      const result = await callback(page, { chapter, chapterTitle, workId, workName });
      results.push({ chapter, success: true, result });
    } else {
      results.push({ chapter, success: false, error: '章节不存在' });
    }
  }
  
  return results;
}

module.exports = {
  openChapter,
  openChapters,
  parseChapterNum,
  chineseToNumber
};
