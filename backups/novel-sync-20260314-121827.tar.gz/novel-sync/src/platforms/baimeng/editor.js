/**
 * 白梦写作 - 编辑器模块
 * 
 * 功能：
 * - 编辑器内容操作（清空、获取、设置）
 * - 标题操作（获取、修改）
 * - 保存操作
 * 
 * 来源：polish-and-replace.js 已验证逻辑
 */

// ============================================================
// 内容清洗规则（通用）
// ============================================================

/**
 * 垃圾内容类型定义
 * 
 * 🔴 关键：明确定义所有需要过滤的内容类型
 */
const JUNK_PATTERNS = {
  // 工具栏文字（固定关键词）
  toolbar: [
    '章节概要',
    '总结当前章节概要',
    '批量生成概要'
  ],
  
  // 章节标题格式（第X章：XXX 或 第X章，XXX）
  // 出现在前3行的才认为是标题
  chapterTitle: /^第[一二三四五六七八九十百千\d]+章[：:，,]\s*.+$/,
  
  // 纯章节号（第X章）
  chapterNumber: /^第[一二三四五六七八九十百千\d]+章$/
};

/**
 * 判断一行是否是垃圾内容
 * 
 * @param {string} line - 文本行
 * @param {number} lineIndex - 行索引（从0开始）
 * @param {string[]} allLines - 所有行
 * @returns {{ isJunk: boolean, reason?: string }}
 */
function isJunkLine(line, lineIndex, allLines) {
  const trimmed = line.trim();
  
  // 空行不是垃圾（保留段落分隔）
  if (!trimmed) {
    return { isJunk: false };
  }
  
  // 1. 检查工具栏文字
  if (JUNK_PATTERNS.toolbar.includes(trimmed)) {
    return { isJunk: true, reason: 'toolbar' };
  }
  
  // 2. 检查章节标题（只在前5行检查）
  if (lineIndex < 5) {
    // 匹配 "第X章：XXX" 格式
    if (JUNK_PATTERNS.chapterTitle.test(trimmed)) {
      return { isJunk: true, reason: 'chapterTitle' };
    }
    
    // 匹配纯 "第X章" 格式（如果没有更完整的标题）
    if (JUNK_PATTERNS.chapterNumber.test(trimmed)) {
      return { isJunk: true, reason: 'chapterNumber' };
    }
  }
  
  return { isJunk: false };
}

/**
 * 从文本中提取标题
 * 
 * @param {string} text - 完整文本
 * @returns {string|null} 提取的标题
 */
function extractTitle(text) {
  const lines = text.split('\n');
  
  // 在前5行查找标题
  for (let i = 0; i < Math.min(5, lines.length); i++) {
    const line = lines[i].trim();
    
    // 优先匹配完整标题 "第X章：XXX"
    const match = line.match(/^第[一二三四五六七八九十百千\d]+章[：:，,]\s*(.+)$/);
    if (match) {
      return line;  // 返回完整标题
    }
    
    // 其次匹配纯章节号
    if (JUNK_PATTERNS.chapterNumber.test(line)) {
      return line;
    }
  }
  
  return null;
}

/**
 * 清洗文本内容（移除垃圾）
 * 
 * @param {string} text - 原始文本
 * @returns {string} 清洗后的文本
 */
function cleanContent(text) {
  const lines = text.split('\n');
  const cleaned = [];
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const { isJunk, reason } = isJunkLine(line, i, lines);
    
    if (!isJunk) {
      cleaned.push(line);
    }
  }
  
  // 合并并清理多余空行
  return cleaned
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')  // 最多保留双换行
    .trim();
}

// ============================================================
// 正文操作
// ============================================================

/**
 * 获取编辑器内容（清洗后）
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<string>} 清洗后的编辑器文本内容
 */
async function getContent(page) {
  return page.evaluate(() => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return '';
    
    // 直接获取 innerText
    return editor.innerText || '';
  }).then(text => {
    // 🔴 关键：使用通用清洗函数
    return cleanContent(text);
  });
}

/**
 * 获取原始内容（未清洗，用于备份）
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<string>} 原始编辑器文本内容
 */
async function getRawContent(page) {
  return page.evaluate(() => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return '';
    return editor.innerText || '';
  });
}

/**
 * 设置编辑器内容
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} content - 新内容
 * @returns {Promise<{success: boolean}>}
 */
async function setContent(page, content) {
  const result = await page.evaluate((text) => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return { success: false, error: '未找到编辑器' };
    
    // 🔴 关键修复：直接清空并重建段落
    editor.innerHTML = '';
    
    // 按段落添加
    const paragraphs = text.split('\n');
    for (const p of paragraphs) {
      if (p.trim()) {
        const pEl = document.createElement('p');
        pEl.textContent = p;
        editor.appendChild(pEl);
      }
    }
    
    return { success: true };
  }, content);
  
  return result;
}

/**
 * 清空编辑器内容
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function clearContent(page) {
  return page.evaluate(() => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return { success: false, error: '未找到编辑器' };
    
    editor.focus();
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(editor);
    selection.removeAllRanges();
    selection.addRange(range);
    document.execCommand('delete');
    
    return { success: true };
  });
}

/**
 * 追加内容到末尾
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} text - 要追加的文本
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function appendContent(page, text) {
  return page.evaluate((content) => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return { success: false, error: '未找到编辑器' };
    
    // 按段落添加
    const paragraphs = content.split('\n');
    for (const p of paragraphs) {
      const pEl = document.createElement('p');
      pEl.textContent = p;
      editor.appendChild(pEl);
    }
    
    return { success: true };
  }, text);
}

/**
 * 在指定位置插入内容
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} text - 要插入的文本
 * @param {Object} options - 选项
 * @param {number} options.lineNumber - 行号（从1开始）
 * @param {string} options.position - 插入位置：'before' | 'after' | 'replace'
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function insertContent(page, text, options = {}) {
  const { lineNumber = 1, position = 'before' } = options;
  
  return page.evaluate((content, lineNum, pos) => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return { success: false, error: '未找到编辑器' };
    
    const paragraphs = editor.querySelectorAll('p');
    
    if (lineNum < 1 || lineNum > paragraphs.length + 1) {
      return { success: false, error: `行号超出范围 (1-${paragraphs.length + 1})` };
    }
    
    // 创建新段落
    const newParagraphs = content.split('\n').map(line => {
      const p = document.createElement('p');
      p.textContent = line;
      return p;
    });
    
    const targetIndex = lineNum - 1;
    
    if (pos === 'replace') {
      // 替换指定行
      const targetP = paragraphs[targetIndex];
      if (targetP) {
        targetP.textContent = content;
        return { success: true };
      }
    } else if (pos === 'before') {
      // 在指定行前插入
      const targetP = paragraphs[targetIndex];
      if (targetP) {
        newParagraphs.reverse().forEach(p => {
          editor.insertBefore(p, targetP);
        });
      } else {
        newParagraphs.forEach(p => editor.appendChild(p));
      }
    } else {
      // 在指定行后插入
      const targetP = paragraphs[targetIndex];
      if (targetP && targetP.nextSibling) {
        newParagraphs.reverse().forEach(p => {
          editor.insertBefore(p, targetP.nextSibling);
        });
      } else {
        newParagraphs.forEach(p => editor.appendChild(p));
      }
    }
    
    return { success: true };
  }, text, lineNumber, position);
}

/**
 * 替换指定文本
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} oldText - 要替换的文本
 * @param {string} newText - 新文本
 * @param {Object} options - 选项
 * @param {boolean} options.all - 替换所有匹配项（默认 false）
 * @returns {Promise<{success: boolean, count?: number, error?: string}>}
 */
async function replaceText(page, oldText, newText, options = {}) {
  const { all = false } = options;
  
  return page.evaluate((oldStr, newStr, replaceAll) => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return { success: false, error: '未找到编辑器' };
    
    const paragraphs = editor.querySelectorAll('p');
    let count = 0;
    
    for (const p of paragraphs) {
      if (!p.textContent.includes(oldStr)) continue;
      
      if (replaceAll) {
        // 替换所有匹配
        const regex = new RegExp(oldStr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
        const matches = p.textContent.match(regex);
        if (matches) {
          count += matches.length;
          p.textContent = p.textContent.replace(regex, newStr);
        }
      } else {
        // 只替换第一个
        p.textContent = p.textContent.replace(oldStr, newStr);
        count++;
        break;
      }
    }
    
    return { success: true, count };
  }, oldText, newText, all);
}

/**
 * 聚焦编辑器
 * 
 * @param {Page} page - Playwright page 对象
 */
async function focus(page) {
  await page.evaluate(() => {
    const editor = document.querySelector('.Daydream');
    editor?.focus();
  });
}

/**
 * 检查编辑器是否为空
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<boolean>}
 */
async function isEmpty(page) {
  const content = await getContent(page);
  return content.trim().length === 0;
}

// ============================================================
// 标题操作
// ============================================================

/**
 * 获取章节标题（大标题）
 * 
 * 优先级：
 * 1. 从正文第一行提取完整标题（包含副标题）
 * 2. 从标题 input 提取
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<string|null>} 标题文本
 */
async function getTitle(page) {
  // 方案1：从正文提取标题
  const rawContent = await getRawContent(page);
  const title = extractTitle(rawContent);
  if (title) return title;
  
  // 方案2：从标题 input 提取
  return page.evaluate(() => {
    const editor = document.querySelector('.Daydream');
    if (editor) {
      const titleInput = editor.querySelector('input[type="text"], input:not([type])');
      if (titleInput && titleInput.value) return titleInput.value;
    }
    
    // 最终降级：查找页面任意标题 input
    const input = document.querySelector('input[type="text"], input:not([type])');
    return input?.value || null;
  });
}

/**
 * 修改章节标题
 * 
 * 流程：找到标题 input → 全选 → 输入新标题 → Enter 确认
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} newTitle - 新标题
 * @param {string} [currentTitle] - 当前标题（用于定位，可选）
 * @returns {Promise<{success: boolean, error?: string, oldTitle?: string}>}
 */
async function setTitle(page, newTitle, currentTitle = null) {
  // 🔴 关键修复：直接查找编辑器内的标题 input
  const inputHandle = await page.evaluateHandle(() => {
    const editor = document.querySelector('.Daydream');
    if (!editor) return null;
    
    // 查找编辑器内的标题 input
    const inputs = editor.querySelectorAll('input[type="text"], input:not([type])');
    for (const input of inputs) {
      // 标题 input 通常有较大的字体
      const style = window.getComputedStyle(input);
      const fontSize = parseFloat(style.fontSize);
      if (fontSize >= 20) {  // 标题字体通常 >= 20px
        return input;
      }
    }
    
    // 降级：返回第一个 input
    return inputs[0] || null;
  });
  
  if (!inputHandle || !(await inputHandle.evaluate(el => !!el))) {
    return { success: false, error: '未找到标题输入框' };
  }
  
  // 获取旧标题
  const oldTitle = await inputHandle.evaluate(el => el.value);
  console.log('[标题] 找到标题输入框，当前值:', oldTitle);
  
  // 🔴 关键：直接操作 input
  await inputHandle.click();
  await page.waitForTimeout(100);
  
  // 快速设置值 + 触发事件（替代逐字符输入）
  await inputHandle.evaluate((el, val) => {
    el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }, newTitle);
  await page.waitForTimeout(200);
  
  // 按 Enter 确认
  await inputHandle.press('Enter');
  await page.waitForTimeout(500);
  
  return { 
    success: true, 
    oldTitle 
  };
}

// ============================================================
// 保存操作
// ============================================================

/**
 * 保存作品
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function save(page) {
  const result = await page.evaluate(() => {
    const buttons = document.querySelectorAll('button, [role="button"]');
    for (const btn of buttons) {
      const text = btn.innerText || '';
      if (text.includes('保存') || text === '保存作品') {
        btn.click();
        return { success: true, text };
      }
    }
    return { success: false, error: '未找到保存按钮' };
  });
  
  if (result.success) {
    await page.waitForTimeout(3000);  // 等待保存完成
  }
  
  return result;
}

// ============================================================
// 智能排版
// ============================================================

/**
 * 执行智能排版
 * 
 * 功能：自动调整文本格式（段落、缩进等）
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<{success: boolean, before?: string, after?: string, error?: string}>}
 */
async function smartFormat(page) {
  // 1. 获取排版前内容
  const before = await getContent(page);
  
  // 2. 点击智能排版按钮
  const clicked = await page.evaluate(() => {
    const buttons = document.querySelectorAll('button, [role="button"]');
    for (const btn of buttons) {
      const text = btn.innerText || '';
      if (text.includes('智能排版')) {
        btn.click();
        return { success: true, text };
      }
    }
    return { success: false, error: '未找到智能排版按钮' };
  });
  
  if (!clicked.success) {
    return clicked;
  }
  
  // 3. 等待排版完成（观察DOM变化）
  await page.waitForTimeout(2000);
  
  // 4. 获取排版后内容
  const after = await getContent(page);
  
  // 5. 返回结果
  return {
    success: true,
    before,
    after,
    changed: before !== after
  };
}

/**
 * 检查智能排版按钮是否存在
 * 
 * @param {Page} page - Playwright page 对象
 * @returns {Promise<boolean>}
 */
async function hasSmartFormatButton(page) {
  return page.evaluate(() => {
    const buttons = document.querySelectorAll('button, [role="button"]');
    for (const btn of buttons) {
      const text = btn.innerText || '';
      if (text.includes('智能排版')) {
        return true;
      }
    }
    return false;
  });
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  // 正文操作
  getContent,
  getRawContent,
  setContent,
  appendContent,
  insertContent,
  replaceText,
  clearContent,
  focus,
  isEmpty,
  
  // 标题操作
  getTitle,
  setTitle,
  
  // 保存操作
  save,
  
  // 智能排版
  smartFormat,
  hasSmartFormatButton,
  
  // 内容清洗工具（导出供测试）
  cleanContent,
  extractTitle,
  isJunkLine,
  JUNK_PATTERNS
};
