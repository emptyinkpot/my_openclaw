/**
 * 白梦写作平台 - 重构版
 * 
 * 使用基类模块，提供统一的接口
 * 
 * @module platforms/baimeng
 */

const { BrowserBase, AuthBase, ElementBase } = require('../base');
const config = require('../../config');
const logger = require('../../utils/logger');

// ============================================================
// 白梦写作浏览器类
// ============================================================

class BaimengBrowser extends BrowserBase {
  constructor(options = {}) {
    super('baimeng', options);
  }
}

// ============================================================
// 白梦写作认证类
// ============================================================

class BaimengAuth extends AuthBase {
  constructor(browserInstance) {
    super('baimeng', browserInstance);
  }
  
  /**
   * 检查登录状态
   */
  async checkLogin() {
    const page = this.browser.getPage();
    
    await page.goto(this.siteConfig.urls.home, { 
      timeout: 15000, 
      waitUntil: 'domcontentloaded' 
    });
    await page.waitForTimeout(3000);
    
    // 检查是否有登录按钮
    const hasLoginBtn = await page.locator('button:has-text("登录")').first().isVisible().catch(() => false);
    
    return {
      isLoggedIn: !hasLoginBtn,
      message: !hasLoginBtn ? '已登录' : '未登录',
    };
  }
}

// ============================================================
// 白梦写作元素操作类
// ============================================================

class BaimengElement extends ElementBase {
  constructor(browserInstance) {
    super('baimeng', browserInstance);
  }
  
  /**
   * 获取侧边栏位置
   */
  async getSidebarPosition() {
    return this.evaluate(() => {
      const sidebar = document.querySelector('.sidebar');
      if (!sidebar) return null;
      const rect = sidebar.getBoundingClientRect();
      return { x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 };
    });
  }
  
  /**
   * 点击侧边栏获取焦点
   */
  async focusSidebar() {
    const page = this.getPage();
    const pos = await this.getSidebarPosition();
    if (!pos) return false;
    
    await page.mouse.click(pos.x, pos.y);
    await page.waitForTimeout(300);
    return true;
  }
  
  /**
   * 滚动侧边栏到顶部
   */
  async scrollSidebarToTop() {
    const page = this.getPage();
    const pos = await this.getSidebarPosition();
    if (!pos) return false;
    
    await page.mouse.click(pos.x, pos.y);
    await page.waitForTimeout(300);
    
    for (let i = 0; i < 30; i++) {
      await page.mouse.wheel(0, -200);
      await page.waitForTimeout(30);
    }
    await page.waitForTimeout(500);
    
    return true;
  }
  
  /**
   * 获取编辑器内容
   */
  async getEditorContent() {
    return this.evaluate(() => {
      const editor = document.querySelector('.ProseMirror') || document.querySelector('.Daydream');
      return editor?.innerText || '';
    });
  }
  
  /**
   * 设置编辑器内容
   * @param {string} content - 新内容
   */
  async setEditorContent(content) {
    return this.evaluate((text) => {
      const editor = document.querySelector('.ProseMirror') || document.querySelector('.Daydream');
      if (editor) {
        editor.innerText = text;
        editor.dispatchEvent(new Event('input', { bubbles: true }));
        return true;
      }
      return false;
    }, content);
  }
}

// ============================================================
// 侧边栏操作模块
// ============================================================

class BaimengSidebar extends BaimengElement {
  constructor(browserInstance) {
    super(browserInstance);
    this.log = logger.create('baimeng:sidebar');
  }
  
  /**
   * 解析章节号
   */
  parseChapterNumber(name) {
    if (/^\d+$/.test(name)) return parseInt(name, 10);
    
    const match = name.match(/第([零一二三四五六七八九十百千\d]+)章/);
    if (!match) return parseInt(name, 10) || 0;
    
    const numStr = match[1];
    if (/^\d+$/.test(numStr)) return parseInt(numStr, 10);
    
    // 中文数字转换
    const nums = { '零': 0, '〇': 0, '一': 1, '二': 2, '三': 3, '四': 4,
      '五': 5, '六': 6, '七': 7, '八': 8, '九': 9 };
    const units = { '十': 10, '百': 100, '千': 1000 };
    
    let result = 0, temp = 0;
    for (let i = 0; i < numStr.length; i++) {
      const c = numStr[i];
      if (nums[c] !== undefined) temp = temp * 10 + nums[c];
      else if (units[c] !== undefined) {
        if (temp === 0 && i === 0) temp = 1;
        result += temp * units[c];
        temp = 0;
      }
    }
    return result + temp;
  }
  
  /**
   * 查找并点击章节
   */
  async findChapter(chapterName) {
    const page = this.getPage();
    const pos = await this.getSidebarPosition();
    if (!pos) return { found: false };
    
    await this.focusSidebar();
    await this.scrollSidebarToTop();
    
    const chapterNum = this.parseChapterNumber(chapterName);
    this.log.info(`查找章节号: ${chapterNum} (原始输入: ${chapterName})`);
    
    // 滚动查找
    for (let i = 0; i < 150; i++) {
      const result = await this.evaluate((num) => {
        function chineseToNum(str) {
          if (/^\d+$/.test(str)) return parseInt(str, 10);
          const nums = { '零': 0, '〇': 0, '一': 1, '二': 2, '三': 3, '四': 4,
            '五': 5, '六': 6, '七': 7, '八': 8, '九': 9 };
          const units = { '十': 10, '百': 100, '千': 1000 };
          let result = 0, temp = 0;
          for (let i = 0; i < str.length; i++) {
            const c = str[i];
            if (nums[c] !== undefined) temp = temp * 10 + nums[c];
            else if (units[c] !== undefined) {
              if (temp === 0 && i === 0) temp = 1;
              result += temp * units[c];
              temp = 0;
            }
          }
          return result + temp;
        }
        
        const sidebar = document.querySelector('.sidebar');
        if (!sidebar) return { found: false };
        
        const items = sidebar.querySelectorAll('[class*="cursor-pointer"]');
        for (const item of items) {
          const text = (item.innerText || '').trim();
          const match = text.match(/^第([零一二三四五六七八九十百千\d]+)章/);
          if (!match) continue;
          
          const itemNum = chineseToNum(match[1]);
          if (itemNum !== num) continue;
          
          const hasArrow = item.querySelector('[class*="chevron"]') || 
                          item.querySelector('[class*="arrow"]') ||
                          item.querySelector('svg[class*="rotate"]');
          
          if (!hasArrow && typeof item.click === 'function') {
            item.click();
            return { found: true, text: text.split('\n')[0] };
          }
        }
        return { found: false };
      }, chapterNum);
      
      if (result.found) {
        this.log.success(`找到并点击: ${result.text}`);
        return { found: true, text: result.text };
      }
      
      await page.mouse.move(pos.x, pos.y);
      await page.mouse.wheel(0, 80);
      await page.waitForTimeout(80);
    }
    
    return { found: false };
  }
}

// ============================================================
// 白梦写作平台管理器
// ============================================================

class BaimengPlatform {
  constructor(options = {}) {
    this.options = options;
    this.log = logger.create('baimeng');
    
    this.browser = new BaimengBrowser(options);
    this.auth = null;
    this.element = null;
    this.sidebar = null;
  }
  
  /**
   * 初始化平台
   */
  async init() {
    this.log.info('初始化白梦写作平台...');
    
    await this.browser.launch();
    this.auth = new BaimengAuth(this.browser);
    this.element = new BaimengElement(this.browser);
    this.sidebar = new BaimengSidebar(this.browser);
    
    return this;
  }
  
  /**
   * 确保已登录
   */
  async ensureLogin() {
    await this.auth.ensureLoggedIn();
    return this;
  }
  
  /**
   * 导航到编辑器
   */
  async gotoEditor() {
    await this.browser.goto('editor');
    await this.browser.wait(3000);
    return this;
  }
  
  /**
   * 查找章节
   */
  async findChapter(chapterName) {
    return this.sidebar.findChapter(chapterName);
  }
  
  /**
   * 获取编辑器内容
   */
  async getContent() {
    return this.element.getEditorContent();
  }
  
  /**
   * 设置编辑器内容
   */
  async setContent(content) {
    return this.element.setEditorContent(content);
  }
  
  /**
   * 关闭
   */
  async close() {
    await this.browser.close();
  }
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  BaimengBrowser,
  BaimengAuth,
  BaimengElement,
  BaimengSidebar,
  BaimengPlatform,
  
  // 兼容旧模块
  browser: {
    launch: async (accountId = 1) => {
      const b = new BaimengBrowser({ accountId });
      return b.launch();
    },
  },
  
  auth: {
    restoreLogin: async (page, accountId = 1) => {
      const b = new BaimengBrowser({ accountId });
      b.page = page;
      b.browser = page.context();
      const a = new BaimengAuth(b);
      return a.restoreLogin();
    },
    checkLogin: async (page) => {
      const b = new BaimengBrowser();
      b.page = page;
      const a = new BaimengAuth(b);
      return a.checkLogin();
    },
  },
  
  sidebar: {
    getPosition: async (page) => {
      const b = new BaimengBrowser();
      b.page = page;
      const s = new BaimengSidebar(b);
      return s.getSidebarPosition();
    },
    focus: async (page) => {
      const b = new BaimengBrowser();
      b.page = page;
      const s = new BaimengSidebar(b);
      return s.focusSidebar();
    },
    scrollToTop: async (page) => {
      const b = new BaimengBrowser();
      b.page = page;
      const s = new BaimengSidebar(b);
      return s.scrollSidebarToTop();
    },
    findChapter: async (page, name) => {
      const b = new BaimengBrowser();
      b.page = page;
      const s = new BaimengSidebar(b);
      return s.findChapter(name);
    },
  },
};
