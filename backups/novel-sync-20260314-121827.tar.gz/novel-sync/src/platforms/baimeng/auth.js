/**
 * 白梦写作 - 认证模块
 * 
 * 简洁的 API，基于服务层
 * 
 * @module platforms/baimeng/auth
 */

const { authService } = require('../../services');

// ============================================================
// 账号管理
// ============================================================

function listAccounts() {
  return authService.listAccounts('baimeng');
}

function checkAccount(userName) {
  return authService.checkAccount('baimeng', userName);
}

// ============================================================
// 登录操作
// ============================================================

async function restoreLogin(page, userName, options = {}) {
  return authService.login({
    platform: 'baimeng',
    userName,
    targetUrl: options.targetUrl,
    page,
  });
}

async function checkLogin(page) {
  const adapter = require('./adapter');
  return adapter.checkLogin(page);
}

async function saveLogin(page, userName) {
  return authService.saveAccount({
    platform: 'baimeng',
    page,
    userName,
  });
}

async function waitForLogin(page, timeout = 120000) {
  return authService.waitForLogin({
    platform: 'baimeng',
    page,
    timeout,
  });
}

async function loginAndSave(page, timeout = 120000) {
  const result = await waitForLogin(page, timeout);
  
  if (!result.success) {
    return { success: false, message: '登录超时' };
  }
  
  return saveLogin(page, result.userName);
}

module.exports = {
  listAccounts,
  checkAccount,
  restoreLogin,
  checkLogin,
  saveLogin,
  waitForLogin,
  loginAndSave,
};
