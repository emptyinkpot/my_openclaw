/**
 * 元素操作基类
 * 
 * 提供通用的元素查找、点击、输入等操作
 * 
 * @module platforms/base/element
 */

const logger = require('../../utils/logger');
const config = require('../../config');

class ElementBase {
  /**
   * @param {string} site - 平台名称
   * @param {BrowserBase} browserInstance - 浏览器实例
   */
  constructor(site, browserInstance) {
    this.site = site;
    this.siteConfig = config.getSiteConfig(site);
    this.browser = browserInstance;
    this.log = logger.create(`element:${site}`);
  }
  
  /**
   * 获取页面
   * @returns {Page}
   */
  getPage() {
    return this.browser.getPage();
  }
  
  /**
   * 等待元素出现
   * @param {string} selector - 选择器
   * @param {number} timeout - 超时时间
   */
  async waitFor(selector, timeout = 10000) {
    const page = this.getPage();
    this.log.debug(`等待元素: ${selector}`);
    
    try {
      await page.waitForSelector(selector, { timeout });
      return true;
    } catch (e) {
      this.log.warn(`元素未出现: ${selector}`);
      return false;
    }
  }
  
  /**
   * 查找元素
   * @param {string} selector - 选择器
   * @param {Object} options - 选项
   */
  async find(selector, options = {}) {
    const page = this.getPage();
    const locator = page.locator(selector);
    
    if (options.wait) {
      await this.waitFor(selector, options.timeout);
    }
    
    if (options.all) {
      return await locator.all();
    }
    
    return locator;
  }
  
  /**
   * 点击元素
   * @param {string} selector - 选择器
   * @param {Object} options - 选项
   */
  async click(selector, options = {}) {
    const page = this.getPage();
    
    this.log.debug(`点击: ${selector}`);
    
    if (options.waitFor) {
      await this.waitFor(selector, options.waitFor);
    }
    
    const locator = page.locator(selector);
    
    // 如果需要悬停
    if (options.hover) {
      await locator.hover();
      await page.waitForTimeout(300);
    }
    
    // 优先使用 JS 点击
    if (options.jsClick !== false) {
      try {
        await locator.evaluate((el) => el.click());
      } catch (e) {
        await locator.click({ timeout: options.timeout || 5000 });
      }
    } else {
      await locator.click({ timeout: options.timeout || 5000 });
    }
    
    if (options.waitAfter) {
      await page.waitForTimeout(options.waitAfter);
    }
  }
  
  /**
   * 输入文本
   * @param {string} selector - 选择器
   * @param {string} text - 文本
   * @param {Object} options - 选项
   */
  async type(selector, text, options = {}) {
    const page = this.getPage();
    
    this.log.debug(`输入文本到: ${selector}`);
    
    if (options.clear) {
      await this.clear(selector);
    }
    
    const locator = page.locator(selector);
    
    if (options.focus) {
      await locator.focus();
    }
    
    await locator.fill(text);
    
    if (options.waitAfter) {
      await page.waitForTimeout(options.waitAfter);
    }
  }
  
  /**
   * 清除输入框
   * @param {string} selector - 选择器
   */
  async clear(selector) {
    const page = this.getPage();
    const locator = page.locator(selector);
    await locator.clear();
  }
  
  /**
   * 获取元素文本
   * @param {string} selector - 选择器
   */
  async getText(selector) {
    const page = this.getPage();
    const locator = page.locator(selector);
    return await locator.textContent();
  }
  
  /**
   * 获取元素值
   * @param {string} selector - 选择器
   */
  async getValue(selector) {
    const page = this.getPage();
    const locator = page.locator(selector);
    return await locator.inputValue();
  }
  
  /**
   * 检查元素是否可见
   * @param {string} selector - 选择器
   */
  async isVisible(selector) {
    const page = this.getPage();
    try {
      return await page.locator(selector).first().isVisible();
    } catch (e) {
      return false;
    }
  }
  
  /**
   * 等待并点击
   * @param {string} selector - 选择器
   * @param {number} timeout - 超时时间
   */
  async waitAndClick(selector, timeout = 10000) {
    await this.waitFor(selector, timeout);
    await this.click(selector);
  }
  
  /**
   * 点击包含特定文本的元素
   * @param {string} text - 文本
   * @param {Object} options - 选项
   */
  async clickByText(text, options = {}) {
    const page = this.getPage();
    const selector = options.selector ? 
      `${options.selector}:has-text("${text}")` : 
      `:has-text("${text}")`;
    
    this.log.debug(`点击包含文本的元素: ${text}`);
    
    const locator = page.locator(selector).first();
    await locator.click({ timeout: options.timeout || 5000 });
  }
  
  /**
   * 滚动到元素
   * @param {string} selector - 选择器
   */
  async scrollTo(selector) {
    const page = this.getPage();
    const locator = page.locator(selector);
    await locator.scrollIntoViewIfNeeded();
  }
  
  /**
   * 执行页面内的 JavaScript
   * @param {Function|string} fn - 函数或代码
   * @param {...any} args - 参数
   */
  async evaluate(fn, ...args) {
    const page = this.getPage();
    return await page.evaluate(fn, ...args);
  }
  
  /**
   * 滚动页面
   * @param {Object} options - 滚动选项
   */
  async scroll(options = {}) {
    const page = this.getPage();
    
    if (options.to === 'bottom') {
      await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
    } else if (options.to === 'top') {
      await page.evaluate(() => window.scrollTo(0, 0));
    } else if (options.pixels) {
      await page.evaluate((y) => window.scrollBy(0, y), options.pixels);
    }
    
    if (options.waitAfter) {
      await page.waitForTimeout(options.waitAfter);
    }
  }
}

module.exports = ElementBase;
