/**
 * 账号存储基类（向后兼容）
 * 
 * 新代码请使用 auth-core.js
 * 
 * @deprecated 请使用 auth-core.js 中的 AuthStore
 */

const { AuthStore: CoreAuthStore, PlatformAdapter, AuthManager, createManager } = require('./auth-core');

// 向后兼容
module.exports = CoreAuthStore;

// 同时导出新模块
module.exports.AuthStore = CoreAuthStore;
module.exports.PlatformAdapter = PlatformAdapter;
module.exports.AuthManager = AuthManager;
module.exports.createManager = createManager;
