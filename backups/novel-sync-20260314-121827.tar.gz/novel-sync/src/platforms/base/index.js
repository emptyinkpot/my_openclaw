/**
 * 基类模块索引
 * 
 * 提供平台模块的基础类
 * 
 * @module platforms/base
 */

const { BrowserBase } = require('./browser');
const AuthBase = require('./auth');
const ElementBase = require('./element');

module.exports = {
  BrowserBase,
  AuthBase,
  ElementBase,
};
