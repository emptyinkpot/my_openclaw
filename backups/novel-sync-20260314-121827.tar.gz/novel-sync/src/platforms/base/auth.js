/**
 * 认证基类
 * 
 * 提供通用的登录状态恢复、检查和备份功能
 * 
 * @module platforms/base/auth
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');
const logger = require('../../utils/logger');

class AuthBase {
  /**
   * @param {string} site - 平台名称
   * @param {BrowserBase} browserInstance - 浏览器实例
   */
  constructor(site, browserInstance) {
    this.site = site;
    this.siteConfig = config.getSiteConfig(site);
    this.browser = browserInstance;
    this.accountId = browserInstance.accountId;
    this.log = logger.create(`auth:${site}`);
  }
  
  /**
   * 获取备份文件路径
   * @returns {string}
   */
  getBackupPath() {
    return this.siteConfig.getBackupFile(this.accountId);
  }
  
  /**
   * 检查备份文件是否存在
   * @returns {boolean}
   */
  hasBackup() {
    const backupPath = this.getBackupPath();
    const exists = fs.existsSync(backupPath);
    
    if (exists) {
      const stats = fs.statSync(backupPath);
      const age = Date.now() - stats.mtimeMs;
      const ageHours = Math.round(age / (1000 * 60 * 60));
      this.log.debug(`备份文件存在，年龄: ${ageHours}小时`);
    }
    
    return exists;
  }
  
  /**
   * 恢复登录状态
   * 子类可覆盖此方法实现特定平台的恢复逻辑
   * 
   * @param {Object} options - 恢复选项
   */
  async restoreLogin(options = {}) {
    const page = this.browser.getPage();
    const backupPath = this.getBackupPath();
    
    if (!this.hasBackup()) {
      throw new Error(`备份文件不存在: ${backupPath}\n请先运行备份脚本保存登录状态`);
    }
    
    this.log.info('开始恢复登录状态...');
    
    // 读取备份
    const backup = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));
    
    // 先访问首页
    const homeUrl = this.siteConfig.urls?.home || this.siteConfig.url;
    await page.goto(homeUrl, { timeout: 30000 });
    await page.waitForTimeout(2000);
    
    // 恢复 localStorage
    if (backup.localStorage) {
      await page.evaluate((items) => {
        for (const [key, value] of Object.entries(items)) {
          // 🔴 重要：直接设置，不使用 clear()
          localStorage.setItem(key, value);
        }
      }, backup.localStorage);
      
      this.log.debug(`已恢复 ${Object.keys(backup.localStorage).length} 个 localStorage 项`);
    }
    
    // 恢复 cookies（如果有）
    if (backup.cookies && this.browser.browser) {
      await this.browser.browser.addCookies(backup.cookies);
      this.log.debug(`已恢复 ${backup.cookies.length} 个 cookies`);
    }
    
    // 刷新页面使登录状态生效
    await page.reload();
    await page.waitForTimeout(3000);
    
    this.log.success('登录状态恢复完成');
    return true;
  }
  
  /**
   * 检查登录状态
   * 子类应覆盖此方法实现特定的检查逻辑
   * 
   * @returns {Promise<{isLoggedIn: boolean, message: string}>}
   */
  async checkLogin() {
    const page = this.browser.getPage();
    
    // 默认检查方法：查找登录按钮
    const loginSelector = this.siteConfig.selectors?.loginButton;
    
    if (loginSelector) {
      const hasLoginBtn = await page.locator(loginSelector).first().isVisible().catch(() => false);
      return {
        isLoggedIn: !hasLoginBtn,
        message: !hasLoginBtn ? '已登录' : '未登录',
      };
    }
    
    return { isLoggedIn: false, message: '无法确定登录状态' };
  }
  
  /**
   * 备份当前登录状态
   * @returns {Object} 备份数据
   */
  async backupLogin() {
    const page = this.browser.getPage();
    
    this.log.info('开始备份登录状态...');
    
    // 获取 localStorage
    const localStorage = await page.evaluate(() => {
      const items = {};
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        items[key] = window.localStorage.getItem(key);
      }
      return items;
    });
    
    // 获取 cookies
    let cookies = [];
    if (this.browser.browser) {
      cookies = await this.browser.browser.cookies();
    }
    
    const backup = {
      site: this.site,
      accountId: this.accountId,
      timestamp: new Date().toISOString(),
      localStorage,
      cookies,
    };
    
    // 保存备份
    const backupPath = this.getBackupPath();
    const backupDir = path.dirname(backupPath);
    
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    fs.writeFileSync(backupPath, JSON.stringify(backup, null, 2));
    
    this.log.success(`登录状态已备份: ${backupPath}`);
    this.log.info(`localStorage: ${Object.keys(localStorage).length} 项`);
    this.log.info(`cookies: ${cookies.length} 项`);
    
    return backup;
  }
  
  /**
   * 确保已登录
   * 自动恢复登录状态，如果恢复失败则抛出错误
   */
  async ensureLoggedIn() {
    const loginStatus = await this.checkLogin();
    
    if (loginStatus.isLoggedIn) {
      this.log.info('已登录，无需恢复');
      return true;
    }
    
    this.log.info('未登录，尝试恢复...');
    
    if (!this.hasBackup()) {
      throw new Error(`登录已过期且无备份文件，请手动登录后运行备份脚本`);
    }
    
    await this.restoreLogin();
    
    // 再次检查
    const status = await this.checkLogin();
    if (!status.isLoggedIn) {
      throw new Error(`登录恢复失败: ${status.message}`);
    }
    
    return true;
  }
}

module.exports = AuthBase;
