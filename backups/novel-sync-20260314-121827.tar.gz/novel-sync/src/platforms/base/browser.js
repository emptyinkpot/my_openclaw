/**
 * 浏览器基类
 * 
 * 提供通用的浏览器启动、管理和清理功能
 * 所有平台模块继承此类
 * 
 * 设计原则：
 * - 统一配置：窗口大小、启动参数集中管理
 * - 低耦合：平台只需继承，无需重复实现
 * - 一致性：所有平台浏览器行为一致
 * 
 * @module platforms/base/browser
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const config = require('../../config');
const logger = require('../../utils/logger');

// ============================================================
// 统一浏览器配置
// ============================================================

/**
 * 默认窗口大小
 * 🔴 重要：所有平台统一使用此大小
 */
const DEFAULT_VIEWPORT = { width: 1920, height: 1080 };

/**
 * 默认启动参数
 */
const DEFAULT_ARGS = [
  '--no-sandbox',
  '--disable-session-crashed-bubble',
  '--hide-crash-restore-bubble',
];

/**
 * 锁文件列表
 */
const LOCK_FILES = ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'Lock'];

// ============================================================
// 浏览器基类
// ============================================================

class BrowserBase {
  /**
   * @param {string} site - 平台名称
   * @param {Object} options - 配置选项
   */
  constructor(site, options = {}) {
    this.site = site;
    this.siteConfig = config.SITES[site] || {};
    this.accountId = options.accountId || options.account || 'default';
    this.browserDir = this._getBrowserDir();
    this.headless = options.headless ?? false;
    this.viewport = options.viewport || DEFAULT_VIEWPORT;
    this.browser = null;
    this.page = null;
    this.log = logger.create(`browser:${site}`);
  }
  
  /**
   * 获取浏览器数据目录
   */
  _getBrowserDir() {
    if (this.siteConfig.getBrowserDir) {
      return this.siteConfig.getBrowserDir(this.accountId);
    }
    return path.join(config.PATHS.GLOBAL_BROWSER, `${this.site}-${this.accountId}`);
  }
  
  /**
   * 清理锁文件
   */
  cleanLockFiles() {
    let cleaned = 0;
    
    for (const filename of LOCK_FILES) {
      const filePath = path.join(this.browserDir, filename);
      try {
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
          cleaned++;
        }
      } catch (e) {
        // 忽略清理失败
      }
    }
    
    if (cleaned > 0) {
      this.log.debug(`已清理 ${cleaned} 个锁文件`);
    }
  }
  
  /**
   * 确保浏览器数据目录存在
   */
  ensureBrowserDir() {
    if (!fs.existsSync(this.browserDir)) {
      fs.mkdirSync(this.browserDir, { recursive: true });
    }
  }
  
  /**
   * 启动浏览器
   * 
   * @returns {Promise<{browser: Browser, page: Page}>}
   */
  async launch() {
    this.ensureBrowserDir();
    this.cleanLockFiles();
    
    const startTime = Date.now();
    this.log.info(`启动浏览器 (${this.viewport.width}x${this.viewport.height})...`);
    
    try {
      const args = [
        ...DEFAULT_ARGS,
        `--window-size=${this.viewport.width},${this.viewport.height}`,
      ];
      
      this.browser = await chromium.launchPersistentContext(this.browserDir, {
        headless: this.headless,
        viewport: this.viewport,
        args,
      });
      
      this.page = this.browser.pages()[0] || await this.browser.newPage();
      
      const elapsed = Date.now() - startTime;
      this.log.success(`浏览器启动成功 (${elapsed}ms)`);
      
      return { browser: this.browser, page: this.page };
    } catch (error) {
      this.log.error(`浏览器启动失败: ${error.message}`);
      throw error;
    }
  }
  
  /**
   * 关闭浏览器
   */
  async close() {
    if (this.browser) {
      try {
        await this.browser.close();
        this.log.info('浏览器已关闭');
      } catch (e) {
        this.log.warn(`关闭浏览器时出错: ${e.message}`);
      }
      this.browser = null;
      this.page = null;
    }
  }
  
  /**
   * 获取当前页面
   */
  getPage() {
    if (!this.page) {
      throw new Error('浏览器未启动，请先调用 launch()');
    }
    return this.page;
  }
  
  /**
   * 导航到 URL
   */
  async goto(urlOrKey, options = {}) {
    const page = this.getPage();
    
    let url = urlOrKey;
    if (this.siteConfig.urls && this.siteConfig.urls[urlOrKey]) {
      url = this.siteConfig.urls[urlOrKey];
    }
    
    const timeout = options.timeout || 30000;
    
    this.log.info(`导航到: ${url}`);
    await page.goto(url, { timeout, waitUntil: options.waitUntil || 'domcontentloaded' });
    
    if (options.waitFor) {
      await page.waitForTimeout(options.waitFor);
    }
  }
  
  /**
   * 等待
   */
  async wait(ms) {
    await this.getPage().waitForTimeout(ms);
  }
  
  /**
   * 截图
   */
  async screenshot(name) {
    const page = this.getPage();
    const dir = '/tmp/novel-sync-screenshots';
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    const filename = `${this.site}-${name}-${Date.now()}.png`;
    const filepath = path.join(dir, filename);
    
    await page.screenshot({ path: filepath, fullPage: true });
    this.log.info(`截图: ${filepath}`);
    
    return filepath;
  }
}

// ============================================================
// 快速启动函数（无需实例化）
// ============================================================

/**
 * 快速启动浏览器
 * 
 * @param {string} site - 平台名称
 * @param {Object} options - 选项
 * @returns {Promise<{browser: Browser, page: Page}>}
 */
async function launchBrowser(site, options = {}) {
  const browser = new BrowserBase(site, options);
  return browser.launch();
}

/**
 * 清理指定平台的锁文件
 */
function cleanBrowserLocks(site, accountId = 'default') {
  const siteConfig = config.SITES[site];
  if (!siteConfig) return;
  
  const browserDir = siteConfig.getBrowserDir 
    ? siteConfig.getBrowserDir(accountId)
    : path.join(config.PATHS.GLOBAL_BROWSER, `${site}-${accountId}`);
  
  for (const filename of LOCK_FILES) {
    try {
      const filePath = path.join(browserDir, filename);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (e) {
      // 忽略
    }
  }
}

module.exports = {
  BrowserBase,
  DEFAULT_VIEWPORT,
  DEFAULT_ARGS,
  LOCK_FILES,
  launchBrowser,
  cleanBrowserLocks,
};
