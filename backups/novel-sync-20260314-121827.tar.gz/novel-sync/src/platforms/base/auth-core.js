/**
 * 认证核心模块
 * 
 * 设计原则：
 * - 高效跳转：直接跳转目标页面，不绕路
 * - 低耦合：不依赖浏览器实例，接受 page 参数
 * - 可组合：函数粒度细，可灵活组合
 * 
 * 架构：
 * - AuthStore：存储层，只负责数据保存/加载
 * - PlatformAdapter：适配层，定义平台特定行为
 * - AuthManager：管理层，组合存储和适配器
 * 
 * @module platforms/base/auth-core
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

// ============================================================
// 存储层：AuthStore
// ============================================================

/**
 * 账号存储类
 * 
 * 只负责数据的保存和加载，不涉及浏览器操作
 */
class AuthStore {
  constructor(platform) {
    this.platform = platform;
    this.storeDir = config.PATHS.GLOBAL_COOKIES || '/workspace/projects/cookies-accounts';
    
    if (!fs.existsSync(this.storeDir)) {
      fs.mkdirSync(this.storeDir, { recursive: true });
    }
  }
  
  /**
   * 生成文件名
   */
  _generateFileName() {
    const now = new Date();
    const date = now.toISOString().slice(0, 10).replace(/-/g, '');
    const time = now.toTimeString().slice(0, 8).replace(/:/g, '');
    return `${this.platform}-${date}-${time}.json`;
  }
  
  /**
   * 获取所有账号文件
   */
  listFiles() {
    return fs.readdirSync(this.storeDir)
      .filter(f => {
        const newPattern = new RegExp(`^${this.platform}-\\d{8}-\\d{6}\\.json$`);
        const oldPattern = new RegExp(`^${this.platform}-account-[^.]+\\.json$`);
        return newPattern.test(f) || oldPattern.test(f);
      })
      .map(f => ({
        name: f,
        path: path.join(this.storeDir, f),
        mtime: fs.statSync(path.join(this.storeDir, f)).mtime,
      }))
      .sort((a, b) => b.mtime - a.mtime);
  }
  
  /**
   * 加载账号数据
   * 
   * @param {string} identifier - 用户名或文件名
   * @returns {Object|null}
   */
  load(identifier) {
    // 如果是文件名，直接加载
    if (identifier?.endsWith('.json')) {
      const filePath = path.join(this.storeDir, identifier);
      if (fs.existsSync(filePath)) {
        return this._parseFile(filePath);
      }
    }
    
    // 按用户名查找
    if (identifier) {
      for (const f of this.listFiles()) {
        const data = this._parseFile(f.path);
        if (data?.userName === identifier) {
          return data;
        }
      }
    }
    
    // 返回最新的账号
    const files = this.listFiles();
    if (files.length > 0) {
      return this._parseFile(files[0].path);
    }
    
    return null;
  }
  
  /**
   * 解析文件
   */
  _parseFile(filePath) {
    try {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      return {
        platform: data.platform || this.platform,
        userName: data.userName || data.meta?.userName || null,
        fileName: path.basename(filePath),
        savedAt: data.savedAt || data.createdAt || null,
        expiresAt: data.expiresAt || null,
        cookies: data.cookies || [],
        localStorage: data.localStorage || {},
        sessionStorage: data.sessionStorage || {},
        meta: data.meta || {},
      };
    } catch (e) {
      return null;
    }
  }
  
  /**
   * 保存账号数据
   * 
   * @param {Object} data - 账号数据
   * @returns {Object} 保存结果
   */
  save(data) {
    const fileName = this._generateFileName();
    const filePath = path.join(this.storeDir, fileName);
    
    const content = {
      platform: this.platform,
      userName: data.userName,
      savedAt: new Date().toISOString(),
      expiresAt: data.expiresAt,
      cookies: data.cookies,
      localStorage: data.localStorage,
      sessionStorage: data.sessionStorage,
      meta: data.meta,
    };
    
    fs.writeFileSync(filePath, JSON.stringify(content, null, 2));
    
    return {
      success: true,
      fileName,
      filePath,
      userName: data.userName,
    };
  }
  
  /**
   * 删除账号
   */
  delete(fileName) {
    const filePath = path.join(this.storeDir, fileName);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  }
  
  /**
   * 检查账号状态
   */
  check(identifier) {
    const data = this.load(identifier);
    
    if (!data) {
      return { exists: false, valid: false, userName: null, message: '无账号' };
    }
    
    const { userName, fileName, expiresAt, cookies } = data;
    
    if (!cookies?.length) {
      return { exists: true, valid: false, userName, fileName, message: '无cookies' };
    }
    
    if (expiresAt) {
      const expires = new Date(expiresAt);
      const now = new Date();
      
      if (expires < now) {
        return { exists: true, valid: false, expired: true, userName, fileName, message: `已过期(${expires.toLocaleDateString()})` };
      }
      
      const daysLeft = Math.floor((expires - now) / (86400000));
      return { exists: true, valid: true, userName, fileName, message: daysLeft <= 7 ? `${daysLeft}天后过期` : `有效至${expires.toLocaleDateString()}` };
    }
    
    return { exists: true, valid: true, userName, fileName, message: '有效' };
  }
  
  /**
   * 列出所有账号
   */
  list() {
    return this.listFiles()
      .map(f => this.check(f.name))
      .filter(a => a.exists);
  }
}

// ============================================================
// 适配层：PlatformAdapter
// ============================================================

/**
 * 平台适配器基类
 * 
 * 定义平台特定的行为，子类需要实现
 */
class PlatformAdapter {
  constructor(options = {}) {
    this.name = options.name || 'unknown';
    this.domains = options.domains || [];
    this.homeUrl = options.homeUrl || '';
  }
  
  /**
   * 检查登录状态（子类实现）
   * 
   * @param {Page} page
   * @returns {Promise<{isLoggedIn: boolean, userName: string|null}>}
   */
  async checkLogin(page) {
    throw new Error('子类需要实现 checkLogin');
  }
  
  /**
   * 恢复登录状态（子类实现）
   * 
   * @param {Page} page
   * @param {Object} data - 账号数据
   * @returns {Promise<boolean>}
   */
  async restore(page, data) {
    throw new Error('子类需要实现 restore');
  }
  
  /**
   * 判断是否在平台域名
   */
  isOnPlatform(url) {
    return this.domains.some(d => url.includes(d));
  }
  
  /**
   * 确保在平台页面
   */
  async ensureOnPlatform(page) {
    if (!this.isOnPlatform(page.url())) {
      await page.goto(this.homeUrl, { waitUntil: 'domcontentloaded' });
    }
  }
}

// ============================================================
// 管理层：AuthManager
// ============================================================

/**
 * 认证管理器
 * 
 * 组合存储和适配器，提供统一接口
 */
class AuthManager {
  /**
   * @param {AuthStore} store
   * @param {PlatformAdapter} adapter
   */
  constructor(store, adapter) {
    this.store = store;
    this.adapter = adapter;
  }
  
  // ============================================================
  // 账号管理
  // ============================================================
  
  /**
   * 列出所有账号
   */
  listAccounts() {
    return this.store.list();
  }
  
  /**
   * 检查账号状态
   */
  checkAccount(identifier) {
    return this.store.check(identifier);
  }
  
  /**
   * 删除账号
   */
  deleteAccount(fileName) {
    return this.store.delete(fileName);
  }
  
  // ============================================================
  // 登录状态检查
  // ============================================================
  
  /**
   * 检查页面登录状态
   * 
   * @param {Page} page
   * @returns {Promise<{isLoggedIn: boolean, userName: string|null}>}
   */
  async checkLogin(page) {
    await this.adapter.ensureOnPlatform(page);
    await page.waitForTimeout(1000);
    return this.adapter.checkLogin(page);
  }
  
  // ============================================================
  // 登录状态恢复（高效跳转）
  // ============================================================
  
  /**
   * 恢复登录状态
   * 
   * 高效策略：
   * 1. 如果已在目标页面，直接恢复
   * 2. 否则先恢复 cookies，再跳转
   * 
   * @param {Page} page
   * @param {string} identifier - 用户名或文件名
   * @param {Object} options
   * @param {string} options.targetUrl - 目标页面（可选）
   * @returns {Promise<{success: boolean, userName: string}>}
   */
  async restore(page, identifier, options = {}) {
    const data = this.store.load(identifier);
    
    if (!data) {
      return { success: false, message: '无账号数据' };
    }
    
    const { targetUrl } = options;
    
    // 高效恢复策略
    if (targetUrl && this.adapter.isOnPlatform(targetUrl)) {
      // 有目标页面且在平台内，先恢复cookies再跳转
      await this._restoreCookies(page, data);
      await page.goto(targetUrl, { waitUntil: 'domcontentloaded' });
      await this._restoreStorage(page, data);
    } else {
      // 无目标页面，走标准恢复流程
      await this.adapter.restore(page, data);
    }
    
    // 验证登录状态
    await page.waitForTimeout(1500);
    const { isLoggedIn, userName } = await this.adapter.checkLogin(page);
    
    return {
      success: isLoggedIn,
      userName: userName || data.userName,
    };
  }
  
  /**
   * 恢复 cookies
   */
  async _restoreCookies(page, data) {
    if (data.cookies?.length) {
      await page.context().addCookies(data.cookies);
    }
  }
  
  /**
   * 恢复 storage
   */
  async _restoreStorage(page, data) {
    if (data.localStorage && Object.keys(data.localStorage).length > 0) {
      await page.evaluate((items) => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, data.localStorage);
    }
  }
  
  // ============================================================
  // 登录状态保存
  // ============================================================
  
  /**
   * 保存登录状态
   * 
   * @param {Page} page
   * @param {string} userName - 用户名（可选，自动获取）
   * @returns {Promise<{success: boolean, userName: string, fileName: string}>}
   */
  async save(page, userName) {
    // 检查登录状态并获取用户名
    const { isLoggedIn, userName: detectedName } = await this.adapter.checkLogin(page);
    
    if (!isLoggedIn) {
      return { success: false, message: '未登录' };
    }
    
    const finalUserName = userName || detectedName || '未知用户';
    
    // 计算过期时间
    const cookies = await page.context().cookies();
    const expiresAt = this._calculateExpires(cookies);
    
    // 获取 storage
    const [localStorage, sessionStorage] = await Promise.all([
      this._getStorage(page, 'localStorage'),
      this._getStorage(page, 'sessionStorage'),
    ]);
    
    // 保存
    const result = this.store.save({
      userName: finalUserName,
      expiresAt,
      cookies,
      localStorage,
      sessionStorage,
      meta: {
        url: page.url(),
        savedAt: new Date().toISOString(),
      },
    });
    
    return {
      success: true,
      userName: finalUserName,
      fileName: result.fileName,
      expiresAt,
    };
  }
  
  /**
   * 计算过期时间
   */
  _calculateExpires(cookies) {
    const now = Date.now();
    const minValid = now + 7 * 86400000;
    
    const validExpires = cookies
      .map(c => c.expires * 1000)
      .filter(t => t > minValid);
    
    if (!validExpires.length) {
      const date = new Date();
      date.setFullYear(date.getFullYear() + 1);
      return date.toISOString();
    }
    
    return new Date(Math.min(...validExpires)).toISOString();
  }
  
  /**
   * 获取 storage
   */
  async _getStorage(page, type) {
    return page.evaluate((t) => {
      const storage = t === 'localStorage' ? localStorage : sessionStorage;
      const items = {};
      for (let i = 0; i < storage.length; i++) {
        const key = storage.key(i);
        items[key] = storage.getItem(key);
      }
      return items;
    }, type).catch(() => ({}));
  }
  
  // ============================================================
  // 等待登录
  // ============================================================
  
  /**
   * 等待用户手动登录
   * 
   * @param {Page} page
   * @param {number} timeout - 超时时间（毫秒）
   * @returns {Promise<{success: boolean, userName: string|null}>}
   */
  async waitForLogin(page, timeout = 120000) {
    console.log(`[${this.adapter.name}] 等待登录...`);
    
    const start = Date.now();
    
    while (Date.now() - start < timeout) {
      const { isLoggedIn, userName } = await this.adapter.checkLogin(page);
      if (isLoggedIn) {
        console.log(`[${this.adapter.name}] 登录成功: ${userName}`);
        return { success: true, userName };
      }
      await page.waitForTimeout(2000);
    }
    
    return { success: false, userName: null };
  }
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  AuthStore,
  PlatformAdapter,
  AuthManager,
  
  /**
   * 创建认证管理器的便捷方法
   */
  createManager(platform, adapter) {
    const store = new AuthStore(platform);
    return new AuthManager(store, adapter);
  },
};
