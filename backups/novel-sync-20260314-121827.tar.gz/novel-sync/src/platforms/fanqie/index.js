/**
 * 番茄小说 - 统一模块导出
 * 
 * 模块结构：
 * - browser: 浏览器管理
 * - auth: 登录认证
 * - works: 作品管理
 * 
 * 来源：重构自 src/tasks/fanqie.js
 * 参考：src/platforms/baimeng/index.js
 */

const browser = require('./browser');
const auth = require('./auth');
const works = require('./works');

// 平台信息
const platform = {
  name: '番茄小说',
  id: 'fanqie',
  url: 'https://fanqienovel.com',
};

module.exports = {
  // 平台信息
  platform,
  
  // 模块
  browser,
  auth,
  works,
};
