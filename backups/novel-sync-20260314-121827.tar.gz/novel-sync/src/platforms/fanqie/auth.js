/**
 * 番茄小说 - 认证模块
 * 
 * 简洁的 API，基于服务层
 * 
 * @module platforms/fanqie/auth
 */

const { authService } = require('../../services');

// ============================================================
// 账号管理
// ============================================================

function listAccounts() {
  return authService.listAccounts('fanqie');
}

function checkAccount(userName) {
  return authService.checkAccount('fanqie', userName);
}

// ============================================================
// 登录操作
// ============================================================

/**
 * 恢复登录状态
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} userName - 用户名（可选）
 * @param {Object} options - 选项
 * @param {string} options.targetUrl - 目标页面（高效跳转）
 */
async function restoreLogin(page, userName, options = {}) {
  return authService.login({
    platform: 'fanqie',
    userName,
    targetUrl: options.targetUrl,
    page, // 使用传入的 page
  });
}

/**
 * 检查登录状态
 */
async function checkLogin(page) {
  const adapter = require('./adapter');
  return adapter.checkLogin(page);
}

/**
 * 保存登录状态
 */
async function saveLogin(page, userName) {
  return authService.saveAccount({
    platform: 'fanqie',
    page,
    userName,
  });
}

/**
 * 等待登录
 */
async function waitForLogin(page, timeout = 120000) {
  return authService.waitForLogin({
    platform: 'fanqie',
    page,
    timeout,
  });
}

/**
 * 登录并保存（一站式）
 */
async function loginAndSave(page, timeout = 120000) {
  const result = await waitForLogin(page, timeout);
  
  if (!result.success) {
    return { success: false, message: '登录超时' };
  }
  
  return saveLogin(page, result.userName);
}

module.exports = {
  listAccounts,
  checkAccount,
  restoreLogin,
  checkLogin,
  saveLogin,
  waitForLogin,
  loginAndSave,
};
