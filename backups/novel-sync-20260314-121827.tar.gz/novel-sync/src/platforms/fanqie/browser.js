/**
 * 番茄小说 - 浏览器模块
 * 
 * 功能：
 * - 清理锁文件
 * - 启动浏览器
 * 
 * 来源：重构自 src/tasks/fanqie.js
 * 继承：src/platforms/base/browser.js
 */

const { BrowserBase, DEFAULT_VIEWPORT } = require('../base/browser');

/**
 * 番茄浏览器类
 */
class FanqieBrowser extends BrowserBase {
  constructor(options = {}) {
    super('fanqie', options);
  }
}

/**
 * 启动浏览器（便捷函数）
 * 
 * @param {Object} options - 选项
 * @param {string|number} options.account - 账号ID
 * @param {Object} options.viewport - 窗口大小，默认 1920x1080
 * @returns {Promise<{browser: Browser, page: Page}>}
 */
async function launch(options = {}) {
  const browser = new FanqieBrowser(options);
  return browser.launch();
}

/**
 * 关闭浏览器
 */
async function close(browser) {
  try {
    await browser.close();
  } catch (e) {
    // 忽略
  }
}

/**
 * 清理锁文件
 */
function cleanLockFiles(browserDir) {
  const { cleanBrowserLocks } = require('../base/browser');
  cleanBrowserLocks('fanqie', browserDir);
}

module.exports = {
  FanqieBrowser,
  launch,
  close,
  cleanLockFiles,
  DEFAULT_VIEWPORT,
};
