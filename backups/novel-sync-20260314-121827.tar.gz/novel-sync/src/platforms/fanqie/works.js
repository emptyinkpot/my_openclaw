/**
 * 番茄小说 - 作品模块
 * 
 * 功能：
 * - 获取作品列表
 * - 查找作品ID
 * - 获取章节列表
 * 
 * 来源：重构自 src/tasks/fanqie.js
 * 参考：src/platforms/baimeng/works.js
 */

const fs = require('fs');
const path = require('path');
const config = require('../../config');

const SITE = config.SITES.fanqie;

// 缓存文件路径
const CACHE_DIR = path.join(config.PATHS.STORAGE, 'cache');
const WORKS_CACHE_FILE = path.join(CACHE_DIR, 'fanqie-works-cache.json');

/**
 * 获取作品列表
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @param {boolean} options.useCache - 是否使用缓存，默认 true
 * @returns {Promise<Array<{id: string, title: string, status: string}>>}
 */
async function getWorks(page, options = {}) {
  const { useCache = true } = options;
  
  // 使用缓存
  if (useCache && fs.existsSync(WORKS_CACHE_FILE)) {
    const cache = JSON.parse(fs.readFileSync(WORKS_CACHE_FILE, 'utf-8'));
    const cacheAge = Date.now() - cache.timestamp;
    
    // 缓存有效期 24 小时
    if (cacheAge < 24 * 60 * 60 * 1000) {
      console.log('(使用缓存)');
      return cache.works;
    }
  }
  
  console.log('[番茄] 获取作品列表...');
  
  // 访问作品管理页面
  await page.goto(SITE.urls.writer, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(3000);
  
  // 提取作品列表
  const works = await page.evaluate(() => {
    const results = [];
    
    // 尝试多种选择器
    const selectors = [
      '[class*="book"]',
      '[class*="work"]',
      '[class*="item"]',
      'a[href*="book"]'
    ];
    
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach(el => {
        // 查找标题元素
        const titleEl = el.querySelector('[class*="title"], [class*="name"], h3, h4, h5') || el;
        let title = titleEl?.innerText?.trim();
        
        if (title && title.length > 0 && title.length < 100) {
          // 清理标题
          title = title.split('\n')[0].trim();
          
          // 过滤无效标题
          if (!title.includes('作品小贴士') && title.length > 2) {
            // 尝试提取 ID
            const href = el.href || el.querySelector('a')?.href || '';
            const idMatch = href.match(/book[=/]([a-zA-Z0-9]+)/) || href.match(/id=([a-zA-Z0-9]+)/);
            
            results.push({
              id: idMatch ? idMatch[1] : '',
              title,
              status: ''
            });
          }
        }
      });
    }
    
    // 去重
    const seen = new Set();
    return results.filter(w => {
      if (seen.has(w.title)) return false;
      seen.add(w.title);
      return true;
    });
  });
  
  console.log(`[番茄] 获取到 ${works.length} 个作品`);
  works.forEach((w, i) => console.log(`  ${i + 1}. ${w.title}`));
  
  // 保存缓存
  if (!fs.existsSync(CACHE_DIR)) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
  }
  fs.writeFileSync(WORKS_CACHE_FILE, JSON.stringify({
    timestamp: Date.now(),
    works
  }, null, 2));
  
  return works;
}

/**
 * 查找作品
 * 
 * @param {Array} works - 作品列表
 * @param {string} input - 用户输入（ID 或标题关键词）
 * @returns {Object|null} 匹配的作品
 */
function findWork(works, input) {
  if (!input) return null;
  
  // 尝试按 ID 匹配
  const byId = works.find(w => w.id === input);
  if (byId) return byId;
  
  // 尝试按标题精确匹配
  const byTitle = works.find(w => w.title === input);
  if (byTitle) return byTitle;
  
  // 尝试按标题模糊匹配
  const byKeyword = works.find(w => 
    w.title.includes(input) || input.includes(w.title)
  );
  
  return byKeyword || null;
}

/**
 * 获取章节列表
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} workId - 作品ID
 * @returns {Promise<Array<{id: string, title: string, index: number}>>}
 */
async function getChapters(page, workId) {
  console.log('[番茄] 获取章节列表...');
  
  // 访问章节管理页面
  const url = `https://fanqienovel.com/main/writer/chapter-manage?bookId=${workId}`;
  await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(3000);
  
  // 提取章节列表
  const chapters = await page.evaluate(() => {
    const results = [];
    let index = 0;
    
    document.querySelectorAll('[class*="chapter"], a[href*="chapter"]').forEach(el => {
      const title = el.innerText?.trim().split('\n')[0];
      
      if (title && title.length > 0 && title.length < 100) {
        // 提取章节号
        const numMatch = title.match(/第?(\d+)/);
        const num = numMatch ? parseInt(numMatch[1]) : index + 1;
        
        // 提取 ID
        const href = el.href || '';
        const idMatch = href.match(/chapter[=/]([a-zA-Z0-9]+)/) || href.match(/id=([a-zA-Z0-9]+)/);
        
        results.push({
          id: idMatch ? idMatch[1] : '',
          title,
          index: num,
          order: index++
        });
      }
    });
    
    return results;
  });
  
  console.log(`[番茄] 获取到 ${chapters.length} 个章节`);
  
  return chapters;
}

/**
 * 查找章节
 * 
 * @param {Array} chapters - 章节列表
 * @param {string|number} input - 用户输入（章节号或标题）
 * @returns {Object|null} 匹配的章节
 */
function findChapter(chapters, input) {
  if (!input) return null;
  
  // 尝试按章节号匹配
  const chapterNum = typeof input === 'number' ? input : parseInt(input);
  if (!isNaN(chapterNum)) {
    const byNum = chapters.find(c => c.index === chapterNum);
    if (byNum) return byNum;
  }
  
  // 尝试按标题匹配
  const byTitle = chapters.find(c => 
    c.title === input || c.title.includes(input)
  );
  
  return byTitle || null;
}

/**
 * 清除缓存
 */
function clearCache() {
  if (fs.existsSync(WORKS_CACHE_FILE)) {
    fs.unlinkSync(WORKS_CACHE_FILE);
  }
}

module.exports = {
  getWorks,
  findWork,
  getChapters,
  findChapter,
  clearCache,
};
