/**
 * 番茄小说 - 平台适配器（新版）
 * 
 * 低耦合、高鲁棒性
 * 
 * @module platforms/fanqie/adapter
 */

const { logger, safeCall } = require('../../core');

const log = logger.create('fanqie-adapter');

/**
 * 番茄小说适配器
 */
const fanqieAdapter = {
  // 平台信息
  name: '番茄小说',
  homeUrl: 'https://fanqienovel.com',
  domains: ['fanqienovel.com', '.fanqienovel.com'],
  
  /**
   * 检查登录状态
   * 
   * @param {Page} page
   * @returns {Promise<{isLoggedIn: boolean, userName: string|null}>}
   */
  async checkLogin(page) {
    try {
      // 确保在平台页面
      const url = page.url();
      if (!this.domains.some(d => url.includes(d))) {
        await page.goto(this.homeUrl, { waitUntil: 'domcontentloaded', timeout: 15000 });
        await page.waitForTimeout(2000);
      }
      
      // 检查登录按钮
      const hasLoginBtn = await safeCall(
        () => page.locator('button:has-text("登录"), a:has-text("登录")').first().isVisible(),
        false
      );
      
      if (hasLoginBtn) {
        return { isLoggedIn: false, userName: null };
      }
      
      // 尝试获取用户名
      const userName = await this._getUserName(page);
      
      return { isLoggedIn: true, userName };
    } catch (error) {
      log.error('检查登录状态失败', error.message);
      return { isLoggedIn: false, userName: null };
    }
  },
  
  /**
   * 获取用户名
   * 
   * 多种方式尝试，提高成功率
   */
  async _getUserName(page) {
    // 方式1: hover 头像获取
    const fromAvatar = await safeCall(async () => {
      const avatar = page.locator('[class*="avatar"], [class*="Avatar"]').first();
      if (await avatar.isVisible({ timeout: 1000 })) {
        await avatar.hover();
        await page.waitForTimeout(500);
        
        const nameEl = page.locator('[class*="dropdown"] [class*="name"], [class*="menu"] [class*="name"]').first();
        if (await nameEl.isVisible({ timeout: 500 })) {
          const text = await nameEl.textContent();
          if (text?.trim()) return text.trim();
        }
      }
      return null;
    }, null);
    
    if (fromAvatar) return fromAvatar;
    
    // 方式2: 从页面元素获取
    const selectors = [
      '[class*="userName"]',
      '[class*="user-name"]',
      '[class*="nickname"]',
    ];
    
    for (const sel of selectors) {
      const text = await safeCall(async () => {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 500 })) {
          const t = await el.textContent();
          return t?.trim();
        }
        return null;
      }, null);
      
      if (text && text.length >= 2) return text;
    }
    
    return null;
  },
  
  /**
   * 恢复登录状态
   * 
   * @param {Page} page
   * @param {Object} data - 账号数据
   */
  async restore(page, data) {
    // 恢复 cookies
    if (data.cookies?.length) {
      await page.context().addCookies(data.cookies);
    }
    
    // 访问页面
    const targetUrl = data.meta?.url || this.homeUrl;
    await page.goto(targetUrl, { waitUntil: 'domcontentloaded' });
    
    // 恢复 localStorage
    if (data.localStorage && Object.keys(data.localStorage).length > 0) {
      await page.evaluate((items) => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, data.localStorage);
      
      await page.reload({ waitUntil: 'domcontentloaded' });
    }
    
    await page.waitForTimeout(1500);
  },
  
  /**
   * 判断是否在平台域名
   */
  isOnPlatform(url) {
    return this.domains.some(d => url.includes(d));
  },
};

module.exports = fanqieAdapter;
