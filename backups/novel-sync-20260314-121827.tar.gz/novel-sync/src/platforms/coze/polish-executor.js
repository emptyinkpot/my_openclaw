/**
 * 润色执行模块
 * 
 * 提供统一的润色流程，避免重复代码
 * 
 * 功能：
 * - 打开润色网站
 * - 导入资源库（可选）
 * - 粘贴内容并润色
 * - 等待进度条完成
 * - 提取润色结果
 * 
 * 使用：
 *   const { executePolish } = require('./polish-executor');
 *   const result = await executePolish(page, content, options);
 */

const fs = require('fs');
const path = require('path');

// 润色网站地址
const POLISH_SITE = 'https://7d4jcknzqk.coze.site';

// 默认资源库路径
const DEFAULT_RESOURCE_PATH = '/workspace/projects/workspace/projects/novel-sync/storage/polish/resources.json';

/**
 * 执行润色（完整流程）
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} content - 待润色内容
 * @param {Object} options - 选项
 * @param {string} options.resourcePath - 资源库路径（可选）
 * @param {boolean} options.importResources - 是否导入资源库（默认 false）
 * @param {number} options.timeout - 超时时间（默认 300000ms = 5分钟）
 * @param {Function} options.onProgress - 进度回调
 * @returns {Promise<{success: boolean, title?: string, content?: string, error?: string}>}
 */
async function executePolish(page, content, options = {}) {
  const {
    resourcePath = DEFAULT_RESOURCE_PATH,
    importResources = false,
    timeout = 300000,
    onProgress = () => {}
  } = options;
  
  // 1. 检查内容长度
  if (!content || content.trim().length < 50) {
    return { 
      success: false, 
      error: '内容过短或为空（少于50字），可能是占位符' 
    };
  }
  
  onProgress('打开润色网站...');
  
  // 2. 打开润色网站
  await page.goto(POLISH_SITE, { timeout: 30000 });
  await page.waitForTimeout(5000);
  
  // 3. 导入资源库（可选）
  if (importResources && fs.existsSync(resourcePath)) {
    onProgress('导入资源库...');
    await importResourceLibrary(page, resourcePath);
    
    // 返回润色页面
    await page.goto(POLISH_SITE, { timeout: 30000 });
    await page.waitForTimeout(5000);
  }
  
  // 4. 粘贴内容
  onProgress('粘贴内容...');
  await pasteContent(page, content);
  
  // 5. 点击润色按钮
  onProgress('点击润色按钮...');
  const clickResult = await clickPolishButton(page);
  
  if (!clickResult.success) {
    return { success: false, error: clickResult.error };
  }
  
  // 6. 等待润色完成
  onProgress('等待润色完成...');
  const waitResult = await waitForCompletion(page, timeout, onProgress);
  
  if (!waitResult.success) {
    return { success: false, error: waitResult.error };
  }
  
  // 7. 提取结果
  onProgress('提取润色结果...');
  const result = await extractResult(page);
  
  return result;
}

/**
 * 导入资源库
 */
async function importResourceLibrary(page, resourcePath) {
  // 设置对话框处理器
  page.on('dialog', async dialog => {
    console.log('  对话框:', dialog.message());
    await dialog.accept();
  });
  
  await page.click('button:has-text("资源库")');
  await page.waitForTimeout(2000);
  await page.click('button:has-text("一键导入")');
  await page.waitForTimeout(2000);
  
  const inputs = await page.$$('input[type="file"]');
  await inputs[0].setInputFiles(resourcePath);
  await page.waitForTimeout(5000);
}

/**
 * 粘贴内容到润色网站
 */
async function pasteContent(page, content) {
  const textarea = await page.$('textarea:visible');
  if (!textarea) {
    throw new Error('未找到文本输入框');
  }
  await textarea.fill(content);
  await page.waitForTimeout(2000);
}

/**
 * 点击润色按钮
 */
async function clickPolishButton(page) {
  const btnInfo = await page.evaluate(() => {
    const buttons = Array.from(document.querySelectorAll('button'));
    const btn = buttons.find(b => b.textContent.includes('开始润色'));
    return btn ? { found: true, disabled: btn.disabled } : { found: false };
  });
  
  if (!btnInfo.found) {
    return { success: false, error: '未找到润色按钮' };
  }
  
  if (btnInfo.disabled) {
    return { success: false, error: '润色按钮被禁用（可能需要先粘贴内容）' };
  }
  
  await page.click('button:has-text("开始润色")');
  return { success: true };
}

/**
 * 等待润色完成（检测进度条）
 */
async function waitForCompletion(page, timeout, onProgress) {
  const startTime = Date.now();
  
  // 等待进度条出现
  onProgress('等待进度条出现...');
  let foundProgress = false;
  
  while (!foundProgress && Date.now() - startTime < timeout) {
    await page.waitForTimeout(3000);
    foundProgress = await page.evaluate(() => 
      document.body.innerText.includes('分段处理')
    );
  }
  
  if (!foundProgress) {
    return { success: false, error: '超时：未检测到进度条' };
  }
  
  onProgress('进度条已出现，等待完成...');
  
  // 等待进度条消失
  let hasProgress = true;
  let count = 0;
  
  while (hasProgress && count < 100 && Date.now() - startTime < timeout) {
    await page.waitForTimeout(3000);
    hasProgress = await page.evaluate(() => 
      document.body.innerText.includes('分段处理')
    );
    count++;
    
    if (count % 5 === 0) {
      onProgress(`处理中... (${count * 3}秒)`);
    }
  }
  
  if (hasProgress) {
    return { success: false, error: '超时：进度条未消失' };
  }
  
  // 额外等待结果渲染
  await page.waitForTimeout(10000);
  
  return { success: true };
}

/**
 * 提取润色结果
 */
async function extractResult(page) {
  const result = await page.evaluate(() => {
    const bodyText = document.body.innerText;
    const outputIdx = bodyText.indexOf('输出结果');
    const replaceIdx = bodyText.indexOf('替换记录');
    
    if (outputIdx === -1) {
      return { success: false, error: '找不到输出结果' };
    }
    
    // 提取内容（去除"替换记录"部分）
    let rawContent = replaceIdx > outputIdx 
      ? bodyText.substring(outputIdx, replaceIdx)
      : bodyText.substring(outputIdx);
    
    let lines = rawContent.split('\n');
    
    // 跳过前缀行
    let i = 0;
    while (i < lines.length) {
      const t = lines[i].trim();
      if (t === '输出结果' || t.match(/^\d+\s*字$/) || t === '复制') {
        i++;
        continue;
      }
      break;
    }
    
    // 提取内容
    let contentLines = [];
    while (i < lines.length) {
      contentLines.push(lines[i]);
      i++;
    }
    
    let content = contentLines.join('\n').trim();
    
    // 提取标题（第一行）
    let title = null;
    const firstLine = contentLines[0] || '';
    
    if (firstLine.match(/^第[一二三四五六七八九十\d]+章/)) {
      title = firstLine.trim();
      content = contentLines.slice(1).join('\n').trim();
    }
    
    // 检测占位符
    if (content.includes('润色结果将显示在这里')) {
      return { 
        success: false, 
        error: '润色结果为占位符文本，请重试' 
      };
    }
    
    return { 
      success: true, 
      title,
      content,
      length: content.length
    };
  });
  
  return result;
}

/**
 * 验证润色结果（长度比例检查）
 * 
 * @param {string} original - 原始内容
 * @param {string} polished - 润色后内容
 * @param {Object} options - 选项
 * @returns {{valid: boolean, reason?: string}}
 */
function verifyPolishResult(original, polished, options = {}) {
  const { minRatio = 0.5, maxRatio = 1.5 } = options;
  
  const originalLen = original.length;
  const polishedLen = polished.length;
  const ratio = polishedLen / originalLen;
  
  if (ratio < minRatio) {
    return { 
      valid: false, 
      reason: `润色结果过短（${polishedLen}/${originalLen} = ${(ratio * 100).toFixed(1)}%）` 
    };
  }
  
  if (ratio > maxRatio) {
    return { 
      valid: false, 
      reason: `润色结果过长（${polishedLen}/${originalLen} = ${(ratio * 100).toFixed(1)}%）` 
    };
  }
  
  return { valid: true };
}

module.exports = {
  executePolish,
  importResourceLibrary,
  pasteContent,
  clickPolishButton,
  waitForCompletion,
  extractResult,
  verifyPolishResult,
  POLISH_SITE
};
