/**
 * Coze 扣子编程平台 - 模块化架构
 * 
 * 使用基类模块，提供统一的接口
 * 
 * @module platforms/coze
 */

const fs = require('fs');
const { BrowserBase, AuthBase, ElementBase } = require('../base');
const config = require('../../config');
const logger = require('../../utils/logger');

// ============================================================
// Coze 浏览器类
// ============================================================

class CozeBrowser extends BrowserBase {
  constructor(options = {}) {
    super('coze', options);
  }
}

// ============================================================
// Coze 认证类
// ============================================================

class CozeAuth extends AuthBase {
  constructor(browserInstance) {
    super('coze', browserInstance);
  }
  
  /**
   * 恢复登录状态（Coze 特殊处理：先访问主站）
   */
  async restoreLogin(options = {}) {
    const page = this.browser.getPage();
    const backupPath = this.getBackupPath();
    
    if (!this.hasBackup()) {
      throw new Error(`备份文件不存在: ${backupPath}`);
    }
    
    this.log.info('开始恢复 Coze 登录状态...');
    
    const backup = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));
    
    // 🔴 关键：先访问主站设置登录状态
    const mainSiteUrl = this.siteConfig.urls.mainSite;
    this.log.info(`访问主站: ${mainSiteUrl}`);
    
    await page.goto(mainSiteUrl, { timeout: 30000, waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(2000);
    
    // 恢复 localStorage
    if (backup.localStorage) {
      await page.evaluate((items) => {
        for (const [key, value] of Object.entries(items)) {
          try {
            localStorage.setItem(key, value);
          } catch (e) {}
        }
      }, backup.localStorage);
      
      this.log.debug(`已恢复 ${Object.keys(backup.localStorage).length} 个 localStorage 项`);
    }
    
    // 恢复 cookies
    if (backup.cookies && this.browser.browser) {
      await this.browser.browser.addCookies(backup.cookies);
      this.log.debug(`已恢复 ${backup.cookies.length} 个 cookies`);
    }
    
    // 刷新页面
    await page.reload();
    await page.waitForTimeout(3000);
    
    this.log.success('Coze 登录状态恢复完成');
    return true;
  }
  
  /**
   * 检查登录状态
   */
  async checkLogin() {
    const page = this.browser.getPage();
    
    await page.goto(this.siteConfig.urls.mainSite, { 
      timeout: 15000, 
      waitUntil: 'domcontentloaded' 
    });
    await page.waitForTimeout(3000);
    
    // 检查是否有登录按钮或用户头像
    const hasLoginBtn = await page.locator('button:has-text("登录")').first().isVisible().catch(() => false);
    const hasUserAvatar = await page.locator('[class*="avatar"], [class*="user"]').first().isVisible().catch(() => false);
    
    return {
      isLoggedIn: !hasLoginBtn || hasUserAvatar,
      message: !hasLoginBtn ? '已登录' : '未登录',
    };
  }
}

// ============================================================
// Coze 元素操作类
// ============================================================

class CozeElement extends ElementBase {
  constructor(browserInstance) {
    super('coze', browserInstance);
  }
}

// ============================================================
// Coze 导航模块
// ============================================================

class CozeNavigation extends CozeElement {
  constructor(browserInstance) {
    super(browserInstance);
    this.log = logger.create('coze:navigation');
  }
  
  /**
   * 进入扣子编程页面
   */
  async gotoCodeSite() {
    this.log.info('进入扣子编程页面...');
    await this.browser.goto('codeSite');
    await this.browser.wait(3000);
  }
  
  /**
   * 进入项目管理
   */
  async gotoProjectManage() {
    this.log.info('进入项目管理...');
    await this.browser.goto('home');
    await this.browser.wait(3000);
  }
  
  /**
   * 获取侧边栏项目列表
   */
  async getProjectList() {
    return this.evaluate(() => {
      const items = document.querySelectorAll('[class*="project"], [class*="item"]');
      return Array.from(items).map(item => ({
        text: (item.innerText || '').trim().substring(0, 50),
        class: item.className?.substring(0, 50),
      })).filter(item => item.text);
    });
  }
  
  /**
   * 点击项目
   */
  async clickProject(projectName) {
    await this.clickByText(projectName, { timeout: 5000 });
    await this.browser.wait(2000);
  }
}

// ============================================================
// Coze 平台管理器
// ============================================================

class CozePlatform {
  constructor(options = {}) {
    this.options = options;
    this.log = logger.create('coze');
    
    this.browser = new CozeBrowser(options);
    this.auth = null;
    this.element = null;
    this.navigation = null;
  }
  
  /**
   * 初始化平台
   */
  async init() {
    this.log.info('初始化 Coze 平台...');
    
    await this.browser.launch();
    this.auth = new CozeAuth(this.browser);
    this.element = new CozeElement(this.browser);
    this.navigation = new CozeNavigation(this.browser);
    
    return this;
  }
  
  /**
   * 确保已登录
   */
  async ensureLogin() {
    await this.auth.ensureLoggedIn();
    return this;
  }
  
  /**
   * 进入扣子编程
   */
  async gotoCodeSite() {
    await this.navigation.gotoCodeSite();
    return this;
  }
  
  /**
   * 进入项目管理
   */
  async gotoProjectManage() {
    await this.navigation.gotoProjectManage();
    return this;
  }
  
  /**
   * 获取项目列表
   */
  async getProjects() {
    return this.navigation.getProjectList();
  }
  
  /**
   * 关闭
   */
  async close() {
    await this.browser.close();
  }
}

// ============================================================

// ============================================================
// 导出
// ============================================================

const polish = require('./polish');
const polishExecutor = require('./polish-executor');

module.exports = {
  CozeBrowser,
  CozeAuth,
  CozeElement,
  CozeNavigation,
  CozePlatform,
  
  // 润色模块
  polish,
  polishExecutor
};
