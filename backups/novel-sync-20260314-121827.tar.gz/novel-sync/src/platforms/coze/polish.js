/**
 * Coze 扣子编程 - 文本润色模块
 * 
 * 流程：
 * 1. 打开润色网站
 * 2. 导入资源库
 * 3. 返回润色页面并刷新（关键！）
 * 4. 粘贴内容
 * 5. 点击润色
 * 6. 等待进度条消失
 * 7. 提取结果
 * 
 * 来源：tasks/baimeng/polish-chapter.js 已验证流程
 * 
 * @module platforms/coze/polish
 */

const clipboard = require('../../../../../../lib/utils/clipboard');
const fs = require('fs');

// ============================================================
// 配置
// ============================================================

const POLISH_SITE = {
  url: 'https://7d4jcknzqk.coze.site',
};

const RESOURCE_FILE = '/workspace/projects/workspace/projects/novel-sync/storage/polish/resources.json';

// ============================================================
// 核心流程
// ============================================================

/**
 * 润色流程
 * 
 * @param {Page} page - 已有的页面对象
 * @param {Object} options
 */
async function polishFlow(page, options = {}) {
  const { inputName = 'latest', source, work, chapter } = options;
  
  console.log('[润色] ========== 开始润色 ==========');
  console.log('[润色] 来源:', source, '| 作品:', work, '| 章节:', chapter);
  
  // 1. 读取内容
  const content = loadFromFile(inputName);
  if (!content) {
    return { success: false, error: '未找到内容' };
  }
  console.log('[润色] 内容长度:', content.length);
  
  // 2. 打开润色网站
  console.log('[润色] 打开润色网站...');
  await page.goto(POLISH_SITE.url);
  await page.waitForTimeout(5000);
  
  // 3. 导入资源库
  console.log('[润色] 导入资源库...');
  
  // 对话框处理器
  page.on('dialog', async dialog => {
    console.log('[润色] 对话框:', dialog.message());
    await dialog.accept();
  });
  
  try {
    await page.click('button:has-text("资源库")');
    await page.waitForTimeout(2000);
    await page.click('button:has-text("一键导入")');
    await page.waitForTimeout(2000);
    
    const inputs = await page.$$('input[type="file"]');
    if (inputs.length > 0) {
      await inputs[0].setInputFiles(RESOURCE_FILE);
      await page.waitForTimeout(5000);
    }
    
    console.log('[润色] 资源库已导入');
  } catch (e) {
    console.log('[润色] ⚠️ 资源库导入失败:', e.message);
  }
  
  // 🔴 关键：返回润色页面并刷新
  console.log('[润色] 返回润色页面并刷新...');
  await page.goto(POLISH_SITE.url);
  await page.waitForTimeout(5000);
  
  // 4. 粘贴内容
  console.log('[润色] 粘贴内容...');
  const ta = await page.$('textarea:visible');
  if (!ta) {
    return { success: false, error: '未找到输入框' };
  }
  await ta.fill(content);
  await page.waitForTimeout(2000);
  
  // 5. 点击润色
  console.log('[润色] 点击润色按钮...');
  
  // 检查按钮状态
  const btnInfo = await page.evaluate(() => {
    const buttons = Array.from(document.querySelectorAll('button'));
    const btn = buttons.find(b => b.textContent.includes('开始润色'));
    return btn ? { found: true, disabled: btn.disabled } : { found: false };
  });
  
  if (!btnInfo.found) {
    return { success: false, error: '未找到润色按钮' };
  }
  
  if (btnInfo.disabled) {
    return { success: false, error: '润色按钮已禁用' };
  }
  
  await page.click('button:has-text("开始润色")');
  console.log('[润色] 已点击润色按钮');
  
  // 6. 等待进度条
  console.log('[润色] 等待进度条...');
  
  // 等待进度条出现
  let foundProgress = false;
  for (let i = 0; i < 20; i++) {
    await page.waitForTimeout(3000);
    foundProgress = await page.evaluate(() => 
      document.body.innerText.includes('分段处理')
    );
    if (foundProgress) {
      console.log('[润色] 进度条已出现');
      break;
    }
  }
  
  if (!foundProgress) {
    console.log('[润色] ⚠️ 未检测到进度条');
  }
  
  // 等待进度条消失
  if (foundProgress) {
    let hasProgress = true;
    let count = 0;
    while (hasProgress && count < 100) {
      await page.waitForTimeout(3000);
      hasProgress = await page.evaluate(() => 
        document.body.innerText.includes('分段处理')
      );
      count++;
      
      // 每30秒显示一次进度
      if (count % 10 === 0 && hasProgress) {
        const percent = await page.evaluate(() => {
          const match = document.body.innerText.match(/(\d+)%/);
          return match ? match[1] : '?';
        });
        console.log(`[润色] 进度: ${percent}%`);
      }
    }
    
    console.log('[润色] 进度条已消失');
  }
  
  // 额外等待
  await page.waitForTimeout(10000);
  
  // 7. 提取结果
  console.log('[润色] 提取结果...');
  
  const result = await page.evaluate(() => {
    const bodyText = document.body.innerText;
    const outputIdx = bodyText.indexOf('输出结果');
    
    if (outputIdx === -1) {
      return { success: false, error: '未找到输出结果' };
    }
    
    let content = bodyText.substring(outputIdx + 4);
    
    // 去掉"替换记录"后面的内容
    const replaceIdx = content.indexOf('替换记录');
    if (replaceIdx > 0) {
      content = content.substring(0, replaceIdx);
    }
    
    // 清理
    content = content.trim();
    
    return {
      success: true,
      content,
      contentLength: content.length,
    };
  });
  
  // 移除对话框处理器
  page.removeAllListeners('dialog');
  
  console.log('[润色] ========== 润色完成 ==========');
  return result;
}

/**
 * 从剪贴板读取
 */
function loadFromFile(name = 'latest') {
  return clipboard.read(name, { namespace: 'polish' });
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  polishFlow,
  POLISH_SITE,
};
