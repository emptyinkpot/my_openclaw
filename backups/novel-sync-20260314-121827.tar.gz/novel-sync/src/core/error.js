/**
 * 核心模块 - 错误处理
 * 
 * 统一的错误处理和恢复机制
 * 
 * @module core/error
 */

/**
 * 错误类型
 */
const ErrorTypes = {
  // 网络错误
  NETWORK: 'NETWORK_ERROR',
  TIMEOUT: 'TIMEOUT_ERROR',
  
  // 浏览器错误
  BROWSER_CRASH: 'BROWSER_CRASH',
  BROWSER_LOCK: 'BROWSER_LOCK',
  PAGE_NOT_READY: 'PAGE_NOT_READY',
  
  // 认证错误
  AUTH_FAILED: 'AUTH_FAILED',
  SESSION_EXPIRED: 'SESSION_EXPIRED',
  ACCOUNT_NOT_FOUND: 'ACCOUNT_NOT_FOUND',
  
  // 数据错误
  DATA_CORRUPT: 'DATA_CORRUPT',
  FILE_NOT_FOUND: 'FILE_NOT_FOUND',
  WRITE_FAILED: 'WRITE_FAILED',
  
  // 操作错误
  ELEMENT_NOT_FOUND: 'ELEMENT_NOT_FOUND',
  OPERATION_FAILED: 'OPERATION_FAILED',
  
  // 系统错误
  UNKNOWN: 'UNKNOWN_ERROR',
};

/**
 * 自定义错误类
 */
class AppError extends Error {
  constructor(type, message, options = {}) {
    super(message);
    this.type = type;
    this.code = options.code || type;
    this.recoverable = options.recoverable ?? true;
    this.retryable = options.retryable ?? true;
    this.context = options.context || {};
    this.timestamp = new Date().toISOString();
    
    // 保持正确的堆栈跟踪
    Error.captureStackTrace?.(this, AppError);
  }
  
  /**
   * 转换为 JSON
   */
  toJSON() {
    return {
      type: this.type,
      code: this.code,
      message: this.message,
      recoverable: this.recoverable,
      retryable: this.retryable,
      context: this.context,
      timestamp: this.timestamp,
    };
  }
}

/**
 * 错误工厂方法
 */
const Errors = {
  network(message, context) {
    return new AppError(ErrorTypes.NETWORK, message, { context, retryable: true });
  },
  
  timeout(message, context) {
    return new AppError(ErrorTypes.TIMEOUT, message, { context, retryable: true });
  },
  
  browserCrash(message, context) {
    return new AppError(ErrorTypes.BROWSER_CRASH, message, { context, recoverable: false, retryable: true });
  },
  
  browserLock(message, context) {
    return new AppError(ErrorTypes.BROWSER_LOCK, message, { context, recoverable: true, retryable: true });
  },
  
  authFailed(message, context) {
    return new AppError(ErrorTypes.AUTH_FAILED, message, { context, recoverable: true, retryable: false });
  },
  
  sessionExpired(message, context) {
    return new AppError(ErrorTypes.SESSION_EXPIRED, message, { context, recoverable: true, retryable: false });
  },
  
  accountNotFound(account, context) {
    return new AppError(ErrorTypes.ACCOUNT_NOT_FOUND, `账号不存在: ${account}`, { context, recoverable: false });
  },
  
  dataCorrupt(message, context) {
    return new AppError(ErrorTypes.DATA_CORRUPT, message, { context, recoverable: false, retryable: false });
  },
  
  fileNotFound(file, context) {
    return new AppError(ErrorTypes.FILE_NOT_FOUND, `文件不存在: ${file}`, { context, recoverable: false });
  },
  
  writeFailed(message, context) {
    return new AppError(ErrorTypes.WRITE_FAILED, message, { context, recoverable: true, retryable: true });
  },
  
  elementNotFound(selector, context) {
    return new AppError(ErrorTypes.ELEMENT_NOT_FOUND, `元素未找到: ${selector}`, { context, recoverable: true, retryable: true });
  },
  
  operationFailed(message, context) {
    return new AppError(ErrorTypes.OPERATION_FAILED, message, { context, recoverable: true, retryable: true });
  },
  
  unknown(message, context) {
    return new AppError(ErrorTypes.UNKNOWN, message, { context });
  },
};

/**
 * 错误处理器
 */
class ErrorHandler {
  constructor(options = {}) {
    this.maxRetries = options.maxRetries || 3;
    this.retryDelay = options.retryDelay || 2000;
    this.onRetry = options.onRetry || (() => {});
    this.onError = options.onError || console.error;
  }
  
  /**
   * 处理错误
   * 
   * @param {Error} error - 错误对象
   * @param {Object} context - 上下文
   * @returns {Object} 处理结果
   */
  handle(error, context = {}) {
    const appError = error instanceof AppError 
      ? error 
      : Errors.unknown(error.message, { originalError: error.message, ...context });
    
    // 记录错误
    this.onError(appError);
    
    return {
      error: appError,
      shouldRetry: appError.retryable,
      shouldRecover: appError.recoverable,
      message: appError.message,
    };
  }
  
  /**
   * 带重试的执行
   * 
   * @param {Function} fn - 要执行的函数
   * @param {Object} options - 选项
   */
  async withRetry(fn, options = {}) {
    const maxRetries = options.maxRetries || this.maxRetries;
    const retryDelay = options.retryDelay || this.retryDelay;
    let lastError = null;
    
    for (let i = 0; i < maxRetries; i++) {
      try {
        return await fn();
      } catch (error) {
        lastError = error;
        const result = this.handle(error, { attempt: i + 1 });
        
        if (!result.shouldRetry || i >= maxRetries - 1) {
          throw result.error;
        }
        
        this.onRetry(i + 1, maxRetries, error);
        await this.delay(retryDelay * (i + 1)); // 指数退避
      }
    }
    
    throw lastError;
  }
  
  /**
   * 安全执行
   * 
   * @param {Function} fn - 要执行的函数
   * @param {*} defaultValue - 失败时的默认值
   */
  async safeCall(fn, defaultValue = null) {
    try {
      return await fn();
    } catch (error) {
      this.onError(error);
      return defaultValue;
    }
  }
  
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// 创建默认处理器
const defaultHandler = new ErrorHandler();

module.exports = {
  ErrorTypes,
  AppError,
  Errors,
  ErrorHandler,
  defaultHandler,
  
  // 便捷方法
  handle: (error, context) => defaultHandler.handle(error, context),
  withRetry: (fn, options) => defaultHandler.withRetry(fn, options),
  safeCall: (fn, defaultValue) => defaultHandler.safeCall(fn, defaultValue),
};
