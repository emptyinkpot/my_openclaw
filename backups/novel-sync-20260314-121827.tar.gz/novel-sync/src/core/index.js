/**
 * 核心模块 - 统一入口
 * 
 * 提供所有核心功能的统一访问点
 * 
 * @module core
 */

const { 
  ErrorTypes, 
  AppError, 
  Errors, 
  ErrorHandler,
  handle,
  withRetry,
  safeCall,
} = require('./error');

const { 
  SafeStorage, 
  AccountStorage 
} = require('./storage');

const browserModule = require('./browser');
const browserManager = require('./browser-manager');

// 日志模块（简化版）
const logger = {
  create(name) {
    return {
      info: (msg, ...args) => console.log(`[${name}] ${msg}`, ...args),
      error: (msg, ...args) => console.error(`[${name}] ❌ ${msg}`, ...args),
      warn: (msg, ...args) => console.warn(`[${name}] ⚠️ ${msg}`, ...args),
      success: (msg, ...args) => console.log(`[${name}] ✅ ${msg}`, ...args),
      debug: (msg, ...args) => process.env.DEBUG && console.log(`[${name}] [DEBUG] ${msg}`, ...args),
    };
  }
};

module.exports = {
  // 错误处理
  ErrorTypes,
  AppError,
  Errors,
  ErrorHandler,
  handle,
  withRetry,
  safeCall,
  
  // 存储
  SafeStorage,
  AccountStorage,
  
  // 浏览器（旧版，保留兼容）
  BrowserLock: browserModule.BrowserLock,
  BrowserManager: browserModule.BrowserManager,
  
  // 全局浏览器管理器（推荐）
  browserManager,
  
  // 日志
  logger,
};
