/**
 * 核心模块 - 浏览器管理器
 * 
 * 单例模式，管理浏览器实例
 * 支持锁机制、资源清理、健康检查
 * 
 * @module core/browser
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { Errors, withRetry, safeCall } = require('./error');

// ============================================================
// 浏览器锁
// ============================================================

class BrowserLock {
  constructor(lockDir) {
    this.lockDir = lockDir;
    this.lockFile = path.join(lockDir, '.browser.lock');
    this.pid = process.pid;
  }
  
  /**
   * 获取锁
   */
  acquire(timeout = 10000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      try {
        // 确保目录存在
        if (!fs.existsSync(this.lockDir)) {
          fs.mkdirSync(this.lockDir, { recursive: true });
        }
        
        // 检查是否已有锁
        if (fs.existsSync(this.lockFile)) {
          const lockData = this.readLock();
          
          // 检查持有锁的进程是否还存在
          if (lockData && this.isProcessAlive(lockData.pid)) {
            // 等待锁释放
            const elapsed = Date.now() - startTime;
            if (elapsed > timeout) {
              throw Errors.browserLock('浏览器被其他进程占用', { lockData });
            }
            this.sleep(500);
            continue;
          }
          
          // 进程已死，清理锁
          this.cleanLockFiles();
        }
        
        // 创建锁
        fs.writeFileSync(this.lockFile, JSON.stringify({
          pid: this.pid,
          time: Date.now(),
        }));
        
        return true;
      } catch (error) {
        if (error.type === 'BROWSER_LOCK') throw error;
        this.sleep(200);
      }
    }
    
    throw Errors.browserLock('获取浏览器锁超时');
  }
  
  /**
   * 释放锁
   */
  release() {
    try {
      if (fs.existsSync(this.lockFile)) {
        const lockData = this.readLock();
        if (lockData?.pid === this.pid) {
          fs.unlinkSync(this.lockFile);
        }
      }
    } catch (e) {
      // 忽略
    }
  }
  
  /**
   * 强制清理锁
   */
  forceClean() {
    this.cleanLockFiles();
  }
  
  readLock() {
    try {
      return JSON.parse(fs.readFileSync(this.lockFile, 'utf8'));
    } catch {
      return null;
    }
  }
  
  isProcessAlive(pid) {
    try {
      process.kill(pid, 0);
      return true;
    } catch {
      return false;
    }
  }
  
  cleanLockFiles() {
    const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie', '.browser.lock'];
    for (const file of lockFiles) {
      const filePath = path.join(this.lockDir, file);
      if (fs.existsSync(filePath)) {
        try { fs.unlinkSync(filePath); } catch (e) {}
      }
    }
  }
  
  sleep(ms) {
    const start = Date.now();
    while (Date.now() - start < ms) {}
  }
}

// ============================================================
// 浏览器管理器
// ============================================================

class BrowserManager {
  constructor() {
    this.instances = new Map(); // 浏览器实例映射
    this.locks = new Map(); // 锁映射
    this.defaultViewport = { width: 1920, height: 1080 };
    this.defaultArgs = [
      '--no-sandbox',
      '--disable-session-crashed-bubble',
      '--hide-crash-restore-bubble',
    ];
  }
  
  /**
   * 获取或创建浏览器实例
   * 
   * @param {string} key - 实例标识（如 'fanqie-墨水的生命周期'）
   * @param {Object} options - 选项
   * @returns {Promise<{browser: Browser, page: Page, lock: BrowserLock}>}
   */
  async acquire(key, options = {}) {
    const {
      dataDir = `/workspace/projects/browser/${key}`,
      headless = false,
      viewport = this.defaultViewport,
    } = options;
    
    // 检查是否已有实例
    const existing = this.instances.get(key);
    if (existing && !existing.browser.isConnected()) {
      // 浏览器已断开，清理
      this.instances.delete(key);
      this.locks.get(key)?.release();
      this.locks.delete(key);
    }
    
    if (existing?.browser.isConnected()) {
      // 复用现有实例
      const page = existing.browser.pages()[0];
      return { browser: existing.browser, page, lock: this.locks.get(key) };
    }
    
    // 创建新实例
    const lock = new BrowserLock(dataDir);
    lock.acquire();
    this.locks.set(key, lock);
    
    try {
      const browser = await withRetry(async () => {
        // 确保目录存在
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }
        
        // 清理旧锁文件
        lock.cleanLockFiles();
        
        // 启动浏览器
        return chromium.launchPersistentContext(dataDir, {
          headless,
          viewport,
          args: [
            ...this.defaultArgs,
            `--window-size=${viewport.width},${viewport.height}`,
          ],
        });
      }, { maxRetries: 2, retryDelay: 1000 });
      
      // 注册实例
      this.instances.set(key, { browser, dataDir, createdAt: Date.now() });
      
      // 获取或创建页面
      const page = browser.pages()[0] || await browser.newPage();
      
      return { browser, page, lock };
    } catch (error) {
      lock.release();
      this.locks.delete(key);
      throw Errors.browserCrash(`启动浏览器失败: ${error.message}`, { key, error: error.message });
    }
  }
  
  /**
   * 释放浏览器实例
   */
  async release(key) {
    const instance = this.instances.get(key);
    const lock = this.locks.get(key);
    
    if (instance) {
      try {
        await instance.browser.close();
      } catch (e) {}
      this.instances.delete(key);
    }
    
    if (lock) {
      lock.release();
      this.locks.delete(key);
    }
  }
  
  /**
   * 检查实例健康状态
   */
  checkHealth(key) {
    const instance = this.instances.get(key);
    if (!instance) return { healthy: false, reason: '不存在' };
    
    if (!instance.browser.isConnected()) {
      return { healthy: false, reason: '已断开' };
    }
    
    return { healthy: true, uptime: Date.now() - instance.createdAt };
  }
  
  /**
   * 清理所有实例
   */
  async cleanup() {
    const keys = [...this.instances.keys()];
    for (const key of keys) {
      await this.release(key);
    }
  }
  
  /**
   * 获取实例统计
   */
  getStats() {
    return {
      total: this.instances.size,
      instances: [...this.instances.keys()],
    };
  }
}

// 单例
const browserManager = new BrowserManager();

// 进程退出时清理
process.on('exit', () => browserManager.cleanup());
process.on('SIGINT', () => browserManager.cleanup());
process.on('SIGTERM', () => browserManager.cleanup());

module.exports = {
  BrowserLock,
  BrowserManager,
  browserManager,
};
