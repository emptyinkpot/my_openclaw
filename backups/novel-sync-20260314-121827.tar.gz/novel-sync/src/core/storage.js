/**
 * 核心模块 - 安全存储
 * 
 * 提供原子写入、自动备份、数据校验
 * 防止意外损坏数据
 * 
 * @module core/storage
 */

const fs = require('fs');
const path = require('path');
const { Errors, withRetry } = require('./error');

/**
 * 安全存储类
 */
class SafeStorage {
  /**
   * @param {string} baseDir - 基础目录
   * @param {Object} options - 选项
   */
  constructor(baseDir, options = {}) {
    this.baseDir = baseDir;
    this.backupDir = options.backupDir || path.join(baseDir, '.backups');
    this.maxBackups = options.maxBackups || 5;
    this.validateWrites = options.validateWrites ?? true;
  }
  
  /**
   * 原子写入文件
   * 
   * 策略：
   * 1. 先写入临时文件
   * 2. 验证写入是否成功
   * 3. 备份原文件
   * 4. 原子重命名
   * 
   * @param {string} filePath - 文件路径
   * @param {*} data - 数据
   */
  async write(filePath, data) {
    const fullPath = this.resolvePath(filePath);
    const dir = path.dirname(fullPath);
    
    // 确保目录存在
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    // 序列化数据
    const content = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
    
    // 临时文件路径
    const tempPath = `${fullPath}.tmp.${Date.now()}`;
    const backupPath = this.getBackupPath(filePath);
    
    return withRetry(async () => {
      try {
        // 1. 写入临时文件
        fs.writeFileSync(tempPath, content, 'utf8');
        
        // 2. 验证写入
        if (this.validateWrites) {
          const written = fs.readFileSync(tempPath, 'utf8');
          if (written !== content) {
            throw Errors.writeFailed('写入验证失败：内容不匹配');
          }
        }
        
        // 3. 备份原文件
        if (fs.existsSync(fullPath)) {
          this.ensureBackupDir();
          const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
          const backupFile = path.join(this.backupDir, `${path.basename(filePath)}.bak-${timestamp}`);
          fs.copyFileSync(fullPath, backupFile);
          this.cleanOldBackups(filePath);
        }
        
        // 4. 原子重命名
        fs.renameSync(tempPath, fullPath);
        
        return { success: true, path: fullPath };
      } catch (error) {
        // 清理临时文件
        if (fs.existsSync(tempPath)) {
          try { fs.unlinkSync(tempPath); } catch (e) {}
        }
        throw error;
      }
    }, { maxRetries: 3 });
  }
  
  /**
   * 读取文件
   * 
   * @param {string} filePath - 文件路径
   * @param {*} defaultValue - 默认值
   * @returns {*} 数据
   */
  read(filePath, defaultValue = null) {
    const fullPath = this.resolvePath(filePath);
    
    if (!fs.existsSync(fullPath)) {
      return defaultValue;
    }
    
    try {
      const content = fs.readFileSync(fullPath, 'utf8');
      
      // 尝试解析 JSON
      try {
        return JSON.parse(content);
      } catch {
        return content;
      }
    } catch (error) {
      // 尝试从备份恢复
      const backup = this.getLatestBackup(filePath);
      if (backup) {
        console.warn(`[Storage] 文件损坏，从备份恢复: ${backup}`);
        try {
          const content = fs.readFileSync(backup, 'utf8');
          return JSON.parse(content);
        } catch {}
      }
      
      return defaultValue;
    }
  }
  
  /**
   * 安全更新文件
   * 
   * 读取 -> 修改 -> 写入（原子操作）
   * 
   * @param {string} filePath - 文件路径
   * @param {Function} updater - 更新函数
   * @param {*} defaultValue - 默认值
   */
  async update(filePath, updater, defaultValue = null) {
    const current = this.read(filePath, defaultValue);
    const updated = await updater(current);
    
    if (updated === undefined) {
      throw Errors.operationFailed('更新函数不能返回 undefined');
    }
    
    return this.write(filePath, updated);
  }
  
  /**
   * 删除文件
   */
  delete(filePath) {
    const fullPath = this.resolvePath(filePath);
    
    if (fs.existsSync(fullPath)) {
      // 备份后再删除
      this.ensureBackupDir();
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupFile = path.join(this.backupDir, `${path.basename(filePath)}.deleted-${timestamp}`);
      fs.copyFileSync(fullPath, backupFile);
      fs.unlinkSync(fullPath);
      return true;
    }
    return false;
  }
  
  /**
   * 检查文件是否存在
   */
  exists(filePath) {
    return fs.existsSync(this.resolvePath(filePath));
  }
  
  /**
   * 列出文件
   */
  list(pattern) {
    const files = fs.readdirSync(this.baseDir);
    if (pattern) {
      const regex = new RegExp(pattern);
      return files.filter(f => regex.test(f));
    }
    return files;
  }
  
  // ============================================================
  // 备份管理
  // ============================================================
  
  ensureBackupDir() {
    if (!fs.existsSync(this.backupDir)) {
      fs.mkdirSync(this.backupDir, { recursive: true });
    }
  }
  
  getBackupPath(filePath) {
    return path.join(this.backupDir, path.basename(filePath));
  }
  
  getLatestBackup(filePath) {
    const fileName = path.basename(filePath);
    const backups = fs.readdirSync(this.backupDir)
      .filter(f => f.startsWith(fileName) && f.includes('.bak-'))
      .sort()
      .reverse();
    
    if (backups.length > 0) {
      return path.join(this.backupDir, backups[0]);
    }
    return null;
  }
  
  cleanOldBackups(filePath) {
    const fileName = path.basename(filePath);
    const backups = fs.readdirSync(this.backupDir)
      .filter(f => f.startsWith(fileName) && f.includes('.bak-'))
      .sort();
    
    // 只保留最近的 N 个备份
    while (backups.length > this.maxBackups) {
      const oldest = backups.shift();
      fs.unlinkSync(path.join(this.backupDir, oldest));
    }
  }
  
  resolvePath(filePath) {
    // 支持绝对路径
    if (path.isAbsolute(filePath)) {
      return filePath;
    }
    return path.join(this.baseDir, filePath);
  }
}

// ============================================================
// 账号存储（专用）
// ============================================================

class AccountStorage extends SafeStorage {
  constructor(platform, options = {}) {
    const baseDir = options.baseDir || '/workspace/projects/cookies-accounts';
    super(baseDir, options);
    this.platform = platform;
  }
  
  /**
   * 保存账号
   */
  async saveAccount(userName, data) {
    const fileName = this._generateFileName();
    const accountData = {
      platform: this.platform,
      userName,
      savedAt: new Date().toISOString(),
      expiresAt: data.expiresAt,
      cookies: data.cookies,
      localStorage: data.localStorage,
      sessionStorage: data.sessionStorage,
      meta: data.meta || {},
    };
    
    await this.write(fileName, accountData);
    return { fileName, userName };
  }
  
  /**
   * 加载账号
   */
  loadAccount(identifier) {
    // 如果是文件名
    if (identifier?.endsWith('.json')) {
      return this.read(identifier);
    }
    
    // 按用户名查找
    const files = this.list(`^${this.platform}-\\d{8}-\\d{6}\\.json$`);
    for (const file of files) {
      const data = this.read(file);
      if (data?.userName === identifier) {
        return { ...data, fileName: file };
      }
    }
    
    // 返回最新的
    if (files.length > 0) {
      const latest = files.sort().reverse()[0];
      return { ...this.read(latest), fileName: latest };
    }
    
    return null;
  }
  
  /**
   * 列出所有账号
   */
  listAccounts() {
    const files = this.list(`^${this.platform}-\\d{8}-\\d{6}\\.json$`);
    return files.map(f => {
      const data = this.read(f);
      return {
        userName: data?.userName,
        fileName: f,
        savedAt: data?.savedAt,
        expiresAt: data?.expiresAt,
        valid: this._checkValid(data),
      };
    }).filter(a => a.userName);
  }
  
  _checkValid(data) {
    if (!data?.cookies?.length) return false;
    if (!data?.expiresAt) return true;
    return new Date(data.expiresAt) > new Date();
  }
  
  _generateFileName() {
    const now = new Date();
    const date = now.toISOString().slice(0, 10).replace(/-/g, '');
    const time = now.toTimeString().slice(0, 8).replace(/:/g, '');
    return `${this.platform}-${date}-${time}.json`;
  }
}

module.exports = {
  SafeStorage,
  AccountStorage,
};
