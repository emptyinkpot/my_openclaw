/**
 * 全局浏览器管理器
 * 
 * 设计原则：
 * - 使用 CDP 端口，浏览器可以独立运行
 * - 支持连接已有浏览器
 * - 使用持久化目录，登录状态持久
 * 
 * @module core/global-browser
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { logger } = require('./index');

const log = logger.create('browser');

// ============================================================
// 配置
// ============================================================

const DEFAULT_VIEWPORT = { width: 1920, height: 1080 };
const DEFAULT_ARGS = [
  '--no-sandbox',
  '--disable-session-crashed-bubble',
  '--hide-crash-restore-bubble',
];
const CDP_PORT = 9222;
const CDP_LOCK_FILE = '/tmp/browser-cdp.lock';

// ============================================================
// 锁文件清理
// ============================================================

function cleanLockFiles(dataDir) {
  const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'Lock'];
  for (const file of lockFiles) {
    const filePath = path.join(dataDir, file);
    if (fs.existsSync(filePath)) {
      try { fs.unlinkSync(filePath); } catch (e) {}
    }
  }
}

// ============================================================
// CDP 管理
// ============================================================

function readCdpLock() {
  try {
    if (fs.existsSync(CDP_LOCK_FILE)) {
      return JSON.parse(fs.readFileSync(CDP_LOCK_FILE, 'utf8'));
    }
  } catch (e) {}
  return null;
}

function writeCdpLock(data) {
  try {
    fs.writeFileSync(CDP_LOCK_FILE, JSON.stringify(data));
  } catch (e) {}
}

function clearCdpLock() {
  try {
    if (fs.existsSync(CDP_LOCK_FILE)) {
      fs.unlinkSync(CDP_LOCK_FILE);
    }
  } catch (e) {}
}

// ============================================================
// 浏览器管理
// ============================================================

/**
 * 获取或创建浏览器实例
 * 
 * 策略：
 * 1. 尝试连接已有浏览器（通过 CDP）
 * 2. 如果没有，启动新的浏览器
 * 
 * @param {Object} options
 * @param {string} options.key - 浏览器标识
 * @param {string} options.dataDir - 数据目录（可选）
 * @param {boolean} options.headless - 无头模式（默认 false）
 * @returns {Promise<{browser: Browser, page: Page, isNew: boolean}>}
 */
async function getBrowser(options = {}) {
  const {
    key = 'default',
    dataDir,
    headless = false,
  } = options;
  
  // 确定数据目录
  const actualDataDir = dataDir || `/workspace/projects/browser/${key}`;
  
  // 1. 尝试连接已有浏览器
  const cdpLock = readCdpLock();
  if (cdpLock && cdpLock.key === key) {
    try {
      log.info(`尝试连接已有浏览器: ${key}`);
      const browser = await chromium.connectOverCDP(`http://localhost:${cdpLock.port}`);
      
      if (browser.isConnected()) {
        const contexts = browser.contexts();
        const page = contexts.length > 0 && contexts[0].pages().length > 0 
          ? contexts[0].pages()[0] 
          : await browser.newPage();
        
        log.success(`连接成功: ${key}`);
        return { browser, page, isNew: false };
      }
    } catch (e) {
      log.warn(`连接失败: ${e.message}`);
      clearCdpLock();
    }
  }
  
  // 2. 启动新的浏览器
  log.info(`启动浏览器: ${key}`);
  
  // 确保目录存在
  if (!fs.existsSync(actualDataDir)) {
    fs.mkdirSync(actualDataDir, { recursive: true });
  }
  
  // 清理锁文件
  cleanLockFiles(actualDataDir);
  
  // 找一个可用的端口
  const port = await findAvailablePort(CDP_PORT);
  
  try {
    const browser = await chromium.launchPersistentContext(actualDataDir, {
      headless,
      viewport: DEFAULT_VIEWPORT,
      args: [
        ...DEFAULT_ARGS,
        `--window-size=${DEFAULT_VIEWPORT.width},${DEFAULT_VIEWPORT.height}`,
        `--remote-debugging-port=${port}`,
      ],
    });
    
    // 获取或创建页面
    const pages = browser.pages();
    const page = pages.length > 0 ? pages[0] : await browser.newPage();
    
    // 写入 CDP 锁
    writeCdpLock({ key, port, startedAt: Date.now() });
    
    log.success(`浏览器启动成功: ${key} (端口: ${port})`);
    
    return { browser, page, isNew: true };
  } catch (error) {
    log.error(`浏览器启动失败: ${error.message}`);
    throw error;
  }
}

/**
 * 找一个可用的端口
 */
async function findAvailablePort(startPort) {
  const net = require('net');
  
  for (let port = startPort; port < startPort + 100; port++) {
    const available = await new Promise(resolve => {
      const server = net.createServer();
      server.once('error', () => resolve(false));
      server.once('listening', () => {
        server.close();
        resolve(true);
      });
      server.listen(port);
    });
    
    if (available) return port;
  }
  
  return startPort;
}

/**
 * 获取当前浏览器信息
 */
function getCurrentInfo() {
  return readCdpLock();
}

/**
 * 检查浏览器是否在运行
 */
async function isRunning(key) {
  const cdpLock = readCdpLock();
  if (!cdpLock || (key && cdpLock.key !== key)) {
    return false;
  }
  
  try {
    const browser = await chromium.connectOverCDP(`http://localhost:${cdpLock.port}`);
    const connected = browser.isConnected();
    browser.close().catch(() => {});
    return connected;
  } catch (e) {
    return false;
  }
}

/**
 * 关闭浏览器
 */
async function closeBrowser() {
  const cdpLock = readCdpLock();
  if (!cdpLock) return false;
  
  try {
    const browser = await chromium.connectOverCDP(`http://localhost:${cdpLock.port}`);
    await browser.close();
    clearCdpLock();
    log.info('浏览器已关闭');
    return true;
  } catch (e) {
    clearCdpLock();
    return false;
  }
}

/**
 * 列出所有浏览器数据目录
 */
function listDataDirs() {
  const browserDir = '/workspace/projects/browser';
  if (!fs.existsSync(browserDir)) return [];
  
  return fs.readdirSync(browserDir)
    .filter(f => {
      const stat = fs.statSync(path.join(browserDir, f));
      return stat.isDirectory();
    });
}

module.exports = {
  getBrowser,
  getCurrentInfo,
  isRunning,
  closeBrowser,
  listDataDirs,
  
  // 常量
  CDP_PORT,
};
