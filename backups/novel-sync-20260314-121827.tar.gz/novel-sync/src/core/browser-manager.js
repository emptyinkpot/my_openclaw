/**
 * 浏览器管理器（独立进程版）
 * 
 * 核心设计：
 * 1. 浏览器作为独立进程运行（使用 child_process）
 * 2. 脚本通过 CDP 连接到浏览器
 * 3. 脚本结束不影响浏览器进程
 * 
 * @module core/browser-manager
 */

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const net = require('net');

// ============================================================
// 配置
// ============================================================

const BROWSER_BASE_DIR = '/workspace/projects/browser';
const CDP_PORT_START = 9222;
const STATE_FILE = '/tmp/browser-manager-state.json';
const CHROMIUM_PATH = '/root/.cache/ms-playwright/chromium-1208/chrome-linux64/chrome';

const DEFAULT_VIEWPORT = { width: 1920, height: 1080 };

// ============================================================
// 状态管理
// ============================================================

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    }
  } catch (e) {}
  return { browsers: {} };
}

function saveState(state) {
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
  } catch (e) {}
}

// ============================================================
// 端口管理
// ============================================================

async function findAvailablePort(startPort) {
  for (let port = startPort; port < startPort + 100; port++) {
    const available = await new Promise(resolve => {
      const server = net.createServer();
      server.once('error', () => resolve(false));
      server.once('listening', () => {
        server.close();
        resolve(true);
      });
      server.listen(port);
    });
    
    if (available) return port;
  }
  return startPort;
}

// ============================================================
// 锁文件清理
// ============================================================

function cleanLockFiles(dataDir) {
  const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'Lock'];
  for (const file of lockFiles) {
    try {
      const filePath = path.join(dataDir, file);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    } catch (e) {}
  }
}

// ============================================================
// 浏览器管理器类
// ============================================================

class BrowserManager {
  constructor() {
    this.state = loadState();
    this.connections = new Map();
  }
  
  /**
   * 获取或创建浏览器
   * 
   * 策略：
   * 1. 检查状态文件中是否有已运行的浏览器
   * 2. 尝试 CDP 连接
   * 3. 连接失败则启动新的浏览器进程
   * 
   * @param {Object} options
   * @returns {Promise<{browser: Browser, context: BrowserContext, page: Page, isNew: boolean}>}
   */
  async getOrCreate(options = {}) {
    const {
      key = 'default',
      dataDir,
      headless = false,
    } = options;
    
    console.log(`[BrowserManager] 获取浏览器: ${key}`);
    
    const actualDataDir = dataDir || path.join(BROWSER_BASE_DIR, key);
    
    // 1. 检查状态文件
    const browserState = this.state.browsers[key];
    if (browserState?.cdpPort) {
      // 尝试连接
      try {
        console.log(`[BrowserManager] 尝试连接已有浏览器 (端口 ${browserState.cdpPort})...`);
        const browser = await chromium.connectOverCDP(`http://localhost:${browserState.cdpPort}`);
        
        if (browser.isConnected()) {
          // 创建新的浏览器上下文（不是标签页）
          const context = await browser.newContext({
            viewport: DEFAULT_VIEWPORT,
          });
          const page = await context.newPage();
          
          this.connections.set(key, { browser, context });
          
          console.log(`[BrowserManager] ✅ 连接成功，创建新页面`);
          return { browser, context, page, isNew: false };
        }
      } catch (e) {
        console.log(`[BrowserManager] 连接失败: ${e.message}`);
        delete this.state.browsers[key];
        saveState(this.state);
      }
    }
    
    // 2. 启动新的浏览器进程
    console.log(`[BrowserManager] 启动新浏览器进程...`);
    
    // 确保目录存在
    if (!fs.existsSync(actualDataDir)) {
      fs.mkdirSync(actualDataDir, { recursive: true });
    }
    
    // 清理锁文件
    cleanLockFiles(actualDataDir);
    
    // 找一个可用端口
    const cdpPort = await findAvailablePort(CDP_PORT_START);
    
    // 启动浏览器进程（独立进程，使用 nohup）
    const args = [
      `--user-data-dir=${actualDataDir}`,
      `--remote-debugging-port=${cdpPort}`,
      '--no-first-run',
      '--no-sandbox',
      '--disable-session-crashed-bubble',
      '--hide-crash-restore-bubble',
      `--window-size=${DEFAULT_VIEWPORT.width},${DEFAULT_VIEWPORT.height}`,
      '--no-default-browser-check',
      '--disable-default-apps',
      '--disable-extensions',
      '--disable-sync',
      '--disable-translate',
      '--disable-infobars',
      '--enable-automation',
      '--disable-dev-shm-usage',
      headless ? '--headless' : '',
      'about:blank',
    ].filter(Boolean);
    
    // 使用 spawn 启动独立进程
    const browserProcess = spawn(CHROMIUM_PATH, args, {
      detached: true,  // 独立于父进程
      stdio: 'ignore', // 忽略输出
    });
    
    // 让子进程在父进程退出后继续运行
    browserProcess.unref();
    
    console.log(`[BrowserManager] 浏览器进程已启动 (PID: ${browserProcess.pid}, 端口: ${cdpPort})`);
    
    // 等待浏览器启动
    await this._waitForBrowser(cdpPort, 15000);
    
    // 连接到浏览器
    const browser = await chromium.connectOverCDP(`http://localhost:${cdpPort}`);
    
    // 创建上下文和页面
    const context = await browser.newContext({
      viewport: DEFAULT_VIEWPORT,
    });
    const page = await context.newPage();
    
    // 保存状态
    this.state.browsers[key] = {
      cdpPort,
      dataDir: actualDataDir,
      pid: browserProcess.pid,
      startedAt: Date.now(),
    };
    saveState(this.state);
    
    this.connections.set(key, { browser, context });
    
    console.log(`[BrowserManager] ✅ 浏览器启动成功`);
    
    return { browser, context, page, isNew: true };
  }
  
  /**
   * 等待浏览器启动
   */
  async _waitForBrowser(port, timeout = 15000) {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      try {
        const browser = await chromium.connectOverCDP(`http://localhost:${port}`);
        await browser.close();
        return true;
      } catch (e) {
        await new Promise(r => setTimeout(r, 500));
      }
    }
    
    throw new Error(`浏览器启动超时 (${timeout}ms)`);
  }
  
  /**
   * 关闭标签页
   */
  async closePage(page) {
    try {
      await page.close();
      console.log(`[BrowserManager] 标签页已关闭`);
    } catch (e) {}
  }
  
  /**
   * 关闭上下文
   */
  async closeContext(context) {
    try {
      await context.close();
      console.log(`[BrowserManager] 上下文已关闭`);
    } catch (e) {}
  }
  
  /**
   * 关闭浏览器
   */
  async closeBrowser(key) {
    const conn = this.connections.get(key);
    if (conn) {
      try {
        await conn.browser.close();
      } catch (e) {}
      this.connections.delete(key);
    }
    
    delete this.state.browsers[key];
    saveState(this.state);
    console.log(`[BrowserManager] 浏览器已关闭: ${key}`);
  }
  
  /**
   * 关闭所有浏览器
   */
  async closeAll() {
    for (const [key, conn] of this.connections) {
      try {
        await conn.browser.close();
      } catch (e) {}
    }
    this.connections.clear();
    this.state.browsers = {};
    saveState(this.state);
  }
  
  /**
   * 检查浏览器是否运行
   */
  async isRunning(key) {
    const browserState = this.state.browsers[key];
    if (!browserState?.cdpPort) return false;
    
    try {
      const browser = await chromium.connectOverCDP(`http://localhost:${browserState.cdpPort}`);
      const connected = browser.isConnected();
      browser.close().catch(() => {});
      return connected;
    } catch (e) {
      return false;
    }
  }
  
  /**
   * 获取状态
   */
  getStatus() {
    return {
      state: this.state,
      connections: Array.from(this.connections.keys()),
    };
  }
}

// ============================================================
// 单例导出
// ============================================================

const browserManager = new BrowserManager();

module.exports = {
  BrowserManager,
  browserManager,
  
  getOrCreate: (options) => browserManager.getOrCreate(options),
  closePage: (page) => browserManager.closePage(page),
  closeContext: (context) => browserManager.closeContext(context),
  closeBrowser: (key) => browserManager.closeBrowser(key),
  closeAll: () => browserManager.closeAll(),
  getStatus: () => browserManager.getStatus(),
  isRunning: (key) => browserManager.isRunning(key),
};
