/**
 * 多账号管理器
 * 
 * 支持账号轮换、负载均衡
 * 
 * @module utils/account-manager
 */

const fs = require('fs');
const path = require('path');
const config = require('../config');
const logger = require('./logger');

// 账号状态
const AccountStatus = {
  AVAILABLE: 'available',
  BUSY: 'busy',
  ERROR: 'error',
  COOLDOWN: 'cooldown',
};

// 账号记录
const accounts = new Map();

// 轮换索引
let roundRobinIndex = 0;

/**
 * 账号管理器类
 */
class AccountManager {
  /**
   * @param {string} site - 平台名称
   */
  constructor(site) {
    this.site = site;
    this.siteConfig = config.getSiteConfig(site);
    this.log = logger.create(`account:${site}`);
    
    // 初始化账号
    this.initAccounts();
  }
  
  /**
   * 初始化账号列表
   */
  initAccounts() {
    const browserDir = config.PATHS.GLOBAL_BROWSER;
    
    // 查找该平台的所有账号目录
    const pattern = new RegExp(`^${this.site}-(\\d+)$`);
    
    if (fs.existsSync(browserDir)) {
      fs.readdirSync(browserDir).forEach(dir => {
        const match = dir.match(pattern);
        if (match) {
          const accountId = parseInt(match[1], 10);
          accounts.set(this.getAccountKey(accountId), {
            id: accountId,
            status: AccountStatus.AVAILABLE,
            lastUsed: null,
            errorCount: 0,
          });
        }
      });
    }
    
    // 确保至少有一个默认账号
    if (accounts.size === 0) {
      accounts.set(this.getAccountKey(1), {
        id: 1,
        status: AccountStatus.AVAILABLE,
        lastUsed: null,
        errorCount: 0,
      });
    }
    
    this.log.info(`已加载 ${accounts.size} 个账号`);
  }
  
  /**
   * 获取账号键
   */
  getAccountKey(accountId) {
    return `${this.site}:${accountId}`;
  }
  
  /**
   * 获取所有账号
   */
  getAllAccounts() {
    const result = [];
    accounts.forEach((acc, key) => {
      if (key.startsWith(`${this.site}:`)) {
        result.push({
          ...acc,
          browserDir: this.siteConfig.getBrowserDir(acc.id),
          backupFile: this.siteConfig.getBackupFile(acc.id),
        });
      }
    });
    return result;
  }
  
  /**
   * 获取可用账号（轮换模式）
   * @param {string} mode - 选择模式: round-robin, random, least-used
   */
  getNextAccount(mode = 'round-robin') {
    const available = this.getAllAccounts()
      .filter(acc => acc.status === AccountStatus.AVAILABLE);
    
    if (available.length === 0) {
      throw new Error('没有可用账号');
    }
    
    let selected;
    
    switch (mode) {
      case 'round-robin':
        selected = available[roundRobinIndex % available.length];
        roundRobinIndex++;
        break;
        
      case 'random':
        selected = available[Math.floor(Math.random() * available.length)];
        break;
        
      case 'least-used':
        selected = available.reduce((prev, curr) => {
          if (!prev.lastUsed) return curr;
          if (!curr.lastUsed) return curr;
          return curr.lastUsed < prev.lastUsed ? curr : prev;
        });
        break;
        
      default:
        selected = available[0];
    }
    
    this.log.info(`选择账号: ${selected.id} (${mode} 模式)`);
    return selected;
  }
  
  /**
   * 标记账号为忙碌
   */
  setBusy(accountId) {
    const key = this.getAccountKey(accountId);
    const acc = accounts.get(key);
    if (acc) {
      acc.status = AccountStatus.BUSY;
      acc.lastUsed = new Date().toISOString();
    }
  }
  
  /**
   * 标记账号为可用
   */
  setAvailable(accountId) {
    const key = this.getAccountKey(accountId);
    const acc = accounts.get(key);
    if (acc) {
      acc.status = AccountStatus.AVAILABLE;
    }
  }
  
  /**
   * 标记账号错误
   */
  setError(accountId, error) {
    const key = this.getAccountKey(accountId);
    const acc = accounts.get(key);
    if (acc) {
      acc.status = AccountStatus.ERROR;
      acc.errorCount++;
      acc.lastError = error;
      acc.lastErrorTime = new Date().toISOString();
      
      this.log.error(`账号 ${accountId} 发生错误: ${error}`);
    }
  }
  
  /**
   * 设置冷却时间
   */
  setCooldown(accountId, duration = 60000) {
    const key = this.getAccountKey(accountId);
    const acc = accounts.get(key);
    if (acc) {
      acc.status = AccountStatus.COOLDOWN;
      
      setTimeout(() => {
        acc.status = AccountStatus.AVAILABLE;
        this.log.info(`账号 ${accountId} 冷却完成`);
      }, duration);
    }
  }
  
  /**
   * 获取账号状态报告
   */
  getStatusReport() {
    const report = {
      total: 0,
      available: 0,
      busy: 0,
      error: 0,
      cooldown: 0,
      accounts: [],
    };
    
    this.getAllAccounts().forEach(acc => {
      report.total++;
      report[acc.status]++;
      report.accounts.push({
        id: acc.id,
        status: acc.status,
        lastUsed: acc.lastUsed,
        errorCount: acc.errorCount,
      });
    });
    
    return report;
  }
  
  /**
   * 使用账号执行任务
   * @param {Function} taskFn - 任务函数，接收 (accountId) 参数
   * @param {Object} options - 选项
   */
  async withAccount(taskFn, options = {}) {
    const mode = options.mode || 'round-robin';
    const maxRetries = options.maxRetries || 3;
    
    let lastError;
    let attempts = 0;
    
    while (attempts < maxRetries) {
      attempts++;
      
      try {
        const account = this.getNextAccount(mode);
        this.setBusy(account.id);
        
        this.log.info(`使用账号 ${account.id} 执行任务 (尝试 ${attempts}/${maxRetries})`);
        
        const result = await taskFn(account.id);
        
        this.setAvailable(account.id);
        return result;
        
      } catch (error) {
        lastError = error;
        
        // 标记错误
        if (error.accountId) {
          this.setError(error.accountId, error.message);
        }
        
        // 如果是登录问题，设置冷却
        if (error.message?.includes('登录') || error.message?.includes('auth')) {
          this.setCooldown(error.accountId || 1, 300000); // 5 分钟冷却
        }
        
        this.log.warn(`任务失败 (尝试 ${attempts}/${maxRetries}): ${error.message}`);
      }
    }
    
    throw lastError || new Error('所有尝试均失败');
  }
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  AccountManager,
  AccountStatus,
  
  // 快速创建
  create: (site) => new AccountManager(site),
  
  // 快速获取下一个账号
  getNextAccount: (site, mode) => {
    const manager = new AccountManager(site);
    return manager.getNextAccount(mode);
  },
};
