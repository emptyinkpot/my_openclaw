/**
 * 错误模式库
 * 
 * 设计原则：
 * - 小而美：每个模式简洁明了
 * - 可复用：一个模式匹配多种错误
 * - 低耦合：模式定义与修复逻辑分离
 * 
 * @module utils/error-patterns
 */

/**
 * 错误类型枚举
 */
const ErrorType = {
  TIMEOUT: 'TIMEOUT',
  NETWORK: 'NETWORK',
  SELECTOR: 'SELECTOR',
  AUTH: 'AUTH',
  CONTENT: 'CONTENT',
  BROWSER: 'BROWSER',
  UNKNOWN: 'UNKNOWN',
};

/**
 * 错误模式定义
 * 
 * 每个模式包含：
 * - pattern: 匹配规则（正则或函数）
 * - type: 错误类型
 * - severity: 严重程度 (1-5, 5最严重)
 * - autoFix: 是否可自动修复
 * - fixStrategy: 修复策略名称
 * - hint: 人工处理提示
 */
const ERROR_PATTERNS = [
  // ============================================================
  // 超时类错误
  // ============================================================
  {
    id: 'TIMEOUT_SELECTOR',
    pattern: /timeout.*waiting for selector|waiting for.*timeout/i,
    type: ErrorType.TIMEOUT,
    severity: 3,
    autoFix: true,
    fixStrategy: 'waitAndRetry',
    hint: '元素加载慢，尝试增加超时时间或等待前置条件',
    examples: ['Timeout waiting for selector', 'waiting for element timeout'],
  },
  {
    id: 'TIMEOUT_NAVIGATION',
    pattern: /navigation.*timeout|page\.goto.*timeout/i,
    type: ErrorType.TIMEOUT,
    severity: 3,
    autoFix: true,
    fixStrategy: 'reloadPage',
    hint: '页面导航超时，检查网络或增加超时时间',
    examples: ['Navigation timeout', 'page.goto timeout'],
  },
  {
    id: 'TIMEOUT_PROGRESS',
    pattern: /进度.*超时|progress.*timeout|等待.*超时/i,
    type: ErrorType.TIMEOUT,
    severity: 2,
    autoFix: true,
    fixStrategy: 'extendTimeout',
    hint: '任务执行时间过长，尝试延长等待时间',
    examples: ['润色进度超时', 'progress timeout'],
  },

  // ============================================================
  // 选择器类错误
  // ============================================================
  {
    id: 'SELECTOR_NOT_FOUND',
    pattern: /no element found|element.*not found|cannot find/i,
    type: ErrorType.SELECTOR,
    severity: 4,
    autoFix: true,
    fixStrategy: 'findAlternative',
    hint: '选择器失效，尝试备用选择器或更新选择器',
    examples: ['No element found for selector', 'element not found'],
  },
  {
    id: 'SELECTOR_STALE',
    pattern: /stale element|element is detached|element is not attached/i,
    type: ErrorType.SELECTOR,
    severity: 3,
    autoFix: true,
    fixStrategy: 'refindElement',
    hint: '元素已过期，需要重新查找',
    examples: ['stale element reference', 'element is not attached'],
  },
  {
    id: 'SELECTOR_NOT_VISIBLE',
    pattern: /element is not visible|not visible|hidden/i,
    type: ErrorType.SELECTOR,
    severity: 3,
    autoFix: true,
    fixStrategy: 'scrollToElement',
    hint: '元素不可见，尝试滚动到元素位置',
    examples: ['element is not visible', 'Element is hidden'],
  },

  // ============================================================
  // 认证类错误
  // ============================================================
  {
    id: 'AUTH_EXPIRED',
    pattern: /login.*expire|token.*expire|session.*expire|未登录|登录失效/i,
    type: ErrorType.AUTH,
    severity: 5,
    autoFix: true,
    fixStrategy: 'restoreLogin',
    hint: '登录态过期，尝试恢复登录状态',
    examples: ['登录失效', 'login expired', 'token expired'],
  },
  {
    id: 'AUTH_REQUIRED',
    pattern: /请登录|need login|authentication required|401|403/i,
    type: ErrorType.AUTH,
    severity: 5,
    autoFix: true,
    fixStrategy: 'restoreLogin',
    hint: '需要登录，尝试恢复登录状态',
    examples: ['请先登录', '401 Unauthorized', '403 Forbidden'],
  },
  {
    id: 'AUTH_CAPTCHA',
    pattern: /captcha|验证码|人机验证/i,
    type: ErrorType.AUTH,
    severity: 5,
    autoFix: false,
    fixStrategy: null,
    hint: '需要人工处理验证码',
    examples: ['请输入验证码', 'captcha required'],
  },

  // ============================================================
  // 网络类错误
  // ============================================================
  {
    id: 'NETWORK_ERROR',
    pattern: /network|ENOTFOUND|ECONNREFUSED|ETIMEDOUT|net::err/i,
    type: ErrorType.NETWORK,
    severity: 4,
    autoFix: true,
    fixStrategy: 'retryWithDelay',
    hint: '网络错误，稍后重试',
    examples: ['network error', 'ENOTFOUND', 'ECONNREFUSED'],
  },
  {
    id: 'NETWORK_SLOW',
    pattern: /slow|响应慢|加载慢/i,
    type: ErrorType.NETWORK,
    severity: 2,
    autoFix: true,
    fixStrategy: 'extendTimeout',
    hint: '网络慢，增加超时时间',
    examples: ['响应太慢', 'loading slow'],
  },

  // ============================================================
  // 内容类错误
  // ============================================================
  {
    id: 'CONTENT_EMPTY',
    pattern: /content.*empty|内容为空|no content|获取失败/i,
    type: ErrorType.CONTENT,
    severity: 3,
    autoFix: true,
    fixStrategy: 'retryAction',
    hint: '内容为空，检查是否加载完成',
    examples: ['内容为空', 'content is empty', 'no content found'],
  },
  {
    id: 'CONTENT_MISMATCH',
    pattern: /content.*mismatch|内容不匹配|验证失败/i,
    type: ErrorType.CONTENT,
    severity: 3,
    autoFix: true,
    fixStrategy: 'retryAction',
    hint: '内容不匹配，检查输入/输出逻辑',
    examples: ['内容不匹配', 'verification failed'],
  },
  {
    id: 'CONTENT_GARBAGE',
    pattern: /垃圾文字|多余内容|garbage/i,
    type: ErrorType.CONTENT,
    severity: 2,
    autoFix: true,
    fixStrategy: 'cleanContent',
    hint: '内容包含垃圾文字，需要清理',
    examples: ['包含垃圾文字', 'garbage content'],
  },

  // ============================================================
  // 浏览器类错误
  // ============================================================
  {
    id: 'BROWSER_CRASHED',
    pattern: /browser.*crash|browser.*close|target closed|browser disconnected/i,
    type: ErrorType.BROWSER,
    severity: 5,
    autoFix: true,
    fixStrategy: 'restartBrowser',
    hint: '浏览器崩溃，尝试重启',
    examples: ['browser crashed', 'target closed', 'browser disconnected'],
  },
  {
    id: 'BROWSER_CONTEXT',
    pattern: /context.*destroy|context.*close|page.*close/i,
    type: ErrorType.BROWSER,
    severity: 4,
    autoFix: true,
    fixStrategy: 'restartBrowser',
    hint: '浏览器上下文关闭，需要重启',
    examples: ['context destroyed', 'page closed'],
  },

  // ============================================================
  // 未知错误
  // ============================================================
  {
    id: 'UNKNOWN',
    pattern: /.*/s,
    type: ErrorType.UNKNOWN,
    severity: 1,
    autoFix: false,
    fixStrategy: null,
    hint: '未知错误，需要人工分析',
    examples: [],
  },
];

/**
 * 匹配错误模式
 * 
 * @param {Error|string} error - 错误对象或消息
 * @returns {Object} 匹配的错误模式
 */
function matchPattern(error) {
  const message = typeof error === 'string' ? error : (error.message || String(error));
  
  for (const pattern of ERROR_PATTERNS) {
    if (pattern.pattern.test(message)) {
      return {
        ...pattern,
        matchedMessage: message,
        confidence: pattern.id === 'UNKNOWN' ? 0 : 1,
      };
    }
  }
  
  // 理论上不会走到这里，因为 UNKNOWN 匹配所有
  return ERROR_PATTERNS[ERROR_PATTERNS.length - 1];
}

/**
 * 批量匹配（用于调试）
 * 
 * @param {string} message - 错误消息
 * @returns {Array} 所有匹配的模式
 */
function matchAllPatterns(message) {
  const matches = [];
  for (const pattern of ERROR_PATTERNS) {
    if (pattern.pattern.test(message)) {
      matches.push(pattern);
    }
  }
  return matches;
}

/**
 * 获取可自动修复的模式
 * 
 * @returns {Array} 可自动修复的模式列表
 */
function getAutoFixablePatterns() {
  return ERROR_PATTERNS.filter(p => p.autoFix && p.fixStrategy);
}

/**
 * 按类型获取模式
 * 
 * @param {string} type - 错误类型
 * @returns {Array} 该类型的模式列表
 */
function getPatternsByType(type) {
  return ERROR_PATTERNS.filter(p => p.type === type);
}

/**
 * 添加自定义模式
 * 
 * @param {Object} pattern - 模式定义
 */
function addPattern(pattern) {
  // 验证必要字段
  if (!pattern.id || !pattern.pattern || !pattern.type) {
    throw new Error('Pattern must have id, pattern, and type');
  }
  
  // 插入到 UNKNOWN 之前
  const unknownIndex = ERROR_PATTERNS.findIndex(p => p.id === 'UNKNOWN');
  ERROR_PATTERNS.splice(unknownIndex, 0, pattern);
}

module.exports = {
  ErrorType,
  ERROR_PATTERNS,
  matchPattern,
  matchAllPatterns,
  getAutoFixablePatterns,
  getPatternsByType,
  addPattern,
};
