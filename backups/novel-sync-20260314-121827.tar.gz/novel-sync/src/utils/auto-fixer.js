/**
 * 自动修复器
 * 
 * 设计原则：
 * - 策略模式：每种修复逻辑是独立的策略函数
 * - 可扩展：支持注册自定义修复策略
 * - 可追溯：记录所有修复历史
 * - 安全性：修复失败不影响原流程
 * 
 * @module utils/auto-fixer
 */

const { matchPattern, ErrorType } = require('./error-patterns');
const experienceStore = require('./experience-store');

/**
 * 修复策略函数映射
 * 
 * 每个策略函数接收上下文，返回修复结果
 */
const FIX_STRATEGIES = {
  // ============================================================
  // 超时类修复
  // ============================================================
  
  /**
   * 等待后重试
   */
  waitAndRetry: async (ctx) => {
    const { page, options = {} } = ctx;
    const delay = options.delay || 2000;
    
    await page.waitForTimeout(delay);
    return { success: true, action: `waited ${delay}ms` };
  },
  
  /**
   * 刷新页面
   */
  reloadPage: async (ctx) => {
    const { page, options = {} } = ctx;
    const waitTime = options.waitTime || 3000;
    
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(waitTime);
    return { success: true, action: 'page reloaded' };
  },
  
  /**
   * 延长超时时间
   */
  extendTimeout: async (ctx) => {
    const { options = {} } = ctx;
    const multiplier = options.multiplier || 2;
    
    return { 
      success: true, 
      action: `timeout extended by ${multiplier}x`,
      newTimeout: (options.originalTimeout || 30000) * multiplier,
    };
  },
  
  // ============================================================
  // 选择器类修复
  // ============================================================
  
  /**
   * 查找备用选择器
   */
  findAlternative: async (ctx) => {
    const { page, options = {} } = ctx;
    const { alternatives = [] } = options;
    
    for (const selector of alternatives) {
      try {
        const element = await page.$(selector);
        if (element) {
          return { 
            success: true, 
            action: `found alternative: ${selector}`,
            newSelector: selector,
          };
        }
      } catch (e) {
        // 继续尝试下一个
      }
    }
    
    return { success: false, action: 'no alternative found' };
  },
  
  /**
   * 重新查找元素
   */
  refindElement: async (ctx) => {
    const { page, options = {} } = ctx;
    const { selector } = options;
    
    if (!selector) {
      return { success: false, action: 'no selector provided' };
    }
    
    try {
      await page.waitForSelector(selector, { state: 'visible', timeout: 5000 });
      return { success: true, action: 'element refound' };
    } catch (e) {
      return { success: false, action: 'element still not found' };
    }
  },
  
  /**
   * 滚动到元素
   */
  scrollToElement: async (ctx) => {
    const { page, options = {} } = ctx;
    const { selector } = options;
    
    if (!selector) {
      return { success: false, action: 'no selector provided' };
    }
    
    try {
      await page.locator(selector).scrollIntoViewIfNeeded();
      await page.waitForTimeout(500);
      return { success: true, action: 'scrolled to element' };
    } catch (e) {
      return { success: false, action: 'scroll failed' };
    }
  },
  
  // ============================================================
  // 认证类修复
  // ============================================================
  
  /**
   * 恢复登录状态
   */
  restoreLogin: async (ctx) => {
    const { page, options = {} } = ctx;
    const { platform, authRestoreFn } = options;
    
    if (!authRestoreFn) {
      return { 
        success: false, 
        action: 'no auth restore function provided',
        needsManual: true,
      };
    }
    
    try {
      await authRestoreFn(page, platform);
      return { success: true, action: 'login restored' };
    } catch (e) {
      return { 
        success: false, 
        action: `login restore failed: ${e.message}`,
        needsManual: true,
      };
    }
  },
  
  // ============================================================
  // 网络类修复
  // ============================================================
  
  /**
   * 延迟后重试
   */
  retryWithDelay: async (ctx) => {
    const { options = {} } = ctx;
    const delay = options.delay || 3000;
    const maxRetries = options.maxRetries || 3;
    
    return { 
      success: true, 
      action: `will retry after ${delay}ms`,
      delay,
      maxRetries,
    };
  },
  
  // ============================================================
  // 内容类修复
  // ============================================================
  
  /**
   * 重试操作
   */
  retryAction: async (ctx) => {
    const { options = {} } = ctx;
    
    return { 
      success: true, 
      action: 'action should be retried',
      shouldRetry: true,
    };
  },
  
  /**
   * 清理内容
   */
  cleanContent: async (ctx) => {
    const { options = {} } = ctx;
    const { content, cleanFn } = options;
    
    if (cleanFn && content) {
      const cleaned = cleanFn(content);
      return { success: true, action: 'content cleaned', cleaned };
    }
    
    return { success: false, action: 'no content or clean function' };
  },
  
  // ============================================================
  // 浏览器类修复
  // ============================================================
  
  /**
   * 重启浏览器
   */
  restartBrowser: async (ctx) => {
    const { options = {} } = ctx;
    const { browserManager, platform } = options;
    
    if (!browserManager) {
      return { 
        success: false, 
        action: 'no browser manager provided',
        needsManual: true,
      };
    }
    
    try {
      // 关闭旧浏览器
      if (ctx.browser) {
        await ctx.browser.close().catch(() => {});
      }
      
      // 启动新浏览器
      const { browser, page } = await browserManager.launch(platform);
      return { 
        success: true, 
        action: 'browser restarted',
        browser,
        page,
      };
    } catch (e) {
      return { 
        success: false, 
        action: `browser restart failed: ${e.message}`,
        needsManual: true,
      };
    }
  },
};

/**
 * 修复历史记录
 */
const FIX_HISTORY = [];

/**
 * 自动修复器类
 */
class AutoFixer {
  constructor(options = {}) {
    this.options = options;
    this.maxAttempts = options.maxAttempts || 3;
    this.onFix = options.onFix || null;
    this.onFail = options.onFail || null;
  }
  
  /**
   * 尝试自动修复
   * 
   * @param {Error|string} error - 错误
   * @param {Object} context - 上下文（page, browser, options 等）
   * @returns {Promise<Object>} 修复结果
   */
  async fix(error, context = {}) {
    const pattern = matchPattern(error);
    
    // 记录修复尝试
    const fixRecord = {
      timestamp: new Date().toISOString(),
      error: typeof error === 'string' ? error : error.message,
      pattern: pattern.id,
      type: pattern.type,
      severity: pattern.severity,
      attempts: [],
      result: null,
    };
    
    // 不可自动修复
    if (!pattern.autoFix || !pattern.fixStrategy) {
      fixRecord.result = {
        success: false,
        reason: 'not auto-fixable',
        hint: pattern.hint,
      };
      FIX_HISTORY.push(fixRecord);
      
      // 记录到经验库
      experienceStore.recordFailure(pattern, error, context);
      
      return fixRecord.result;
    }
    
    // 获取修复策略
    const strategy = FIX_STRATEGIES[pattern.fixStrategy];
    if (!strategy) {
      fixRecord.result = {
        success: false,
        reason: `unknown strategy: ${pattern.fixStrategy}`,
        hint: pattern.hint,
      };
      FIX_HISTORY.push(fixRecord);
      return fixRecord.result;
    }
    
    // 尝试修复
    for (let attempt = 1; attempt <= this.maxAttempts; attempt++) {
      try {
        const result = await strategy({
          ...context,
          options: { ...context.options, ...this.options },
        });
        
        fixRecord.attempts.push({
          attempt,
          action: result.action,
          success: result.success,
        });
        
        if (result.success) {
          fixRecord.result = { ...result, attempts: attempt };
          FIX_HISTORY.push(fixRecord);
          
          // 回调
          if (this.onFix) {
            this.onFix(pattern, result, context);
          }
          
          // 记录到经验库
          experienceStore.recordSuccess(pattern, error, context, result);
          
          return fixRecord.result;
        }
        
        // 失败后等待
        if (attempt < this.maxAttempts) {
          await this._delay(1000 * attempt);
        }
      } catch (e) {
        fixRecord.attempts.push({
          attempt,
          error: e.message,
          success: false,
        });
      }
    }
    
    // 所有尝试都失败
    fixRecord.result = {
      success: false,
      reason: `all ${this.maxAttempts} attempts failed`,
      hint: pattern.hint,
      attempts: fixRecord.attempts,
    };
    FIX_HISTORY.push(fixRecord);
    
    // 回调
    if (this.onFail) {
      this.onFail(pattern, fixRecord.result, context);
    }
    
    // 记录到经验库
    experienceStore.recordFailure(pattern, error, context);
    
    return fixRecord.result;
  }
  
  /**
   * 延迟
   */
  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  /**
   * 获取修复历史
   */
  static getHistory(limit = 50) {
    return FIX_HISTORY.slice(-limit);
  }
  
  /**
   * 清除历史
   */
  static clearHistory() {
    FIX_HISTORY.length = 0;
  }
  
  /**
   * 注册自定义修复策略
   */
  static registerStrategy(name, fn) {
    if (typeof fn !== 'function') {
      throw new Error('Strategy must be a function');
    }
    FIX_STRATEGIES[name] = fn;
  }
  
  /**
   * 获取所有策略名称
   */
  static getStrategyNames() {
    return Object.keys(FIX_STRATEGIES);
  }
}

/**
 * 快速修复函数
 * 
 * @param {Error|string} error - 错误
 * @param {Object} context - 上下文
 * @returns {Promise<Object>} 修复结果
 */
async function quickFix(error, context = {}) {
  const fixer = new AutoFixer();
  return fixer.fix(error, context);
}

module.exports = {
  AutoFixer,
  FIX_STRATEGIES,
  quickFix,
};
