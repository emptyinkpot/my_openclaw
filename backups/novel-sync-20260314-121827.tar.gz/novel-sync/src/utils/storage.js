/**
 * 存储模块
 * 
 * 提供统一的浏览器存储操作
 * 
 * 功能：
 * - localStorage 管理
 * - cookie 管理
 * - sessionStorage 管理
 * - 批量设置
 * - 导入导出
 */

const fs = require('fs');
const path = require('path');

// 默认存储目录
const DEFAULT_DIR = '/tmp/openclaw/storage';

/**
 * localStorage 操作
 */
const localStorage = {
  /**
   * 设置单个项
   */
  async setItem(page, key, value) {
    await page.evaluate((k, v) => {
      window.localStorage.setItem(k, v);
    }, key, value);
  },
  
  /**
   * 批量设置
   */
  async setItems(page, items) {
    await page.evaluate((data) => {
      for (const [key, value] of Object.entries(data)) {
        try {
          window.localStorage.setItem(key, value);
        } catch (e) {
          console.error(`Failed to set ${key}:`, e);
        }
      }
    }, items);
  },
  
  /**
   * 获取单个项
   */
  async getItem(page, key) {
    return await page.evaluate((k) => {
      return window.localStorage.getItem(k);
    }, key);
  },
  
  /**
   * 获取所有项
   */
  async getAllItems(page) {
    return await page.evaluate(() => {
      const items = {};
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        items[key] = window.localStorage.getItem(key);
      }
      return items;
    });
  },
  
  /**
   * 删除单个项
   */
  async removeItem(page, key) {
    await page.evaluate((k) => {
      window.localStorage.removeItem(k);
    }, key);
  },
  
  /**
   * 清空
   */
  async clear(page) {
    await page.evaluate(() => {
      window.localStorage.clear();
    });
  },
  
  /**
   * 导出为文件
   */
  async exportToFile(page, filepath) {
    const items = await this.getAllItems(page);
    const dir = path.dirname(filepath);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(filepath, JSON.stringify(items, null, 2));
    
    return filepath;
  },
  
  /**
   * 从文件导入
   */
  async importFromFile(page, filepath) {
    if (!fs.existsSync(filepath)) {
      throw new Error(`文件不存在: ${filepath}`);
    }
    
    const items = JSON.parse(fs.readFileSync(filepath, 'utf-8'));
    await this.setItems(page, items);
    
    return Object.keys(items).length;
  }
};

/**
 * cookie 操作
 */
const cookie = {
  /**
   * 设置单个 cookie
   */
  async setCookie(context, name, value, options = {}) {
    await context.addCookies([{
      name,
      value,
      domain: options.domain || '.example.com',
      path: options.path || '/',
      expires: options.expires || Math.floor(Date.now() / 1000) + 365 * 24 * 60 * 60,
      httpOnly: options.httpOnly || false,
      secure: options.secure || false,
      sameSite: options.sameSite || 'Lax'
    }]);
  },
  
  /**
   * 批量设置 cookies
   */
  async setCookies(context, cookies) {
    await context.addCookies(cookies);
  },
  
  /**
   * 获取所有 cookies
   */
  async getCookies(context) {
    return await context.cookies();
  },
  
  /**
   * 获取指定域的 cookies
   */
  async getCookiesByDomain(context, domain) {
    const all = await this.getCookies(context);
    return all.filter(c => c.domain.includes(domain));
  },
  
  /**
   * 删除 cookie
   */
  async removeCookie(context, name, domain) {
    const cookies = await this.getCookies(context);
    const toRemove = cookies.filter(c => 
      c.name === name && c.domain.includes(domain)
    );
    
    // 通过设置过期时间来删除
    for (const c of toRemove) {
      await context.addCookies([{
        ...c,
        expires: 0
      }]);
    }
  },
  
  /**
   * 导出为文件
   */
  async exportToFile(context, filepath) {
    const cookies = await this.getCookies(context);
    const dir = path.dirname(filepath);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    fs.writeFileSync(filepath, JSON.stringify(cookies, null, 2));
    
    return filepath;
  },
  
  /**
   * 从文件导入
   */
  async importFromFile(context, filepath) {
    if (!fs.existsSync(filepath)) {
      throw new Error(`文件不存在: ${filepath}`);
    }
    
    const cookies = JSON.parse(fs.readFileSync(filepath, 'utf-8'));
    await this.setCookies(context, cookies);
    
    return cookies.length;
  }
};

/**
 * sessionStorage 操作
 */
const sessionStorage = {
  /**
   * 设置单个项
   */
  async setItem(page, key, value) {
    await page.evaluate((k, v) => {
      window.sessionStorage.setItem(k, v);
    }, key, value);
  },
  
  /**
   * 批量设置
   */
  async setItems(page, items) {
    await page.evaluate((data) => {
      for (const [key, value] of Object.entries(data)) {
        try {
          window.sessionStorage.setItem(key, value);
        } catch (e) {
          console.error(`Failed to set ${key}:`, e);
        }
      }
    }, items);
  },
  
  /**
   * 获取所有项
   */
  async getAllItems(page) {
    return await page.evaluate(() => {
      const items = {};
      for (let i = 0; i < window.sessionStorage.length; i++) {
        const key = window.sessionStorage.key(i);
        items[key] = window.sessionStorage.getItem(key);
      }
      return items;
    });
  },
  
  /**
   * 清空
   */
  async clear(page) {
    await page.evaluate(() => {
      window.sessionStorage.clear();
    });
  }
};

/**
 * 统一存储管理
 */
const storage = {
  /**
   * 保存所有存储状态
   */
  async saveAll(page, context, baseDir = DEFAULT_DIR) {
    const timestamp = new Date().toISOString().replace(/[-:T]/g, '').substring(0, 14);
    const dir = path.join(baseDir, timestamp);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    const localStorageFile = path.join(dir, 'localStorage.json');
    const cookiesFile = path.join(dir, 'cookies.json');
    const sessionStorageFile = path.join(dir, 'sessionStorage.json');
    
    await localStorage.exportToFile(page, localStorageFile);
    await cookie.exportToFile(context, cookiesFile);
    await sessionStorage.exportToFile(page, sessionStorageFile);
    
    return { dir, localStorageFile, cookiesFile, sessionStorageFile };
  },
  
  /**
   * 恢复所有存储状态
   */
  async restoreAll(page, context, dir) {
    const localStorageFile = path.join(dir, 'localStorage.json');
    const cookiesFile = path.join(dir, 'cookies.json');
    const sessionStorageFile = path.join(dir, 'sessionStorage.json');
    
    let localStorageCount = 0;
    let cookiesCount = 0;
    let sessionStorageCount = 0;
    
    if (fs.existsSync(localStorageFile)) {
      localStorageCount = await localStorage.importFromFile(page, localStorageFile);
    }
    
    if (fs.existsSync(cookiesFile)) {
      cookiesCount = await cookie.importFromFile(context, cookiesFile);
    }
    
    if (fs.existsSync(sessionStorageFile)) {
      const data = JSON.parse(fs.readFileSync(sessionStorageFile, 'utf-8'));
      await sessionStorage.setItems(page, data);
      sessionStorageCount = Object.keys(data).length;
    }
    
    return { localStorageCount, cookiesCount, sessionStorageCount };
  },
  
  /**
   * 清理旧存储
   */
  cleanupOldStorage(baseDir = DEFAULT_DIR, maxAge = 7 * 24 * 60 * 60 * 1000) {
    if (!fs.existsSync(baseDir)) {
      return { cleaned: 0 };
    }
    
    const now = Date.now();
    const dirs = fs.readdirSync(baseDir)
      .filter(f => fs.statSync(path.join(baseDir, f)).isDirectory())
      .map(f => ({
        name: f,
        path: path.join(baseDir, f),
        mtime: fs.statSync(path.join(baseDir, f)).mtime
      }));
    
    let cleaned = 0;
    
    for (const dir of dirs) {
      if (now - dir.mtime > maxAge) {
        fs.rmSync(dir.path, { recursive: true });
        cleaned++;
      }
    }
    
    return { cleaned };
  }
};

module.exports = {
  localStorage,
  cookie,
  sessionStorage,
  storage,
  DEFAULT_DIR
};
