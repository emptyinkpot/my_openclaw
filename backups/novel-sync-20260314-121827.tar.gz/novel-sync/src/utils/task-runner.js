/**
 * 任务运行器 - 强制执行编码规范
 * 
 * 🔴 所有任务脚本必须通过此模块运行 🔴
 * 
 * 使用方式：
 *   const { runTask } = require('./src/utils/task-runner');
 *   runTask('任务名称', async (ctx) => { ... });
 */

const fs = require('fs');
const path = require('path');

// ============================================================
// 配置
// ============================================================

// 项目根目录（novel-sync 目录）
const PROJECT_ROOT = path.join(__dirname, '../..');

// 规范文件路径
const STANDARDS_FILES = {
  coding: path.join(PROJECT_ROOT, 'CODING_STANDARDS.md'),
  debug: path.join(PROJECT_ROOT, 'DEBUG_LOG.md'),
  verified: path.join(PROJECT_ROOT, 'docs/已验证代码库.md'),
  userTeaching: path.join(PROJECT_ROOT, 'docs/用户教导记录.md'),
};

// 标记文件路径
const CHECK_FLAG_FILE = path.join(PROJECT_ROOT, '.task-check-flag');

// 违规记录文件
const VIOLATION_LOG = path.join(PROJECT_ROOT, '.violation-log.md');

// ============================================================
// 核心函数
// ============================================================

/**
 * 检查是否已执行过规范检查
 */
function hasCheckedStandards() {
  // 检查环境变量
  if (process.env.TASK_STANDARDS_CHECKED === 'true') {
    return true;
  }
  
  // 检查标记文件
  if (fs.existsSync(CHECK_FLAG_FILE)) {
    try {
      const flag = JSON.parse(fs.readFileSync(CHECK_FLAG_FILE, 'utf-8'));
      const now = Date.now();
      // 标记有效期为 30 分钟
      if (now - flag.timestamp < 30 * 60 * 1000) {
        return true;
      }
    } catch (e) {
      // 文件损坏，重新检查
    }
  }
  
  return false;
}

/**
 * 标记已执行规范检查
 */
function markStandardsChecked() {
  // 设置环境变量
  process.env.TASK_STANDARDS_CHECKED = 'true';
  
  // 写入标记文件
  fs.writeFileSync(CHECK_FLAG_FILE, JSON.stringify({
    timestamp: Date.now(),
    pid: process.pid
  }, null, 2));
}

/**
 * 读取并打印规范关键内容
 * 这是强制执行的核心
 */
function printStandardsSummary() {
  console.log('\n' + '='.repeat(60));
  console.log('📋 强制规范检查');
  console.log('='.repeat(60));
  
  // 1. 编码规范核心
  console.log('\n【1】编码规范核心：');
  const rules = [
    '✓ 从已验证代码复制，不重写',
    '✓ 只添加新功能，不修改已有逻辑',
    '✓ 保持函数签名一致',
    '✓ 添加注释说明来源',
    '✓ 所有脚本必须使用 runTask() 入口',
  ];
  rules.forEach(r => console.log(`  ${r}`));
  
  // 2. 读取 DEBUG_LOG.md 中的关键问题
  console.log('\n【2】历史问题速查：');
  try {
    const debug = fs.readFileSync(STANDARDS_FILES.debug, 'utf-8');
    const problemMatch = debug.match(/\| 症状 \| 可能原因 \| 解决方向 \|[\s\S]*?(?=\n\n|\n##)/);
    if (problemMatch) {
      console.log('  ' + problemMatch[0].split('\n').slice(0, 7).join('\n  '));
    }
  } catch (e) {
    console.log('  (无法读取 DEBUG_LOG.md)');
  }
  
  // 3. 已验证选择器
  console.log('\n【3】已验证选择器：');
  const selectors = [
    ['.sidebar', '侧边栏'],
    ['[class*="cursor-pointer"]', '可点击项'],
    ['a[href*="editor"]', '作品链接'],
    ['.ProseMirror, .Daydream', '编辑器内容'],
  ];
  selectors.forEach(([sel, desc]) => {
    console.log(`  ✓ ${sel} → ${desc}`);
  });
  
  // 4. 用户教导要点
  console.log('\n【4】用户教导要点：');
  const teachings = [
    '✓ 滚动前先点击获取焦点',
    '✓ localStorage 设置后必须刷新',
    '✓ 使用 JS 的 click() 而非 playwright click',
    '✓ 禁止使用 localStorage.clear()',
  ];
  teachings.forEach(t => console.log(`  ${t}`));
  
  // 5. 强制行为模式
  console.log('\n【5】强制行为模式：');
  console.log('  ✓ 每次任务先 write_todos');
  console.log('  ✓ 第一项：读取规范文件');
  console.log('  ✓ 读取完成后标记 completed');
  
  console.log('\n' + '='.repeat(60));
  console.log('✅ 规范检查完成，可以开始任务');
  console.log('='.repeat(60) + '\n');
}

/**
 * 查找可复用的代码
 * @param {string} keyword - 关键词
 * @returns {Array} 匹配的代码片段
 */
function findReusableCode(keyword) {
  const results = [];
  
  try {
    const verified = fs.readFileSync(STANDARDS_FILES.verified, 'utf-8');
    const lines = verified.split('\n');
    
    lines.forEach((line, i) => {
      if (line.toLowerCase().includes(keyword.toLowerCase())) {
        results.push({
          line: i + 1,
          content: line.substring(0, 100)
        });
      }
    });
  } catch (e) {
    // 文件不存在
  }
  
  return results.slice(0, 10);
}

/**
 * 检查脚本是否符合规范
 * @param {string} scriptPath - 脚本路径
 * @returns {Object} 检查结果
 */
function checkScriptCompliance(scriptPath) {
  const content = fs.readFileSync(scriptPath, 'utf-8');
  const issues = [];
  const warnings = [];
  
  // 1. 检查是否导入了 runTask
  if (!content.includes('runTask') && !content.includes('task-runner')) {
    issues.push('🔴 未使用 runTask 作为入口');
  }
  
  // 2. 检查是否有直接 require chromium
  if (content.includes("require('playwright')") || content.includes('require("playwright")')) {
    if (!content.includes('browser.js') && !content.includes('browser.launch')) {
      issues.push('🔴 直接使用 playwright，应使用 browser 模块');
    }
  }
  
  // 3. 检查是否有 localStorage.clear()
  if (content.includes('localStorage.clear()')) {
    issues.push('🔴 禁止使用 localStorage.clear()');
  }
  
  // 4. 检查是否有硬编码的等待时间过长
  const waitMatches = content.match(/waitForTimeout\((\d+)\)/g);
  if (waitMatches) {
    waitMatches.forEach(m => {
      const time = parseInt(m.match(/\d+/)[0]);
      if (time > 10000) {
        warnings.push(`⚠️ 等待时间过长: ${time}ms`);
      }
    });
  }
  
  // 5. 检查是否有来源注释
  if (content.includes('require(') && !content.includes('来源：') && !content.includes('来源:')) {
    warnings.push('⚠️ 建议添加代码来源注释');
  }
  
  // 6. 检查 URL 拼写
  if (content.includes('baimoxiezuo')) {
    issues.push('🔴 URL 拼写错误: baimoxiezuo → baimengxiezuo');
  }
  
  return {
    compliant: issues.length === 0,
    issues,
    warnings,
    score: Math.max(0, 100 - issues.length * 30 - warnings.length * 10)
  };
}

/**
 * 记录违规
 * @param {string} type - 违规类型
 * @param {string} detail - 详情
 */
function logViolation(type, detail) {
  const timestamp = new Date().toISOString();
  const record = `\n### [${timestamp.substring(0, 19)}] ${type}\n${detail}\n`;
  
  try {
    fs.appendFileSync(VIOLATION_LOG, record);
    console.log(`⚠️ 违规已记录: ${type}`);
  } catch (e) {
    console.log('无法写入违规日志');
  }
}

/**
 * 运行任务（强制入口）
 * @param {string} taskName - 任务名称
 * @param {Function} taskFn - 任务函数
 * @param {Object} options - 选项
 */
async function runTask(taskName, taskFn, options = {}) {
  console.log(`\n🚀 任务: ${taskName}`);
  console.log('-'.repeat(40));
  
  // 强制检查：是否已读取规范
  if (!hasCheckedStandards()) {
    printStandardsSummary();
    markStandardsChecked();
  } else {
    console.log('✅ 规范已检查过（本次会话有效）\n');
  }
  
  // 创建任务上下文
  const context = {
    findReusableCode,
    checkScriptCompliance,
    logViolation,
    standardsFiles: STANDARDS_FILES,
    PROJECT_ROOT,
  };
  
  // 运行任务
  const startTime = Date.now();
  
  try {
    const result = await taskFn(context);
    
    const duration = Math.round((Date.now() - startTime) / 1000);
    
    // 任务完成后提醒
    console.log('\n' + '-'.repeat(40));
    console.log(`✅ 任务完成 (耗时: ${duration}s)`);
    console.log('📁 记得更新文档：');
    console.log('  □ docs/已验证代码库.md（如有新验证代码）');
    console.log('  □ DEBUG_LOG.md（如有问题解决）');
    console.log('-'.repeat(40) + '\n');
    
    return result;
    
  } catch (error) {
    console.error('\n❌ 任务失败:', error.message);
    console.log('\n📝 记得更新 DEBUG_LOG.md 记录此问题\n');
    
    // 记录失败
    logViolation('任务失败', `任务: ${taskName}\n错误: ${error.message}`);
    
    throw error;
  }
}

/**
 * 快速入口 - 用于简单任务
 */
function quickTask(taskName, taskFn) {
  return runTask(taskName, taskFn, { quick: true });
}

/**
 * 生成规范检查报告
 */
function generateComplianceReport() {
  const report = {
    timestamp: new Date().toISOString(),
    standardsChecked: hasCheckedStandards(),
    flagFile: fs.existsSync(CHECK_FLAG_FILE) ? 
      JSON.parse(fs.readFileSync(CHECK_FLAG_FILE, 'utf-8')) : null,
    violations: fs.existsSync(VIOLATION_LOG) ?
      fs.readFileSync(VIOLATION_LOG, 'utf-8') : '无违规记录'
  };
  
  return report;
}

// ============================================================
// 导出
// ============================================================

module.exports = {
  // 核心函数
  runTask,
  quickTask,
  
  // 辅助函数
  findReusableCode,
  checkScriptCompliance,
  printStandardsSummary,
  logViolation,
  generateComplianceReport,
  
  // 状态函数
  hasCheckedStandards,
  markStandardsChecked,
  
  // 常量
  STANDARDS_FILES,
  PROJECT_ROOT,
};
