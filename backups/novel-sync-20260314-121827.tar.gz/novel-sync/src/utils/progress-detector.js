/**
 * 进度检测模块
 * 
 * 提供通用的进度检测功能
 * 
 * 功能：
 * - 润色进度检测
 * - 进度条检测
 * - 文本变化检测
 * - DOM 变化检测
 */

/**
 * 等待润色进度完成
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function waitForPolishProgress(page, options = {}) {
  const { 
    timeout = 300000,  // 5分钟
    progressText = '分段处理',
    interval = 3000,
    onProgress = () => {}
  } = options;
  
  const startTime = Date.now();
  
  // 等待进度条出现
  onProgress('等待进度条出现...');
  let progressStarted = false;
  
  while (!progressStarted && Date.now() - startTime < timeout) {
    const found = await checkTextExists(page, progressText);
    if (found) {
      progressStarted = true;
      onProgress('进度条已出现');
      break;
    }
    await page.waitForTimeout(interval);
  }
  
  if (!progressStarted) {
    return { success: false, error: '未检测到进度条' };
  }
  
  // 等待进度条消失
  onProgress('处理中...');
  let progressEnded = false;
  let checkCount = 0;
  
  while (!progressEnded && Date.now() - startTime < timeout) {
    const found = await checkTextExists(page, progressText);
    checkCount++;
    
    if (!found) {
      progressEnded = true;
      onProgress('进度条已消失');
      break;
    }
    
    if (checkCount % 5 === 0) {
      const elapsed = Math.round((Date.now() - startTime) / 1000);
      onProgress(`处理中... (${elapsed}秒)`);
    }
    
    await page.waitForTimeout(interval);
  }
  
  if (!progressEnded) {
    return { success: false, error: '进度条未消失（超时）' };
  }
  
  // 额外等待结果渲染
  await page.waitForTimeout(5000);
  
  return { success: true };
}

/**
 * 检测文本是否存在
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} text - 文本
 * @returns {Promise<boolean>}
 */
async function checkTextExists(page, text) {
  return page.evaluate((t) => {
    return document.body.innerText.includes(t);
  }, text);
}

/**
 * 等待文本变化
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} selector - 选择器
 * @param {string} oldText - 旧文本
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, newText?: string, error?: string}>}
 */
async function waitForTextChange(page, selector, oldText, options = {}) {
  const { timeout = 30000, interval = 500 } = options;
  
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const text = await page.textContent(selector).catch(() => null);
    
    if (text && text !== oldText) {
      return { success: true, newText: text };
    }
    
    await page.waitForTimeout(interval);
  }
  
  return { success: false, error: '文本未变化' };
}

/**
 * 等待元素数量变化
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} selector - 选择器
 * @param {number} expectedCount - 期望数量
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, count?: number, error?: string}>}
 */
async function waitForElementCount(page, selector, expectedCount, options = {}) {
  const { timeout = 30000, interval = 500, operator = '>=' } = options;
  
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const count = await page.locator(selector).count();
    
    const match = operator === '>=' ? count >= expectedCount :
                  operator === '<=' ? count <= expectedCount :
                  operator === '>' ? count > expectedCount :
                  operator === '<' ? count < expectedCount :
                  count === expectedCount;
    
    if (match) {
      return { success: true, count };
    }
    
    await page.waitForTimeout(interval);
  }
  
  const count = await page.locator(selector).count();
  return { 
    success: false, 
    count, 
    error: `元素数量不匹配: 期望${operator}${expectedCount}, 实际${count}` 
  };
}

/**
 * 等待 DOM 稳定
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean}>}
 */
async function waitForDOMStable(page, options = {}) {
  const { 
    checkInterval = 500, 
    stableCount = 3, 
    timeout = 30000 
  } = options;
  
  const startTime = Date.now();
  let lastHTML = '';
  let stableTimes = 0;
  
  while (Date.now() - startTime < timeout) {
    const html = await page.content();
    
    if (html === lastHTML) {
      stableTimes++;
      if (stableTimes >= stableCount) {
        return { success: true };
      }
    } else {
      stableTimes = 0;
      lastHTML = html;
    }
    
    await page.waitForTimeout(checkInterval);
  }
  
  return { success: false, error: 'DOM 未稳定' };
}

/**
 * 检测加载状态
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, isLoading?: boolean}>}
 */
async function checkLoadingState(page, options = {}) {
  const { loadingSelectors = [] } = options;
  
  // 检查常见加载指示器
  const defaultLoadingSelectors = [
    '.loading',
    '.spinner',
    '[class*="loading"]',
    '[class*="spinner"]'
  ];
  
  const selectors = [...defaultLoadingSelectors, ...loadingSelectors];
  
  for (const selector of selectors) {
    const count = await page.locator(selector).count();
    if (count > 0) {
      const visible = await page.locator(selector).first().isVisible();
      if (visible) {
        return { success: true, isLoading: true };
      }
    }
  }
  
  return { success: true, isLoading: false };
}

/**
 * 等待加载完成
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function waitForLoadingComplete(page, options = {}) {
  const { timeout = 60000, interval = 1000 } = options;
  
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const { isLoading } = await checkLoadingState(page, options);
    
    if (!isLoading) {
      return { success: true };
    }
    
    await page.waitForTimeout(interval);
  }
  
  return { success: false, error: '加载未完成' };
}

/**
 * 监控进度百分比
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, finalPercent?: number, error?: string}>}
 */
async function monitorProgressPercent(page, options = {}) {
  const { 
    timeout = 300000, 
    interval = 2000,
    onProgress = () => {}
  } = options;
  
  const startTime = Date.now();
  let lastPercent = 0;
  
  while (Date.now() - startTime < timeout) {
    const percent = await page.evaluate(() => {
      // 查找进度条
      const progressBar = document.querySelector('[role="progressbar"]');
      if (progressBar) {
        const value = progressBar.getAttribute('aria-valuenow');
        return value ? parseInt(value) : null;
      }
      
      // 查找百分比文本
      const text = document.body.innerText;
      const match = text.match(/(\d+)%/);
      return match ? parseInt(match[1]) : null;
    });
    
    if (percent !== null && percent !== lastPercent) {
      lastPercent = percent;
      onProgress(percent);
    }
    
    if (percent === 100) {
      return { success: true, finalPercent: 100 };
    }
    
    await page.waitForTimeout(interval);
  }
  
  return { success: false, error: '进度监控超时', finalPercent: lastPercent };
}

module.exports = {
  waitForPolishProgress,
  checkTextExists,
  waitForTextChange,
  waitForElementCount,
  waitForDOMStable,
  checkLoadingState,
  waitForLoadingComplete,
  monitorProgressPercent
};
