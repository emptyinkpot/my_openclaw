/**
 * 日志记录系统
 * 
 * 提供统一的日志记录功能，支持文件输出和终端彩色输出
 * 
 * @module utils/logger
 */

const fs = require('fs');
const path = require('path');

// 日志级别
const LOG_LEVELS = {
  debug: 0,
  info: 1,
  success: 1,
  warn: 2,
  error: 3,
};

// 终端颜色
const COLORS = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  
  black: '\x1b[30m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  
  bgRed: '\x1b[41m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
};

// 图标
const ICONS = {
  debug: '🔍',
  info: 'ℹ️',
  success: '✅',
  warn: '⚠️',
  error: '❌',
  task: '📋',
  time: '⏱️',
};

// 全局配置
let globalConfig = {
  level: 'info',
  logDir: '/tmp/novel-sync-logs',
  enableFile: true,
  enableConsole: true,
};

/**
 * 日志类
 */
class Logger {
  constructor(namespace, options = {}) {
    this.namespace = namespace;
    this.level = options.level || globalConfig.level;
    this.logFile = null;
    
    if (globalConfig.enableFile) {
      this.initLogFile();
    }
  }
  
  /**
   * 初始化日志文件
   */
  initLogFile() {
    if (!fs.existsSync(globalConfig.logDir)) {
      fs.mkdirSync(globalConfig.logDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    this.logFile = path.join(globalConfig.logDir, `${this.namespace}-${timestamp}.log`);
  }
  
  /**
   * 格式化时间戳
   */
  getTimestamp() {
    return new Date().toISOString().slice(11, 23);
  }
  
  /**
   * 检查是否应该输出该级别的日志
   */
  shouldLog(level) {
    return LOG_LEVELS[level] >= LOG_LEVELS[this.level];
  }
  
  /**
   * 写入日志
   */
  write(level, message, data = null) {
    if (!this.shouldLog(level)) return;
    
    const timestamp = this.getTimestamp();
    const icon = ICONS[level] || '';
    
    // 终端输出
    if (globalConfig.enableConsole) {
      const color = {
        debug: COLORS.dim,
        info: COLORS.cyan,
        success: COLORS.green,
        warn: COLORS.yellow,
        error: COLORS.red,
      }[level] || COLORS.white;
      
      const prefix = `${COLORS.dim}[${timestamp}]${COLORS.reset} ${color}${icon}${COLORS.reset} ${COLORS.bright}[${this.namespace}]${COLORS.reset}`;
      
      console.log(`${prefix} ${message}`);
      
      if (data !== null) {
        console.log(COLORS.dim + JSON.stringify(data, null, 2) + COLORS.reset);
      }
    }
    
    // 文件输出
    if (globalConfig.enableFile && this.logFile) {
      const logLine = `[${timestamp}] [${level.toUpperCase()}] [${this.namespace}] ${message}${data ? '\n' + JSON.stringify(data, null, 2) : ''}\n`;
      fs.appendFileSync(this.logFile, logLine);
    }
  }
  
  /**
   * 调试日志
   */
  debug(message, data = null) {
    this.write('debug', message, data);
  }
  
  /**
   * 信息日志
   */
  info(message, data = null) {
    this.write('info', message, data);
  }
  
  /**
   * 成功日志
   */
  success(message, data = null) {
    this.write('success', message, data);
  }
  
  /**
   * 警告日志
   */
  warn(message, data = null) {
    this.write('warn', message, data);
  }
  
  /**
   * 错误日志
   */
  error(message, error = null) {
    const data = error ? {
      message: error.message,
      stack: error.stack,
    } : null;
    this.write('error', message, data);
  }
  
  /**
   * 任务开始
   */
  taskStart(taskName) {
    this.write('info', `${ICONS.task} 开始任务: ${taskName}`);
    return Date.now();
  }
  
  /**
   * 任务完成
   */
  taskEnd(taskName, startTime) {
    const elapsed = Date.now() - startTime;
    this.write('success', `${ICONS.task} 完成任务: ${taskName} (${ICONS.time} ${elapsed}ms)`);
    return elapsed;
  }
  
  /**
   * 分隔线
   */
  separator(char = '=', length = 60) {
    console.log(COLORS.dim + char.repeat(length) + COLORS.reset);
  }
  
  /**
   * 标题
   */
  title(text) {
    this.separator();
    console.log(COLORS.bright + COLORS.cyan + text + COLORS.reset);
    this.separator();
  }
}

/**
 * 创建日志实例
 * @param {string} namespace - 命名空间
 * @param {Object} options - 选项
 * @returns {Logger}
 */
function createLogger(namespace, options = {}) {
  return new Logger(namespace, options);
}

/**
 * 设置全局配置
 * @param {Object} config - 配置对象
 */
function setGlobalConfig(config) {
  Object.assign(globalConfig, config);
}

/**
 * 获取全局配置
 * @returns {Object}
 */
function getGlobalConfig() {
  return { ...globalConfig };
}

// 创建默认导出
const logger = createLogger('default');

module.exports = {
  Logger,
  create: createLogger,
  createLogger,
  setGlobalConfig,
  getGlobalConfig,
  default: logger,
};
