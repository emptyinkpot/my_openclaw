/**
 * 安全操作模块
 * 
 * 提供带重试和超时的安全操作
 * 
 * 功能：
 * - 安全点击（带重试）
 * - 安全输入（带验证）
 * - 安全等待（带超时）
 * - 安全滚动
 */

/**
 * 安全点击
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} selector - 选择器
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function safeClick(page, selector, options = {}) {
  const { 
    timeout = 10000, 
    retries = 3, 
    waitBefore = 0,
    waitAfter = 300 
  } = options;
  
  for (let i = 0; i < retries; i++) {
    try {
      if (waitBefore > 0) {
        await page.waitForTimeout(waitBefore);
      }
      
      // 等待元素可见
      await page.waitForSelector(selector, { 
        state: 'visible', 
        timeout 
      });
      
      // 点击
      await page.click(selector);
      
      if (waitAfter > 0) {
        await page.waitForTimeout(waitAfter);
      }
      
      return { success: true };
    } catch (e) {
      if (i === retries - 1) {
        return { 
          success: false, 
          error: `点击失败 (${retries}次重试): ${e.message}` 
        };
      }
      
      // 等待后重试
      await page.waitForTimeout(1000);
    }
  }
  
  return { success: false, error: '未知错误' };
}

/**
 * 安全输入
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} selector - 选择器
 * @param {string} text - 输入文本
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function safeInput(page, selector, text, options = {}) {
  const { 
    timeout = 10000, 
    retries = 3, 
    clear = true,
    verify = true,
    delay = 50
  } = options;
  
  for (let i = 0; i < retries; i++) {
    try {
      // 等待元素可见
      await page.waitForSelector(selector, { 
        state: 'visible', 
        timeout 
      });
      
      // 聚焦
      await page.focus(selector);
      await page.waitForTimeout(200);
      
      // 清空
      if (clear) {
        await page.fill(selector, '');
        await page.waitForTimeout(200);
      }
      
      // 输入
      await page.type(selector, text, { delay });
      await page.waitForTimeout(300);
      
      // 验证
      if (verify) {
        const value = await page.inputValue(selector);
        if (value !== text) {
          throw new Error(`输入验证失败: 期望"${text}", 实际"${value}"`);
        }
      }
      
      return { success: true };
    } catch (e) {
      if (i === retries - 1) {
        return { 
          success: false, 
          error: `输入失败 (${retries}次重试): ${e.message}` 
        };
      }
      
      await page.waitForTimeout(1000);
    }
  }
  
  return { success: false, error: '未知错误' };
}

/**
 * 安全等待选择器
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} selector - 选择器
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function safeWait(page, selector, options = {}) {
  const { 
    timeout = 30000, 
    state = 'visible',
    retries = 1 
  } = options;
  
  for (let i = 0; i < retries; i++) {
    try {
      await page.waitForSelector(selector, { state, timeout });
      return { success: true };
    } catch (e) {
      if (i === retries - 1) {
        return { 
          success: false, 
          error: `等待超时: ${selector}` 
        };
      }
      
      await page.waitForTimeout(2000);
    }
  }
  
  return { success: false, error: '未知错误' };
}

/**
 * 安全滚动
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean}>}
 */
async function safeScroll(page, options = {}) {
  const { 
    direction = 'bottom', 
    steps = 10, 
    waitBetween = 500 
  } = options;
  
  try {
    const scrollHeight = await page.evaluate(() => document.body.scrollHeight);
    const viewportHeight = await page.evaluate(() => window.innerHeight);
    const stepSize = (scrollHeight - viewportHeight) / steps;
    
    for (let i = 0; i < steps; i++) {
      const y = direction === 'bottom' 
        ? stepSize * (i + 1) 
        : scrollHeight - stepSize * (i + 1);
      
      await page.evaluate((scrollY) => {
        window.scrollTo(0, scrollY);
      }, y);
      
      await page.waitForTimeout(waitBetween);
    }
    
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 安全执行（带超时和重试）
 * 
 * @param {Function} fn - 异步函数
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, result?: any, error?: string}>}
 */
async function safeExecute(fn, options = {}) {
  const { timeout = 30000, retries = 1, delay = 1000 } = options;
  
  for (let i = 0; i < retries; i++) {
    try {
      const result = await Promise.race([
        fn(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('操作超时')), timeout)
        )
      ]);
      
      return { success: true, result };
    } catch (e) {
      if (i === retries - 1) {
        return { 
          success: false, 
          error: `执行失败 (${retries}次重试): ${e.message}` 
        };
      }
      
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  return { success: false, error: '未知错误' };
}

/**
 * 安全导航
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} url - URL
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function safeNavigate(page, url, options = {}) {
  const { 
    timeout = 30000, 
    waitUntil = 'domcontentloaded',
    retries = 2 
  } = options;
  
  for (let i = 0; i < retries; i++) {
    try {
      await page.goto(url, { timeout, waitUntil });
      return { success: true };
    } catch (e) {
      if (i === retries - 1) {
        return { 
          success: false, 
          error: `导航失败: ${url} - ${e.message}` 
        };
      }
      
      await page.waitForTimeout(2000);
    }
  }
  
  return { success: false, error: '未知错误' };
}

/**
 * 安全截图
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} path - 保存路径
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function safeScreenshot(page, path) {
  try {
    await page.screenshot({ path, fullPage: false });
    return { success: true, path };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 等待文本出现
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} text - 文本内容
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function waitForText(page, text, options = {}) {
  const { timeout = 30000, interval = 1000 } = options;
  
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const found = await page.evaluate((t) => {
      return document.body.innerText.includes(t);
    }, text);
    
    if (found) {
      return { success: true };
    }
    
    await page.waitForTimeout(interval);
  }
  
  return { success: false, error: `等待文本超时: "${text}"` };
}

/**
 * 等待文本消失
 * 
 * @param {Page} page - Playwright page 对象
 * @param {string} text - 文本内容
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function waitForTextGone(page, text, options = {}) {
  const { timeout = 30000, interval = 1000 } = options;
  
  const startTime = Date.now();
  
  while (Date.now() - startTime < timeout) {
    const found = await page.evaluate((t) => {
      return document.body.innerText.includes(t);
    }, text);
    
    if (!found) {
      return { success: true };
    }
    
    await page.waitForTimeout(interval);
  }
  
  return { success: false, error: `等待文本消失超时: "${text}"` };
}

module.exports = {
  safeClick,
  safeInput,
  safeWait,
  safeScroll,
  safeExecute,
  safeNavigate,
  safeScreenshot,
  waitForText,
  waitForTextGone
};
