/**
 * 工具模块索引
 * 
 * @module utils
 */

const logger = require('./logger');
const retry = require('./retry');
const progress = require('./progress');
const resultChecker = require('./result-checker');
const argsParser = require('./args-parser');
const helper = require('./helper');
const taskRunner = require('./task-runner');
const fileUtils = require('./file-utils');
const safeAction = require('./safe-action');
const progressDetector = require('./progress-detector');
const backupManager = require('./backup-manager');
const workflow = require('./workflow');
const screenshot = require('./screenshot');
const storage = require('./storage');
const debugger_ = require('./debugger');
const StepReporter = require('./step-reporter');
const input = require('./input');
const errorPatterns = require('./error-patterns');
const autoFixer = require('./auto-fixer');
const experienceStore = require('./experience-store');
const selfHealing = require('./self-healing');

module.exports = {
  // 原有模块
  logger,
  retry,
  progress,
  resultChecker,
  argsParser,
  helper,
  taskRunner,
  fileUtils,
  safeAction,
  progressDetector,
  backupManager,
  workflow,
  screenshot,
  storage,
  debugger: debugger_,
  StepReporter,
  input,
  
  // 自动调试系统
  errorPatterns,
  autoFixer,
  experienceStore,
  selfHealing,
};
