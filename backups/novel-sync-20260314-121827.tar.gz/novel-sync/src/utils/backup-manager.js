/**
 * 备份管理模块
 * 
 * 提供统一的备份和恢复功能
 * 
 * 功能：
 * - 创建备份
 * - 恢复备份
 * - 校验备份
 * - 清理旧备份
 * - 备份索引管理
 */

const fs = require('fs');
const path = require('path');
const fileUtils = require('./file-utils');

// 默认配置
const DEFAULT_CONFIG = {
  backupDir: './backups',
  retention: {
    daily: 7,      // 最近7天每天一份
    weekly: 4,     // 最近4周每周一份
    monthly: 12    // 最近12月每月一份
  },
  verify: true
};

/**
 * 创建备份
 * 
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, version?: string, path?: string, error?: string}>}
 */
async function createBackup(options = {}) {
  const {
    backupDir = DEFAULT_CONFIG.backupDir,
    targets = [],
    trigger = 'manual'
  } = options;
  
  // 生成版本号
  const timestamp = new Date().toISOString().replace(/[-:T]/g, '').substring(0, 14);
  const version = `v${timestamp}`;
  const backupPath = path.join(backupDir, version);
  
  // 创建备份目录
  fileUtils.ensureDir(backupPath);
  
  // 备份清单
  const manifest = {
    version,
    timestamp: new Date().toISOString(),
    trigger,
    files: [],
    stats: {
      totalFiles: 0,
      totalSize: 0,
      successCount: 0,
      failedCount: 0
    }
  };
  
  // 执行备份
  for (const target of targets) {
    const result = backupTarget(target, backupPath);
    
    manifest.files.push(...result.files);
    manifest.stats.totalFiles += result.files.length;
    manifest.stats.totalSize += result.totalSize;
    manifest.stats.successCount += result.successCount;
    manifest.stats.failedCount += result.failedCount;
  }
  
  // 保存清单
  const manifestPath = path.join(backupPath, 'manifest.json');
  const writeResult = fileUtils.safeWrite(manifestPath, JSON.stringify(manifest, null, 2));
  
  if (!writeResult.success) {
    return { success: false, error: '保存清单失败' };
  }
  
  // 校验备份
  if (options.verify !== false) {
    const verifyResult = verifyBackup(backupPath, manifest);
    if (!verifyResult.success) {
      // 删除无效备份
      fileUtils.removeDirectory(backupPath);
      return { success: false, error: '备份校验失败', details: verifyResult.errors };
    }
  }
  
  // 更新索引
  updateBackupIndex(backupDir, version, manifest);
  
  return {
    success: true,
    version,
    path: backupPath,
    stats: manifest.stats
  };
}

/**
 * 备份单个目标
 */
function backupTarget(target, backupPath) {
  const result = {
    files: [],
    totalSize: 0,
    successCount: 0,
    failedCount: 0
  };
  
  if (target.type === 'directory') {
    const srcPath = target.path;
    const destPath = path.join(backupPath, target.name);
    
    if (!fs.existsSync(srcPath)) {
      return result;
    }
    
    const copyResult = fileUtils.copyDirectory(srcPath, destPath, {
      filter: target.filter
    });
    
    result.files = copyResult.files.map(f => ({
      path: f,
      checksum: fileUtils.calculateChecksum(f)
    }));
    result.totalSize = copyResult.totalSize;
    result.successCount = copyResult.files.length;
    result.failedCount = copyResult.errors.length;
    
  } else if (target.type === 'file') {
    const srcPath = target.path;
    const destPath = path.join(backupPath, target.name);
    
    if (!fs.existsSync(srcPath)) {
      return result;
    }
    
    const copyResult = fileUtils.copyFile(srcPath, destPath);
    
    if (copyResult.success) {
      result.files.push({
        path: destPath,
        checksum: fileUtils.calculateChecksum(destPath)
      });
      result.totalSize = copyResult.size;
      result.successCount = 1;
    } else {
      result.failedCount = 1;
    }
  }
  
  return result;
}

/**
 * 校验备份
 * 
 * @param {string} backupPath - 备份路径
 * @param {Object} manifest - 备份清单
 * @returns {{success: boolean, errors: string[]}}
 */
function verifyBackup(backupPath, manifest) {
  const errors = [];
  
  // 检查清单文件
  const manifestPath = path.join(backupPath, 'manifest.json');
  if (!fs.existsSync(manifestPath)) {
    errors.push('清单文件不存在');
    return { success: false, errors };
  }
  
  // 校验文件完整性
  for (const file of manifest.files) {
    const filePath = file.path;
    
    if (!fs.existsSync(filePath)) {
      errors.push(`文件不存在: ${filePath}`);
      continue;
    }
    
    // 校验校验和
    if (file.checksum) {
      const checksum = fileUtils.calculateChecksum(filePath);
      if (checksum !== file.checksum) {
        errors.push(`校验和不匹配: ${filePath}`);
      }
    }
  }
  
  return {
    success: errors.length === 0,
    errors
  };
}

/**
 * 恢复备份
 * 
 * @param {string} version - 版本号
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function restoreBackup(version, options = {}) {
  const {
    backupDir = DEFAULT_CONFIG.backupDir,
    targets = null,  // null 表示恢复所有
    dryRun = false
  } = options;
  
  const backupPath = path.join(backupDir, version);
  
  if (!fs.existsSync(backupPath)) {
    return { success: false, error: `备份不存在: ${version}` };
  }
  
  // 读取清单
  const manifestPath = path.join(backupPath, 'manifest.json');
  const readResult = fileUtils.safeRead(manifestPath);
  
  if (!readResult.success) {
    return { success: false, error: '读取清单失败' };
  }
  
  const manifest = JSON.parse(readResult.content);
  
  // 校验备份
  const verifyResult = verifyBackup(backupPath, manifest);
  if (!verifyResult.success) {
    return { 
      success: false, 
      error: '备份校验失败', 
      details: verifyResult.errors 
    };
  }
  
  // 恢复文件
  const restoreTargets = targets || manifest.files;
  
  for (const file of restoreTargets) {
    if (dryRun) {
      console.log(`[DRY-RUN] 将恢复: ${file.path}`);
      continue;
    }
    
    // 实际恢复逻辑（需要根据具体需求实现）
    // ...
  }
  
  return { success: true, stats: manifest.stats };
}

/**
 * 清理旧备份
 * 
 * @param {Object} options - 选项
 * @returns {{removed: string[], kept: string[]}}
 */
function cleanupOldBackups(options = {}) {
  const {
    backupDir = DEFAULT_CONFIG.backupDir,
    retention = DEFAULT_CONFIG.retention
  } = options;
  
  if (!fs.existsSync(backupDir)) {
    return { removed: [], kept: [] };
  }
  
  // 获取所有备份版本
  const versions = fs.readdirSync(backupDir)
    .filter(name => name.startsWith('v') && fs.statSync(path.join(backupDir, name)).isDirectory())
    .sort()
    .reverse();  // 最新的在前
  
  const now = new Date();
  const removed = [];
  const kept = [];
  
  // 分类保留
  const dailyKeep = new Set();
  const weeklyKeep = new Set();
  const monthlyKeep = new Set();
  
  for (const version of versions) {
    const date = parseVersionDate(version);
    if (!date) continue;
    
    const daysAgo = Math.floor((now - date) / (1000 * 60 * 60 * 24));
    const weekAgo = Math.floor(daysAgo / 7);
    const monthAgo = Math.floor(daysAgo / 30);
    
    // 最近7天每天一份
    if (daysAgo < retention.daily && dailyKeep.size < retention.daily) {
      dailyKeep.add(version);
      continue;
    }
    
    // 最近4周每周一份
    if (weekAgo < retention.weekly && !weeklyKeep.has(weekAgo)) {
      weeklyKeep.add(weekAgo);
      continue;
    }
    
    // 最近12月每月一份
    if (monthAgo < retention.monthly && !monthlyKeep.has(monthAgo)) {
      monthlyKeep.add(monthAgo);
      continue;
    }
  }
  
  // 确定保留和删除
  const allKeep = new Set([...dailyKeep, ...weeklyKeep, ...monthlyKeep]);
  
  for (const version of versions) {
    if (allKeep.has(version) || version === versions[0]) {
      kept.push(version);
    } else {
      removed.push(version);
      fileUtils.removeDirectory(path.join(backupDir, version));
    }
  }
  
  return { removed, kept };
}

/**
 * 解析版本日期
 */
function parseVersionDate(version) {
  const match = version.match(/v(\d{14})/);
  if (!match) return null;
  
  const str = match[1];
  return new Date(
    parseInt(str.substring(0, 4)),
    parseInt(str.substring(4, 6)) - 1,
    parseInt(str.substring(6, 8)),
    parseInt(str.substring(8, 10)),
    parseInt(str.substring(10, 12)),
    parseInt(str.substring(12, 14))
  );
}

/**
 * 更新备份索引
 */
function updateBackupIndex(backupDir, version, manifest) {
  const indexPath = path.join(backupDir, 'index.json');
  
  let index = { versions: [] };
  
  if (fs.existsSync(indexPath)) {
    const readResult = fileUtils.safeRead(indexPath);
    if (readResult.success) {
      index = JSON.parse(readResult.content);
    }
  }
  
  // 添加新版本
  index.versions.push({
    version,
    timestamp: manifest.timestamp,
    trigger: manifest.trigger,
    stats: manifest.stats
  });
  
  // 按时间排序
  index.versions.sort((a, b) => 
    new Date(b.timestamp) - new Date(a.timestamp)
  );
  
  fileUtils.safeWrite(indexPath, JSON.stringify(index, null, 2));
}

/**
 * 列出所有备份
 * 
 * @param {Object} options - 选项
 * @returns {Array}
 */
function listBackups(options = {}) {
  const { backupDir = DEFAULT_CONFIG.backupDir } = options;
  const indexPath = path.join(backupDir, 'index.json');
  
  if (!fs.existsSync(indexPath)) {
    return [];
  }
  
  const readResult = fileUtils.safeRead(indexPath);
  if (!readResult.success) {
    return [];
  }
  
  const index = JSON.parse(readResult.content);
  return index.versions || [];
}

/**
 * 获取最新备份
 * 
 * @param {Object} options - 选项
 * @returns {Object|null}
 */
function getLatestBackup(options = {}) {
  const backups = listBackups(options);
  return backups.length > 0 ? backups[0] : null;
}

module.exports = {
  createBackup,
  restoreBackup,
  verifyBackup,
  cleanupOldBackups,
  listBackups,
  getLatestBackup,
  updateBackupIndex
};
