/**
 * 参数解析工具模块
 * 
 * 提供统一的命令行参数解析功能
 * 
 * 功能：
 * - 解析章节号（支持多种格式）
 * - 解析作品名
 * - 解析选项标志
 */

/**
 * 解析章节号
 * 
 * 支持格式：
 * - 数字: 66
 * - 中文: 六十六
 * - 带章: 第66章, 第六十六章
 * 
 * @param {string} input - 输入
 * @returns {number|null}
 */
function parseChapterNum(input) {
  if (!input) return null;
  
  // 纯数字
  if (/^\d+$/.test(input)) {
    return parseInt(input);
  }
  
  // 第X章 格式
  const match = input.match(/^第(.+)章$/);
  if (match) {
    const num = match[1];
    
    // 数字
    if (/^\d+$/.test(num)) {
      return parseInt(num);
    }
    
    // 中文数字
    return chineseToNumber(num);
  }
  
  // 纯中文数字
  return chineseToNumber(input);
}

/**
 * 中文数字转数字
 * 
 * @param {string} str - 中文数字字符串
 * @returns {number|null}
 */
function chineseToNumber(str) {
  // 简单映射
  const simpleMap = {
    '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
    '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
    '十一': 11, '十二': 12, '十三': 13, '十四': 14, '十五': 15,
    '十六': 16, '十七': 17, '十八': 18, '十九': 19, '二十': 20,
    '二十一': 21, '二十二': 22, '二十三': 23, '二十四': 24, '二十五': 25,
    '二十六': 26, '二十七': 27, '二十八': 28, '二十九': 29, '三十': 30,
    '三十一': 31, '三十二': 32, '三十三': 33, '三十四': 34, '三十五': 35,
    '三十六': 36, '三十七': 37, '三十八': 38, '三十九': 39, '四十': 40,
    '四十一': 41, '四十二': 42, '四十三': 43, '四十四': 44, '四十五': 45,
    '四十六': 46, '四十七': 47, '四十八': 48, '四十九': 49, '五十': 50,
    '五十一': 51, '五十二': 52, '五十三': 53, '五十四': 54, '五十五': 55,
    '五十六': 56, '五十七': 57, '五十八': 58, '五十九': 59, '六十': 60,
    '六十一': 61, '六十二': 62, '六十三': 63, '六十四': 64, '六十五': 65,
    '六十六': 66, '六十七': 67, '六十八': 68, '六十九': 69, '七十': 70,
    '七十一': 71, '七十二': 72, '七十三': 73, '七十四': 74, '七十五': 75,
    '七十六': 76, '七十七': 77, '七十八': 78, '七十九': 79, '八十': 80,
    '八十一': 81, '八十二': 82, '八十三': 83, '八十四': 84, '八十五': 85,
    '八十六': 86, '八十七': 87, '八十八': 88, '八十九': 89, '九十': 90,
    '九十一': 91, '九十二': 92, '九十三': 93, '九十四': 94, '九十五': 95,
    '九十六': 96, '九十七': 97, '九十八': 98, '九十九': 99, '一百': 100
  };
  
  // 直接匹配
  if (simpleMap[str]) {
    return simpleMap[str];
  }
  
  // 复杂解析（如 "九十九"）
  let result = 0;
  let temp = 0;
  
  for (const char of str) {
    const num = simpleMap[char];
    if (!num) continue;
    
    if (num === 10) {
      temp = temp === 0 ? 10 : temp * 10;
    } else if (num < 10) {
      temp = num;
    } else {
      result += temp;
      temp = num;
    }
  }
  
  result += temp;
  return result > 0 ? result : null;
}

/**
 * 解析命令行参数
 * 
 * @param {string[]} args - process.argv.slice(2)
 * @param {Object} schema - 参数定义
 * @returns {Object}
 * 
 * @example
 * const params = parseArgs(process.argv.slice(2), {
 *   workName: { index: 0, required: true },
 *   chapter: { index: 1, parse: 'chapterNum' },
 *   force: { flag: true },
 *   'no-backup': { flag: true }
 * });
 * 
 * // 结果: { workName: '作品名', chapter: 66, force: false, 'no-backup': true }
 */
function parseArgs(args, schema) {
  const result = {};
  const positionalArgs = args.filter(a => !a.startsWith('--'));
  const flags = args.filter(a => a.startsWith('--'));
  
  for (const [key, def] of Object.entries(schema)) {
    // 标志参数
    if (def.flag) {
      result[key] = flags.includes(`--${key}`);
      continue;
    }
    
    // 位置参数
    if (def.index !== undefined) {
      const value = positionalArgs[def.index];
      
      if (!value && def.required) {
        throw new Error(`缺少必需参数: ${key}`);
      }
      
      // 类型转换
      if (value) {
        if (def.parse === 'chapterNum') {
          result[key] = parseChapterNum(value);
        } else if (def.parse === 'int') {
          result[key] = parseInt(value);
        } else if (def.parse === 'float') {
          result[key] = parseFloat(value);
        } else if (def.parse === 'boolean') {
          result[key] = value === 'true';
        } else {
          result[key] = value;
        }
      }
      
      // 默认值
      if (result[key] === undefined && def.default !== undefined) {
        result[key] = def.default;
      }
    }
  }
  
  return result;
}

/**
 * 显示用法说明
 * 
 * @param {string} scriptName - 脚本名
 * @param {Object} schema - 参数定义
 * @param {string[]} examples - 示例命令
 */
function showUsage(scriptName, schema, examples = []) {
  console.log(`用法: node ${scriptName}`);
  
  const required = [];
  const optional = [];
  
  for (const [key, def] of Object.entries(schema)) {
    if (def.flag) {
      optional.push(`[--${key}]`);
    } else if (def.required) {
      required.push(`<${key}>`);
    } else {
      optional.push(`[${key}]`);
    }
  }
  
  console.log(`  ${required.join(' ')} ${optional.join(' ')}`);
  console.log('');
  
  // 参数说明
  console.log('参数:');
  for (const [key, def] of Object.entries(schema)) {
    const req = def.required ? '(必需)' : '(可选)';
    const desc = def.description || '';
    console.log(`  ${key} ${req} ${desc}`);
  }
  
  // 示例
  if (examples.length > 0) {
    console.log('');
    console.log('示例:');
    for (const ex of examples) {
      console.log(`  ${ex}`);
    }
  }
}

module.exports = {
  parseChapterNum,
  chineseToNumber,
  parseArgs,
  showUsage
};
