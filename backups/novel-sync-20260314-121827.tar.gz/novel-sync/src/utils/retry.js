/**
 * 重试机制模块
 * 
 * 提供统一的错误处理和自动重试功能
 * 
 * @module utils/retry
 */

const logger = require('./logger');

/**
 * 默认重试配置
 */
const DEFAULT_CONFIG = {
  maxRetries: 3,
  delay: 2000,
  backoff: 'linear', // linear, exponential, none
  onRetry: null,     // 重试前的回调
  onSuccess: null,   // 成功后的回调
  onFinalError: null, // 最终失败后的回调
};

/**
 * 延迟函数
 * @param {number} ms - 毫秒
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 计算延迟时间
 * @param {number} attempt - 当前尝试次数
 * @param {Object} config - 配置
 */
function calculateDelay(attempt, config) {
  const { delay, backoff } = config;
  
  switch (backoff) {
    case 'exponential':
      return delay * Math.pow(2, attempt - 1);
    case 'linear':
      return delay * attempt;
    case 'none':
    default:
      return delay;
  }
}

/**
 * 带重试的执行函数
 * 
 * @param {Function} fn - 要执行的函数
 * @param {Object} options - 配置选项
 * @returns {Promise<any>} 函数执行结果
 * 
 * @example
 * const result = await retry(async () => {
 *   return await someAsyncOperation();
 * }, { maxRetries: 3, delay: 1000 });
 */
async function retry(fn, options = {}) {
  const config = { ...DEFAULT_CONFIG, ...options };
  const log = options.logger || logger.create('retry');
  
  let lastError;
  
  for (let attempt = 1; attempt <= config.maxRetries; attempt++) {
    try {
      const result = await fn();
      
      // 成功回调
      if (config.onSuccess) {
        await config.onSuccess(result, attempt);
      }
      
      return result;
    } catch (error) {
      lastError = error;
      
      const isLastAttempt = attempt === config.maxRetries;
      
      if (isLastAttempt) {
        // 最终失败回调
        if (config.onFinalError) {
          await config.onFinalError(error, attempt);
        }
        
        log.error(`所有重试失败 (${attempt}/${config.maxRetries})`, error);
        throw error;
      }
      
      const delayMs = calculateDelay(attempt, config);
      
      log.warn(`尝试 ${attempt}/${config.maxRetries} 失败: ${error.message}`);
      log.info(`${delayMs}ms 后重试...`);
      
      // 重试前回调
      if (config.onRetry) {
        await config.onRetry(error, attempt, delayMs);
      }
      
      await sleep(delayMs);
    }
  }
  
  throw lastError;
}

/**
 * 带重试的页面操作
 * 
 * @param {Page} page - Playwright page 对象
 * @param {Function} fn - 操作函数
 * @param {Object} options - 配置选项
 */
async function retryPageAction(page, fn, options = {}) {
  return retry(fn, {
    ...options,
    onRetry: async (error, attempt, delay) => {
      // 页面操作失败时，尝试恢复
      if (options.recovery) {
        await options.recovery(page, error, attempt);
      }
      
      if (options.onRetry) {
        await options.onRetry(error, attempt, delay);
      }
    },
  });
}

/**
 * 批量操作（带重试）
 * 
 * @param {Array} items - 要处理的项
 * @param {Function} fn - 处理函数
 * @param {Object} options - 配置选项
 * @returns {Promise<{success: Array, failed: Array}>}
 */
async function batchRetry(items, fn, options = {}) {
  const log = options.logger || logger.create('batch');
  const results = {
    success: [],
    failed: [],
  };
  
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const index = i + 1;
    
    log.info(`处理 ${index}/${items.length}...`);
    
    try {
      const result = await retry(() => fn(item, i), {
        ...options,
        logger: log,
      });
      
      results.success.push({ item, result, index });
      log.success(`✓ 第 ${index} 项处理成功`);
    } catch (error) {
      results.failed.push({ item, error, index });
      log.error(`✗ 第 ${index} 项处理失败: ${error.message}`);
      
      // 如果配置为失败后停止
      if (options.stopOnError) {
        break;
      }
    }
  }
  
  return results;
}

/**
 * 超时包装器
 * 
 * @param {Promise} promise - 要执行的 Promise
 * @param {number} timeout - 超时时间（毫秒）
 * @param {string} message - 超时错误消息
 */
async function withTimeout(promise, timeout, message = '操作超时') {
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error(`${message} (${timeout}ms)`)), timeout);
    }),
  ]);
}

/**
 * 错误类型判断
 */
const ErrorTypes = {
  isTimeout: (error) => error.message?.includes('timeout') || error.message?.includes('Timeout'),
  isNetwork: (error) => error.message?.includes('network') || error.message?.includes('ENOTFOUND'),
  isNotFound: (error) => error.message?.includes('not found') || error.message?.includes('404'),
  isRateLimit: (error) => error.message?.includes('rate') || error.message?.includes('429'),
};

module.exports = {
  retry,
  retryPageAction,
  batchRetry,
  withTimeout,
  sleep,
  ErrorTypes,
  DEFAULT_CONFIG,
};
