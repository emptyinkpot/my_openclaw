/**
 * 经验存储模块
 * 
 * 设计原则：
 * - 结构化：JSON 格式存储，方便查询
 * - 持久化：自动保存到文件
 * - 统计性：自动计算成功率
 * - 可查询：支持按类型、时间、关键词查询
 * 
 * @module utils/experience-store
 */

const fs = require('fs');
const path = require('path');

// 默认存储路径
const DEFAULT_STORE_PATH = '/tmp/openclaw/experience/store.json';

/**
 * 经验存储类
 */
class ExperienceStore {
  constructor(options = {}) {
    this.storePath = options.storePath || DEFAULT_STORE_PATH;
    this.autoSave = options.autoSave !== false;
    this.maxRecords = options.maxRecords || 1000;
    
    // 内存缓存
    this.records = [];
    this.stats = {
      totalRecords: 0,
      successCount: 0,
      failureCount: 0,
      byType: {},
      byPattern: {},
    };
    
    // 初始化
    this._load();
  }
  
  // ============================================================
  // 记录方法
  // ============================================================
  
  /**
   * 记录成功修复
   */
  recordSuccess(pattern, error, context, result) {
    const record = this._createRecord('success', pattern, error, context, result);
    this.records.unshift(record);
    this._updateStats('success', pattern);
    this._trimRecords();
    this._save();
    return record;
  }
  
  /**
   * 记录修复失败
   */
  recordFailure(pattern, error, context) {
    const record = this._createRecord('failure', pattern, error, context);
    this.records.unshift(record);
    this._updateStats('failure', pattern);
    this._trimRecords();
    this._save();
    return record;
  }
  
  /**
   * 创建记录
   */
  _createRecord(status, pattern, error, context, result) {
    return {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
      timestamp: new Date().toISOString(),
      status,
      pattern: {
        id: pattern.id,
        type: pattern.type,
        severity: pattern.severity,
      },
      error: typeof error === 'string' ? error : error.message,
      context: this._sanitizeContext(context),
      result: result ? {
        action: result.action,
        attempts: result.attempts,
      } : null,
    };
  }
  
  /**
   * 清理上下文（移除不可序列化的内容）
   */
  _sanitizeContext(context) {
    const safe = {};
    for (const [key, value] of Object.entries(context)) {
      if (['page', 'browser', 'fn', 'function', 'authRestoreFn'].includes(key)) {
        continue;
      }
      if (typeof value === 'function') {
        continue;
      }
      if (typeof value === 'object' && value !== null) {
        try {
          JSON.stringify(value);
          safe[key] = value;
        } catch (e) {
          // 不可序列化，跳过
        }
      } else {
        safe[key] = value;
      }
    }
    return safe;
  }
  
  // ============================================================
  // 查询方法
  // ============================================================
  
  /**
   * 查询历史经验
   */
  query(options = {}) {
    let results = [...this.records];
    
    // 按状态筛选
    if (options.status) {
      results = results.filter(r => r.status === options.status);
    }
    
    // 按类型筛选
    if (options.type) {
      results = results.filter(r => r.pattern.type === options.type);
    }
    
    // 按模式筛选
    if (options.patternId) {
      results = results.filter(r => r.pattern.id === options.patternId);
    }
    
    // 关键词搜索
    if (options.keyword) {
      const kw = options.keyword.toLowerCase();
      results = results.filter(r => 
        r.error.toLowerCase().includes(kw) ||
        (r.result?.action || '').toLowerCase().includes(kw)
      );
    }
    
    // 时间范围
    if (options.since) {
      const since = new Date(options.since);
      results = results.filter(r => new Date(r.timestamp) >= since);
    }
    
    // 限制数量
    if (options.limit) {
      results = results.slice(0, options.limit);
    }
    
    return results;
  }
  
  /**
   * 查找相似错误的成功案例
   */
  findSimilarSuccess(error) {
    const message = typeof error === 'string' ? error : error.message;
    const pattern = this._extractPattern(message);
    
    return this.records.find(r => 
      r.status === 'success' && 
      r.pattern.id === pattern
    );
  }
  
  /**
   * 获取最佳修复策略
   */
  getBestStrategy(patternId) {
    const successRecords = this.records.filter(r => 
      r.status === 'success' && 
      r.pattern.id === patternId
    );
    
    if (successRecords.length === 0) {
      return null;
    }
    
    // 统计各策略成功率
    const strategies = {};
    for (const record of successRecords) {
      const action = record.result?.action || 'unknown';
      strategies[action] = (strategies[action] || 0) + 1;
    }
    
    // 返回最成功的策略
    const best = Object.entries(strategies)
      .sort((a, b) => b[1] - a[1])[0];
    
    return {
      action: best[0],
      successCount: best[1],
      totalAttempts: this.records.filter(r => r.pattern.id === patternId).length,
    };
  }
  
  /**
   * 获取统计信息
   */
  getStats() {
    return {
      ...this.stats,
      successRate: this.stats.totalRecords > 0 
        ? (this.stats.successCount / this.stats.totalRecords * 100).toFixed(1) + '%'
        : 'N/A',
    };
  }
  
  // ============================================================
  // 统计更新
  // ============================================================
  
  /**
   * 更新统计
   */
  _updateStats(status, pattern) {
    this.stats.totalRecords++;
    
    if (status === 'success') {
      this.stats.successCount++;
    } else {
      this.stats.failureCount++;
    }
    
    // 按类型统计
    if (!this.stats.byType[pattern.type]) {
      this.stats.byType[pattern.type] = { success: 0, failure: 0 };
    }
    this.stats.byType[pattern.type][status]++;
    
    // 按模式统计
    if (!this.stats.byPattern[pattern.id]) {
      this.stats.byPattern[pattern.id] = { success: 0, failure: 0 };
    }
    this.stats.byPattern[pattern.id][status]++;
  }
  
  /**
   * 提取错误模式 ID
   */
  _extractPattern(message) {
    // 简单的关键词匹配
    if (/timeout/i.test(message)) return 'TIMEOUT_SELECTOR';
    if (/not found|no element/i.test(message)) return 'SELECTOR_NOT_FOUND';
    if (/login|auth|token/i.test(message)) return 'AUTH_EXPIRED';
    if (/network|ENOTFOUND|ECONNREFUSED/i.test(message)) return 'NETWORK_ERROR';
    if (/browser|crash|closed/i.test(message)) return 'BROWSER_CRASHED';
    return 'UNKNOWN';
  }
  
  // ============================================================
  // 持久化
  // ============================================================
  
  /**
   * 保存到文件
   */
  _save() {
    if (!this.autoSave) return;
    
    try {
      const dir = path.dirname(this.storePath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      
      fs.writeFileSync(this.storePath, JSON.stringify({
        stats: this.stats,
        records: this.records.slice(0, this.maxRecords),
      }, null, 2));
    } catch (e) {
      console.error('[ExperienceStore] 保存失败:', e.message);
    }
  }
  
  /**
   * 从文件加载
   */
  _load() {
    try {
      if (fs.existsSync(this.storePath)) {
        const data = JSON.parse(fs.readFileSync(this.storePath, 'utf8'));
        this.stats = data.stats || this.stats;
        this.records = data.records || [];
      }
    } catch (e) {
      console.error('[ExperienceStore] 加载失败:', e.message);
    }
  }
  
  /**
   * 清理旧记录
   */
  _trimRecords() {
    if (this.records.length > this.maxRecords) {
      this.records = this.records.slice(0, this.maxRecords);
    }
  }
  
  /**
   * 清空所有记录
   */
  clear() {
    this.records = [];
    this.stats = {
      totalRecords: 0,
      successCount: 0,
      failureCount: 0,
      byType: {},
      byPattern: {},
    };
    this._save();
  }
  
  /**
   * 导出为 Markdown
   */
  exportMarkdown() {
    const lines = [
      '# 经验库统计',
      '',
      `**总记录**: ${this.stats.totalRecords}`,
      `**成功**: ${this.stats.successCount}`,
      `**失败**: ${this.stats.failureCount}`,
      '',
      '## 按错误类型',
      '',
    ];
    
    for (const [type, counts] of Object.entries(this.stats.byType)) {
      lines.push(`- ${type}: 成功 ${counts.success}, 失败 ${counts.failure}`);
    }
    
    lines.push('', '## 最近记录', '');
    
    for (const record of this.records.slice(0, 20)) {
      lines.push(`### ${record.timestamp} [${record.status}]`);
      lines.push(`- 模式: ${record.pattern.id}`);
      lines.push(`- 错误: ${record.error.slice(0, 100)}...`);
      if (record.result) {
        lines.push(`- 修复: ${record.result.action}`);
      }
      lines.push('');
    }
    
    return lines.join('\n');
  }
}

// 单例
let instance = null;

/**
 * 获取单例
 */
function getStore(options = {}) {
  if (!instance) {
    instance = new ExperienceStore(options);
  }
  return instance;
}

module.exports = getStore();
module.exports.ExperienceStore = ExperienceStore;
module.exports.getStore = getStore;
