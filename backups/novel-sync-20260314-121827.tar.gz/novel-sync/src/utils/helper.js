/**
 * 通用工具函数
 */

/**
 * 数字转中文
 */
function numToChinese(num) {
  if (num <= 20) {
    const map = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十',
      '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十'];
    return map[num] || String(num);
  }
  const digits = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
  const units = ['', '十', '百'];
  let result = '', n = num, unitIndex = 0;
  while (n > 0) {
    const digit = n % 10;
    if (digit > 0) result = digits[digit] + units[unitIndex] + result;
    n = Math.floor(n / 10);
    unitIndex++;
  }
  return result;
}

/**
 * 中文数字转阿拉伯数字
 * @param {string} str - 中文数字或阿拉伯数字
 * @returns {number} 数字
 */
function chineseToNumber(str) {
  // 如果是纯数字，直接返回
  if (/^\d+$/.test(str)) {
    return parseInt(str, 10);
  }
  
  const nums = {
    '零': 0, '〇': 0,
    '一': 1, '二': 2, '三': 3, '四': 4,
    '五': 5, '六': 6, '七': 7, '八': 8,
    '九': 9
  };
  
  const units = { '十': 10, '百': 100, '千': 1000 };
  
  let result = 0;
  let temp = 0;  // 当前累计的数字
  
  for (let i = 0; i < str.length; i++) {
    const char = str[i];
    
    if (nums[char] !== undefined) {
      // 数字：0-9
      temp = temp * 10 + nums[char];
    } else if (units[char] !== undefined) {
      // 单位：十、百、千
      const unit = units[char];
      
      // 特殊处理：开头是单位（如 "十一" = 11）
      if (temp === 0 && i === 0) {
        temp = 1;
      }
      
      result += temp * unit;
      temp = 0;
    }
  }
  
  // 加上剩余的个位数
  result += temp;
  
  return result;
}

/**
 * 解析章节号（支持多种格式）
 * @param {string|number} input - 章节名或章节号
 * @returns {number} 章节号数字
 * 
 * 支持格式：
 * - 数字：1, 66, 100
 * - 中文：第一章, 六十六
 * - 阿拉伯：第1章, 第66章
 * - 带标题：第一章：故事, 第1章 故事
 */
function parseChapterNumber(input) {
  if (typeof input === 'number') return input;
  
  const str = input.toString().trim();
  
  // 纯数字：1, 66, 100
  if (/^\d+$/.test(str)) {
    return parseInt(str, 10);
  }
  
  // 第X章格式：第一章, 第1章, 第66章
  const match = str.match(/第([零一二三四五六七八九十百千\d]+)章/);
  if (match) {
    return chineseToNumber(match[1]);
  }
  
  // 纯中文数字：一, 六十六
  if (/^[零一二三四五六七八九十百千]+$/.test(str)) {
    return chineseToNumber(str);
  }
  
  // 尝试提取数字
  const numMatch = str.match(/(\d+)/);
  if (numMatch) {
    return parseInt(numMatch[1], 10);
  }
  
  return 0;
}

/**
 * 字符串相似度
 */
function similarity(str1, str2) {
  if (!str1 || !str2) return 0;
  if (str1 === str2) return 1;
  
  const s1 = str1.trim().toLowerCase();
  const s2 = str2.trim().toLowerCase();
  
  if (s1 === s2) return 1;
  if (s1.length === 0 || s2.length === 0) return 0;
  if (s1.includes(s2) || s2.includes(s1)) return 0.8;
  
  let matches = 0;
  const len = Math.min(s1.length, s2.length);
  for (let i = 0; i < len; i++) {
    if (s1[i] === s2[i]) matches++;
  }
  
  return matches / Math.max(s1.length, s2.length);
}

module.exports = { numToChinese, chineseToNumber, parseChapterNumber, similarity };
