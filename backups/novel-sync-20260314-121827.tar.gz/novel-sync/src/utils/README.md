# 工具模块 (utils)

## 功能说明

通用工具函数，可跨平台复用。

---

## helper.js

### 功能
通用辅助函数

### 导出函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `numToChinese(num)` | 数字转中文 | `num`: 数字 | `string` |
| `similarity(str1, str2)` | 字符串相似度 | `str1`, `str2` | `number (0-1)` |

### numToChinese

**功能**：将数字转换为中文格式

**示例**：
```javascript
numToChinese(1)   // "一"
numToChinese(15)  // "十五"
numToChinese(42)  // "四十二"
numToChinese(100) // "一百"
```

**实现要点**：
- 1-20 使用映射表
- 21+ 使用 digits + units
- **必须保留 units 数组**（历史教训：精简时丢失导致错误）

**代码**：
```javascript
function numToChinese(num) {
  if (num <= 20) {
    const map = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十',
      '十一', '十二', '十三', '十四', '十五', '十六', '十七', '十八', '十九', '二十'];
    return map[num] || String(num);
  }
  const digits = ['', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
  const units = ['', '十', '百'];  // 必须保留！
  let result = '', n = num, unitIndex = 0;
  while (n > 0) {
    const digit = n % 10;
    if (digit > 0) result = digits[digit] + units[unitIndex] + result;
    n = Math.floor(n / 10);
    unitIndex++;
  }
  return result;
}
```

### similarity

**功能**：计算两个字符串的相似度

**示例**：
```javascript
similarity('hello', 'hello')  // 1
similarity('hello', 'world')  // 0.2
similarity('abc', 'abcd')     // 0.8 (包含关系)
```

**用途**：模糊匹配作品标题

---

## dom.js（待创建）

### 功能
DOM 操作工具函数

### 计划函数

| 函数 | 说明 | 参数 | 返回值 |
|------|------|------|--------|
| `waitForElement(page, selector)` | 等待元素出现 | `page`, `selector` | `Promise<Element>` |
| `isVisible(page, selector)` | 检查元素是否可见 | `page`, `selector` | `Promise<boolean>` |

---

## 使用示例

```javascript
const { numToChinese, similarity } = require('./src/utils/helper');

// 数字转中文
const chapterName = `第${numToChinese(42)}章`; // "第四十二章"

// 模糊匹配
const score = similarity('枪与凋零之花', '枪与凋零');
// score = 0.8
```
