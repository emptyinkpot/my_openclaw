/**
 * 统一文本输入工具
 * 
 * 问题：Playwright 的 keyboard.type() 逐字符输入，速度极慢
 * 解决：根据场景选择最高效的输入方式
 * 
 * @module input
 * @example
 * const input = require('./input');
 * 
 * // 快速填充（推荐，瞬间完成）
 * await input.fastFill(page, 'textarea', content);
 * 
 * // 智能输入（自动选择最佳方式）
 * await input.smartInput(page, 'textarea', content);
 */

/**
 * 快速填充 - 直接设置元素值（最快）
 * 
 * 适用场景：
 * - textarea、input[type="text"]
 * - contenteditable 元素
 * - 白梦编辑器 (.Daydream)
 * 
 * @param {import('playwright').Page} page - Playwright page 对象
 * @param {string} selector - 元素选择器
 * @param {string} content - 要填充的内容
 * @throws {Error} 元素不存在时抛出错误
 * @example
 * await input.fastFill(page, 'textarea', 'hello world');
 */
async function fastFill(page, selector, content) {
  if (!page) throw new Error('page 参数不能为空');
  if (!selector) throw new Error('selector 参数不能为空');
  if (content === undefined) content = '';
  
  await page.evaluate(({ sel, val }) => {
    const el = document.querySelector(sel);
    if (!el) throw new Error(`元素不存在: ${sel}`);
    
    // 根据元素类型选择设置方式
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      // 标准 input/textarea
      el.value = val;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    } else if (el.isContentEditable || el.classList.contains('Daydream')) {
      // contenteditable 或白梦编辑器
      el.innerHTML = val;
      el.dispatchEvent(new Event('input', { bubbles: true }));
    } else {
      // 其他元素，尝试设置 textContent
      el.textContent = val;
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }, { sel: selector, val: content });
}

/**
 * 模拟输入 - 触发完整事件链（中等速度）
 * 
 * 适用场景：
 * - 需要触发 keydown/keyup 事件的输入框
 * - 框架组件（React、Vue 等）
 * 
 * @param {import('playwright').Page} page - Playwright page 对象
 * @param {string} selector - 元素选择器
 * @param {string} text - 要输入的文本
 * @param {object} options - 选项
 * @param {number} [options.delay=0] - 每个字符之间的延迟（毫秒）
 * @param {boolean} [options.clear=true] - 是否先清空
 * @throws {Error} 元素不存在时抛出错误
 * @example
 * await input.simulateType(page, 'input', 'hello', { delay: 10 });
 */
async function simulateType(page, selector, text, options = {}) {
  const { delay = 0, clear = true } = options;
  
  if (!page) throw new Error('page 参数不能为空');
  if (!selector) throw new Error('selector 参数不能为空');
  if (text === undefined) text = '';
  
  const el = await page.$(selector);
  if (!el) throw new Error(`元素不存在: ${selector}`);
  
  // 点击聚焦
  await el.click();
  await page.waitForTimeout(50);
  
  // 清空
  if (clear) {
    await page.keyboard.press('Control+a');
    await page.waitForTimeout(30);
  }
  
  // 如果不需要延迟，直接填充（快得多）
  if (delay === 0) {
    await page.evaluate((elem, val) => {
      elem.value = val;
      elem.dispatchEvent(new Event('input', { bubbles: true }));
      elem.dispatchEvent(new Event('change', { bubbles: true }));
    }, el, text);
  } else {
    // 需要延迟才逐字符输入
    await page.keyboard.type(text, { delay });
  }
}

/**
 * 剪贴板粘贴 - 通过剪贴板粘贴（极快）
 * 
 * 适用场景：
 * - 大量文本
 * - 支持粘贴的输入框
 * - 需要保留格式的富文本
 * 
 * @param {import('playwright').Page} page - Playwright page 对象
 * @param {string} selector - 元素选择器
 * @param {string} content - 要粘贴的内容
 * @throws {Error} 元素不存在时抛出错误
 * @example
 * await input.pasteFromClipboard(page, 'textarea', longText);
 */
async function pasteFromClipboard(page, selector, content) {
  if (!page) throw new Error('page 参数不能为空');
  if (!selector) throw new Error('selector 参数不能为空');
  if (content === undefined) content = '';
  
  // 写入剪贴板
  await page.evaluate((text) => {
    navigator.clipboard.writeText(text);
  }, content);
  
  // 点击目标元素
  const el = await page.$(selector);
  if (!el) throw new Error(`元素不存在: ${selector}`);
  await el.click();
  await page.waitForTimeout(50);
  
  // 触发粘贴
  await page.keyboard.press('Control+v');
  await page.waitForTimeout(50);
}

/**
 * 智能输入 - 自动选择最佳方式
 * 
 * 根据内容长度和元素类型自动选择最高效的输入方式：
 * - textarea / contenteditable → fastFill（瞬间）
 * - input 且内容短 → simulateType（快）
 * - 其他 → pasteFromClipboard（极快）
 * 
 * @param {import('playwright').Page} page - Playwright page 对象
 * @param {string} selector - 元素选择器
 * @param {string} content - 要输入的内容
 * @param {object} options - 选项
 * @param {'auto'|'fast'|'simulate'|'paste'} [options.mode='auto'] - 输入模式
 * @throws {Error} 元素不存在时抛出错误
 * @example
 * // 自动选择最佳方式
 * await input.smartInput(page, 'textarea', content);
 * 
 * // 强制使用剪贴板粘贴
 * await input.smartInput(page, 'textarea', content, { mode: 'paste' });
 */
async function smartInput(page, selector, content, options = {}) {
  const { mode = 'auto' } = options;
  
  // 参数验证
  if (!page) throw new Error('page 参数不能为空');
  if (!selector) throw new Error('selector 参数不能为空');
  if (content === undefined) content = '';
  
  // 指定模式直接使用
  if (mode === 'fast') return fastFill(page, selector, content);
  if (mode === 'simulate') return simulateType(page, selector, content);
  if (mode === 'paste') return pasteFromClipboard(page, selector, content);
  
  // auto 模式：根据元素类型自动选择
  const el = await page.$(selector);
  if (!el) throw new Error(`元素不存在: ${selector}`);
  
  const info = await el.evaluate(e => ({
    tagName: e.tagName,
    isContentEditable: e.isContentEditable,
    isDaydream: e.classList.contains('Daydream')
  }));
  
  // 白梦编辑器或 contenteditable：直接填充
  if (info.isDaydream || info.isContentEditable) {
    return fastFill(page, selector, content);
  }
  
  // textarea：直接填充
  if (info.tagName === 'TEXTAREA') {
    return fastFill(page, selector, content);
  }
  
  // input 且内容较短（<100字）：模拟输入
  if (info.tagName === 'INPUT' && content.length < 100) {
    return simulateType(page, selector, content);
  }
  
  // 其他情况：尝试剪贴板粘贴，失败则回退到快速填充
  try {
    return pasteFromClipboard(page, selector, content);
  } catch {
    return fastFill(page, selector, content);
  }
}

module.exports = {
  fastFill,
  simulateType,
  pasteFromClipboard,
  smartInput
};
