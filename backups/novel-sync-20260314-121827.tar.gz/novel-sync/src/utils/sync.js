/**
 * 作品同步工具
 * 
 * 用于匹配和同步番茄小说与白梦写作的作品标题
 */

const { similarity } = require('./helper');

/**
 * 匹配两个平台的作品
 * @param {Array} fanqieWorks - 番茄作品列表
 * @param {Array} baimengWorks - 白梦作品列表
 * @param {number} threshold - 相似度阈值 (0-1)
 * @returns {Object} 匹配结果
 */
function match(fanqieWorks, baimengWorks, threshold = 0.6) {
  const matches = [];
  const unmatched = { fanqie: [], baimeng: [] };
  
  // 白梦作品去重
  const baimengMap = new Map();
  baimengWorks.forEach(w => baimengMap.set(w.title, w));
  
  // 匹配番茄作品
  for (const fq of fanqieWorks) {
    let bestMatch = null;
    let bestScore = 0;
    
    for (const [bmTitle, bm] of baimengMap) {
      const score = similarity(fq.title, bmTitle);
      if (score > bestScore && score >= threshold) {
        bestScore = score;
        bestMatch = bm;
      }
    }
    
    if (bestMatch) {
      matches.push({
        fanqie: fq,
        baimeng: bestMatch,
        score: bestScore,
        needsSync: fq.title !== bestMatch.title
      });
      baimengMap.delete(bestMatch.title);
    } else {
      unmatched.fanqie.push(fq);
    }
  }
  
  // 剩余的白梦作品
  for (const [, bm] of baimengMap) {
    unmatched.baimeng.push(bm);
  }
  
  // 生成文本报告
  const lines = [];
  lines.push(`\n=== 匹配结果 ===\n`);
  lines.push(`匹配成功: ${matches.length} 个`);
  lines.push(`番茄独有: ${unmatched.fanqie.length} 个`);
  lines.push(`白梦独有: ${unmatched.baimeng.length} 个`);
  lines.push(``);
  
  if (matches.filter(m => m.needsSync).length > 0) {
    lines.push(`需要同步标题:`);
    matches.filter(m => m.needsSync).forEach(m => {
      lines.push(`  番茄: ${m.fanqie.title}`);
      lines.push(`  白梦: ${m.baimeng.title}`);
      lines.push(`  相似度: ${Math.round(m.score * 100)}%`);
      lines.push(``);
    });
  }
  
  return {
    matches,
    unmatched,
    text: lines.join('\n')
  };
}

/**
 * 同步标题
 * @param {Array} fanqieWorks - 番茄作品列表
 * @param {Array} baimengWorks - 白梦作品列表
 * @param {Object} baimengTask - 白梦任务模块
 * @param {number} threshold - 相似度阈值
 * @param {boolean} dryRun - 是否只预览
 * @returns {Object} 同步结果
 */
async function sync(fanqieWorks, baimengWorks, baimengTask, threshold = 0.6, dryRun = true) {
  const result = match(fanqieWorks, baimengWorks, threshold);
  const syncList = result.matches.filter(m => m.needsSync);
  
  console.log(`\n需要同步 ${syncList.length} 个标题\n`);
  
  if (dryRun) {
    console.log(`[预览模式] 以下标题将被同步:\n`);
    syncList.forEach((m, i) => {
      console.log(`${i + 1}. 白梦: "${m.baimeng.title}" → "${m.fanqie.title}"`);
    });
    console.log(`\n执行 node src/main.js sync --apply 进行实际同步`);
    return { dryRun: true, count: syncList.length, list: syncList };
  }
  
  // 实际同步
  const results = [];
  for (const m of syncList) {
    try {
      console.log(`\n同步: ${m.baimeng.title} → ${m.fanqie.title}`);
      const r = await baimengTask.updateTitle(m.baimeng.title, m.fanqie.title);
      results.push({ success: true, ...r });
    } catch (e) {
      console.error(`失败: ${e.message}`);
      results.push({ success: false, error: e.message, item: m });
    }
  }
  
  return {
    dryRun: false,
    total: syncList.length,
    success: results.filter(r => r.success).length,
    failed: results.filter(r => !r.success).length,
    results
  };
}

module.exports = { match, sync };
