/**
 * 浏览器管理器 - 支持完整备份恢复（Cookies + Local Storage）
 * 
 * ⚠️ 使用全局浏览器数据目录: /workspace/projects/browser/default
 */

const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const config = require('../config');

// 全局浏览器数据目录
const BROWSER_DATA_DIR = '/workspace/projects/browser/default';
// 全局备份文件路径
const BAIMENG_BACKUP_FILE = '/workspace/projects/cookies-accounts/baimeng-account-1-full.json';
const FANQIE_BACKUP_FILE = '/workspace/projects/cookies-accounts/fanqie-default-full.json';

class BrowserManager {
  constructor() {
    if (BrowserManager.instance) {
      return BrowserManager.instance;
    }
    this.browser = null;
    this.page = null;
    this.userDataDir = BROWSER_DATA_DIR;
    BrowserManager.instance = this;
  }

  async init() {
    if (this.browser) return this.browser;

    console.log('[Browser] 启动中...');
    
    // 清理锁文件
    this.cleanLockFiles();

    this.browser = await chromium.launchPersistentContext(this.userDataDir, {
      headless: false,
      viewport: null,  // 让浏览器自动调整视口
      args: [
        '--no-sandbox',
        '--start-maximized',  // 最大化窗口
        '--disable-session-crashed-bubble',
        '--hide-crash-restore-bubble',
        '--disable-popup-blocking',
        '--disable-external-intent-requests'
      ]
    });

    this.page = this.browser.pages()[0] || await this.browser.newPage();
    console.log('[Browser] 已启动');
    
    // 自动恢复白梦登录状态
    await this.autoRestoreBaimeng();
    // 自动恢复番茄登录状态
    await this.autoRestoreFanqie();
    
    return this.browser;
  }

  async getPage() {
    if (!this.browser) await this.init();
    return { page: this.page, browser: this.browser };
  }

  sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  cleanLockFiles() {
    const lockFiles = ['SingletonLock', 'SingletonSocket', 'SingletonCookie', 'Lock'];
    for (const file of lockFiles) {
      const filePath = path.join(this.userDataDir, file);
      if (fs.existsSync(filePath)) {
        try { fs.unlinkSync(filePath); } catch (e) {}
      }
    }
  }

  /**
   * 自动恢复白梦登录状态
   */
  async autoRestoreBaimeng() {
    if (!fs.existsSync(BAIMENG_BACKUP_FILE)) {
      return;
    }

    try {
      const backup = JSON.parse(fs.readFileSync(BAIMENG_BACKUP_FILE, 'utf-8'));
      console.log(`[Browser] 自动恢复白梦登录状态...`);
      
      // 先访问白梦
      await this.page.goto(config.BAIMENG.URL, { waitUntil: 'domcontentloaded' });
      await this.sleep(1000);
      
      // 恢复 Local Storage
      if (backup.localStorage) {
        await this.page.evaluate((items) => {
          for (const [key, value] of Object.entries(items)) {
            localStorage.setItem(key, value);
          }
        }, backup.localStorage);
        console.log(`[Browser] 已恢复 ${Object.keys(backup.localStorage).length} 个 Local Storage 项`);
      }
      
      // 恢复 Cookies
      if (backup.cookies && backup.cookies.length > 0) {
        await this.browser.addCookies(backup.cookies);
        console.log(`[Browser] 已恢复 ${backup.cookies.length} 个 Cookies`);
      }
      
      console.log(`[Browser] 白梦登录状态恢复完成`);
    } catch (e) {
      console.log('[Browser] 恢复白梦登录状态失败:', e.message);
    }
  }

  /**
   * 自动恢复番茄登录状态
   */
  async autoRestoreFanqie() {
    if (!fs.existsSync(FANQIE_BACKUP_FILE)) {
      return;
    }

    try {
      const backup = JSON.parse(fs.readFileSync(FANQIE_BACKUP_FILE, 'utf-8'));
      console.log(`[Browser] 自动恢复番茄登录状态...`);
      
      // 先访问番茄首页
      await this.page.goto('https://fanqienovel.com', { waitUntil: 'domcontentloaded' });
      await this.sleep(1000);
      
      // 恢复 Local Storage
      if (backup.localStorage) {
        await this.page.evaluate((items) => {
          for (const [key, value] of Object.entries(items)) {
            localStorage.setItem(key, value);
          }
        }, backup.localStorage);
        console.log(`[Browser] 已恢复 ${Object.keys(backup.localStorage).length} 个 Local Storage 项`);
      }
      
      // 恢复 Cookies
      if (backup.cookies && backup.cookies.length > 0) {
        await this.browser.addCookies(backup.cookies);
        console.log(`[Browser] 已恢复 ${backup.cookies.length} 个 Cookies`);
      }
      
      console.log(`[Browser] 番茄登录状态恢复完成`);
    } catch (e) {
      console.log('[Browser] 恢复番茄登录状态失败:', e.message);
    }
  }

  /**
   * 自动备份白梦登录状态
   */
  async autoBackupBaimeng() {
    if (!this.browser) return;

    try {
      await this.page.goto(config.BAIMENG.URL, { waitUntil: 'domcontentloaded' });
      await this.sleep(1000);
      
      const localStorage = await this.page.evaluate(() => {
        const items = {};
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          items[key] = localStorage.getItem(key);
        }
        return items;
      });
      
      const cookies = await this.browser.cookies(['https://baimengxiezuo.com']);
      
      const backup = {
        localStorage,
        cookies,
        timestamp: new Date().toISOString()
      };
      
      fs.writeFileSync(BAIMENG_BACKUP_FILE, JSON.stringify(backup, null, 2));
      console.log(`[Browser] 已备份白梦登录状态`);
    } catch (e) {
      console.log('[Browser] 备份白梦登录状态失败:', e.message);
    }
  }

  static getInstance() {
    if (!BrowserManager.instance) {
      BrowserManager.instance = new BrowserManager();
    }
    return BrowserManager.instance;
  }
}

module.exports = BrowserManager;
