/**
 * 文件操作工具模块
 * 
 * 提供通用的文件操作功能
 * 
 * 功能：
 * - 文件/目录复制
 * - 校验和计算
 * - 文件大小格式化
 * - 目录遍历
 * - 安全写入
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/**
 * 复制目录（递归）
 * 
 * @param {string} srcDir - 源目录
 * @param {string} destDir - 目标目录
 * @param {Object} options - 选项
 * @returns {{files: string[], totalSize: number, errors: string[]}}
 */
function copyDirectory(srcDir, destDir, options = {}) {
  const result = {
    files: [],
    totalSize: 0,
    errors: []
  };
  
  if (!fs.existsSync(srcDir)) {
    result.errors.push(`源目录不存在: ${srcDir}`);
    return result;
  }
  
  fs.mkdirSync(destDir, { recursive: true });
  
  const entries = fs.readdirSync(srcDir, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    
    if (entry.isDirectory()) {
      const subResult = copyDirectory(srcPath, destPath, options);
      result.files.push(...subResult.files);
      result.totalSize += subResult.totalSize;
      result.errors.push(...subResult.errors);
    } else {
      // 过滤文件
      if (options.filter && !options.filter(entry.name)) {
        continue;
      }
      
      const copyResult = copyFile(srcPath, destPath);
      if (copyResult.success) {
        result.files.push(destPath);
        result.totalSize += copyResult.size;
      } else {
        result.errors.push(copyResult.error);
      }
    }
  }
  
  return result;
}

/**
 * 复制单个文件
 * 
 * @param {string} srcPath - 源文件路径
 * @param {string} destPath - 目标文件路径
 * @returns {{success: boolean, size?: number, error?: string}}
 */
function copyFile(srcPath, destPath) {
  try {
    if (!fs.existsSync(srcPath)) {
      return { success: false, error: `源文件不存在: ${srcPath}` };
    }
    
    // 确保目标目录存在
    const destDir = path.dirname(destPath);
    fs.mkdirSync(destDir, { recursive: true });
    
    fs.copyFileSync(srcPath, destPath);
    const stat = fs.statSync(destPath);
    
    return { success: true, size: stat.size };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 计算文件校验和（MD5）
 * 
 * @param {string} filePath - 文件路径
 * @returns {string|null} 校验和
 */
function calculateChecksum(filePath) {
  try {
    const content = fs.readFileSync(filePath);
    return crypto.createHash('md5').update(content).digest('hex');
  } catch (e) {
    return null;
  }
}

/**
 * 格式化文件大小
 * 
 * @param {number} bytes - 字节数
 * @returns {string} 格式化后的字符串
 */
function formatSize(bytes) {
  if (bytes === 0) return '0 B';
  
  const units = ['B', 'KB', 'MB', 'GB'];
  const k = 1024;
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + units[i];
}

/**
 * 安全写入文件（原子操作）
 * 
 * @param {string} filePath - 文件路径
 * @param {string|Buffer} content - 内容
 * @returns {{success: boolean, error?: string}}
 */
function safeWrite(filePath, content) {
  try {
    const dir = path.dirname(filePath);
    fs.mkdirSync(dir, { recursive: true });
    
    // 先写入临时文件
    const tempPath = `${filePath}.tmp`;
    fs.writeFileSync(tempPath, content);
    
    // 重命名为目标文件（原子操作）
    fs.renameSync(tempPath, filePath);
    
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 安全读取文件
 * 
 * @param {string} filePath - 文件路径
 * @param {string} encoding - 编码（默认 utf-8）
 * @returns {{success: boolean, content?: string|Buffer, error?: string}}
 */
function safeRead(filePath, encoding = 'utf-8') {
  try {
    if (!fs.existsSync(filePath)) {
      return { success: false, error: '文件不存在' };
    }
    
    const content = fs.readFileSync(filePath, encoding);
    return { success: true, content };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 删除目录（递归）
 * 
 * @param {string} dirPath - 目录路径
 * @returns {{success: boolean, error?: string}}
 */
function removeDirectory(dirPath) {
  try {
    if (!fs.existsSync(dirPath)) {
      return { success: true }; // 目录不存在也算成功
    }
    
    fs.rmSync(dirPath, { recursive: true, force: true });
    return { success: true };
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 获取目录大小
 * 
 * @param {string} dirPath - 目录路径
 * @returns {number} 字节数
 */
function getDirectorySize(dirPath) {
  if (!fs.existsSync(dirPath)) return 0;
  
  let size = 0;
  const entries = fs.readdirSync(dirPath, { withFileTypes: true });
  
  for (const entry of entries) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      size += getDirectorySize(fullPath);
    } else {
      size += fs.statSync(fullPath).size;
    }
  }
  
  return size;
}

/**
 * 列出目录下所有文件
 * 
 * @param {string} dirPath - 目录路径
 * @param {Object} options - 选项
 * @returns {string[]} 文件路径列表
 */
function listFiles(dirPath, options = {}) {
  const { 
    recursive = true, 
    filter = null,
    relative = false 
  } = options;
  
  if (!fs.existsSync(dirPath)) return [];
  
  const files = [];
  
  function walk(dir, base) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      
      if (entry.isDirectory() && recursive) {
        walk(fullPath, base);
      } else if (entry.isFile()) {
        // 过滤
        if (filter && !filter(entry.name)) continue;
        
        files.push(relative ? path.relative(base, fullPath) : fullPath);
      }
    }
  }
  
  walk(dirPath, dirPath);
  return files;
}

/**
 * 确保目录存在
 * 
 * @param {string} dirPath - 目录路径
 */
function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

/**
 * 获取文件信息
 * 
 * @param {string} filePath - 文件路径
 * @returns {{exists: boolean, size?: number, mtime?: Date, isDir?: boolean}}
 */
function getFileInfo(filePath) {
  try {
    if (!fs.existsSync(filePath)) {
      return { exists: false };
    }
    
    const stat = fs.statSync(filePath);
    return {
      exists: true,
      size: stat.size,
      mtime: stat.mtime,
      isDir: stat.isDirectory()
    };
  } catch (e) {
    return { exists: false };
  }
}

module.exports = {
  copyDirectory,
  copyFile,
  calculateChecksum,
  formatSize,
  safeWrite,
  safeRead,
  removeDirectory,
  getDirectorySize,
  listFiles,
  ensureDir,
  getFileInfo
};
