/**
 * 结果验证工具模块
 * 
 * 提供各种验证功能，确保操作正确性
 * 
 * 功能：
 * - 内容长度验证
 * - 内容变化检测
 * - 章节匹配验证
 * - 异常内容检测
 */

/**
 * 验证内容长度
 * 
 * @param {string} content - 内容
 * @param {Object} options - 选项
 * @returns {{valid: boolean, reason?: string}}
 */
function verifyLength(content, options = {}) {
  const { 
    minLength = 50, 
    maxLength = 100000,
    warnLength = 500 
  } = options;
  
  if (!content) {
    return { valid: false, reason: '内容为空' };
  }
  
  const len = content.length;
  
  if (len < minLength) {
    return { valid: false, reason: `内容过短（${len}字 < ${minLength}字），可能是占位符` };
  }
  
  if (len > maxLength) {
    return { valid: false, reason: `内容过长（${len}字 > ${maxLength}字），可能提取错误` };
  }
  
  if (len < warnLength) {
    return { valid: true, reason: `⚠️ 内容较短（${len}字），请确认` };
  }
  
  return { valid: true };
}

/**
 * 验证内容变化
 * 
 * @param {string} before - 修改前内容
 * @param {string} after - 修改后内容
 * @param {Object} options - 选项
 * @returns {{changed: boolean, ratio: number, reason?: string}}
 */
function verifyChange(before, after, options = {}) {
  const { minChangeRatio = 0.01, maxChangeRatio = 2.0 } = options;
  
  if (!before || !after) {
    return { changed: false, ratio: 0, reason: '内容为空' };
  }
  
  const beforeLen = before.length;
  const afterLen = after.length;
  const ratio = afterLen / beforeLen;
  
  // 完全相同
  if (before === after) {
    return { changed: false, ratio: 1, reason: '内容未变化' };
  }
  
  // 变化过大
  if (ratio > maxChangeRatio) {
    return { 
      changed: true, 
      ratio, 
      reason: `⚠️ 内容大幅增加（${(ratio * 100).toFixed(0)}%），请确认` 
    };
  }
  
  if (ratio < minChangeRatio) {
    return { 
      changed: true, 
      ratio, 
      reason: `⚠️ 内容大幅减少（${(ratio * 100).toFixed(0)}%），请确认` 
    };
  }
  
  return { changed: true, ratio };
}

/**
 * 检测异常内容
 * 
 * @param {string} content - 内容
 * @returns {{valid: boolean, issues: string[]}}
 */
function detectAnomalies(content) {
  const issues = [];
  
  // 占位符检测
  const placeholders = [
    '润色结果将显示在这里',
    '请输入内容',
    '加载中',
    'undefined',
    'null'
  ];
  
  for (const p of placeholders) {
    if (content.includes(p)) {
      issues.push(`包含占位符: "${p}"`);
    }
  }
  
  // 工具栏文字检测
  const toolbarTexts = ['章节概要', '批量生成概要', '总结当前章节概要'];
  for (const t of toolbarTexts) {
    if (content.includes(t)) {
      issues.push(`包含工具栏文字: "${t}"`);
    }
  }
  
  // 重复行检测
  const lines = content.split('\n');
  const lineCounts = {};
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed && trimmed.length > 10) {
      lineCounts[trimmed] = (lineCounts[trimmed] || 0) + 1;
    }
  }
  
  for (const [line, count] of Object.entries(lineCounts)) {
    if (count > 3) {
      issues.push(`重复行(${count}次): "${line.substring(0, 30)}..."`);
    }
  }
  
  // 过多空行检测
  const emptyLines = lines.filter(l => !l.trim()).length;
  if (emptyLines > lines.length * 0.5) {
    issues.push(`空行过多（${emptyLines}/${lines.length}）`);
  }
  
  return {
    valid: issues.length === 0,
    issues
  };
}

/**
 * 验证章节标题
 * 
 * @param {string} title - 标题
 * @param {number} expectedChapter - 预期章节号
 * @returns {{valid: boolean, reason?: string}}
 */
function verifyChapterTitle(title, expectedChapter) {
  if (!title) {
    return { valid: false, reason: '标题为空' };
  }
  
  // 提取章节号
  const match = title.match(/第([一二三四五六七八九十\d]+)章/);
  
  if (!match) {
    return { valid: false, reason: `标题格式错误: ${title}` };
  }
  
  // 转换章节号
  const chapterStr = match[1];
  const chapterNum = chineseToNumber(chapterStr) || parseInt(chapterStr);
  
  if (chapterNum !== expectedChapter) {
    return { 
      valid: false, 
      reason: `章节号不匹配: 标题="${title}", 预期=第${expectedChapter}章` 
    };
  }
  
  return { valid: true, chapterNum };
}

/**
 * 中文数字转数字
 */
function chineseToNumber(str) {
  const map = {
    '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
    '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
    '十一': 11, '十二': 12, '十三': 13, '十四': 14, '十五': 15,
    '十六': 16, '十七': 17, '十八': 18, '十九': 19, '二十': 20
  };
  return map[str] || null;
}

/**
 * 综合验证
 * 
 * @param {Object} data - 验证数据
 * @param {string} data.originalContent - 原始内容
 * @param {string} data.polishedContent - 润色后内容
 * @param {string} data.originalTitle - 原始标题
 * @param {string} data.polishedTitle - 润色后标题
 * @param {number} data.chapterNum - 章节号
 * @returns {{valid: boolean, issues: string[]}}
 */
function comprehensiveVerify(data) {
  const issues = [];
  
  // 1. 验证润色结果长度
  const lengthResult = verifyLength(data.polishedContent);
  if (!lengthResult.valid) {
    issues.push(`润色结果: ${lengthResult.reason}`);
  }
  
  // 2. 验证内容变化
  const changeResult = verifyChange(data.originalContent, data.polishedContent);
  if (changeResult.reason) {
    issues.push(`内容变化: ${changeResult.reason}`);
  }
  
  // 3. 检测异常内容
  const anomalyResult = detectAnomalies(data.polishedContent);
  if (!anomalyResult.valid) {
    issues.push(`异常检测: ${anomalyResult.issues.join('; ')}`);
  }
  
  // 4. 验证章节标题
  if (data.chapterNum && data.polishedTitle) {
    const titleResult = verifyChapterTitle(data.polishedTitle, data.chapterNum);
    if (!titleResult.valid) {
      issues.push(`标题验证: ${titleResult.reason}`);
    }
  }
  
  return {
    valid: issues.length === 0,
    issues
  };
}

module.exports = {
  verifyLength,
  verifyChange,
  detectAnomalies,
  verifyChapterTitle,
  comprehensiveVerify
};
