/**
 * 调试工具模块
 * 
 * 提供统一的调试和诊断功能，避免重复造轮子
 * 
 * 功能：
 * - 页面状态诊断
 * - 元素探查
 * - 截图诊断
 * - 缓存管理
 * - 错误记录
 * - 中间结果保存
 */

const fs = require('fs');
const path = require('path');
const screenshot = require('./screenshot');

// 默认调试目录
const DEBUG_DIR = '/tmp/openclaw/debug';

/**
 * 调试器类
 */
class Debugger {
  constructor(options = {}) {
    this.namespace = options.namespace || 'default';
    this.debugDir = options.debugDir || DEBUG_DIR;
    this.enableLog = options.enableLog !== false;
    
    this.logFile = path.join(this.debugDir, this.namespace, 'debug.log');
    this.cacheDir = path.join(this.debugDir, this.namespace, 'cache');
    
    this._ensureDirs();
  }
  
  // ============================================================
  // 页面诊断
  // ============================================================
  
  /**
   * 诊断页面状态
   * 
   * @param {Page} page - Playwright 页面对象
   * @param {Object} options - 选项
   * @returns {Promise<Object>} 诊断结果
   */
  async diagnosePage(page, options = {}) {
    const { screenshot: takeScreenshot = true, dom = true, storage = true } = options;
    
    const result = {
      timestamp: new Date().toISOString(),
      url: page.url(),
      title: await page.title().catch(() => null),
    };
    
    // 基本信息
    result.basic = {
      url: result.url,
      title: result.title,
      viewport: page.viewportSize(),
    };
    
    // DOM 信息
    if (dom) {
      result.dom = await this._analyzeDOM(page);
    }
    
    // 存储信息
    if (storage) {
      result.storage = await this._analyzeStorage(page);
    }
    
    // 截图
    if (takeScreenshot) {
      result.screenshot = await screenshot.takeScreenshot(page, 'diagnosis', {
        dir: path.join(this.debugDir, this.namespace),
        timestamp: true
      });
    }
    
    // 记录日志
    this.log('diagnosis', result);
    
    return result;
  }
  
  /**
   * 分析 DOM 结构
   */
  async _analyzeDOM(page) {
    return await page.evaluate(() => {
      // 常见编辑器选择器
      const editors = [
        '.Daydream',
        '.ProseMirror',
        '[contenteditable="true"]',
        'textarea',
        '.editor'
      ];
      
      const result = {
        editors: [],
        buttons: [],
        inputs: []
      };
      
      // 检查编辑器
      for (const sel of editors) {
        const els = document.querySelectorAll(sel);
        if (els.length > 0) {
          result.editors.push({
            selector: sel,
            count: els.length,
            firstContent: els[0]?.innerText?.substring(0, 100)
          });
        }
      }
      
      // 检查关键按钮
      const buttonPatterns = ['保存', '发布', '提交', '润色', '复制'];
      for (const text of buttonPatterns) {
        const btn = document.querySelector(`button:has-text("${text}")`);
        if (btn) {
          result.buttons.push({
            text,
            visible: btn.offsetParent !== null,
            disabled: btn.disabled
          });
        }
      }
      
      // 检查输入框
      const inputs = document.querySelectorAll('input[type="text"], textarea');
      result.inputs = Array.from(inputs).slice(0, 5).map(el => ({
        tag: el.tagName,
        type: el.type,
        placeholder: el.placeholder,
        value: el.value?.substring(0, 50)
      }));
      
      return result;
    });
  }
  
  /**
   * 分析存储状态
   */
  async _analyzeStorage(page) {
    return await page.evaluate(() => {
      const result = {
        localStorage: {},
        sessionStorage: {},
        cookies: document.cookie
      };
      
      // localStorage 关键项
      const keys = ['token', 'user', 'auth', 'login', 'session'];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (keys.some(k => key.toLowerCase().includes(k))) {
          result.localStorage[key] = localStorage.getItem(key)?.substring(0, 50) + '...';
        }
      }
      
      // sessionStorage 关键项
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (keys.some(k => key.toLowerCase().includes(k))) {
          result.sessionStorage[key] = sessionStorage.getItem(key)?.substring(0, 50) + '...';
        }
      }
      
      return result;
    });
  }
  
  // ============================================================
  // 元素探查
  // ============================================================
  
  /**
   * 探查元素
   * 
   * @param {Page} page - Playwright 页面对象
   * @param {string} selector - 选择器
   * @returns {Promise<Object>} 元素信息
   */
  async probeElement(page, selector) {
    try {
      const element = await page.$(selector);
      
      if (!element) {
        return { found: false, selector };
      }
      
      const info = await element.evaluate((el) => ({
        tag: el.tagName,
        text: el.innerText?.substring(0, 100),
        visible: el.offsetParent !== null,
        disabled: el.disabled || false,
        classes: el.className?.split(' ').slice(0, 10),
        attributes: Array.from(el.attributes).map(a => ({ name: a.name, value: a.value?.substring(0, 50) })),
        boundingBox: el.getBoundingClientRect()
      }));
      
      return { found: true, selector, ...info };
      
    } catch (e) {
      return { found: false, selector, error: e.message };
    }
  }
  
  /**
   * 查找包含文本的元素
   * 
   * @param {Page} page - Playwright 页面对象
   * @param {string} text - 文本内容
   * @param {Object} options - 选项
   * @returns {Promise<Object[]>} 匹配元素列表
   */
  async findElementsWithText(page, text, options = {}) {
    const { tag = '*' } = options;
    
    const elements = await page.evaluate((args) => {
      const { text, tag } = args;
      const xpath = `//${tag}[contains(text(), '${text}')]`;
      const result = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      
      const items = [];
      for (let i = 0; i < result.snapshotLength; i++) {
        const el = result.snapshotItem(i);
        items.push({
          tag: el.tagName,
          text: el.innerText?.substring(0, 100),
          xpath: `/${el.tagName.toLowerCase()}[contains(text(), '${text}')]`
        });
      }
      
      return items;
    }, { text, tag });
    
    return elements;
  }
  
  // ============================================================
  // 缓存管理
  // ============================================================
  
  /**
   * 保存中间结果
   * 
   * @param {string} key - 缓存键
   * @param {any} data - 数据
   * @param {Object} options - 选项
   * @returns {string} 缓存文件路径
   */
  saveCache(key, data, options = {}) {
    const { ttl = 3600000 } = options; // 默认1小时
    
    const cacheFile = path.join(this.cacheDir, `${key}.json`);
    const cacheData = {
      key,
      data,
      timestamp: Date.now(),
      ttl,
      expiresAt: Date.now() + ttl
    };
    
    fs.writeFileSync(cacheFile, JSON.stringify(cacheData, null, 2));
    
    this.log('cache-save', { key, file: cacheFile });
    
    return cacheFile;
  }
  
  /**
   * 读取缓存
   * 
   * @param {string} key - 缓存键
   * @returns {any|null} 缓存数据或 null
   */
  loadCache(key) {
    const cacheFile = path.join(this.cacheDir, `${key}.json`);
    
    if (!fs.existsSync(cacheFile)) {
      return null;
    }
    
    try {
      const cacheData = JSON.parse(fs.readFileSync(cacheFile, 'utf-8'));
      
      // 检查是否过期
      if (cacheData.expiresAt && Date.now() > cacheData.expiresAt) {
        fs.unlinkSync(cacheFile);
        this.log('cache-expired', { key });
        return null;
      }
      
      this.log('cache-load', { key });
      return cacheData.data;
      
    } catch (e) {
      return null;
    }
  }
  
  /**
   * 清除缓存
   * 
   * @param {string} pattern - 缓存键模式（支持通配符 *）
   */
  clearCache(pattern = '*') {
    const files = fs.readdirSync(this.cacheDir);
    const regex = new RegExp(`^${pattern.replace(/\*/g, '.*')}$`);
    
    let cleared = 0;
    for (const file of files) {
      if (regex.test(file.replace('.json', ''))) {
        fs.unlinkSync(path.join(this.cacheDir, file));
        cleared++;
      }
    }
    
    this.log('cache-clear', { pattern, cleared });
    return cleared;
  }
  
  /**
   * 列出缓存
   */
  listCache() {
    const files = fs.readdirSync(this.cacheDir);
    
    return files.map(file => {
      const filepath = path.join(this.cacheDir, file);
      try {
        const data = JSON.parse(fs.readFileSync(filepath, 'utf-8'));
        return {
          key: data.key,
          timestamp: data.timestamp,
          expiresAt: data.expiresAt,
          expired: data.expiresAt && Date.now() > data.expiresAt
        };
      } catch (e) {
        return { key: file, error: e.message };
      }
    });
  }
  
  // ============================================================
  // 错误记录
  // ============================================================
  
  /**
   * 记录错误
   * 
   * @param {Error|string} error - 错误
   * @param {Object} context - 上下文
   * @returns {string} 错误记录文件路径
   */
  recordError(error, context = {}) {
    const errorData = {
      timestamp: new Date().toISOString(),
      error: {
        message: error.message || String(error),
        stack: error.stack,
        name: error.name
      },
      context,
      url: context.url,
      selector: context.selector
    };
    
    const errorFile = path.join(this.debugDir, this.namespace, 'errors', `${Date.now()}.json`);
    this._ensureDir(path.dirname(errorFile));
    fs.writeFileSync(errorFile, JSON.stringify(errorData, null, 2));
    
    this.log('error', errorData);
    
    return errorFile;
  }
  
  /**
   * 获取错误模板
   * 
   * @returns {string} Markdown 错误模板
   */
  static getErrorTemplate() {
    return `### [分类] 问题标题

**时间**: {{timestamp}}

**现象**:
- 场景：{{场景描述}}
- 预期：{{预期结果}}
- 实际：{{实际结果}}
- 错误：{{错误信息}}
- 频率：{{必现/偶现}}

**诊断过程**:
1. Step 1 - 现象确认：{{内容}}
2. Step 2 - 定位范围：
   - 模块：{{模块名}}
   - 函数：{{函数名}}
   - 行号：{{行号}}
3. Step 3 - 根因分析：
   - 直接原因：{{原因}}
   - 根本原因：{{原因}}
   - 5 Why 分析：{{分析过程}}
4. Step 4 - 解决方案：{{方案}}

**解决方案**:
\`\`\`javascript
// 修复代码
\`\`\`

**关键点**:
- {{要点1}}
- {{要点2}}

**教训**: {{一句话总结}}

**预防措施**: {{如何避免}}
`;
  }
  
  // ============================================================
  // 日志
  // ============================================================
  
  /**
   * 记录日志
   */
  log(action, data) {
    if (!this.enableLog) return;
    
    const logEntry = {
      timestamp: new Date().toISOString(),
      action,
      data
    };
    
    const logLine = JSON.stringify(logEntry) + '\n';
    fs.appendFileSync(this.logFile, logLine);
  }
  
  /**
   * 获取日志
   */
  getLogs(options = {}) {
    const { limit = 100, action = null } = options;
    
    if (!fs.existsSync(this.logFile)) {
      return [];
    }
    
    const lines = fs.readFileSync(this.logFile, 'utf-8').trim().split('\n');
    let logs = lines.map(line => JSON.parse(line));
    
    if (action) {
      logs = logs.filter(log => log.action === action);
    }
    
    return logs.slice(-limit);
  }
  
  // ============================================================
  // 辅助方法
  // ============================================================
  
  _ensureDirs() {
    this._ensureDir(this.debugDir);
    this._ensureDir(path.join(this.debugDir, this.namespace));
    this._ensureDir(path.join(this.debugDir, this.namespace, 'cache'));
    this._ensureDir(path.join(this.debugDir, this.namespace, 'errors'));
  }
  
  _ensureDir(dir) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

// ============================================================
// 便捷函数
// ============================================================

/**
 * 快速诊断页面
 */
async function quickDiagnose(page, namespace = 'default') {
  const debug = new Debugger({ namespace });
  return debug.diagnosePage(page);
}

/**
 * 保存润色结果缓存
 */
function savePolishCache(chapterNum, result) {
  const debug = new Debugger({ namespace: 'polish' });
  return debug.saveCache(`chapter-${chapterNum}`, result);
}

/**
 * 加载润色结果缓存
 */
function loadPolishCache(chapterNum) {
  const debug = new Debugger({ namespace: 'polish' });
  return debug.loadCache(`chapter-${chapterNum}`);
}

/**
 * 清除润色缓存
 */
function clearPolishCache() {
  const debug = new Debugger({ namespace: 'polish' });
  return debug.clearCache('chapter-*');
}

module.exports = {
  Debugger,
  quickDiagnose,
  savePolishCache,
  loadPolishCache,
  clearPolishCache,
  DEBUG_DIR
};
