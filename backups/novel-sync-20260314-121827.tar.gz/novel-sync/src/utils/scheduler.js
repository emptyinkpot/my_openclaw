/**
 * 定时任务管理器
 * 
 * 支持定时执行脚本任务
 * 
 * @module utils/scheduler
 */

const cron = require('node-cron');
const logger = require('./logger');
const { runTask } = require('./task-runner');

// 已注册的任务
const scheduledTasks = new Map();

// 任务 ID 计数器
let taskIdCounter = 0;

/**
 * 定时任务配置
 */
const defaultConfig = {
  timezone: 'Asia/Shanghai',
  scheduled: true,
  recoverMissedExecutions: false,
};

/**
 * 创建定时任务
 * 
 * @param {string} cronExpression - cron 表达式
 * @param {Function|string} task - 任务函数或脚本路径
 * @param {Object} options - 配置选项
 * @returns {number} 任务 ID
 * 
 * @example
 * // 每天凌晨 2 点执行
 * schedule('0 2 * * *', async () => {
 *   console.log('执行备份任务');
 * });
 * 
 * // 每小时执行
 * schedule('0 * * * *', 'scripts/backup.js');
 */
function schedule(cronExpression, task, options = {}) {
  const config = { ...defaultConfig, ...options };
  const log = logger.create('scheduler');
  
  // 验证 cron 表达式
  if (!cron.validate(cronExpression)) {
    throw new Error(`无效的 cron 表达式: ${cronExpression}`);
  }
  
  const taskId = ++taskIdCounter;
  const taskName = options.name || `task-${taskId}`;
  
  log.info(`注册定时任务: ${taskName}`);
  log.info(`  Cron: ${cronExpression}`);
  log.info(`  时区: ${config.timezone}`);
  
  // 创建 cron 任务
  const cronTask = cron.schedule(cronExpression, async () => {
    const startTime = Date.now();
    log.info(`\n${'='.repeat(50)}`);
    log.info(`开始执行定时任务: ${taskName}`);
    log.info(`时间: ${new Date().toISOString()}`);
    log.info(`${'='.repeat(50)}`);
    
    try {
      if (typeof task === 'function') {
        await task();
      } else if (typeof task === 'string') {
        // 执行脚本
        const { exec } = require('child_process');
        const { promisify } = require('util');
        const execAsync = promisify(exec);
        
        const { stdout, stderr } = await execAsync(`node ${task}`);
        
        if (stdout) log.info(`输出: ${stdout.substring(0, 500)}`);
        if (stderr) log.warn(`错误输出: ${stderr.substring(0, 500)}`);
      }
      
      const elapsed = Date.now() - startTime;
      log.success(`定时任务完成: ${taskName} (${elapsed}ms)`);
      
    } catch (error) {
      log.error(`定时任务失败: ${taskName}`);
      log.error(error.message);
    }
  }, config);
  
  // 存储任务
  scheduledTasks.set(taskId, {
    id: taskId,
    name: taskName,
    cron: cronExpression,
    task: cronTask,
    config,
    createdAt: new Date().toISOString(),
    lastRun: null,
    runCount: 0,
  });
  
  return taskId;
}

/**
 * 取消定时任务
 * @param {number} taskId - 任务 ID
 */
function cancel(taskId) {
  const task = scheduledTasks.get(taskId);
  
  if (!task) {
    throw new Error(`任务不存在: ${taskId}`);
  }
  
  task.task.stop();
  scheduledTasks.delete(taskId);
  
  logger.create('scheduler').info(`已取消定时任务: ${task.name}`);
}

/**
 * 暂停定时任务
 * @param {number} taskId - 任务 ID
 */
function pause(taskId) {
  const task = scheduledTasks.get(taskId);
  
  if (!task) {
    throw new Error(`任务不存在: ${taskId}`);
  }
  
  task.task.stop();
  logger.create('scheduler').info(`已暂停定时任务: ${task.name}`);
}

/**
 * 恢复定时任务
 * @param {number} taskId - 任务 ID
 */
function resume(taskId) {
  const task = scheduledTasks.get(taskId);
  
  if (!task) {
    throw new Error(`任务不存在: ${taskId}`);
  }
  
  task.task.start();
  logger.create('scheduler').info(`已恢复定时任务: ${task.name}`);
}

/**
 * 获取所有定时任务
 * @returns {Array} 任务列表
 */
function list() {
  return Array.from(scheduledTasks.values()).map(t => ({
    id: t.id,
    name: t.name,
    cron: t.cron,
    createdAt: t.createdAt,
    runCount: t.runCount,
  }));
}

/**
 * 停止所有定时任务
 */
function stopAll() {
  const log = logger.create('scheduler');
  
  scheduledTasks.forEach((task, id) => {
    task.task.stop();
    log.info(`已停止: ${task.name}`);
  });
  
  scheduledTasks.clear();
  log.info('所有定时任务已停止');
}

// ============================================================
// 预设任务模板
// ============================================================

const presets = {
  /**
   * 每天备份登录状态
   */
  dailyBackup: (site, accountId = 1, hour = 2) => {
    return schedule(`0 ${hour} * * *`, async () => {
      const { exec } = require('child_process');
      const { promisify } = require('util');
      const execAsync = promisify(exec);
      
      await execAsync(`bash scripts/storage.sh backup ${site} ${accountId}`);
    }, { name: `daily-backup-${site}-${accountId}` });
  },
  
  /**
   * 每小时检查登录状态
   */
  hourlyCheck: (site, accountId = 1) => {
    return schedule(`0 * * * *`, async () => {
      // 检查逻辑
    }, { name: `hourly-check-${site}-${accountId}` });
  },
};

// ============================================================
// 导出
// ============================================================

module.exports = {
  schedule,
  cancel,
  pause,
  resume,
  list,
  stopAll,
  presets,
};
