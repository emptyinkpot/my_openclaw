/**
 * 工作流模块
 * 
 * 提供常见的工作流程组合
 * 
 * 功能：
 * - 标准启动流程（启动浏览器+恢复登录）
 * - 打开章节流程
 * - 润色流程
 * - 备份流程
 */

const path = require('path');

/**
 * 标准启动流程
 * 
 * 流程：启动浏览器 → 恢复登录
 * 
 * @param {Object} platform - 平台模块（baimeng 或 coze）
 * @param {Object} options - 选项
 * @returns {Promise<{browser: Browser, page: Page}>}
 */
async function standardLaunch(platform, options = {}) {
  const { 
    accountId = 1,
    headless = false,
    timeout = 30000 
  } = options;
  
  // 启动浏览器
  const { browser, page } = await platform.browser.launch({ 
    accountId,
    headless 
  });
  
  // 恢复登录
  await platform.auth.restoreLogin(page, accountId);
  
  return { browser, page };
}

/**
 * 打开章节工作流
 * 
 * 流程：启动 → 登录 → 打开作品 → 查找章节 → 验证
 * 
 * @param {Object} platform - 平台模块
 * @param {string} workName - 作品名称
 * @param {number|string} chapter - 章节号
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, browser?: Browser, page?: Page, error?: string}>}
 */
async function openChapterWorkflow(platform, workName, chapter, options = {}) {
  const {
    verify = true,
    loadContent = true,
    autoClose = false
  } = options;
  
  try {
    // 1. 启动并登录
    const { browser, page } = await standardLaunch(platform, options);
    
    // 2. 打开章节
    const result = await platform.chapterNav.openChapter(page, {
      workName,
      chapter,
      verify
    });
    
    if (!result.success) {
      if (autoClose) await browser.close();
      return { success: false, error: result.error, browser, page };
    }
    
    // 3. 加载完整内容
    if (loadContent) {
      await platform.content.scrollToBottom(page);
      await page.waitForTimeout(2000);
    }
    
    return { 
      success: true, 
      browser, 
      page,
      chapterTitle: result.chapterTitle,
      workId: result.workId
    };
    
  } catch (e) {
    return { success: false, error: e.message };
  }
}

/**
 * 润色章节工作流
 * 
 * 流程：打开章节 → 备份 → 润色 → 替换 → 保存
 * 
 * @param {Object} platform - 平台模块
 * @param {Object} polish - 润色模块
 * @param {string} workName - 作品名称
 * @param {number} chapter - 章节号
 * @param {Object} options - 选项
 * @returns {Promise<{success: boolean, error?: string}>}
 */
async function polishChapterWorkflow(platform, polish, workName, chapter, options = {}) {
  const {
    backup = true,
    verify = true,
    forceRefresh = false
  } = options;
  
  // 1. 打开章节
  const openResult = await openChapterWorkflow(platform, workName, chapter, { verify });
  
  if (!openResult.success) {
    return openResult;
  }
  
  const { browser, page } = openResult;
  
  try {
    // 2. 备份原始内容
    const originalTitle = await platform.editor.getTitle(page);
    const originalContent = await platform.editor.getRawContent(page);
    
    if (backup) {
      await createBackup(workName, chapter, originalTitle, originalContent);
    }
    
    // 3. 润色
    const polishResult = await polish.executePolish(page, originalContent, options);
    
    if (!polishResult.success) {
      return { success: false, error: polishResult.error, browser, page };
    }
    
    // 4. 验证润色结果
    if (verify) {
      const verifyResult = polish.verifyPolishResult(originalContent, polishResult.content);
      if (!verifyResult.valid) {
        return { success: false, error: verifyResult.reason, browser, page };
      }
    }
    
    // 5. 替换标题
    if (polishResult.title) {
      await platform.editor.setTitle(page, polishResult.title);
    }
    
    // 6. 替换正文
    await platform.editor.clearContent(page);
    await platform.editor.setContent(page, polishResult.content);
    
    // 7. 保存
    await platform.editor.save(page);
    
    return { 
      success: true, 
      browser, 
      page,
      originalTitle,
      originalContent,
      polishedTitle: polishResult.title,
      polishedContent: polishResult.content
    };
    
  } catch (e) {
    return { success: false, error: e.message, browser, page };
  }
}

/**
 * 创建章节备份
 */
async function createBackup(workName, chapter, title, content) {
  const backupManager = require('./backup-manager');
  const fileUtils = require('./file-utils');
  
  const backupDir = '/tmp/openclaw/backups';
  const timestamp = new Date().toISOString().replace(/[-:T]/g, '').substring(0, 14);
  const filename = `${workName}-第${chapter}章-${timestamp}.txt`;
  const filepath = path.join(backupDir, filename);
  
  const data = `【标题】\n${title || '(无)'}\n\n【正文】\n${content}`;
  
  fileUtils.ensureDir(backupDir);
  fileUtils.safeWrite(filepath, data);
  
  return filepath;
}

/**
 * 批量处理工作流
 * 
 * @param {Function} processor - 处理函数 async (page, context) => {}
 * @param {Object} platform - 平台模块
 * @param {Object} context - 上下文
 * @param {Object} options - 选项
 */
async function batchWorkflow(processor, platform, context, options = {}) {
  const { 
    items = [],
    concurrency = 1,
    delay = 3000,
    onProgress = () => {}
  } = options;
  
  const results = [];
  
  // 启动浏览器（只启动一次）
  const { browser, page } = await standardLaunch(platform, options);
  
  try {
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      
      onProgress({
        current: i + 1,
        total: items.length,
        item
      });
      
      try {
        const result = await processor(page, { ...context, item });
        results.push({ item, success: true, result });
      } catch (e) {
        results.push({ item, success: false, error: e.message });
      }
      
      // 延迟
      if (i < items.length - 1 && delay > 0) {
        await page.waitForTimeout(delay);
      }
    }
    
    return { success: true, results, browser, page };
    
  } catch (e) {
    return { success: false, error: e.message, results, browser, page };
  }
}

/**
 * 重试工作流
 * 
 * @param {Function} workflow - 工作流函数
 * @param {Object} options - 选项
 */
async function retryWorkflow(workflow, options = {}) {
  const { maxRetries = 3, delay = 5000, onRetry = () => {} } = options;
  
  let lastError = null;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      const result = await workflow();
      
      if (result.success) {
        return result;
      }
      
      lastError = result.error;
      
    } catch (e) {
      lastError = e.message;
    }
    
    if (i < maxRetries - 1) {
      onRetry({ attempt: i + 1, maxRetries, error: lastError });
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  return { success: false, error: lastError };
}

module.exports = {
  standardLaunch,
  openChapterWorkflow,
  polishChapterWorkflow,
  batchWorkflow,
  retryWorkflow,
  createBackup
};
