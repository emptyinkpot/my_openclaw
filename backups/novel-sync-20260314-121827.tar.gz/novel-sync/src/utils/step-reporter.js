/**
 * 统一步骤报告工具
 * 
 * 设计原则：
 * - 终端友好：不使用 Markdown 表格
 * - 实时显示：每个步骤完成立即显示状态
 * - 美观对齐：最终报告整齐排列
 * 
 * 用法：
 * const reporter = new StepReporter();
 * reporter.start('Step 0', '自动备份');
 * reporter.success('v202603140129xx');
 * reporter.print();
 */

class StepReporter {
  constructor() {
    this.steps = [];
    this.startTime = Date.now();
  }

  /** 开始步骤 */
  start(stepId, name) {
    this.steps.push({
      id: stepId,
      name,
      status: 'running',
      detail: '',
      startTime: Date.now()
    });
    // 实时显示：步骤名 + 等待
    process.stdout.write(`  ${stepId}: ${name}... `);
  }

  /** 成功 */
  success(detail = '') {
    const current = this.steps[this.steps.length - 1];
    if (current) {
      current.status = 'success';
      current.detail = detail;
      current.duration = Date.now() - current.startTime;
      console.log(`✅ ${detail}`);
    }
  }

  /** 失败 */
  fail(error = '') {
    const current = this.steps[this.steps.length - 1];
    if (current) {
      current.status = 'failed';
      current.detail = error;
      console.log(`❌ ${error}`);
    }
  }

  /** 跳过 */
  skip(reason = '') {
    const current = this.steps[this.steps.length - 1];
    if (current) {
      current.status = 'skipped';
      current.detail = reason;
      console.log(`⏭️ ${reason}`);
    }
  }

  /** 警告 */
  warn(warning) {
    const current = this.steps[this.steps.length - 1];
    if (current) {
      current.detail += (current.detail ? ' | ' : '') + `⚠️ ${warning}`;
    }
  }

  /** 打印报告 - 终端友好格式 */
  print() {
    const totalDuration = Date.now() - this.startTime;
    const successCount = this.steps.filter(s => s.status === 'success').length;
    const failedCount = this.steps.filter(s => s.status === 'failed').length;
    const skippedCount = this.steps.filter(s => s.status === 'skipped').length;

    // 计算步骤标签最大宽度（用于对齐）
    const stepLabels = this.steps.map(s => `${s.id}: ${s.name}`);
    const maxLabelWidth = Math.max(...stepLabels.map(l => this._width(l)));

    // 计算详情最大宽度
    const maxDetailWidth = Math.max(...this.steps.map(s => this._width(s.detail || '')));
    
    // 总宽度：图标(2) + 空格(1) + 标签 + 空格(2) + 详情 + 空格(1) + 边框(2)
    const contentWidth = 2 + 1 + maxLabelWidth + 2 + maxDetailWidth + 1;

    console.log('');
    console.log('  ┌' + '─'.repeat(contentWidth) + '┐');
    console.log('  │' + this._center('执行报告', contentWidth) + '│');
    console.log('  ├' + '─'.repeat(contentWidth) + '┤');
    
    for (const step of this.steps) {
      const icon = this._icon(step.status);
      const label = `${step.id}: ${step.name}`;
      const labelPad = this._pad(label, maxLabelWidth);
      const detailPad = this._pad(step.detail || '', maxDetailWidth);
      
      console.log(`  │ ${icon} ${label}${labelPad}  ${step.detail || ''}${detailPad} │`);
    }
    
    console.log('  └' + '─'.repeat(contentWidth) + '┘');
    console.log(`  总计 ${this.steps.length} 步骤: ✅ ${successCount} 成功 | ❌ ${failedCount} 失败 | ⏭️ ${skippedCount} 跳过`);
    console.log(`  耗时: ${this._time(totalDuration)}`);
    console.log('');
  }

  _icon(status) {
    return { success: '✅', failed: '❌', skipped: '⏭️' }[status] || '❓';
  }

  _time(ms) {
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
    return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
  }

  /** 计算字符串显示宽度（中文占2格） */
  _width(str) {
    let w = 0;
    for (const c of str) {
      w += c.charCodeAt(0) > 127 ? 2 : 1;
    }
    return w;
  }

  /** 生成填充空格（右对齐用） */
  _pad(str, targetWidth) {
    const currentWidth = this._width(str);
    return ' '.repeat(Math.max(0, targetWidth - currentWidth));
  }

  /** 居中文本 */
  _center(text, width) {
    const textWidth = this._width(text);
    const leftPad = Math.floor((width - textWidth) / 2);
    const rightPad = width - textWidth - leftPad;
    return ' '.repeat(Math.max(0, leftPad)) + text + ' '.repeat(Math.max(0, rightPad));
  }
}

module.exports = StepReporter;
