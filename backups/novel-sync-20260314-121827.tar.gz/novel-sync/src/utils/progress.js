/**
 * 进度持久化模块
 * 
 * 支持长时间任务的断点续传
 * 
 * @module utils/progress
 */

const fs = require('fs');
const path = require('path');
const logger = require('./logger');

// 默认进度目录
const DEFAULT_PROGRESS_DIR = '/tmp/novel-sync-progress';

/**
 * 进度管理类
 */
class ProgressManager {
  /**
   * @param {string} taskName - 任务名称
   * @param {Object} options - 配置选项
   */
  constructor(taskName, options = {}) {
    this.taskName = taskName;
    this.progressDir = options.progressDir || DEFAULT_PROGRESS_DIR;
    this.progressFile = path.join(this.progressDir, `${taskName}-progress.json`);
    this.log = options.logger || logger.create('progress');
    
    this.ensureDir();
  }
  
  /**
   * 确保进度目录存在
   */
  ensureDir() {
    if (!fs.existsSync(this.progressDir)) {
      fs.mkdirSync(this.progressDir, { recursive: true });
    }
  }
  
  /**
   * 保存进度
   * @param {string} step - 当前步骤
   * @param {Object} data - 进度数据
   */
  save(step, data = {}) {
    const progress = {
      taskName: this.taskName,
      step,
      data,
      timestamp: Date.now(),
      datetime: new Date().toISOString(),
    };
    
    fs.writeFileSync(this.progressFile, JSON.stringify(progress, null, 2));
    this.log.debug(`进度已保存: ${step}`);
    
    return progress;
  }
  
  /**
   * 加载进度
   * @returns {Object|null} 进度数据
   */
  load() {
    if (!fs.existsSync(this.progressFile)) {
      return null;
    }
    
    try {
      const progress = JSON.parse(fs.readFileSync(this.progressFile, 'utf-8'));
      
      // 检查是否过期（默认 24 小时）
      const age = Date.now() - progress.timestamp;
      const maxAge = 24 * 60 * 60 * 1000;
      
      if (age > maxAge) {
        this.log.warn('进度已过期，将忽略');
        this.clear();
        return null;
      }
      
      this.log.info(`已加载进度: ${progress.step}`);
      return progress;
    } catch (e) {
      this.log.warn(`加载进度失败: ${e.message}`);
      return null;
    }
  }
  
  /**
   * 检查是否有保存的进度
   * @returns {boolean}
   */
  hasProgress() {
    return fs.existsSync(this.progressFile);
  }
  
  /**
   * 清除进度
   */
  clear() {
    if (fs.existsSync(this.progressFile)) {
      fs.unlinkSync(this.progressFile);
      this.log.debug('进度已清除');
    }
  }
  
  /**
   * 执行任务（支持断点续传）
   * 
   * @param {Object} steps - 步骤定义
   * @param {Object} options - 配置选项
   * 
   * @example
   * await progress.run({
   *   'init': async (data) => { ... return { count: 10 }; },
   *   'process': async (data) => { ... return { processed: 10 }; },
   *   'finish': async (data) => { ... },
   * });
   */
  async run(steps, options = {}) {
    const stepNames = Object.keys(steps);
    const resumeFrom = options.resumeFrom || this.load()?.step;
    
    let startFrom = 0;
    
    if (resumeFrom && stepNames.includes(resumeFrom)) {
      startFrom = stepNames.indexOf(resumeFrom);
      this.log.info(`从步骤 "${resumeFrom}" 恢复`);
    }
    
    let data = this.load()?.data || options.initialData || {};
    
    for (let i = startFrom; i < stepNames.length; i++) {
      const stepName = stepNames[i];
      const stepFn = steps[stepName];
      
      this.log.info(`执行步骤: ${stepName} (${i + 1}/${stepNames.length})`);
      
      try {
        const result = await stepFn(data);
        data = { ...data, ...result };
        
        // 保存进度（最后一步除外）
        if (i < stepNames.length - 1) {
          this.save(stepName, data);
        }
      } catch (error) {
        this.save(stepName, data);
        this.log.error(`步骤 "${stepName}" 失败: ${error.message}`);
        throw error;
      }
    }
    
    // 完成后清除进度
    this.clear();
    this.log.success('任务完成');
    
    return data;
  }
}

/**
 * 创建进度管理器
 * @param {string} taskName - 任务名称
 * @param {Object} options - 配置选项
 * @returns {ProgressManager}
 */
function createProgress(taskName, options = {}) {
  return new ProgressManager(taskName, options);
}

/**
 * 快速保存进度
 */
function saveProgress(taskName, step, data) {
  const progress = new ProgressManager(taskName);
  return progress.save(step, data);
}

/**
 * 快速加载进度
 */
function loadProgress(taskName) {
  const progress = new ProgressManager(taskName);
  return progress.load();
}

/**
 * 快速清除进度
 */
function clearProgress(taskName) {
  const progress = new ProgressManager(taskName);
  progress.clear();
}

module.exports = {
  ProgressManager,
  create: createProgress,
  createProgress,
  saveProgress,
  loadProgress,
  clearProgress,
};
