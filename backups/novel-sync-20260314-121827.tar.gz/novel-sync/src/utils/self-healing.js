/**
 * 自愈模块
 * 
 * 整合错误识别、自动修复、经验积累的统一接口
 * 
 * 设计原则：
 * - 低耦合：每个组件独立可替换
 * - 一致性：统一的错误处理接口
 * - 可复用：修复策略可复用
 * - 模块化：功能拆分清晰
 * - 小而美：每个函数专注一件事
 * 
 * @module utils/self-healing
 */

const { matchPattern, ErrorType, addPattern } = require('./error-patterns');
const { AutoFixer, quickFix } = require('./auto-fixer');
const experienceStore = require('./experience-store');

/**
 * 自愈执行器
 */
class SelfHealing {
  constructor(options = {}) {
    this.fixer = new AutoFixer(options);
    this.maxRetries = options.maxRetries || 3;
    this.onBeforeFix = options.onBeforeFix || null;
    this.onAfterFix = options.onAfterFix || null;
    this.onGiveUp = options.onGiveUp || null;
    this.verbose = options.verbose || false;
  }
  
  /**
   * 执行带自愈能力的操作
   * 
   * @param {Function} action - 要执行的操作
   * @param {Object} context - 上下文
   * @returns {Promise<Object>} 执行结果
   * 
   * @example
   * const healing = new SelfHealing();
   * const result = await healing.execute(
   *   async () => await page.click('.btn'),
   *   { page, browser, selector: '.btn' }
   * );
   */
  async execute(action, context = {}) {
    let lastError;
    
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        // 执行操作
        const result = await action();
        return { success: true, result, attempts: attempt };
      } catch (error) {
        lastError = error;
        
        // 分析错误
        const pattern = matchPattern(error);
        
        this._log(`[尝试 ${attempt}/${this.maxRetries}] ${pattern.id}: ${error.message || error}`);
        
        // 最后一次尝试不再修复
        if (attempt === this.maxRetries) {
          break;
        }
        
        // 回调
        if (this.onBeforeFix) {
          await this.onBeforeFix(error, pattern, context, attempt);
        }
        
        // 尝试修复
        if (pattern.autoFix) {
          const fixResult = await this.fixer.fix(error, context);
          
          if (fixResult.success) {
            this._log(`[修复成功] ${fixResult.action}`);
            
            // 回调
            if (this.onAfterFix) {
              await this.onAfterFix(error, pattern, fixResult, context, attempt);
            }
            
            // 如果修复创建了新的 page/browser，更新上下文
            if (fixResult.page) context.page = fixResult.page;
            if (fixResult.browser) context.browser = fixResult.browser;
            
            // 等待后继续
            await this._delay(500);
            continue;
          }
        }
        
        // 修复失败或不可修复，等待后重试
        await this._delay(1000 * attempt);
      }
    }
    
    // 所有尝试都失败
    if (this.onGiveUp) {
      await this.onGiveUp(lastError, context);
    }
    
    const pattern = matchPattern(lastError);
    return {
      success: false,
      error: lastError,
      pattern: pattern.id,
      hint: pattern.hint,
      attempts: this.maxRetries,
    };
  }
  
  /**
   * 包装函数为自愈版本
   * 
   * @param {Function} fn - 原函数
   * @param {Object} defaultContext - 默认上下文
   * @returns {Function} 包装后的函数
   */
  wrap(fn, defaultContext = {}) {
    const self = this;
    return async function(...args) {
      const context = { ...defaultContext, args };
      return self.execute(() => fn.apply(this, args), context);
    };
  }
  
  /**
   * 批量执行（带自愈）
   * 
   * @param {Array} items - 要处理的项
   * @param {Function} fn - 处理函数
   * @param {Object} context - 上下文
   * @returns {Promise<Object>} 批量结果
   */
  async batch(items, fn, context = {}) {
    const results = {
      success: [],
      failed: [],
      stats: { total: items.length, succeeded: 0, failed: 0 },
    };
    
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const result = await this.execute(
        () => fn(item, i),
        { ...context, item, index: i }
      );
      
      if (result.success) {
        results.success.push({ item, result: result.result, index: i });
        results.stats.succeeded++;
      } else {
        results.failed.push({ item, error: result.error, index: i });
        results.stats.failed++;
      }
    }
    
    return results;
  }
  
  /**
   * 延迟
   */
  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  
  /**
   * 日志
   */
  _log(message) {
    if (this.verbose) {
      console.log(`[SelfHealing] ${message}`);
    }
  }
}

/**
 * 创建自愈包装器（便捷方法）
 */
function createHealingWrapper(options = {}) {
  const healing = new SelfHealing(options);
  return healing.wrap.bind(healing);
}

/**
 * 快速自愈执行（便捷方法）
 */
async function healingExecute(action, context = {}) {
  const healing = new SelfHealing();
  return healing.execute(action, context);
}

/**
 * 获取经验统计
 */
function getExperienceStats() {
  return experienceStore.getStats();
}

/**
 * 查询历史经验
 */
function queryExperience(options = {}) {
  return experienceStore.query(options);
}

/**
 * 导出经验库为 Markdown
 */
function exportExperience() {
  return experienceStore.exportMarkdown();
}

/**
 * 注册自定义错误模式
 */
function registerErrorPattern(pattern) {
  addPattern(pattern);
}

/**
 * 注册自定义修复策略
 */
function registerFixStrategy(name, fn) {
  AutoFixer.registerStrategy(name, fn);
}

// ============================================================
// 预置常用包装器
// ============================================================

/**
 * 创建页面操作包装器
 */
function createPageWrapper(page, options = {}) {
  const healing = new SelfHealing({ verbose: true, ...options });
  
  return {
    // 安全点击
    click: healing.wrap(async (selector) => {
      await page.waitForSelector(selector, { state: 'visible' });
      await page.click(selector);
    }, { page }),
    
    // 安全输入
    fill: healing.wrap(async (selector, text) => {
      await page.waitForSelector(selector, { state: 'visible' });
      await page.fill(selector, text);
    }, { page }),
    
    // 安全导航
    goto: healing.wrap(async (url) => {
      await page.goto(url, { waitUntil: 'domcontentloaded' });
    }, { page }),
    
    // 等待选择器
    waitFor: healing.wrap(async (selector) => {
      await page.waitForSelector(selector, { state: 'visible' });
    }, { page }),
    
    // 原始 healing 对象
    healing,
  };
}

module.exports = {
  // 核心类
  SelfHealing,
  
  // 便捷方法
  createHealingWrapper,
  healingExecute,
  
  // 经验相关
  getExperienceStats,
  queryExperience,
  exportExperience,
  
  // 扩展方法
  registerErrorPattern,
  registerFixStrategy,
  
  // 预置包装器
  createPageWrapper,
  
  // 重导出
  matchPattern,
  ErrorType,
  quickFix,
};
