/**
 * 截图模块
 * 
 * 提供统一的截图功能
 * 
 * 功能：
 * - 标准截图
 * - 命名空间截图
 * - 全页截图
 * - 元素截图
 * - 截图管理
 */

const path = require('path');
const fs = require('fs');

// 默认截图目录
const DEFAULT_DIR = '/tmp/openclaw/screenshots';

/**
 * 标准截图
 * 
 * @param {Page} page - Playwright 页面对象
 * @param {string} name - 截图名称（不含扩展名）
 * @param {Object} options - 选项
 * @returns {Promise<string>} 截图路径
 */
async function takeScreenshot(page, name, options = {}) {
  const {
    dir = DEFAULT_DIR,
    fullPage = false,
    timestamp = false,
    quality = 80
  } = options;
  
  // 确保目录存在
  ensureDir(dir);
  
  // 生成文件名
  const prefix = timestamp ? `${Date.now()}-` : '';
  const filename = `${prefix}${name}.png`;
  const filepath = path.join(dir, filename);
  
  // 截图
  await page.screenshot({
    path: filepath,
    fullPage,
    quality
  });
  
  console.log(`  ✓ 截图: ${filepath}`);
  
  return filepath;
}

/**
 * 命名空间截图
 * 
 * @param {Page} page - Playwright 页面对象
 * @param {string} namespace - 命名空间（如 'baimeng', 'coze'）
 * @param {string} name - 截图名称
 * @param {Object} options - 选项
 * @returns {Promise<string>} 截图路径
 */
async function takeNamespacedScreenshot(page, namespace, name, options = {}) {
  const dir = path.join(DEFAULT_DIR, namespace);
  return takeScreenshot(page, name, { ...options, dir });
}

/**
 * 全页截图
 * 
 * @param {Page} page - Playwright 页面对象
 * @param {string} name - 截图名称
 * @param {Object} options - 选项
 * @returns {Promise<string>} 截图路径
 */
async function takeFullPageScreenshot(page, name, options = {}) {
  return takeScreenshot(page, name, { ...options, fullPage: true });
}

/**
 * 元素截图
 * 
 * @param {Page} page - Playwright 页面对象
 * @param {string} selector - 元素选择器
 * @param {string} name - 截图名称
 * @param {Object} options - 选项
 * @returns {Promise<string>} 截图路径
 */
async function takeElementScreenshot(page, selector, name, options = {}) {
  const { dir = DEFAULT_DIR, timestamp = false } = options;
  
  // 确保目录存在
  ensureDir(dir);
  
  // 生成文件名
  const prefix = timestamp ? `${Date.now()}-` : '';
  const filename = `${prefix}${name}.png`;
  const filepath = path.join(dir, filename);
  
  // 截图元素
  const element = await page.$(selector);
  if (!element) {
    throw new Error(`元素不存在: ${selector}`);
  }
  
  await element.screenshot({ path: filepath });
  
  console.log(`  ✓ 元素截图: ${filepath}`);
  
  return filepath;
}

/**
 * 条件截图
 * 
 * @param {Page} page - Playwright 页面对象
 * @param {boolean} condition - 条件
 * @param {string} name - 截图名称
 * @param {Object} options - 选项
 * @returns {Promise<string|null>} 截图路径或 null
 */
async function takeConditionalScreenshot(page, condition, name, options = {}) {
  if (!condition) {
    return null;
  }
  
  return takeScreenshot(page, name, options);
}

/**
 * 错误截图
 * 
 * @param {Page} page - Playwright 页面对象
 * @param {Error} error - 错误对象
 * @param {string} context - 上下文描述
 * @param {Object} options - 选项
 * @returns {Promise<string>} 截图路径
 */
async function takeErrorScreenshot(page, error, context = 'error', options = {}) {
  const name = `${context}-error-${Date.now()}`;
  const dir = path.join(DEFAULT_DIR, 'errors');
  
  const filepath = await takeScreenshot(page, name, { ...options, dir, timestamp: false });
  
  console.error(`  ✗ 错误截图: ${filepath}`);
  console.error(`    错误: ${error.message}`);
  
  return filepath;
}

/**
 * 调试截图
 * 
 * @param {Page} page - Playwright 页面对象
 * @param {string} stage - 调试阶段
 * @param {Object} options - 选项
 * @returns {Promise<string>} 截图路径
 */
async function takeDebugScreenshot(page, stage, options = {}) {
  const name = `debug-${stage}`;
  const dir = path.join(DEFAULT_DIR, 'debug');
  
  return takeScreenshot(page, name, { ...options, dir });
}

/**
 * 管理截图
 * 
 * @param {Object} options - 选项
 */
function manageScreenshots(options = {}) {
  const {
    dir = DEFAULT_DIR,
    maxAge = 7 * 24 * 60 * 60 * 1000, // 7天
    maxSize = 100, // MB
    keep = 50 // 保留数量
  } = options;
  
  if (!fs.existsSync(dir)) {
    return { cleaned: 0, message: '目录不存在' };
  }
  
  // 获取所有截图
  const files = fs.readdirSync(dir)
    .filter(f => f.endsWith('.png'))
    .map(f => ({
      name: f,
      path: path.join(dir, f),
      stat: fs.statSync(path.join(dir, f))
    }))
    .sort((a, b) => b.stat.mtime - a.stat.mtime);
  
  let cleaned = 0;
  
  // 按时间清理
  const now = Date.now();
  for (const file of files) {
    if (now - file.stat.mtime > maxAge) {
      fs.unlinkSync(file.path);
      cleaned++;
    }
  }
  
  // 按数量清理
  if (files.length > keep) {
    const toRemove = files.slice(keep);
    for (const file of toRemove) {
      if (fs.existsSync(file.path)) {
        fs.unlinkSync(file.path);
        cleaned++;
      }
    }
  }
  
  return {
    cleaned,
    remaining: files.length - cleaned,
    message: `清理了 ${cleaned} 个旧截图`
  };
}

/**
 * 获取截图列表
 * 
 * @param {Object} options - 选项
 * @returns {Array} 截图列表
 */
function listScreenshots(options = {}) {
  const { dir = DEFAULT_DIR, limit = 20 } = options;
  
  if (!fs.existsSync(dir)) {
    return [];
  }
  
  return fs.readdirSync(dir)
    .filter(f => f.endsWith('.png'))
    .map(f => {
      const stat = fs.statSync(path.join(dir, f));
      return {
        name: f,
        path: path.join(dir, f),
        size: stat.size,
        mtime: stat.mtime
      };
    })
    .sort((a, b) => b.mtime - a.mtime)
    .slice(0, limit);
}

// 辅助函数

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

module.exports = {
  takeScreenshot,
  takeNamespacedScreenshot,
  takeFullPageScreenshot,
  takeElementScreenshot,
  takeConditionalScreenshot,
  takeErrorScreenshot,
  takeDebugScreenshot,
  manageScreenshots,
  listScreenshots,
  DEFAULT_DIR
};
