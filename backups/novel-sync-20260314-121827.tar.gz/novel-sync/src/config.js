/**
 * 统一配置管理
 * 
 * 集中管理所有平台配置、全局配置和运行时配置
 * 
 * @module config
 */

const path = require('path');
const fs = require('fs');

// ============================================================
// 基础路径
// ============================================================

const ROOT_DIR = path.join(__dirname, '..');
const GLOBAL_ROOT = '/workspace/projects';

// ============================================================
// 全局配置
// ============================================================

const GLOBAL_CONFIG = {
  // 默认超时（毫秒）
  defaultTimeout: 30000,
  
  // 重试次数
  retryCount: 3,
  
  // 重试间隔（毫秒）
  retryDelay: 2000,
  
  // 是否无头模式
  headless: false,
  
  // 日志级别: debug, info, warn, error
  logLevel: 'info',
  
  // 日志目录
  logDir: '/tmp/novel-sync-logs',
  
  // 进度保存目录
  progressDir: '/tmp/novel-sync-progress',
};

// ============================================================
// 平台配置
// ============================================================

const SITES = {
  // 白梦写作平台
  baimeng: {
    name: '白梦写作',
    url: 'https://baimengxiezuo.com',
    urls: {
      home: 'https://baimengxiezuo.com',
      library: 'https://baimengxiezuo.com/zh-Hans/library/',
      editor: 'https://baimengxiezuo.com/zh-Hans/editor/',
    },
    
    // 浏览器数据目录
    getBrowserDir(accountId = 1) {
      return path.join(GLOBAL_ROOT, 'browser', `baimeng-${accountId}`);
    },
    
    // 登录备份路径
    getBackupFile(accountId = 1) {
      return path.join(GLOBAL_ROOT, 'cookies-accounts', `baimeng-account-${accountId}-full.json`);
    },
    
    // 默认账号
    defaultAccount: 1,
    
    // 选择器
    selectors: {
      sidebar: '.sidebar',
      chapterItem: '[class*="cursor-pointer"]',
      editorContent: '.ProseMirror, .Daydream',
      loginButton: 'button:has-text("登录")',
      modifyCard: {
        button: 'button:has-text("修改内容")',
        textarea: '.modify-textarea, textarea',
        submit: 'button:has-text("确定")',
      },
    },
    
    // 超时配置
    timeout: {
      pageLoad: 30000,
      editorReady: 5000,
      cardVisible: 3000,
    },
  },
  
  // 番茄小说
  fanqie: {
    name: '番茄小说',
    url: 'https://fanqienovel.com',
    urls: {
      home: 'https://fanqienovel.com',
      writer: 'https://fanqienovel.com/main/writer/book-manage',
    },
    
    getBrowserDir(accountId = 1) {
      return path.join(GLOBAL_ROOT, 'browser', `fanqie-${accountId}`);
    },
    
    getBackupFile(accountId = 1) {
      return path.join(GLOBAL_ROOT, 'cookies-accounts', `fanqie-account-${accountId}.json`);
    },
    
    defaultAccount: 1,
  },
  
  // Coze 扣子编程
  coze: {
    name: 'Coze 扣子编程',
    urls: {
      mainSite: 'https://www.coze.cn',
      codeSite: 'https://code.coze.cn',
      home: 'https://code.coze.cn/home',
    },
    
    getBrowserDir(accountId = 1) {
      return path.join(GLOBAL_ROOT, 'browser', `coze-${accountId}`);
    },
    
    getBackupFile(accountId = 1) {
      return path.join(GLOBAL_ROOT, 'cookies-accounts', `coze-account-${accountId}.json`);
    },
    
    // 选择器
    selectors: {
      projectItem: '[class*="project"]',
      sidebarMenu: '.sidebar-menu, [class*="sidebar"]',
      editor: '.monaco-editor, .code-editor',
    },
    
    timeout: {
      pageLoad: 30000,
      spaTransition: 3000,
    },
  },
};

// ============================================================
// 路径配置
// ============================================================

const PATHS = {
  // 项目路径
  ROOT: ROOT_DIR,
  SRC: path.join(ROOT_DIR, 'src'),
  TASKS: path.join(ROOT_DIR, 'tasks'),
  SCRIPTS: path.join(ROOT_DIR, 'scripts'),
  DOCS: path.join(ROOT_DIR, 'docs'),
  STORAGE: path.join(ROOT_DIR, 'storage'),
  
  // 全局路径
  GLOBAL_BROWSER: path.join(GLOBAL_ROOT, 'browser'),
  GLOBAL_COOKIES: path.join(GLOBAL_ROOT, 'cookies-accounts'),
  GLOBAL_KNOWLEDGE: path.join(GLOBAL_ROOT, 'knowledge'),
  GLOBAL_LIB: path.join(GLOBAL_ROOT, 'lib'),
  
  // 默认浏览器数据
  BROWSER_DATA: path.join(GLOBAL_ROOT, 'browser/default'),
  COOKIES_DIR: path.join(GLOBAL_ROOT, 'cookies-accounts'),
  
  // 辅助方法
  getBrowserDir(site, accountId = 'default') {
    if (accountId === 'default') {
      return path.join(GLOBAL_ROOT, 'browser', 'default');
    }
    return path.join(GLOBAL_ROOT, 'browser', `${site}-${accountId}`);
  },
  
  getBackupPath(site, accountId = 1) {
    return path.join(GLOBAL_ROOT, 'cookies-accounts', `${site}-account-${accountId}-full.json`);
  },
};

// ============================================================
// 超时配置
// ============================================================

const TIMEOUT = {
  PAGE_LOAD: 30000,
  SHORT: 2000,
  MEDIUM: 5000,
  LONG: 8000,
  VERY_LONG: 15000,
};

// ============================================================
// 配置管理方法
// ============================================================

/**
 * 获取平台配置
 * @param {string} site - 平台名称 (baimeng, fanqie, coze)
 * @returns {Object} 平台配置
 */
function getSiteConfig(site) {
  if (!SITES[site]) {
    throw new Error(`未知平台: ${site}，可用平台: ${Object.keys(SITES).join(', ')}`);
  }
  return SITES[site];
}

/**
 * 获取全局配置
 * @param {string} key - 配置键
 * @param {*} defaultValue - 默认值
 * @returns {*} 配置值
 */
function getGlobalConfig(key, defaultValue = undefined) {
  return GLOBAL_CONFIG[key] ?? defaultValue;
}

/**
 * 设置全局配置
 * @param {string} key - 配置键
 * @param {*} value - 配置值
 */
function setGlobalConfig(key, value) {
  GLOBAL_CONFIG[key] = value;
}

/**
 * 加载用户自定义配置
 * @param {string} configPath - 配置文件路径
 */
function loadUserConfig(configPath) {
  if (fs.existsSync(configPath)) {
    try {
      const userConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      Object.assign(GLOBAL_CONFIG, userConfig.global || {});
      Object.keys(userConfig.sites || {}).forEach(site => {
        if (SITES[site]) {
          Object.assign(SITES[site], userConfig.sites[site]);
        }
      });
      console.log(`✅ 已加载用户配置: ${configPath}`);
    } catch (e) {
      console.warn(`⚠️ 加载用户配置失败: ${e.message}`);
    }
  }
}

/**
 * 导出当前配置（用于调试）
 * @returns {Object} 完整配置
 */
function exportConfig() {
  return {
    global: { ...GLOBAL_CONFIG },
    sites: { ...SITES },
    paths: { ...PATHS },
    timeout: { ...TIMEOUT },
  };
}

// ============================================================
// 兼容旧配置
// ============================================================

const BROWSER_DATA = PATHS.BROWSER_DATA;
const COOKIES_DIR = PATHS.COOKIES_DIR;

const BAIMENG = SITES.baimeng;
const FANQIE = SITES.fanqie;

// ============================================================
// 导出
// ============================================================

module.exports = {
  // 路径
  PATHS,
  ROOT_DIR,
  GLOBAL_ROOT,
  
  // 全局配置
  GLOBAL_CONFIG,
  getGlobalConfig,
  setGlobalConfig,
  
  // 平台配置
  SITES,
  getSiteConfig,
  
  // 超时
  TIMEOUT,
  
  // 方法
  loadUserConfig,
  exportConfig,
  
  // 兼容旧配置
  BROWSER_DATA,
  COOKIES_DIR,
  BAIMENG,
  FANQIE,
};
