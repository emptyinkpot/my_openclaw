/**
 * 番茄小说任务
 * 
 * 🔴 已重构为二级模块架构
 * 
 * 模块位置：src/platforms/fanqie/
 * - browser.js: 浏览器管理
 * - auth.js: 登录认证
 * - works.js: 作品管理
 * 
 * 本文件保留向后兼容，新代码请直接使用二级模块
 */

const fanqie = require('../platforms/fanqie');

const fanqieTask = {
  /**
   * 登录
   */
  async login() {
    const { browser, page } = await fanqie.browser.launch();
    
    console.log('[番茄] 打开登录页...');
    await page.goto(fanqie.platform.url);
    await page.waitForTimeout(2000);

    // 检查是否已登录
    const { isLoggedIn } = await fanqie.auth.checkLogin(page);
    if (isLoggedIn) {
      console.log('[番茄] 已登录');
      await browser.close();
      return { success: true };
    }

    // 等待用户扫码登录
    const result = await fanqie.auth.waitForLogin(page, 60000);
    await browser.close();
    
    return result;
  },

  /**
   * 检查登录状态
   */
  async checkLogin() {
    const { browser, page } = await fanqie.browser.launch();
    
    const result = await fanqie.auth.checkLogin(page);
    await browser.close();
    
    return result;
  },

  /**
   * 获取作品列表
   */
  async getWorks() {
    const { browser, page } = await fanqie.browser.launch();

    const works = await fanqie.works.getWorks(page);
    await browser.close();
    
    return { 
      success: true, 
      platform: fanqie.platform.id, 
      count: works.length, 
      works 
    };
  },
  
  /**
   * 获取章节列表
   */
  async getChapters(workId) {
    const { browser, page } = await fanqie.browser.launch();
    
    const chapters = await fanqie.works.getChapters(page, workId);
    await browser.close();
    
    return { 
      success: true, 
      count: chapters.length, 
      chapters 
    };
  },
  
  /**
   * 保存登录状态
   */
  async saveLogin(accountId = 1) {
    const { browser, page } = await fanqie.browser.launch({ account: accountId });
    
    await page.goto(fanqie.platform.url);
    await page.waitForTimeout(2000);
    
    const { isLoggedIn } = await fanqie.auth.checkLogin(page);
    if (!isLoggedIn) {
      await browser.close();
      return { success: false, message: '未登录' };
    }
    
    const result = await fanqie.auth.saveLogin(page, accountId);
    await browser.close();
    
    return result;
  }
};

module.exports = fanqieTask;
