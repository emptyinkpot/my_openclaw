/**
 * 白梦写作任务
 */

const BrowserManager = require('../utils/browser-manager');
const { similarity } = require('../utils/helper');
const config = require('../config');

const baimengTask = {
  async login() {
    const bm = BrowserManager.getInstance();
    const { page } = await bm.getPage();

    console.log('[白梦] 打开登录页...');
    await page.goto(config.BAIMENG.URL);
    await bm.sleep(2000);

    const hasLoginBtn = await page.locator('button:has-text("登录")').first().isVisible().catch(() => false);
    if (!hasLoginBtn) {
      console.log('[白梦] 已登录');
      return { success: true };
    }

    console.log('[白梦] 请手动登录...');
    await bm.sleep(30000);

    return { success: true };
  },

  async checkLogin() {
    const bm = BrowserManager.getInstance();
    const { page } = await bm.getPage();
    
    await page.goto('https://baimengxiezuo.com', { waitUntil: 'networkidle' });
    await bm.sleep(2000);
    
    const hasLoginBtn = await page.locator('button:has-text("登录")').first().isVisible().catch(() => false);
    return { isLoggedIn: !hasLoginBtn, message: !hasLoginBtn ? '已登录' : '未登录' };
  },

  async getWorks() {
    const bm = BrowserManager.getInstance();
    const { page } = await bm.getPage();

    console.log('[白梦] 访问作品页面...');
    await page.goto(config.BAIMENG.LIBRARY_URL, { waitUntil: 'networkidle' });
    await bm.sleep(2000);

    console.log('[白梦] 提取作品列表...');
    
    const works = await page.evaluate(() => {
      const results = [];
      document.querySelectorAll('a[href*="/editor/?id="]').forEach(link => {
        const titleEl = link.querySelector('h3');
        const title = titleEl?.innerText?.trim();
        const href = link.getAttribute('href');
        if (title && href && title.length > 0 && title.length < 100 && !title.includes('创建') && !title.includes('新建')) {
          results.push({ 
            title, 
            status: '', 
            editUrl: href
          });
        }
      });
      return results;
    });

    const uniqueWorks = [...new Map(works.map(w => [w.title, w])).values()];
    console.log(`[白梦] 获取到 ${uniqueWorks.length} 个作品`);
    uniqueWorks.forEach((w, i) => console.log(`  ${i + 1}. ${w.title}`));
    
    return { success: true, platform: 'baimeng', count: uniqueWorks.length, works: uniqueWorks };
  },

  /**
   * 更新标题 - 点击三个点 -> 编辑 -> 删除旧标题 -> 输入新标题 -> 点击更新
   */
  async updateTitle(oldTitle, newTitle) {
    const bm = BrowserManager.getInstance();
    const { page } = await bm.getPage();

    console.log('[白梦] 更新标题:', oldTitle, '→', newTitle);
    
    // 访问作品库
    console.log('[白梦] 访问作品库...');
    await page.goto('https://baimengxiezuo.com/zh-Hans/library/', { waitUntil: 'networkidle' });
    await bm.sleep(2000);
    
    // 找到包含目标标题的卡片
    console.log('[白梦] 查找目标作品...');
    const cards = await page.$$('div[class*="group"]');
    
    let targetCard = null;
    let bestScore = 0;
    
    for (const card of cards) {
      try {
        const titleEl = await card.$('h3');
        if (!titleEl) continue;
        
        const title = await titleEl.innerText();
        const score = similarity(oldTitle, title);
        
        if (score > bestScore && score > 0.3) {
          bestScore = score;
          targetCard = card;
        }
      } catch (e) {
        continue;
      }
    }
    
    if (!targetCard) {
      throw new Error(`未找到匹配的作品: ${oldTitle}`);
    }
    
    console.log('[白梦] 找到目标作品 (相似度:', Math.round(bestScore * 100), '%)');
    
    // 点击右上角三个点按钮
    console.log('[白梦] 点击右上角三个点...');
    const menuButton = await targetCard.$('button[aria-haspopup="menu"]');
    if (!menuButton) {
      throw new Error('未找到菜单按钮');
    }
    await menuButton.click();
    await bm.sleep(1500);
    
    // 点击编辑选项
    console.log('[白梦] 点击编辑...');
    const editItem = page.locator('[role="menuitem"]').filter({ hasText: '编辑' }).first();
    await editItem.click();
    await bm.sleep(2000);
    
    // 找到标题输入框
    console.log('[白梦] 修改标题...');
    const titleInput = page.locator('textarea#title');
    await titleInput.waitFor({ state: 'visible', timeout: 5000 });
    
    // 清空并输入新标题
    await titleInput.click();
    await titleInput.fill('');
    await bm.sleep(300);
    await titleInput.fill(newTitle);
    await bm.sleep(500);
    
    // 点击更新按钮
    console.log('[白梦] 点击更新...');
    const updateButton = page.locator('button').filter({ hasText: '更新' }).first();
    if (await updateButton.isVisible().catch(() => false)) {
      await updateButton.click();
      console.log('[白梦] 已点击更新按钮');
    } else {
      // 如果没有更新按钮，尝试按Enter
      console.log('[白梦] 未找到更新按钮，尝试Enter...');
      await titleInput.press('Enter');
    }
    
    await bm.sleep(2000);
    console.log('[白梦] 标题更新完成！');
    
    return { 
      success: true, 
      message: `标题已更新: ${oldTitle} → ${newTitle}`,
      oldTitle,
      newTitle
    };
  }
};

module.exports = baimengTask;
