#!/usr/bin/env node
/**
 * 小说标题同步工具
 * 
 * 用法:
 *   node src/main.js list        # 获取作品列表
 *   node src/main.js match       # 匹配作品
 *   node src/main.js sync        # 同步预览
 *   node src/main.js sync --apply # 实际执行同步
 *   node src/main.js login       # 登录
 *   node src/main.js check       # 检查状态
 */

const BrowserManager = require('./utils/browser-manager');
const fanqieTask = require('./tasks/fanqie');
const baimengTask = require('./tasks/baimeng');
const { match, sync } = require('./utils/sync');

const bm = BrowserManager.getInstance();

const tasks = {
  async login(platform = 'all') {
    console.log('\n=== 登录 ===\n');
    
    if (platform === 'all' || platform === 'fanqie') {
      console.log('>>> 番茄小说');
      await fanqieTask.login();
    }
    
    if (platform === 'all' || platform === 'baimeng') {
      console.log('>>> 白梦写作');
      await baimengTask.login();
    }
    
    return { success: true };
  },

  async check() {
    console.log('\n=== 检查状态 ===\n');
    
    const fanqie = await fanqieTask.checkLogin();
    const baimeng = await baimengTask.checkLogin();
    
    console.log(`番茄小说: ${fanqie.message}`);
    console.log(`白梦写作: ${baimeng.message}`);
    
    return {
      fanqie,
      baimeng,
      allLoggedIn: fanqie.isLoggedIn && baimeng.isLoggedIn
    };
  },

  async list() {
    console.log('\n=== 获取作品列表 ===\n');
    
    const fanqie = await fanqieTask.getWorks();
    const baimeng = await baimengTask.getWorks();
    
    console.log(`\n番茄: ${fanqie.count} 个`);
    console.log(`白梦: ${baimeng.count} 个`);
    
    return { success: true, fanqie, baimeng };
  },

  async match() {
    console.log('\n=== 匹配作品 ===\n');
    
    const fanqie = await fanqieTask.getWorks();
    const baimeng = await baimengTask.getWorks();
    
    const result = match(fanqie, baimeng, 0.6);
    
    console.log(result.text);
    
    return result;
  },

  async sync(apply = false) {
    console.log('\n=== 同步标题 ===\n');
    
    const fanqie = await fanqieTask.getWorks();
    const baimeng = await baimengTask.getWorks();
    
    const result = await sync(fanqie, baimeng, baimengTask, 0.6, !apply);
    
    return result;
  }
};

async function main() {
  const cmd = process.argv[2] || 'help';
  const arg = process.argv[3];

  try {
    let result;
    
    switch (cmd) {
      case 'login':
        result = await tasks.login(arg);
        await bm.autoBackupCookies();
        break;
      case 'check':
        result = await tasks.check();
        break;
      case 'list':
        result = await tasks.list();
        await bm.autoBackupCookies();
        break;
      case 'match':
        result = await tasks.match();
        break;
      case 'sync':
        result = await tasks.sync(arg === '--apply');
        break;
      default:
        console.log(`
用法: node src/main.js <command>

命令:
  login [platform]  登录 (fanqie/baimeng/all)
  check             检查登录状态
  list              获取作品列表
  match             匹配作品（查看匹配结果）
  sync              同步预览（不实际修改）
  sync --apply      实际执行同步（以番茄为准更新白梦）
        `);
        return;
    }
    
    if (cmd !== 'match' && cmd !== 'sync') {
      console.log('\n结果:', JSON.stringify(result, null, 2));
    }
    
  } catch (e) {
    console.error('\n错误:', e.message);
  }
}

main();
