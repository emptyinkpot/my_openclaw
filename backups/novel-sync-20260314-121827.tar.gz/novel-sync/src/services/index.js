/**
 * 服务层 - 统一入口
 * 
 * 所有功能的统一访问点
 * 支持本地调用、机器人调用、API调用
 * 
 * @module services
 */

const { authService, registerPlatform } = require('./auth-service');

// 注册平台适配器
registerPlatform('fanqie', require('../platforms/fanqie/adapter'));
registerPlatform('baimeng', require('../platforms/baimeng/adapter'));

// 导出服务
module.exports = {
  authService,
  registerPlatform,
};
