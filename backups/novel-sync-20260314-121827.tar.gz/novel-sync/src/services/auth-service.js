/**
 * 服务层 - 认证服务
 * 
 * 统一的认证入口，支持多种调用方式：
 * - 本地 CLI 调用
 * - 机器人远程调用
 * - API 调用
 * 
 * 重要：浏览器会保持运行，不会被关闭
 * 
 * @module services/auth-service
 */

const { AccountStorage, Errors, withRetry, logger } = require('../core');
const globalBrowser = require('../core/global-browser');

const log = logger.create('auth-service');

// ============================================================
// 平台注册表
// ============================================================

const platforms = new Map();

function registerPlatform(name, adapter) {
  platforms.set(name, adapter);
  log.info(`注册平台: ${name}`);
}

function getPlatform(name) {
  const adapter = platforms.get(name);
  if (!adapter) {
    throw Errors.operationFailed(`未注册的平台: ${name}`);
  }
  return adapter;
}

// ============================================================
// 认证服务
// ============================================================

class AuthService {
  /**
   * 列出账号
   */
  listAccounts(platform) {
    const storage = new AccountStorage(platform);
    return storage.listAccounts();
  }
  
  /**
   * 检查账号状态
   */
  checkAccount(platform, userName) {
    const storage = new AccountStorage(platform);
    const data = storage.loadAccount(userName);
    
    if (!data) {
      return { exists: false, valid: false, message: '账号不存在' };
    }
    
    const valid = !!data.cookies?.length && 
      (!data.expiresAt || new Date(data.expiresAt) > new Date());
    
    return {
      exists: true,
      valid,
      userName: data.userName,
      expiresAt: data.expiresAt,
      message: valid ? '有效' : '已过期',
    };
  }
  
  /**
   * 登录（恢复会话）
   * 
   * 重要：不会关闭浏览器，保持运行
   * 
   * @param {Object} options
   * @param {string} options.platform - 平台名称
   * @param {string} options.userName - 用户名
   * @param {string} options.targetUrl - 目标页面（可选）
   * @param {Page} options.page - 已有的 page 对象（可选，机器人调用必传）
   * @param {boolean} options.keepBrowser - 是否保持浏览器（默认 true）
   * @returns {Promise<{success: boolean, userName: string, page: Page}>}
   */
  async login(options) {
    const { 
      platform, 
      userName, 
      targetUrl, 
      page: existingPage,
      keepBrowser = true,  // 默认保持浏览器运行
    } = options;
    
    log.info(`登录请求: ${platform}/${userName}`);
    
    // 获取平台适配器
    const adapter = getPlatform(platform);
    const storage = new AccountStorage(platform);
    
    // 加载账号数据
    const accountData = storage.loadAccount(userName);
    if (!accountData) {
      throw Errors.accountNotFound(userName);
    }
    
    if (!accountData.cookies?.length) {
      throw Errors.sessionExpired('账号数据无效');
    }
    
    let page, browser;
    
    // 如果传入了 page，直接使用（机器人调用）
    if (existingPage) {
      page = existingPage;
      log.info('使用传入的 page 对象');
    } else {
      // 获取或创建浏览器实例
      const result = await globalBrowser.getBrowser({
        key: `${platform}-${userName}`,
      });
      browser = result.browser;
      page = result.page;
      
      if (!result.isNew) {
        log.info('复用现有浏览器');
        
        // 检查是否已在目标页面
        const currentUrl = page.url();
        if (adapter.isOnPlatform(currentUrl)) {
          log.info('已在平台页面，无需重新登录');
          
          const { isLoggedIn, userName: detectedName } = await adapter.checkLogin(page);
          return {
            success: isLoggedIn,
            userName: detectedName || userName,
            page,
            reused: true,
          };
        }
      }
    }
    
    // 恢复登录状态
    await withRetry(async () => {
      // 恢复 cookies
      await page.context().addCookies(accountData.cookies);
      
      // 跳转
      const url = targetUrl || adapter.homeUrl;
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
      
      // 恢复 localStorage
      if (accountData.localStorage && Object.keys(accountData.localStorage).length > 0) {
        await page.evaluate((items) => {
          for (const [k, v] of Object.entries(items)) {
            try { localStorage.setItem(k, v); } catch (e) {}
          }
        }, accountData.localStorage);
        
        // 刷新使 localStorage 生效
        await page.reload({ waitUntil: 'domcontentloaded' });
      }
    }, { maxRetries: 2 });
    
    // 验证登录状态
    await page.waitForTimeout(1500);
    const { isLoggedIn, userName: detectedName } = await adapter.checkLogin(page);
    
    if (!isLoggedIn) {
      throw Errors.authFailed('登录验证失败，可能需要重新登录');
    }
    
    log.success(`登录成功: ${detectedName || userName}`);
    
    return {
      success: true,
      userName: detectedName || userName,
      page,
      browser,
      // 不再返回 shouldCleanup，因为我们不关闭浏览器
    };
  }
  
  /**
   * 保存账号
   */
  async saveAccount(options) {
    const { platform, page, userName } = options;
    
    const adapter = getPlatform(platform);
    const storage = new AccountStorage(platform);
    
    const { isLoggedIn, userName: detectedName } = await adapter.checkLogin(page);
    
    if (!isLoggedIn) {
      throw Errors.authFailed('未登录，无法保存');
    }
    
    const finalUserName = userName || detectedName || '未知用户';
    
    const cookies = await page.context().cookies();
    const localStorage = await page.evaluate(() => {
      const items = {};
      for (let i = 0; i < window.localStorage.length; i++) {
        const key = window.localStorage.key(i);
        items[key] = window.localStorage.getItem(key);
      }
      return items;
    });
    
    const expiresAt = this._calculateExpires(cookies);
    
    const result = await storage.saveAccount(finalUserName, {
      cookies,
      localStorage,
      expiresAt,
      meta: {
        url: page.url(),
        savedAt: new Date().toISOString(),
      },
    });
    
    log.success(`保存账号: ${finalUserName}`);
    
    return {
      success: true,
      userName: finalUserName,
      fileName: result.fileName,
    };
  }
  
  /**
   * 等待登录
   */
  async waitForLogin(options) {
    const { platform, page, timeout = 120000 } = options;
    
    const adapter = getPlatform(platform);
    
    log.info('等待用户登录...');
    
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeout) {
      const { isLoggedIn, userName } = await adapter.checkLogin(page);
      
      if (isLoggedIn) {
        log.success(`登录成功: ${userName}`);
        return { success: true, userName };
      }
      
      await page.waitForTimeout(2000);
    }
    
    return { success: false, userName: null };
  }
  
  _calculateExpires(cookies) {
    const now = Date.now();
    const minValid = now + 7 * 86400000;
    
    const validExpires = cookies
      .map(c => c.expires * 1000)
      .filter(t => t > minValid);
    
    if (!validExpires.length) {
      const date = new Date();
      date.setFullYear(date.getFullYear() + 1);
      return date.toISOString();
    }
    
    return new Date(Math.min(...validExpires)).toISOString();
  }
}

const authService = new AuthService();

module.exports = {
  registerPlatform,
  getPlatform,
  AuthService,
  authService,
};
