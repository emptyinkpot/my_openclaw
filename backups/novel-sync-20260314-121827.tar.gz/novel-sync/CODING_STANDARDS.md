<!--
文档元数据
- 文件名: CODING_STANDARDS.md
- 用途: 定义编码规范和约束，作为代码质量标准
- 触发更新: 规范变更（编码规范变更时必须更新）
- 检查方式: node scripts/check-compliance.js
- 最后更新: 2024-01-15
- 更新者: AI
- 关联文件: 所有文件
- 优先级: 🔴 高（必须维护）
-->

# 编码规范（强制执行）

> **📌 快速参考**: `docs/规范快速参考.md`
> 
> **⚠️ 强制维护**：规范变更后必须更新本文档

---

## 🔴🔴🔴 强制入口（每次任务必须执行）🔴🔴🔴

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   每次任务开始，必须按顺序执行以下步骤，不可跳过：               │
│                                                                 │
│   Step 1: write_todos 创建任务列表                              │
│            第一项固定为：「读取规范文件」                        │
│                                                                 │
│   Step 2: read_file KNOWLEDGE_INDEX.md（知识库索引-唯一入口）   │
│            ↓ 根据索引找到相关文档                               │
│                                                                 │
│   Step 3: 按场景搜索知识库                                      │
│            - 遇到问题 → grep "关键词" DEBUG_LOG.md               │
│            - 复用代码 → grep "关键词" docs/已验证代码库.md       │
│            - 找按钮   → grep "关键词" docs/白梦操作手册.md       │
│                                                                 │
│   Step 4: 标记「读取规范文件」为 completed                      │
│                                                                 │
│   Step 5: 所有代码必须使用 runTask() 作为入口                   │
│            const { runTask } = require('./src/utils/task-runner'); │
│                                                                 │
│   Step 6: 写完后运行检查                                        │
│            node scripts/check-compliance.js                     │
│                                                                 │
│   Step 7: 完成后更新知识库                                      │
│            - 解决问题 → DEBUG_LOG.md                            │
│            - 新代码   → docs/已验证代码库.md                    │
│            - 新按钮   → docs/白梦操作手册.md                    │
│            - 更新索引 → KNOWLEDGE_INDEX.md 最近更新             │
│                                                                 │
│   ❌ 不执行以上步骤 = 违规                                      │
│   ❌ 不查知识库直接写 = 违规                                    │
│   ❌ 完成不更新知识库 = 违规                                    │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 知识库快速查找表

| 场景 | 查找命令 | 文档 |
|------|----------|------|
| 遇到问题 | `grep "关键词" DEBUG_LOG.md` | 历史问题解决方案 |
| 复用代码 | `grep "关键词" docs/已验证代码库.md` | 已验证代码 |
| 找按钮 | `grep "关键词" docs/白梦操作手册.md` | 操作手册 |
| 找选择器 | `grep "关键词" docs/元素选择器字典.md` | 选择器字典 |
| 用户教导 | `grep "关键词" docs/用户教导记录.md` | 教导记录 |
| 方法论 | `grep "关键词" docs/通用经验.md` | 通用经验 |

---

## 核心原则

```
1. 模块化 - 按平台和功能拆分
2. 低耦合 - 模块间独立，通过接口通信
3. 可复用 - 通用逻辑抽取到工具层
4. 先查后写 - 查知识库 → 复用代码 → 最小改动
```

---

## 代码模板（必须使用）

```javascript
/**
 * 任务说明
 * 代码来源：src/platforms/baimeng/*.js 已验证模块
 */

const { runTask } = require('./src/utils/task-runner');

runTask('任务名称', async (ctx) => {
  // 1. 导入已验证模块
  const baimeng = require('./src/platforms/baimeng');
  const config = require('./src/config');
  
  // 2. 启动浏览器（来源：browser.js）
  const { browser, page } = await baimeng.browser.launch();
  
  // 3. 恢复登录（来源：auth.js）
  await baimeng.auth.restoreLogin(page);
  
  // 4. 业务逻辑...
  
  // 5. 保持浏览器打开
  await new Promise(() => {});
});
```

---

## 强制执行流程

### 写代码前（必须）

```
□ 1. write_todos 创建任务列表
□ 2. 读取 CODING_STANDARDS.md（本文档）
□ 3. 读取 DEBUG_LOG.md（历史问题）
□ 4. 读取 docs/已验证代码库.md（可复用代码）
□ 5. 确认模块归属（平台/功能）
```

### 写代码时（必须）

```
□ 1. 使用 runTask() 作为入口
□ 2. 从已验证模块导入，不重写
□ 3. 只添加新功能，不修改已有逻辑
□ 4. 添加注释说明来源
```

### 写代码后（必须）

```
□ 1. 运行 node scripts/check-compliance.js
□ 2. 修复所有违规
□ 3. 更新 docs/已验证代码库.md
□ 4. 更新 DEBUG_LOG.md（如有问题）
```

---

## 已验证模块

| 模块 | 路径 | 用途 |
|------|------|------|
| browser | `src/platforms/baimeng/browser.js` | 浏览器启动 |
| auth | `src/platforms/baimeng/auth.js` | 登录恢复 |
| works | `src/platforms/baimeng/works.js` | 作品列表 |
| sidebar | `src/platforms/baimeng/sidebar.js` | 侧边栏操作 |
| content | `src/platforms/baimeng/content.js` | 内容获取 |
| copy | `src/platforms/baimeng/copy.js` | 复制功能 |
| task-runner | `src/utils/task-runner.js` | 任务入口 |

**导入方式**：
```javascript
const baimeng = require('./src/platforms/baimeng');
// 然后使用 baimeng.browser, baimeng.auth 等
```

---

## 已验证选择器

| 选择器 | 用途 | 验证状态 |
|--------|------|----------|
| `.sidebar` | 侧边栏 | ✅ |
| `[class*="cursor-pointer"]` | 可点击项 | ✅ |
| `a[href*="editor"]` | 作品链接 | ✅ |
| `.ProseMirror, .Daydream` | 编辑器内容 | ✅ |

**禁止随意修改选择器！**

---

## 等待时间规范

| 操作 | 时间 | 来源 |
|------|------|------|
| 页面导航 | 2000-3000ms | 已验证 |
| 编辑器加载 | 5000-8000ms | 已验证 |
| 点击响应 | 300-500ms | 已验证 |
| 滚动间隔 | 80-100ms | 已验证 |
| 登录刷新后 | 3000ms | 已验证 |

**禁止随意修改等待时间！**

---

## 禁止事项

```javascript
// ❌ 禁止：使用 localStorage.clear()
localStorage.clear();  // 会导致白屏！

// ❌ 禁止：直接使用 playwright
const { chromium } = require('playwright');  // 应使用 browser 模块

// ❌ 禁止：不使用 runTask 入口
(async () => { ... })();  // 不合规！

// ❌ 禁止：URL 拼写错误
'baimoxiezuo.com'  // 错误！
'baimengxiezuo.com'  // 正确

// ❌ 禁止：硬编码新脚本
// 应复用已验证模块
```

---

## 检查命令

```bash
# 检查规范合规性
node scripts/check-compliance.js

# 显示修复建议
node scripts/check-compliance.js --fix

# JSON 输出
node scripts/check-compliance.js --json
```

---

## 相关文档

- `docs/规范快速参考.md` - 快速查阅
- `docs/已验证代码库.md` - 可复用代码
- `DEBUG_LOG.md` - 历史问题
- `docs/用户教导记录.md` - 用户教导
