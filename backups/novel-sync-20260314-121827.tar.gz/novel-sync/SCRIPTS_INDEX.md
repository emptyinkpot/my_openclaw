# 脚本索引

> 一级脚本可直接运行，二级模块被一级脚本调用

---

## 一级脚本（用户可直接运行）

### 白梦写作平台 (`tasks/baimeng/`)

| 脚本 | 功能 | 命令示例 |
|------|------|----------|
| `polish-and-replace.js` | **核心**：润色并替换章节 | `node tasks/baimeng/polish-and-replace.js "作品名" 66` |
| `baimeng-chapter-finder.js` | **核心**：查找并打开章节 | `node tasks/baimeng/baimeng-chapter-finder.js "作品名" 66` |
| `test-smart-format.js` | 测试智能排版 | `node tasks/baimeng/test-smart-format.js "作品名" 66` |
| `polish-chapter.js` | 润色章节（不替换） | `node tasks/baimeng/polish-chapter.js "作品名" 66` |
| `replace-content.js` | 替换章节内容 | `node tasks/baimeng/replace-content.js "作品名" 66` |
| `open-chapter.js` | 打开指定章节 | `node tasks/baimeng/open-chapter.js "作品名" 66` |

**推荐工作流**：
```bash
# 一站式润色替换
node tasks/baimeng/polish-and-replace.js "作品名" 66

# 分步操作
node tasks/baimeng/baimeng-chapter-finder.js "作品名" 66  # 打开章节
node tasks/baimeng/polish-chapter.js "作品名" 66          # 润色
node tasks/baimeng/replace-content.js "作品名" 66         # 替换
```

### Coze 扣子编程 (`tasks/coze/`)

| 脚本 | 功能 | 命令示例 |
|------|------|----------|
| `polish-flow.js` | **核心**：文本润色流程 | `node tasks/coze/polish-flow.js --work "作品名" --chapter 66` |
| `coze-project-manage-v2.js` | 项目管理 | `node tasks/coze/coze-project-manage-v2.js` |
| `open-coze-code.js` | 打开扣子编程 | `node tasks/coze/open-coze-code.js` |
| `save-coze-login.js` | 保存认证状态 | `node tasks/coze/save-coze-login.js` |

### 工具脚本 (`scripts/`)

| 脚本 | 功能 | 命令 |
|------|------|------|
| `check-compliance.js` | 检查代码规范 | `node scripts/check-compliance.js` |
| `update-knowledge.js` | 同步知识库 | `node scripts/update-knowledge.js --sync` |
| `backup.js` | 执行备份 | `node scripts/backup.js` |
| `restore.js` | 恢复备份 | `node scripts/restore.js <版本>` |

---

## 二级模块（被调用）

### 平台模块 (`src/platforms/`)

#### 白梦写作 (`src/platforms/baimeng/`)

| 模块 | 核心函数 | 功能 |
|------|----------|------|
| `index.js` | 整合导出 | 统一入口 |
| `browser.js` | `launch()`, `close()` | 浏览器管理 |
| `auth.js` | `restoreLogin()`, `checkLogin()` | 登录管理 |
| `works.js` | `getWorks()`, `findWorkId()` | 作品管理 |
| `sidebar.js` | `findChapter()`, `getChapterList()` | 章节导航 |
| `editor.js` | `getTitle()`, `setTitle()`, `getContent()`, `setContent()`, `save()` | 编辑器操作 |
| `content.js` | `copyChapter()`, `scrollToBottom()` | 内容操作 |
| `chapter-nav.js` | `openChapter()`, `parseChapterNum()` | 章节导航 |

#### Coze 平台 (`src/platforms/coze/`)

| 模块 | 核心函数 | 功能 |
|------|----------|------|
| `index.js` | `CozePlatform` 类 | 统一平台管理 |
| `polish.js` | `polishFlow()`, `extractResult()` | 文本润色 |
| `polish-executor.js` | `executePolish()`, `verifyPolishResult()` | 润色执行 |

### 工具模块 (`src/utils/`)

| 模块 | 核心函数 | 功能 |
|------|----------|------|
| `task-runner.js` | `runTask()` | **强制入口** |
| `debugger.js` | `quickDiagnose()`, `savePolishCache()` | **调试工具** |
| `args-parser.js` | `parseArgs()`, `parseChapterNum()` | 参数解析 |
| `file-utils.js` | `safeWrite()`, `safeRead()` | 文件操作 |
| `safe-action.js` | `safeClick()`, `safeInput()` | 安全操作 |
| `backup-manager.js` | `createBackup()`, `restoreBackup()` | 备份管理 |
| `workflow.js` | `openChapterWorkflow()`, `polishChapterWorkflow()` | 工作流 |
| `screenshot.js` | `takeScreenshot()`, `takeErrorScreenshot()` | 截图 |
| `storage.js` | `localStorage`, `cookie` | 存储操作 |
| `result-checker.js` | `verifyLength()`, `detectAnomalies()` | 结果验证 |
| `progress-detector.js` | `waitForPolishProgress()` | 进度检测 |

### 全局共享 (`lib/`)

| 模块 | 核心函数 | 功能 |
|------|----------|------|
| `utils/clipboard.js` | `read()`, `write()` | 跨脚本数据传递 |

---

## 快速查找

### 按场景查找

| 场景 | 使用脚本 |
|------|----------|
| 润色章节 | `tasks/baimeng/polish-and-replace.js` |
| 打开章节 | `tasks/baimeng/baimeng-chapter-finder.js` |
| 替换内容 | `tasks/baimeng/replace-content.js` |
| 备份数据 | `scripts/backup.js` |
| 检查规范 | `scripts/check-compliance.js` |

### 按模块查找

| 需求 | 使用模块 |
|------|----------|
| 浏览器操作 | `src/platforms/*/browser.js` |
| 登录管理 | `src/platforms/*/auth.js` |
| 编辑器操作 | `src/platforms/baimeng/editor.js` |
| 润色功能 | `src/platforms/coze/polish.js` |
| 文件操作 | `src/utils/file-utils.js` |
| 安全操作 | `src/utils/safe-action.js` |

---

## 配置文件

| 文件 | 用途 |
|------|------|
| `src/config.js` | 主配置 |
| `backup.config.js` | 备份配置 |
| `CODING_STANDARDS.md` | 编码规范 |
