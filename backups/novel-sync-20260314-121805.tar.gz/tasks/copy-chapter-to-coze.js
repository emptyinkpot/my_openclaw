/**
 * 复制白梦章节内容并发送到 Coze 文本润色网站
 * 
 * 用法: node copy-chapter-to-coze.js
 */

const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

// 配置
const BROWSER_DIR = '/workspace/projects/browser/default';
const BAIMENG_BACKUP = '/workspace/projects/cookies-accounts/baimeng-account-1-full.json';
const COZE_BACKUP = '/workspace/projects/cookies-accounts/coze-account-1-full.json';

// 作品信息
const WORK_TITLE = '变身咳血少女的我也要努力活下去';
const WORK_ID = 'c4cea052-67e8-447c-8e29-8c0c93c3cbec';
const CHAPTER = '第六十四章';

// Coze 项目管理 URL
const COZE_PROJECT_URL = 'https://code.coze.cn/w/7587425486419378228/projects';

// 临时文件
const CHAPTER_FILE = '/tmp/baimeng-chapter-content.txt';

async function main() {
  console.log('📚 复制章节并发送到 Coze\n');
  console.log(`作品: ${WORK_TITLE}`);
  console.log(`章节: ${CHAPTER}\n`);

  // ========== Step 1: 清理锁文件 ==========
  console.log('Step 1: 清理浏览器锁文件...');
  ['SingletonLock', 'SingletonSocket', 'SingletonCookie'].forEach(f => {
    const p = path.join(BROWSER_DIR, f);
    if (fs.existsSync(p)) fs.unlinkSync(p);
  });
  console.log('  ✓ 锁文件已清理');

  // ========== Step 2: 启动浏览器 ==========
  console.log('\nStep 2: 启动浏览器...');
  const browser = await chromium.launchPersistentContext(BROWSER_DIR, {
    headless: false,
    viewport: null,
    args: ['--no-sandbox', '--start-maximized']
  });
  const page = browser.pages()[0] || await browser.newPage();
  console.log('  ✓ 浏览器已启动');

  // ========== Step 3: 恢复白梦登录 ==========
  console.log('\nStep 3: 恢复白梦登录...');
  if (fs.existsSync(BAIMENG_BACKUP)) {
    const backup = JSON.parse(fs.readFileSync(BAIMENG_BACKUP, 'utf-8'));
    
    // 访问白梦首页
    await page.goto('https://baimengxiezuo.com', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1500);
    
    // 设置 localStorage
    if (backup.localStorage) {
      await page.evaluate(items => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, backup.localStorage);
    }
    
    // 设置 cookies
    if (backup.cookies) {
      await browser.addCookies(backup.cookies);
    }
    
    // 刷新页面
    await page.reload();
    await page.waitForTimeout(2000);
    console.log('  ✓ 白梦登录已恢复');
  }

  // ========== Step 4: 打开作品编辑页 ==========
  console.log('\nStep 4: 打开作品编辑页...');
  const editorUrl = `https://baimengxiezuo.com/zh-Hans/editor/?id=${WORK_ID}`;
  await page.goto(editorUrl, { waitUntil: 'networkidle' });
  await page.waitForTimeout(3000);
  console.log(`  ✓ 已打开: ${WORK_TITLE}`);

  // ========== Step 5: 滚动侧边栏查找章节 ==========
  console.log('\nStep 5: 查找章节...');
  
  // 点击侧边栏获取焦点
  const sidebar = await page.$('[class*="sidebar"]');
  if (sidebar) {
    const box = await sidebar.boundingBox();
    await page.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
    await page.waitForTimeout(300);
  }

  // 滚动查找章节
  let found = false;
  for (let i = 0; i < 60; i++) {
    found = await page.evaluate((chapter) => {
      const items = document.querySelectorAll('[class*="cursor-pointer"]');
      for (const item of items) {
        // 排除文件夹
        const hasArrow = item.querySelector('[class*="chevron"], [class*="arrow"], svg');
        if (hasArrow) continue;
        
        const text = item.innerText || '';
        if (text.includes(chapter)) {
          item.click();
          return true;
        }
      }
      return false;
    }, CHAPTER);
    
    if (found) {
      console.log(`  ✓ 找到并点击: ${CHAPTER}`);
      break;
    }
    
    await page.mouse.wheel(0, 80);
    await page.waitForTimeout(80);
  }

  if (!found) {
    console.log('  ❌ 未找到章节');
    return;
  }

  await page.waitForTimeout(2000);

  // ========== Step 6: 复制章节内容 ==========
  console.log('\nStep 6: 复制章节内容...');
  
  // 点击复制按钮
  const copied = await page.evaluate(() => {
    // 查找复制按钮
    const buttons = document.querySelectorAll('button');
    for (const btn of buttons) {
      if (btn.innerText.trim() === '复制') {
        btn.click();
        return true;
      }
    }
    return false;
  });

  if (copied) {
    console.log('  ✓ 已点击复制按钮');
  } else {
    // 尝试从编辑器获取内容
    console.log('  尝试从编辑器获取内容...');
    const content = await page.evaluate(() => {
      const editor = document.querySelector('.ProseMirror') || 
                     document.querySelector('[contenteditable="true"]');
      return editor?.innerText || '';
    });
    
    if (content) {
      // 保存到文件
      fs.writeFileSync(CHAPTER_FILE, content);
      console.log(`  ✓ 内容已保存: ${CHAPTER_FILE} (${content.length} 字)`);
    }
  }

  await page.waitForTimeout(1000);

  // ========== Step 7: 恢复 Coze 登录 ==========
  console.log('\nStep 7: 恢复 Coze 登录...');
  if (fs.existsSync(COZE_BACKUP)) {
    const cozeBackup = JSON.parse(fs.readFileSync(COZE_BACKUP, 'utf-8'));
    
    // 访问 Coze 主站
    await page.goto('https://www.coze.cn', { waitUntil: 'domcontentloaded' });
    await page.waitForTimeout(1500);
    
    if (cozeBackup.localStorage) {
      await page.evaluate(items => {
        for (const [k, v] of Object.entries(items)) {
          try { localStorage.setItem(k, v); } catch (e) {}
        }
      }, cozeBackup.localStorage);
    }
    
    if (cozeBackup.cookies) {
      await browser.addCookies(cozeBackup.cookies);
    }
    
    console.log('  ✓ Coze 登录已恢复');
  }

  // ========== Step 8: 进入项目管理 ==========
  console.log('\nStep 8: 进入 Coze 项目管理...');
  await page.goto(COZE_PROJECT_URL, { waitUntil: 'networkidle' });
  await page.waitForTimeout(2000);
  console.log('  ✓ 已进入项目管理');

  // ========== Step 9: 点击"文本润色网站" ==========
  console.log('\nStep 9: 打开"文本润色网站"...');
  const projectClicked = await page.evaluate(() => {
    const elements = document.querySelectorAll('*');
    for (const el of elements) {
      const text = el.innerText?.trim();
      if (text === '文本润色网站' || (text?.startsWith('文本润色网站') && text.length < 30)) {
        el.click();
        return true;
      }
    }
    return false;
  });

  if (projectClicked) {
    console.log('  ✓ 已点击: 文本润色网站');
  } else {
    console.log('  ❌ 未找到项目');
  }

  await page.waitForTimeout(2000);

  // 截图
  const screenshotPath = '/tmp/coze-text-polish.png';
  await page.screenshot({ path: screenshotPath });
  console.log(`\n  ✓ 截图: ${screenshotPath}`);

  console.log('\n✅ 完成！浏览器保持打开，请手动粘贴内容。');
  console.log(`\n提示: 内容可能已复制到剪贴板，或保存在 ${CHAPTER_FILE}`);
}

main().catch(e => {
  console.error('错误:', e.message);
  process.exit(1);
});
